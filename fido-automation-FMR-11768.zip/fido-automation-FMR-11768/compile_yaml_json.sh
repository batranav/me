if python ./python/yamljsonValidator.py -a red -s sample -f daily -e prod -path ./
then
    echo "success $PULL_REQUEST_TITLE submitted by $ACTOR"
else
    echo "fail $PULL_REQUEST_TITLE submitted by $ACTOR"
    exit 1
fi

if python ./python/yamljsonValidator.py -a rbi -s sample -f daily -e prod -path ./
then
    echo "success $PULL_REQUEST_TITLE submitted by $ACTOR"
else
    echo "fail $PULL_REQUEST_TITLE submitted by $ACTOR"
    exit 1
fi

if python ./python/yamljsonValidator.py -a scout -s sample -f daily -e prod -path ./
then
    echo "success $PULL_REQUEST_TITLE submitted by $ACTOR"
else
    echo "fail $PULL_REQUEST_TITLE submitted by $ACTOR"
    exit 1
fi