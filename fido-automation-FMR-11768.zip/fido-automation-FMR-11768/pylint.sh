if pylint -E python
then
    echo "success $PULL_REQUEST_TITLE submitted by $ACTOR"
else
    echo "fail $PULL_REQUEST_TITLE submitted by $ACTOR"
    exit 1
fi