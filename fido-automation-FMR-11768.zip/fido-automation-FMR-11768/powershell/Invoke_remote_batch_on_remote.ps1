if($args.Count -lt 4){ Throw "You must specify 4 arguements, Script to invoke,remote name,username,password" }
$scriptToInvoke=$args[0]
$remote_name=$args[1]
$username = $args[2]
$password = $args[3]
$secstr = New-Object -TypeName System.Security.SecureString
$password.ToCharArray() | ForEach-Object {$secstr.AppendChar($_)}
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $secstr
$pathFile="D:\red\data\applogs\invoke_logs\invoke_remote_batch_ps1.log"
$pathFileTimestamp = [System.IO.Path]::GetDirectoryName($pathFile) + "\" + `
        [System.IO.Path]::GetFileNameWithoutExtension($pathFile) + "_" + `
        (get-date -format yyyyMMdd_HHmmss) + ([System.IO.Path]::GetExtension($pathFile))

start-transcript $pathFileTimestamp
invoke-command -computername $remote_name -credential $Cred -ScriptBlock { cmd /c $Using:scriptToInvoke }
stop-transcript
