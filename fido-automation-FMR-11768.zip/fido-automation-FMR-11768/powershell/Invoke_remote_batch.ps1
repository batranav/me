if(!$args[0]) { Throw "You must supply a Script to call" }

$scriptToInvoke=$args[0]

# ***** HC Vault call *****
$application = "red"
$source = "alawpfidolz301"
$frequency = "daily"
$environment = "prod"
$get_uname_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_uname.py"
$get_pwd_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_pwd.py"
$username = python $get_uname_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
$password = python $get_pwd_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
# ***** HC Vault call *****

$secstr = New-Object -TypeName System.Security.SecureString
$password.ToCharArray() | ForEach-Object {$secstr.AppendChar($_)}

$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $secstr
invoke-command -computername "alawpfidolz301.risk.regn.net" -credential $Cred -ScriptBlock { cmd /c $Using:scriptToInvoke }
