Param(
    [Parameter(Mandatory=$True,Position=1)] [string] $tenantId,
    [Parameter(Mandatory=$True,Position=2)] [string] $datafactoryname,
    [Parameter(Mandatory=$True,Position=3)] [string] $resourcegroup,
    [Parameter(Mandatory=$True,Position=4)] [string] $pipelinename,
    [Parameter(Mandatory=$True,Position=5)] [string] $despraymodule,
    [Parameter(Mandatory=$True,Position=6)] [string] $application,
    [Parameter(Mandatory=$True,Position=7)] [string] $subscription,
    [Parameter(Mandatory=$True,Position=8)] [string] $env
  )

Function InvokeADFpipeline([string]$tenantId,
                           [string]$datafactoryname,[string]$resourcegroup,[string]$pipelinename,
                           [string]$despraymodule,[string]$application,[string]$subscription,[string]$env)

{
  $WarningPreference = 'SilentlyContinue'
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

  $application = "red"
  $source = $env
  $frequency = "daily"
  $environment = "prod"
  $get_uname_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_uname_azure.py"
  $get_pwd_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_pwd_azure.py"
  $vault_app_id = python $get_uname_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
  $vault_secret = python $get_pwd_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
  
  $SecureStringPwd = ConvertTo-SecureString $vault_secret -AsPlainText -Force

  $pscredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $vault_app_id, $SecureStringPwd
  Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId | Out-null

  Set-AzContext -SubscriptionName $subscription | Out-null

  

  $dfname = $datafactoryname
  $rgName = $resourcegroup
  $pipe = $pipelinename
  $parameters = @{
      "folder_name_despray_module" = $despraymodule
      "app_red_or_rbi" = $application
      "start_with_files_onprem" = "True"
      "compare_layout" = "False"
      "working_timestamp" = ""

  }

  $RunId = Invoke-AzDataFactoryV2Pipeline -DataFactoryName $dfname -ResourceGroupName $rgName -PipelineName $pipe -Parameter $parameters

  # Check the pipeline run status until it finishes the copy operation
  while ($True) {
    $run = Get-AzDataFactoryV2PipelineRun -ResourceGroupName $rgName -DataFactoryName $dfname -PipelineRunId $RunId

    if ($run) {
        if ( ($run.Status -ne "InProgress") -and ($run.Status -ne "Queued") ) {

            $result_status = $run.Status
            break
        }
    }

    Start-Sleep -Seconds 30
 }

  $result = Get-AzDataFactoryV2PipelineRun -ResourceGroupName $rgName -DataFactoryName $dfname -PipelineRunId $RunId

  if ($result.Status -eq "Succeeded") {
      $result.Output -join "rn"
  }
  else {
      $result.Error -join "rn"
  }
  
  $finaloutput = $RunId+"$"+$result_status
  $finaloutput = $finaloutput -replace "`t|`n|`r",""
  return $finaloutput
}

$result_status = InvokeADFpipeline $tenantId $datafactoryname $resourcegroup $pipelinename $despraymodule $application $subscription $env
$result_status