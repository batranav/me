import sendEmail
import platform
from datetime import datetime
import pyodbc
import time
import fnmatch 
import AutomationLogging
from vault.secrets import get_db_secret
import parseYamlProperty

def loadToDB(logger, result):
    logger.info('Start essbase monitor process::Inside loadToDB')
    logger = AutomationLogging.getLogger('Essbase Stats Load to DB')
    uname, pwd = get_db_secret(logger, 'ALAWDREDSQL201')
    today = datetime.today().strftime('%Y%m%d_%H%M%S')
    connection = pyodbc.connect(driver="{ODBC Driver 17 for SQL Server}",server="ALAWDREDSQL201,50255",database="red",UID=uname,PWD=pwd)
    ds2Cursor = connection.cursor()
    file_filter = ['*Member*', '*data*']
    for row in result:
        insertSql = "insert into [dbo].[essbase_stats] (timestamp,cube_name,status,error_type,log_filename,log_file_timestamp) VALUES (?,?,?,?,?,?)"
        if(fnmatch.fnmatch(str(row.logFileName), file_filter[0]) or fnmatch.fnmatch(str(row.logFileName), file_filter[1])):
            ds2Cursor.execute(insertSql, today, row.cube_name, row.status, row.errorType, str(row.logFileName), time.strftime("%Y%m%d_%H%M%S", row.file_date))
            ds2Cursor.commit()


def getHostName():
    return platform.node().upper()

def xstr(s):
    return "" if s is None else str(s)

def generateemailmsg(countDict, exportSearchList="", headerfields="", tablefields=""):
    cssdata = open(parseYamlProperty.getCSSPath(), "r").read()

    htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>""" + cssdata + "</style>"""

    len_Dict = len(countDict)
    lines = ""
    lines_ext = ""
    lines += """<table id="buildsuccess">
                        <tr>
                        <th>CUBE NAME</th>
                        <th>STATUS</th>
                        <th>ERROR TYPE</th>
                        <th>LOG FILE NAME</th>
                        </tr>"""

    for x in range(len_Dict):
        
        lines_ext += "<tr><td>" +  xstr(countDict[x].cube_name) + "</td>"
        lines_ext += "<td>" +  xstr(countDict[x].status) + "</td>"
        lines_ext += "<td>" +  xstr(countDict[x].errorType) + "</td>"
        lines_ext += "<td>" +  xstr(countDict[x].logFileName) + "</td></tr>"


    lines_combined = htmlHeader + lines + lines_ext + "</TABLE>"
    
    return lines_combined


def notifyEmail(logger, ssFiles, headerfieldsList="", tablefieldsList=""):
    logger.info('Start essbase monitor process::Inside notifyEmail')
    if len(ssFiles) == 0:
        return None

    successEmailFrom = "SUCESS-Fido.Essbase.automation@lexisnexisrisk.com"
    #PlatformPrefix = getHostName() + " :: " 
    subjectPrefix =  "Essbase Log Summary :: " 
    emailFrom = successEmailFrom
    emailTo = "fidofinance@lexisnexisrisk.com,fido.ops@lexisnexisrisk.com"
    #emailTo = "Aishwarya.Srivastava@lexisnexisrisk.com"
    subject = subjectPrefix + "Logs for " + datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    msg = generateemailmsg(ssFiles, headerfieldsList, tablefieldsList)
    sendEmail.send(emailFrom, emailTo, "aishwarya.srivastava@lexisnexisrisk.com", subject, msg)  



#if __name__ == '__main__':
#    notifyEmail(None)