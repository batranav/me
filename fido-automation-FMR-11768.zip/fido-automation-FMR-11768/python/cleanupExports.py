import os, sys, time
from subprocess import call
import os
import datetime
from send_email import *

now = time.time()
removeList = []

def cleanup(folder, numberOfDays):
    global removeList
    for dirpath, dirnames, filenames in os.walk(folder):
        for file in filenames:
            curpath = os.path.join(dirpath, file)
            file_modified = datetime.datetime.fromtimestamp(os.path.getmtime(curpath))
            if datetime.datetime.now() - file_modified > datetime.timedelta(days=numberOfDays):
                print('Removing .. {0} and it was created on {1}'.format(curpath, file_modified))
                removeList.append('Removing .. {0} and it was created on {1}'.format(curpath, file_modified))
                os.remove(curpath)

def sendMail() :
        
        EmailSubject = 'SCOUT folder clean up results' 
        emailFrom = 'fido-scout-automation@lexisnexisrisk.com'
        emailTo = ['raju.nagarajan@lexisnexisrisk.com, margaret.worob@lexisnexisrisk.com']

        send_mail(emailFrom,emailTo,'',EmailSubject,'' + '\n'.join(removeList))

def process(folder, numberOfDays):
    cleanup(folder, numberOfDays)
    sendMail()

if __name__ == "__main__":
    dir_to_search = "\\\\alawpsafil200\\ScoringData1c\\Scout"

    process(dir_to_search, 30)
    print('All Done!')