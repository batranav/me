import getSQLdata
import pyodbc
import AutomationLogging


if __name__ == "__main__":

    sources = ['loggingintodb','pct','peoplesoft','workday','rules','cru']
    # sources = ['pct']

    for i in range(len(sources)):
        try:
            logger = AutomationLogging.getLogger('preprocess_testDBConnections')
            (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, sources[i],'','')
            cnxn = pyodbc.connect(connstr,timeout=-10000)
            print('Connected to {0}\n{1}\n\n'.format(sources[i],connstr))
            # print(connstr)
        except pyodbc.Error as ex:
            sqlstate = ex.args[0]
            print('Could not connect to DB {0}\n{1}\n\n'.format(sources[i],connstr))