#from datetime import datetime
import time
import datetime
import binascii
import codecs
import io
import sys
import csv
import pyodbc
from sendEmail import *
import string
import parseYamlProperty
import getSQLdata
import os
import AutomationLogging

printList = []
cntmismtachList = []
today     = datetime.datetime.now()
yesterday = datetime.datetime.now() - datetime.timedelta(days=3)
today_ddmmyyyy = today.strftime("%d-%m-%Y")+' 00:00:00'
yesterday_ddmmyyyy = yesterday.strftime("%d-%m-%Y")+' 00:00:00'
#print(today_ddmmyyyy)
#print(yesterday_ddmmyyyy)

class GracefullyExit(Exception):
    pass
  
def printwrapper(str, errorFlag=False,addcolor=False):
    print(str)
    if addcolor:
        # strtemp = WARNING+str+ENDC
        strtemp = str
    else:
        strtemp = str
    if errorFlag:
        printList.reverse()
        printList.append(strtemp)
        printList.reverse()
    else:
        printList.append(strtemp)

def createlog(source):
    #print(len(printList))
    if len(printList) > 0:
        logfile = open('logs\\datapull\\' + source + '_' + today.strftime('%m-%d-%Y_%H_%M_%S'), 'w')
        for str in printList:
            logfile.write('%s\n' %str)
        logfile.close()

def attempt_strip(x):
    try:
        return x.strip()
    except AttributeError:
        return x

def checkNone(x):
    if x == 'None':
        #print('None condition')
        return ('')
    else:
        return(x)

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1       

def pull_files():
    flag = 1
    nbrofmismatchfiles = 0
    maxcntmismtachList = 0 
    try:
        source = 'PCT'
        flag = 1
        nbrofmismatchfiles = 0
        maxcntmismtachList = 0 
        printwrapper('Calling PCT DB extract process')
        #strttime = today.strftime('%Y%m%d%H%M%S')
        strttime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        logger = AutomationLogging.getLogger('preprocess_pct_pull')
        (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, source,'daily','')
        cnxn = pyodbc.connect(connstr,timeout=-10000)
        #  pyodbc.connect(connection_string, timeout=login_timeout, attrs_before={SQL_ATTR_CONNECTION_TIMEOUT : connection_timeout})            
        cnxn.timeout = 100
        cursor = cnxn.cursor()
        
        # cursor_cnt = cnxn.cursor()
        printwrapper('\nConnection to PCT DB extablished')
     
        tablesTopull = ['AlacarteLkup','calculationLkup','CarteFeatureLkup','CategoryProductLkup','CustomerAffiliate','customerrequest','LegalContact','FieldLkup','LegalProductLkup','MaintActionLkup','MaintFieldLkup','PCTCategorylkup','PriceAlaCarteLkup','PriceFieldLkup','PriceProductlkup','PriceTypeLkup','ProductFeatureLkup','ProductPriceLkup','ScopeAnswerLkup','ScopeLKup','TierLkup','ValidValueLkup','AddlUserInfo','AttachmentLkup','BookmarkLkup','BookmarkSubLkup','ContractLkup','FeatureTwinLkup','HolidayLkup','LegalProductCloneLkup','ListLkup','NumExceptions','PriceAttachLkup','PriceContractLkup','PriceExceptionFollowupLkup','PriceExceptionLkup','ProductApproverLkup','ProductTemplateLkup','RestartRev','RestartSF','ScopeFactorLkup','TotSolDisc','VolumeDisc','WaiteeLkup','Empl_table','slacount','slacountverify','Legal_Status','LegalRequest','MaintRequestField','MaintRequestMaint','PriceRequestBatch','PriceRequestField','PriceRequestPrice','PriceRequestScope','CustomComments','LegalDocument','PriceRequestPackage','PriceRequestVersionHistory','OCRequest','OCRequestField','Comments','legalRequestClone','LegalRequestPriority','PriceRequestAddOn','RPWRequest']
        # tablesTopull = ['PriceRequestScope']
        tablesTopull_1 = ['NumExceptions']
        
        #sqltoexecute = [sqltoexecute_hpcc_potential_match]
    
        for tbname in tablesTopull:   
            tablewords = tbname.split('|')
            tblname = tablewords[0]
            sqlquery_temp = 'select * from '+ tblname
            tbname2 = tblname
            printwrapper('\n****************************{0}*********************************'.format(tblname))
            printwrapper('\nTable being extracted : {0}'.format(tbname2))
            sqlcnttemp = 'select count(*) from '+tblname
            #printwrapper('\nSQL for table count : {0}'.format(sqlcnttemp))
            cursor.execute(sqlquery_temp)
            # cursor.execute(sqlcnttemp)
            f = open(os.path.join(parseYamlProperty.get_inbound_dir(),'pct\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt'), 'w', encoding='utf-8')
            printwrapper('\nFile location : {0}'.format(os.path.join(parseYamlProperty.get_inbound_dir(),'pct\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt')))
            field_names = str([i[0] for i in cursor.description])
            head = str.replace(str.replace(str.replace(str.replace(str.replace(field_names,'[',''),',','|'),']',''),'\'',''),' ','')
            f.write(head + '\n')
            printwrapper('\nFetching records from table : {0}'.format(tbname2))
            rowcnt = 0
            while 1:
                row = cursor.fetchone()
                rowcnt = rowcnt + 1
                if cursor.description == None:
                    iterator = range(0, 0).__iter__()
                else:
                    iterator = range(0, len(cursor.description)).__iter__()
                col = ''
                outStr = []
                result = ''
                if not row:
                    break
                for idx in iterator:
                    
                    col = checkNone(attempt_strip((str(row[idx]))))
                    if idx > 0:
                        outStr.append('|')
                        outStr.append(str.replace(str.replace(str(col),'\n',''),'|',''))
                        #outStr.append(str.replace(str(col),'|',''))
                    else:
                        outStr.append(str.replace(str.replace(str(col),'\n',''),'|',''))
                        #outStr.append(str.replace(str(col),'|',''))
                result = ''.join(outStr)
                f.write(result)
                f.write("\n")
            f.close()  
            count = rowcnt
            flength = count #file_len(os.path.join(parseYamlProperty.get_inbound_dir(),'pct\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt'))
            printwrapper('\nFile count of file {0} : {1} '.format(os.path.join(parseYamlProperty.get_inbound_dir(),'pct\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt'),flength-1))
            printwrapper('\nCount of records in DB for table {0} is : {1}'.format(tbname2,int(count)))
            if flength - count > 1:
                    cntmismtachList.append(1)
            else:
                    cntmismtachList.append(0)
            printwrapper('\nData extract completed for table : {0}'.format(tbname2))
        #endtime = today.strftime('%Y%m%d%H%M%S')
        endtime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        print(strttime)
        print(endtime)
        tdelta = int(endtime) - int(strttime)
        tdelta_min = tdelta/60
        printwrapper('\n*************************************************************')
        printwrapper('\nStart Time : {0}'.format(strttime))
        printwrapper('\nEnd Time : {0}'.format(endtime))
        printwrapper('\nTotal Duration in minutes : {0}'.format(tdelta_min))
        printwrapper('\nPCT Data extract completed...')
        nbrofmismatchfiles = sum(1 for i in cntmismtachList if i == 1)
        maxcntmismtachList = max(cntmismtachList)
    
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        printwrapper('\nException raised : {0}\n'.format(str(e)))
        flag = 0
    
    finally:
        printwrapper('\n**********\nAll Done!\n**********')
        #createlog(source)
        
        EmailSubject = 'data pull from PCT DB for ' + today.strftime('%Y%m%d')
        successEmailSubject = 'Success: ' + EmailSubject;
        systemErrorEmailSubject = 'ERROR / WARNING : ' + EmailSubject;
        cntmismatchErrorEmailSubject = 'ERROR / WARNING : Mismatch in counts for ' +str(nbrofmismatchfiles)+' file(s) in the ' + EmailSubject;
        emailFrom = 'raju.nagarajan@lexisnexis.com'
        emailTo = 'raja.sundarrajan@lexisnexis.com,vijay.maddipatla@lexisnexis.com' 
                     
        if flag == 1 and maxcntmismtachList == 0:
            send(emailFrom,emailTo,'',successEmailSubject,'' + '\n'.join(printList))
        elif flag == 1 and maxcntmismtachList == 1:
            send(emailFrom,emailTo,'',cntmismatchErrorEmailSubject, '' + '\n'.join(printList))
        else:
            send(emailFrom,emailTo,'',systemErrorEmailSubject, '' + '\n'.join(printList))

if __name__ == '__main__':
    pull_files()
    print('AlacarteLkup'.split('|')[0])