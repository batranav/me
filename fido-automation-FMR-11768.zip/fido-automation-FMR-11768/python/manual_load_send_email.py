import smtplib, os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.utils import COMMASPACE, formatdate
from email import encoders
import mimetypes
import pymsteams
from send_email import *

def send_mail_with_attachment(send_from, send_to, send_cc, subject, text, attachments=[]):
    server="appmail.risk.regn.net"
    if send_cc == '':
       send_cc = []
    print(f"Sending email from {send_from} to {','.join(send_to)}")
    assert type(send_to)==list
    assert type(send_cc)==list

    msg = MIMEMultipart()
    msg['From'] = send_from
    msg['To'] = COMMASPACE.join(send_to)
    msg['Cc'] = COMMASPACE.join(send_cc)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    msg.attach( MIMEText(text) )
    
    for filepath in attachments:
        with open(filepath, 'r') as f:
            attch = (MIMEText(f.read()))
            attch.add_header('Content-Disposition', 'attachment', filename="%s" % os.path.basename(filepath)) 
            msg.attach(attch)

    smtp = smtplib.SMTP(server)
    smtp.sendmail(send_from, send_to + send_cc, msg.as_string())
    smtp.close()


def send_to_teams_channel(webhook, title, message):
    try:
        connect = pymsteams.connectorcard(webhook)
        connect.title(title)
        connect.text(message)
        connect.send()
    except Exception as terr:
        print(terr)



def send_mail_with_table(send_from, send_to, send_cc=[], subject="", dataframe=''):
    server="appmail.risk.regn.net"
    if send_cc == '':
       send_cc = []
    
    assert type(send_to)==list
    assert type(send_cc)==list

    msg = MIMEMultipart()
    msg['From'] = send_from
    msg['To'] = COMMASPACE.join(send_to)
    msg['Cc'] = COMMASPACE.join(send_cc)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject
    msg.attach(MIMEText(dataframe, 'html'))

    print(f"Sending email from {send_from} to {','.join(send_to)}")
    smtp = smtplib.SMTP(server)
    smtp.sendmail(send_from, send_to + send_cc, msg.as_string())
    smtp.close()
