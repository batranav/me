import argparse
import time

def parseAndSleep():

    parser = argparse.ArgumentParser(description='Pass time in Seconds')
    parser.add_argument('-s', '--seconds', help='Time in seconds', required=True)
    args = parser.parse_args()
    print('Going to wait for {0} seconds'.format(args.seconds))
    time.sleep(int(args.seconds))
    print('Done waiting for {0} seconds'.format(args.seconds))

if __name__ == '__main__':
    parseAndSleep()