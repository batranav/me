import os
import traceback
import json
import urllib.request
import urllib.parse
from datetime import datetime
import sys
import pandas as pd
import re
import requests
import shutil
import gzip
import AutomationLogging
from vault.secrets import get_api_secret

import parseYamlProperty

currentdate = datetime.today().strftime("%Y%m%d")

outputFolder = parseYamlProperty.get_inbound_dir() + "\\infosec\\importFiles\\csv"
stagingFolder = parseYamlProperty.get_inbound_dir() + "\\infosec\\importFiles"



def getToken():
    logger = AutomationLogging.getLogger('preprocess_pull_msdefender_segmented')
    tenantId = get_api_secret(logger, 'msdefender_tenantId', secret='pwd')
    appId = get_api_secret(logger, 'msdefender_appId', secret='pwd')
    appSecret = get_api_secret(logger, 'msdefender_appSecret', secret='pwd')
    url = "https://login.microsoftonline.com/%s/oauth2/token" % (tenantId)

    resourceAppIdUri = "https://api.securitycenter.microsoft.com"

    body = {
        "resource": resourceAppIdUri,
        "client_id": appId,
        "client_secret": appSecret,
        "grant_type": "client_credentials",
    }

    data = urllib.parse.urlencode(body).encode("utf-8")

    req = urllib.request.Request(url, data)
    response = urllib.request.urlopen(req)
    jsonResponse = json.loads(response.read())
    aadToken = jsonResponse["access_token"]
    return aadToken


def getData(endpoint, header):
    endpoint_request = urllib.request.Request(endpoint, None, header)
    endpoint_response = urllib.request.urlopen(endpoint_request)
    endpoint_jsonResponse = json.loads(endpoint_response.read())
    return endpoint_jsonResponse


def json_to_csv(in_dir, out_dir):
    if os.stat(in_dir).st_size == 0:
        open(out_dir, "w")
    df = pd.read_json(in_dir)
    p = re.compile(r"(\r|\n|\r\n|\n\r|\t)")
    for i in df.columns:
        df[i] = [p.sub('', str(x)) for x in df[i].tolist()]
    df.to_csv(out_dir, index=False)

def downloadGzFile(url, fPath, master):
    try:
        r = requests.get(url, stream=True)
        if(r.status_code == 200):
            with open(master, 'ab') as out_file:      
                gz_file = gzip.GzipFile(fileobj=r.raw)
                shutil.copyfileobj(gz_file, out_file)     
    except(requests.exceptions.Timeout): 
        print("Timeout")

def exportFilePull(endpoint, header):
    jsonresp = getData(endpoint[0], header)
    if("exportFiles" in jsonresp.keys()): 
        urls = jsonresp.pop("exportFiles") 
        masterFile = os.path.join(stagingFolder, endpoint[1] + "_" + currentdate + "_" + ".json")
        if os.path.exists(masterFile):
            os.remove(masterFile)

        for k, l in enumerate(urls):      
            filePath = os.path.join(stagingFolder, endpoint[1] + "_" + str(k) + ".json")
            downloadGzFile(l, filePath, masterFile)

        if os.stat(masterFile).st_size == 0:
            open(os.path.join(outputFolder, endpoint[1] + ".csv"), "w")
        else:
            df = pd.read_json(masterFile, lines=True)
            if (endpoint[1] == 'software_vulnerabilities_by_machine'):
                df = df.reindex(columns=[
                    "Id", 
                    "DeviceId", 
                    "RbacGroupId", 
                    "RbacGroupName", 
                    "DeviceName", 
                    "OSPlatform", 
                    "OSVersion", 
                    "OSArchitecture", 
                    "SoftwareVendor", 
                    "SoftwareName", 
                    "SoftwareVersion", 
                    "CveId", 
                    "VulnerabilitySeverityLevel", 
                    "RecommendedSecurityUpdate", 
                    "RecommendedSecurityUpdateId", 
                    "RecommendedSecurityUpdateUrl", 
                    "DiskPaths", 
                    "RegistryPaths", 
                    "LastSeenTimestamp", 
                    "FirstSeenTimestamp", 
                    "EndOfSupportStatus",
                    "ExploitabilityLevel", 
                    "RecommendationReference", 
                    "CvssScore"])
            
            df.to_csv(os.path.join(outputFolder, endpoint[1] +  "_" + currentdate + ".csv"), index=False)

def process(token, foldername):
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Bearer " + token,
    }

    export_endpoints = [("https://api.securitycenter.windows.com/api/machines/softwarevulnerabilitiesExport", "software_vulnerabilities_by_machine"),
        ("https://api.securitycenter.microsoft.com/api/machines/SecureConfigurationsAssessmentExport", "secure_configurations_assessment_by_machine")
        ]
        
    for exp in export_endpoints:
        exportFilePull(exp, header)


if __name__ == "__main__":
    try:
        foldername = outputFolder + "\\"
        if not os.path.isdir(foldername):
            os.mkdir(foldername)
        token = getToken()
        process(token, foldername)
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print("\n\n{0}".format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = "".join(line for line in lines)
        print(processerrorMsg)