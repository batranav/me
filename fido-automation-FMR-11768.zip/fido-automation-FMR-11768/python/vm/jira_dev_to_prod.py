import sys
from pathlib import Path
path = str(Path(Path(__file__).parent.absolute()).parent.absolute())
sys.path.insert(0, path)
from distutils.dir_util import copy_tree 
from shutil import copyfile
import shutil
import time
import os

#fromDirectory = "//alawdred201.risk.regn.net/d$/red/data/inbound/salesforce/daily/raw_" + time.strftime('%Y%m%d')+"/"
# copy all contents
src1 = "//alawdred201.risk.regn.net/d$/red/data/inbound/jira/daily/fields_" + time.strftime('%Y%m%d')+".csv"
src2 =  "//alawdred201.risk.regn.net/d$/red/data/inbound/jira/daily/worklog_" + time.strftime('%Y%m%d')+".csv"
src3 =       "//alawdred201.risk.regn.net/d$/red/data/inbound/jira/daily/issues_" + time.strftime('%Y%m%d')+".csv"
src4 =       "//alawdred201.risk.regn.net/d$/red/data/inbound/jira/daily/resolution_" + time.strftime('%Y%m%d')+".csv"
src5 =       "//alawdred201.risk.regn.net/d$/red/data/inbound/jira/daily/worklog_comment_" + time.strftime('%Y%m%d')+".csv"
src6 =       "//alawdred201.risk.regn.net/d$/red/data/inbound/jira/daily/history_" + time.strftime('%Y%m%d')+".csv"
dest1 = "//alawpfidolz301/d$/red/data/inbound/vm_jira/daily/fields_" + time.strftime('%Y%m%d')+".csv"
dest2 =      "//alawpfidolz301/d$/red/data/inbound/vm_jira/daily/worklog_" + time.strftime('%Y%m%d')+".csv"
dest3 =      "//alawpfidolz301/d$/red/data/inbound/vm_jira/daily/issues_" + time.strftime('%Y%m%d')+".csv"
dest4 =      "//alawpfidolz301/d$/red/data/inbound/vm_jira/daily/resolution_" + time.strftime('%Y%m%d')+".csv"
dest5 =      "//alawpfidolz301/d$/red/data/inbound/vm_jira/daily/worklog_comment_" + time.strftime('%Y%m%d')+".csv"
dest6 =      "//alawpfidolz301/d$/red/data/inbound/vm_jira/daily/history_" + time.strftime('%Y%m%d')+".csv"

shutil.copy2( src1,dest1) 
shutil.copy2( src2,dest2) 
shutil.copy2( src3,dest3) 
shutil.copy2( src4,dest4) 
shutil.copy2( src5,dest5) 
shutil.copy2( src6,dest6) 