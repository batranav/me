import os
import sys
import time
import datetime
import parseYamlProperty
import logging
import commonArgs

dt = datetime.datetime.utcnow()  # datetime now (all in UTC)
print('Current Date Time : {0}'.format(dt))

application_name = commonArgs.getApplication()

logging.basicConfig(filename='deleteinfo.log', level=logging.INFO)

def getFolderList(basePath, source, folderType):
    if folderType != '':
        x = basePath + "\\" + source + "\\" + folderType
    else:
        x = basePath + "\\" + source
    return x
   

def cleanupfiles(dir_to_search, numberofdays):
    
    global dt
    numberofdays = int(numberofdays)
    
    print('Path {1}, #ofDays : {0}'.format(numberofdays, dir_to_search))

    delta = datetime.timedelta(numberofdays)    # seven days interval\
    dtX = dt - delta                 # datetime earlier than now
    print('DtX: {0}'.format(dtX))
    for dirpath, dirnames, filenames in os.walk(dir_to_search):
        for sub_dir in dirnames:
            cleanupfiles(dir_to_search + '\\' + sub_dir, numberofdays)        
        for file in filenames:
            fname = os.path.join(dirpath, file)
            if os.path.isfile(fname):    # only the file names
                t = os.path.getmtime(fname)      # time of last modification in seconds
                dat = datetime.datetime.utcfromtimestamp(t)  # datetime representation 
                if dat <= dtX:
                    print('Deleting', repr(fname))
                    strOut = str(repr(fname))
                    logging.info(strOut + '\n')
                    try:
                        os.remove(fname)   
                    except:
                        pass
    
if __name__ == "__main__":
    for source in parseYamlProperty.getAllSourceFolders():
        print('Removing the folder and retentiondays are  : ' + source.sourcefolder + '' + str(source.retentiondays))
        cleanupfiles(source.sourcefolder, source.retentiondays)
    # cleanupfiles('D:\\red\\data\\inbound\\mvr\\daily', 35)
        
  
      