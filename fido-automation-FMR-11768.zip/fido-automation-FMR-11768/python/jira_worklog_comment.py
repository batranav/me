from jira import JIRA
import csv
from jira.resources import Worklog
from datetime import datetime, timedelta
from datetime import date 
from datetime import timedelta 
from vault.secrets import get_api_secret
from commonArgs import getSource
import AutomationLogging
today = date.today() 
onedays = today - timedelta(days = 1) 
sevendays = today - timedelta(days = 2)
def main():
	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_worklog_comment', True)
	source = getSource()
	uname = get_api_secret(logger, source, secret='uname')
	pwd= get_api_secret(logger, source, secret='pwd')
	jira = JIRA(options, basic_auth=(uname,pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   worklogDate > -1d and worklogDate < 1d' , startidx, blocksize)
		numissues=len(newissues)
		if  numissues==0 or  blocknum==10:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0
	issuesfile=open('D:\\red\\data\\inbound\\jira\\daily\\worklog_comment_' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	issueswriter=csv.writer(issuesfile)
	fieldname = ['comment'.replace("", "comment"),'id']
	issueswriter.writerow(fieldname)
	for resultlist in issues:
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']

			worklogs=jira.worklogs(issueId)
			for worklog in worklogs:
				issueswriter.writerow([worklog.comment,worklog.id])
	issuesfile.close()

if __name__== "__main__" :
     main()