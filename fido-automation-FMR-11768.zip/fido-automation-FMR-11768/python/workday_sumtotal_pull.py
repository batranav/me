import pyodbc
from datetime import datetime
import parseYamlProperty
import codecs
import getSQLdata
import os
import AutomationLogging

#print(cursor.description)
#print(len(cursor.description))

def attempt_strip(x):
    try:
        #print(x)
        return x.strip()
    except AttributeError:
        return x

def checkNone(x):
    if x is None:
        #print('None condition')
        return ('')
    else:
        return(x)

def pull_files():
    logger = AutomationLogging.getLogger('preprocess_workday_sumtotal_pull')
    (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, 'workday','daily','')
    cnxn = pyodbc.connect(connstr)
    cursor = cnxn.cursor()
    cpsql ="SELECT [Attemptfk],[ActivityName],[Code],[EmpNo],[CostCenter],[BusUnit],[MgrEmpNo],[MgrEmail],[ActivityLabel],[ActivityActive],[StartDt],[EndDt],[AttendanceStatus],[CostBase],[ActivityStartDt],[ActivityEndDt] FROM [DW_SUMTOTAL].[DW_sumtotal].[dbo].[RELX_Transcript_RBXXX_RKXXX_Users]"
   
    sqltoexecute = cpsql
    
    print (sqltoexecute)
    
    cursor.execute(sqltoexecute)
    
    f = open(os.path.join(parseYamlProperty.get_inbound_dir(),'workday\\daily\\workday_sumtotal_' + datetime.now().strftime('%Y%m%d') + '.txt'),'w')

    while 1:
        row = cursor.fetchone()
        iterator = range(0, len(cursor.description)).__iter__()
        col = ''
        outStr = []
        result = ''
        #print(row)
        if not row:
            break
        for idx in iterator:
            col = checkNone(attempt_strip(row[idx]))
            if idx > 0:
                outStr.append('|')
                outStr.append(col)
            else:
                outStr.append(col)

        result = ' '.join([str(i) for i in outStr])
		
		
        f.write(result.encode("ascii", "ignore").decode() + '\n')
	
    #print(result)

    f.close()

if __name__ == '__main__':
   pull_files()