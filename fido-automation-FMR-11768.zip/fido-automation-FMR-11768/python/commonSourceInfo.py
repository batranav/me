import yaml
import io
import base64
from commonInbound import commonInbound
from commonOutbound import commonOutbound
import parseYamlProperty
import fido_utils
import os
import glob
import datetime
import shutil
_today = fido_utils.getToday()
config = ''

def getPreviousDay(filedate):
    return fido_utils.getYesterday(fido_utils.mkDateTime(filedate, strFormat="%Y%m%d"))

def getPreviousDay_yyyy_mm_dd(filedate):
    date_time_obj = datetime.datetime.strptime(getPreviousDay(filedate), "%Y%m%d").strftime("%Y-%m-%d")
    return date_time_obj

def getConfig():
    return parseYamlProperty.getConfig()

def getProcessingFolder(source, frequency):
    data_loaded = getConfig()    
    frequencyData = data_loaded.get(source).get(frequency)
    fidoFolderName = parseYamlProperty.get_processing_dir(source) + '\\' + frequencyData.get('fidofolder').get('name')
    return fidoFolderName

def getInboundFolder(source, frequency):
    data_loaded = getConfig()    
    frequencyData = data_loaded.get(source).get(frequency)
    fidoFolderName = parseYamlProperty.get_inbound_dir(source) + '\\' + frequencyData.get('fidofolder').get('name')
    return fidoFolderName

def getArchiveFolder(source, frequency):
    data_loaded = getConfig()    
    frequencyData = data_loaded.get(source).get(frequency)
    fidoFolderName = parseYamlProperty.get_archive_dir(source) + '\\' + frequencyData.get('fidofolder').get('name') + '\\archive'
    return fidoFolderName

def getSourceArchiveFolder(source, frequency):
	data_loaded = getConfig()	
	frequencyData = data_loaded.get(source).get(frequency)
	SourceFolder = frequencyData.get('pullrequiredS3files').get('sourcefolders')[0].get('sourcefolder')
	SourceArchiveFolder = SourceFolder.get('name') + 'Archive/'
	return SourceArchiveFolder

def getFidoFolder(source, frequency):
	data_loaded = getConfig()	
	frequencyData = data_loaded.get(source).get(frequency)
	fidoFolderName = parseYamlProperty.get_inbound_dir() + '\\' + frequencyData.get('fidofolder').get('name')
	return fidoFolderName

def getMoveUnusedFilesFlag(frequencyData):
    if frequencyData.get('moveUnusedFiles') == None:
        return True
    else:
        frequencyData.get('moveUnusedFiles')

def getSourceExtension(sf, frequencyData):
    
    sourceExtension = ''

    if sf.get('sourceExtension') != None and sf.get('sourceExtension') != '': 
            sourceExtension = '.' + sf.get('sourceExtension') 
    elif frequencyData.get('sourceExtension') != None: 
            sourceExtension = '.' + frequencyData.get('sourceExtension') 
    
    return sourceExtension

def getFidoExtension(frequencyData):
    
    data_loaded = getConfig()
    
    FidoExtension = ''

    if frequencyData.get('fidoExtension') != None: 
        fidoExtension = '.' + frequencyData.get('fidoExtension') 
    else : 
        fidoExtension = '.' + data_loaded.get('common').get('Fido_Extn')
    
    return fidoExtension

def getDestinationExtension(sf, frequencyData):
	
	destinationExtension = ''

	if sf.get('destinationExtension') != None and sf.get('destinationExtension') != '': 
			destinationExtension = '.' + sf.get('destinationExtension') 
	elif frequencyData.get('destinationExtension') != None: 
			destinationExtension = '.' + frequencyData.get('destinationExtension') 
	
	return destinationExtension

def getPullDBFiles(source, frequency, filedate=_today):
    return getPullRequiredDBFiles(source, frequency, filedate) + getPullOptionalDBFiles(source, frequency, filedate)

def getPullS3Files(source, frequency, filedate=_today):
    return getPullRequiredS3Files(source, frequency, filedate) + getPullOptionalS3Files(source, frequency, filedate)

def getPullAzureFiles(source, frequency, filedate=_today):
    return getPullRequiredAzureFiles(source, frequency, filedate) + getPullOptionalAzureFiles(source, frequency, filedate)
    
def getDBFiles(source, frequency, filedate=_today):
    pullRequiredDB = getPullRequiredDBFiles(source, frequency, filedate=_today)
    pullOptionalDB = getPullOptionalDBFiles(source, frequency, filedate=_today)

    files = [o.fidoname for o in pullRequiredDB] + [o.fidoname for o in pullOptionalDB]

    return files

def getSFTPFiles(source, frequency, filedate=_today):
    pullRequired = getPullRequiredFeedFiles(source, frequency, filedate=_today)
    pushRequired = getPushRequiredFeedFiles(source, frequency, filedate=_today)
    pullOptional = getPullOptionalFeedFiles(source, frequency, filedate=_today)
    pushOptional = getPushOptionalFeedFiles(source, frequency, filedate=_today)

    files = [o.fidoname for o in pullRequired] + [o.fidoname for o in pushRequired] + [o.fidoname for o in pullOptional] + [o.fidoname for o in pushOptional]

    return files

def isPushFiles(source, frequency):
    
    data_loaded = getConfig()    
    
    x = data_loaded.get(source).get(frequency).get('pushrequiredfiles')
    y = data_loaded.get(source).get(frequency).get('pushoptionalfiles')
    
    data = []

    if x is not None:
        data.append(x.get('files'))

    if y is not None:
        data.append(y.get('files'))

    if data != []:
        print(data)
        return True
    
    return False

def isPullFiles(source, frequency):
    data_loaded = getConfig()
    
    x = data_loaded.get(source).get(frequency).get('pullrequiredfiles')
    x1 = data_loaded.get(source).get(frequency).get('pulloptionalfiles')
    y = data_loaded.get(source).get(frequency).get('pullrequiredDBfiles')
    y1 = data_loaded.get(source).get(frequency).get('pulloptionalDBfiles')
    z = data_loaded.get(source).get(frequency).get('pullrequiredS3files')
    z1 = data_loaded.get(source).get(frequency).get('pulloptionalS3files')
    azure_required = data_loaded.get(source).get(frequency).get('pullrequiredAzurefiles')
    azure_optional = data_loaded.get(source).get(frequency).get('pulloptionalAzurefiles')
    data = []

    if x is not None:
        data.append(x.get('files'))

    if y is not None:
        data.append(y.get('files'))

    if z is not None:
        data.append(z.get('files'))

    if x1 is not None:
        data.append(x1.get('files'))

    if y1 is not None:
        data.append(y1.get('files'))

    if z1 is not None:
        data.append(z1.get('files'))
    
    if azure_required is not None:
        data.append(azure_required.get('files'))

    if azure_optional is not None:
        data.append(azure_optional.get('files'))

    if data != []:
        print(data)
        return True
    
    return False
def getRequiredFiles(source, frequency, filedate=_today):
    pullRequired = getPullRequiredFeedFiles(source, frequency, filedate=_today)
    pushRequired = getPushRequiredFeedFiles(source, frequency, filedate=_today)
    pullRequiredDB = getPullRequiredDBFiles(source, frequency, filedate=_today)    
    pullRequiredS3 = getPullRequiredS3Files(source, frequency, filedate=_today)
    pullRequiredAzure = getPullRequiredAzureFiles(source, frequency, filedate=_today)    
    files = [o.fidoname for o in pullRequired] + [o.fidoname for o in pushRequired] + [o.fidoname for o in pullRequiredDB] + [o.fidoname for o in pullRequiredS3] + [o.fidoname for o in pullRequiredAzure]
    return files 
def getOptionalFiles(source, frequency, filedate=_today):
    pullOptional = getPullOptionalFeedFiles(source, frequency, filedate=_today)
    pushOptional = getPushOptionalFeedFiles(source, frequency, filedate=_today)
    pullOptionalDB = getPullOptionalDBFiles(source, frequency, filedate=_today)
    pullOptionalS3 = getPullOptionalS3Files(source, frequency, filedate=_today)
    pullOptionalAzure = getPullOptionalAzureFiles(source, frequency, filedate=_today)
    files = [o.fidoname for o in pullOptional] + [o.fidoname for o in pushOptional] + [o.fidoname for o in pullOptionalDB] + [o.fidoname for o in pullOptionalS3] + [o.fidoname for o in pullOptionalAzure]
    return files

def getPullRequiredFiles(source, frequency, filedate = _today):
    return getPullRequiredFeedFiles(source, frequency, filedate) + getPullRequiredDBFiles(source, frequency, filedate) + getPullRequiredS3Files(source, frequency, filedate)

def getPullOptionalFiles(source, frequency, filedate = _today):
    return getPullOptionalFeedFiles(source, frequency, filedate) + getPullOptionalDBFiles(source, frequency, filedate)

def getPullFiles(source, frequency, filedate = _today):
    return getPullRequiredFeedFiles(source, frequency, filedate) + getPullOptionalFeedFiles(source, frequency, filedate) + getPullRequiredDBFiles(source, frequency, filedate) + getPullOptionalDBFiles(source, frequency, filedate) + getPullRequiredS3Files(source, frequency, filedate)

def getPullFeedFiles(source, frequency, filedate = _today):
    return getPullRequiredFeedFiles(source, frequency, filedate) + getPullOptionalFeedFiles(source, frequency, filedate)

def getPushFiles(source, frequency, filedate = _today):
    return getPushRequiredFeedFiles(source, frequency, filedate) + getPushOptionalFeedFiles(source, frequency, filedate)

def getFeedFiles(source, frequency, filedate=_today):
    return getRequiredFiles(source, frequency, filedate) + getOptionalFiles(source, frequency, filedate)

def getPushRequiredFeedFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pushrequiredfiles') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pushrequiredfiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    
    error_cc_email = ''

    if frequencyData.get('error_cc_email') != None:
        error_cc_email = frequencyData.get('error_cc_email').split(',')
    
    error_cc_email = ','.join([elem for elem in error_cc_email])

    if frequencyData is None:
        return arr

    files = frequencyData.get('files')
    for y in range(0, len(files)):
        
        fidoName   = files[y]
        pullOrPush = "push"
        required   = False
        sourceExtension  = getSourceExtension(frequencyData, frequencyData) 
        fidoExtension  = getFidoExtension(frequencyData)
        sourceName = ""
        relativeSourceFolder = ""
        arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, error_cc_email,"","","","", moveUnusedFiles ))

    return arr

def getPushOptionalFeedFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    arr = []
    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pushoptionalfiles') is None:
        return arr

    frequencyData = data_loaded.get(source).get(frequency).get('pushoptionalfiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    if frequencyData is None:
        return arr

    error_cc_email = ''

    if frequencyData.get('error_cc_email') != None:
        error_cc_email = frequencyData.get('error_cc_email').split(',')

    error_cc_email = ','.join([elem for elem in error_cc_email])

    files = frequencyData.get('files')
    for y in range(0, len(files)):
        
        fidoName   = files[y]
        pullOrPush = "push"
        required   = False
        sourceExtension  = getSourceExtension(frequencyData, frequencyData) 
        fidoExtension  = getFidoExtension(frequencyData)
        sourceName = ""
        relativeSourceFolder = ""
        arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, error_cc_email, "","","", moveUnusedFiles))

    return arr

def getPullRequiredFeedFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredfiles') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pullrequiredfiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    
    if frequencyData is None:
        return arr

    fidofolder = getInboundFolder(source, frequency)
    processingfolder = getProcessingFolder(source, frequency)

    error_cc_email = ''

    if frequencyData.get('error_cc_email') != None:
        error_cc_email = frequencyData.get('error_cc_email').split(',')
    
    error_cc_email = ','.join([elem for elem in error_cc_email]) 
         

    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        if sf.get('error_cc_email') != None:
            error_cc_email = sf.get('error_cc_email')
                   
        
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = True
            _match_latest_file = False
            if files[y].get('file').get('match_latest_file') != None :
                _match_latest_file = files[y].get('file').get('match_latest_file')

            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 

            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDay(filedate) 
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDay(filedate)                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''

            if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                autoSourceFolderPrefix = False
                relativeSourceFolder = sf.get('name') + "/" 
            else :
                autoSourceFolderPrefix = True
                relativeSourceFolder = sf.get('name')  + "/" + filedate + "/"

            absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            # absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            # absFidoCompressedFileName = processingfolder + '\\' + fidoName + '_' + filedate + sourceExtension  
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension              

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, error_cc_email, absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles, _match_latest_file))

    return arr

def getPullOptionalFeedFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pulloptionalfiles') is None:
        return arr
    
    frequencyData = data_loaded.get(source).get(frequency).get('pulloptionalfiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))

    if frequencyData is None:
        return arr

    error_cc_email = ''

    if frequencyData.get('error_cc_email') != None:
        error_cc_email = frequencyData.get('error_cc_email').split(',')

    error_cc_email = ','.join([elem for elem in error_cc_email])       

    fidofolder = getInboundFolder(source, frequency)
    processingfolder = getProcessingFolder(source, frequency)
    
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        if sf.get('error_cc_email') != None:
            error_cc_email = sf.get('error_cc_email')
        

        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = False
            _match_latest_file = False
            if files[y].get('file').get('match_latest_file') != None :
                _match_latest_file = files[y].get('file').get('match_latest_file')

            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix')

            fidoExtension  = getFidoExtension(frequencyData) 

            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDay(filedate) 
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDay(filedate)                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')
                
            if frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            else:
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'        

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''

            if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                autoSourceFolderPrefix = False
                relativeSourceFolder = sf.get('name')  + "/"  
            else :
                autoSourceFolderPrefix = True
                relativeSourceFolder = sf.get('name')  + "/" + filedate + "/"

            absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            # absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            # absFidoCompressedFileName = processingfolder + '\\' + fidoName + '_' + filedate + sourceExtension  
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension              

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, error_cc_email, absSourceFileName, absFidoFileName, absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles, _match_latest_file))
    return arr

def getFidoExtns(source, frequency):
    line = ''
    data_loaded = getConfig()
    try:
        for k, v in data_loaded.get(source).get(frequency).items():
            if line != '':
                line += ','
            if data_loaded.get(source).get(frequency)[k].get('fidoExtension') is None:
                line += data_loaded.get('common').get('Fido_Extn')
            else:
                line += data_loaded.get(source).get(frequency)[k].get('fidoExtension')
        
        return list(dict.fromkeys([item.strip() for item in line.strip().split(",")])) 
    except:
        raise Exception('Can\'t find details for {0} {1} in Yaml'.format(str(source), str(frequency)))

def getPullRequiredDBFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredDBfiles') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pullrequiredDBfiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    
    if frequencyData is None:
        return arr

    error_cc_email = ''

    if frequencyData.get('error_cc_email') != None:
        error_cc_email = frequencyData.get('error_cc_email').split(',')

    fidofolder = getInboundFolder(source, frequency)
    processingfolder = getProcessingFolder(source, frequency)
    
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = True
            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 

            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDay(filedate) 
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDay(filedate)                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if sourceName == None or ( frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False):
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            if sf.get('name') == None:
                relativeSourceFolder = ''
                autoSourceFolderPrefix = False
            else :
                if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                    autoSourceFolderPrefix = False
                    relativeSourceFolder = sf.get('name') + "/" 
                else :
                    autoSourceFolderPrefix = True
                    relativeSourceFolder = sf.get('name')  + "/" + filedate + "/"

            if sourceName == None :
                absSourceFileName = ''
            else :
                absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, '',absSourceFileName, absFidoFileName,  absFidoCompressedFileName,  completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))

    return arr

def getPullRequiredS3Files(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredS3files') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pullrequiredS3files')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    
    if frequencyData is None:
        return arr

    fidofolder = getInboundFolder(source, frequency)

    processingfolder = getProcessingFolder(source, frequency)
    
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = True
            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 
            if sf.get('sourceFileNameDateFormat') != None and sf.get('sourceFileNameDateFormat') == 'yyyy-mm-dd':
                getPreviousDayFormat = getPreviousDay_yyyy_mm_dd(filedate)
            else:
                getPreviousDayFormat = getPreviousDay(filedate)
            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDayFormat
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDayFormat                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if sourceName == None or ( frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False):
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            if sf.get('name') == None:
                relativeSourceFolder = ''
                autoSourceFolderPrefix = False
            else :
                if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                    autoSourceFolderPrefix = False
                    relativeSourceFolder = sf.get('name')
                else :
                    autoSourceFolderPrefix = True
                    relativeSourceFolder = sf.get('name')

            if sourceName == None :
                absSourceFileName = ''
            else :
                absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, '', absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))

    return arr

def getPullRequiredAzureFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []
    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredAzurefiles') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pullrequiredAzurefiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    if frequencyData is None:
        return arr
    fidofolder = getInboundFolder(source, frequency)

    processingfolder = getProcessingFolder(source, frequency)
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = True
            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 
            if sf.get('sourceFileNameDateFormat') != None and sf.get('sourceFileNameDateFormat') == 'yyyy-mm-dd':
                getPreviousDayFormat = getPreviousDay_yyyy_mm_dd(filedate)
            else:
                getPreviousDayFormat = getPreviousDay(filedate)
            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDayFormat
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDayFormat                
            else:
                sourceName = files[y].get('file').get('sourcename') 
            print("sourcename =====>", sourceName)
            # input()
            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if sourceName == None or ( frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False):
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            if sf.get('name') == None:
                relativeSourceFolder = ''
                autoSourceFolderPrefix = False
            else :
                if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                    autoSourceFolderPrefix = False
                    relativeSourceFolder = sf.get('name')
                else :
                    autoSourceFolderPrefix = True
                    relativeSourceFolder = sf.get('name')

            if sourceName == None :
                absSourceFileName = ''
            else :
                absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  
            
            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, '', absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))
    
    return arr


def getPullOptionalS3Files(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredS3files') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pulloptionalS3files')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    
    if frequencyData is None:
        return arr

    fidofolder = getInboundFolder(source, frequency)

    processingfolder = getProcessingFolder(source, frequency)
    
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = False
            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 
            if sf.get('sourceFileNameDateFormat') != None and sf.get('sourceFileNameDateFormat') == 'yyyy-mm-dd':
                getPreviousDayFormat = getPreviousDay_yyyy_mm_dd(filedate)
            else:
                getPreviousDayFormat = getPreviousDay(filedate)
            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDayFormat
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDayFormat                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if sourceName == None or ( frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False):
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            if sf.get('name') == None:
                relativeSourceFolder = ''
                autoSourceFolderPrefix = False
            else :
                if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                    autoSourceFolderPrefix = False
                    relativeSourceFolder = sf.get('name')
                else :
                    autoSourceFolderPrefix = True
                    relativeSourceFolder = sf.get('name')

            if sourceName == None :
                absSourceFileName = ''
            else :
                absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, '',absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))

    return arr

def getPullOptionalAzureFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredS3files') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pulloptionalAzurefiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    if frequencyData is None:
        return arr

    fidofolder = getInboundFolder(source, frequency)

    processingfolder = getProcessingFolder(source, frequency)
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = False
            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 
            if sf.get('sourceFileNameDateFormat') != None and sf.get('sourceFileNameDateFormat') == 'yyyy-mm-dd':
                getPreviousDayFormat = getPreviousDay_yyyy_mm_dd(filedate)
            else:
                getPreviousDayFormat = getPreviousDay(filedate)
            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDayFormat
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDayFormat                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if sourceName == None or ( frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False):
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            if sf.get('name') == None:
                relativeSourceFolder = ''
                autoSourceFolderPrefix = False
            else :
                if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                    autoSourceFolderPrefix = False
                    relativeSourceFolder = sf.get('name')
                else :
                    autoSourceFolderPrefix = True
                    relativeSourceFolder = sf.get('name')

            if sourceName == None :
                absSourceFileName = ''
            else :
                absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, '',absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))

    return arr
    
def getPullOptionalDBFiles(source, frequency, filedate=_today):
    data_loaded = getConfig()    
    
    arr = []

    if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('pullrequiredDBfiles') is None:
        return arr
    frequencyData = data_loaded.get(source).get(frequency).get('pulloptionalDBfiles')
    moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
    
    if frequencyData is None:
        return arr

    fidofolder = getInboundFolder(source, frequency)
    processingfolder = getProcessingFolder(source, frequency)
    for x in range(0, len(frequencyData.get('sourcefolders'))):
        sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
        files = sf.get('files')
        for y in range(0, len(files)):
            fidoName   = files[y].get('file').get('fidoname')

            pullOrPush = "pull"
            required   = False
            if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
                sourceExtension = ''
            else:
                sourceExtension  = getSourceExtension(sf, frequencyData) 

            if sf.get('autoSourceFolderPrefix') != None:
                autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
            else:
                autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

            fidoExtension  = getFidoExtension(frequencyData) 

            if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + filedate
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + filedate
            elif sf.get('datadateInNameSuffix') != None and sf.get('datadateInNameSuffix') == True: 
                if sf.get('frequencyInSourceName') != None and sf.get('frequencyInSourceName') == False:
                    sourceName = files[y].get('file').get('sourcename') +  '_' + getPreviousDay(filedate) 
                else:
                    sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() +  '_' + getPreviousDay(filedate)                
            else:
                sourceName = files[y].get('file').get('sourcename') 

            if frequencyData.get('completedFlagPrefix') == None:
                cmpflagprefix = ''
            else :
                cmpflagprefix = frequencyData.get('completedFlagPrefix')

            if sf.get('completedFlagPrefix') == None:
                cmpflagprefix = cmpflagprefix
            else :
                cmpflagprefix = sf.get('completedFlagPrefix')

            if sourceName == None or ( frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False):
                completedFlagFileName =  ''
            else :
                completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

            if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
                completedFlagFileName =  ''
            if sf.get('name') == None:
                relativeSourceFolder = ''
                autoSourceFolderPrefix = False
            else :
                if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
                    autoSourceFolderPrefix = False
                    relativeSourceFolder = sf.get('name') + "/" 
                else :
                    autoSourceFolderPrefix = True
                    relativeSourceFolder = sf.get('name')  + "/" + filedate + "/"

            if sourceName == None :
                absSourceFileName = ''
            else :
                absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
            absFidoFileName = processingfolder + '\\' + fidoName + '_' + filedate + fidoExtension  
            absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

            arr.append(commonInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, '', absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))

    return arr


def getS3BucketName(source, frequency):
	data_loaded = getConfig()	
	frequencyData = data_loaded.get(source).get(frequency)
	destinationBucketName = frequencyData.get('outboundRequiredS3files').get('destinationBucketName')
	return destinationBucketName

def hasOutboundFiles(source, frequency):

	data_loaded = getConfig()	

	x = data_loaded.get(source).get(frequency).get('outboundRequiredS3files')
	x1 = data_loaded.get(source).get(frequency).get('outboundoptionalS3files')
	azure_required = data_loaded.get(source).get(frequency).get('outboundRequiredAzurefiles')
	azure_optional = data_loaded.get(source).get(frequency).get('outboundoptionalAzurefiles')
	azure_optional = data_loaded.get(source).get(frequency).get('outboundoptionalAzurefiles')
	sftp_required = data_loaded.get(source).get(frequency).get('outboundRequiredSftpfiles')
	sftp_optional = data_loaded.get(source).get(frequency).get('outboundoptionalSftpfiles')

	data = []

	if x is not None:
		data.append(x.get('files'))

	if x1 is not None:
		data.append(x1.get('files'))

	if azure_required is not None:
		data.append(azure_required.get('files'))

	if azure_optional is not None:
		data.append(azure_optional.get('files'))

	if sftp_required is not None:
		data.append(sftp_required.get('files'))

	if azure_optional is not None:
		data.append(azure_optional.get('files'))
	if data != []:
		print(data)
		return True

	return False
###
    # this will set sf and destinationfolder with date only when the flag is set, so current BD Azure pushes will be not impacted
    #    sf.get('name') + (('/' + filedate + '/') if sf.get('autoSourceFolderPrefix') == True else '')
###
def getOutboundRequiredSftpFiles(source, frequency, filedate=_today):
    
	data_loaded = getConfig()	
	arr = []
    
	if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('outboundRequiredSftpfiles') is None:
		return arr

	frequencyData = data_loaded.get(source).get(frequency).get('outboundRequiredSftpfiles')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
	if frequencyData is None:
		return arr
	fidofolder = getFidoFolder(source, frequency)
	for x in range(0, len(frequencyData.get('destinationfolders'))):
		sf = frequencyData.get('destinationfolders')[x].get('destinationfolder')
		destinationfolder = sf.get('name')  + (('/' + filedate ) if sf.get('autoSourceFolderPrefix') == True else '')
		files = sf.get('files')
		for y in range(0, len(files)):
			fidoName   = files[y].get('file').get('fidoname')
			required   = True
			if sf.get('destinationExtensionMissing') != None and sf.get('destinationExtensionMissing') == True:
				destinationExtension = ''
			else:
				destinationExtension  = getDestinationExtension(sf, frequencyData) 
				
			fidoExtension  = getFidoExtension(frequencyData) 
			destinationName = files[y].get('file').get('destinationname') 
			if destinationName == None :
				absDestinationFileName = ''
			else :
				absDestinationFileName = destinationName + (('_' + filedate ) if (sf.get('filedateInNameSuffix') == True or sf.get('filedateInNameSuffix') == None) else '') + destinationExtension
			absFidoFileName = fidoName + (('_' + filedate ) if (sf.get('filedateInNameSuffix') == True) else '') + fidoExtension  
			AzurePushStartTime = ''
			AzurePushEndTime = ''
			AzurePushTimeTakenInMins = ''
			arr.append(commonOutbound(source, frequency, filedate, destinationName, fidoName, required, destinationExtension, fidoExtension, absDestinationFileName, absFidoFileName, destinationfolder, moveUnusedFiles))

	return arr

def getOutboundRequiredFiles(source, frequency, filedate=_today):
	# pullRequired = getPullRequiredFeedFiles(source, frequency, filedate=_today)
	# pushRequired = getPushRequiredFeedFiles(source, frequency, filedate=_today)
	# pullRequiredDB = getPullRequiredDBFiles(source, frequency, filedate=_today)	
	outboundRequiredS3 = getOutboundRequiredS3Files(source, frequency, filedate=_today)


	# files = [o.fidoname for o in pullRequired] + [o.fidoname for o in pushRequired] + [o.fidoname for o in pullRequiredDB] + [o.fidoname for o in pullRequiredS3]
	files = [o.fidoname for o in outboundRequiredS3]

	return files 

def getOutboundFilesSftp(source, frequency, filedate = _today):
    	return getOutboundRequiredSftpFiles(source, frequency, filedate)

def getOutboundOptionalFiles(source, frequency, filedate=_today):
	# pullOptional = getPullOptionalFeedFiles(source, frequency, filedate=_today)
	# pushOptional = getPushOptionalFeedFiles(source, frequency, filedate=_today)
	# pullOptionalDB = getPullOptionalDBFiles(source, frequency, filedate=_today)
	# files = [o.fidoname for o in pullOptional] + [o.fidoname for o in pushOptional] + [o.fidoname for o in pullOptionalDB] 

	# return files
	return []

def getOutboundS3Files(source, frequency, filedate=_today):
	return getOutboundRequiredS3Files(source, frequency, filedate)

def getOutboundAzureFiles(source, frequency, filedate=_today):
	return getOutboundRequiredAzureFiles(source, frequency, filedate)
	
#def getOutboundRequiredFiles(source, frequency, filedate = _today):
#	return getOutboundRequiredS3Files(source, frequency, filedate)

#def getOutboundOptionalFiles(source, frequency, filedate = _today):
#	return []

def getOutboundFiles(source, frequency, filedate = _today):
	return getOutboundRequiredS3Files(source, frequency, filedate)

def getOutboundFilesAzure(source, frequency, filedate = _today):
	return getOutboundRequiredAzureFiles(source, frequency, filedate)

def getOutboundFeedFiles(source, frequency, filedate = _today):
	return []
###
    # this will set sf and destinationfolder with date only when the flag is set, so current BD Azure pushes will be not impacted
    #    sf.get('name') + (('/' + filedate + '/') if sf.get('autoSourceFolderPrefix') == True else '')
###
def getOutboundRequiredS3Files(source, frequency, filedate=_today):

	data_loaded = getConfig()	
	arr = []

	if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('outboundRequiredS3files') is None:
		return arr

	frequencyData = data_loaded.get(source).get(frequency).get('outboundRequiredS3files')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
	if frequencyData is None:
		return arr
	fidofolder = getFidoFolder(source, frequency)

	for x in range(0, len(frequencyData.get('destinationfolders'))):
		sf = frequencyData.get('destinationfolders')[x].get('destinationfolder')
		destinationfolder = sf.get('name') + (('/' + filedate + '/') if sf.get('autoSourceFolderPrefix') == True else '') 
		files = sf.get('files')
		for y in range(0, len(files)):
			fidoName   = files[y].get('file').get('fidoname')
			required   = True
			if sf.get('destinationExtensionMissing') != None and sf.get('destinationExtensionMissing') == True:
				destinationExtension = ''
			else:
				destinationExtension  = getDestinationExtension(sf, frequencyData) 
				
			fidoExtension  = getFidoExtension(frequencyData) 
			destinationName = files[y].get('file').get('destinationname') 
			if destinationName == None :
				absDestinationFileName = ''
			else :
				absDestinationFileName = destinationName + (('_' + filedate ) if (sf.get('filedateInNameSuffix') == True) else '') + destinationExtension
			absFidoFileName = fidoName + (('_' + filedate ) if (sf.get('filedateInNameSuffix') == True ) else '') + fidoExtension   
			s3PushStartTime = ''
			s3PushEndTime = ''
			s3PushTimeTakenInMins = ''
			arr.append(commonOutbound(source, frequency, filedate, destinationName, fidoName, required, destinationExtension, fidoExtension, absDestinationFileName, absFidoFileName, destinationfolder, moveUnusedFiles))

	return arr
###
    # this will set sf and destinationfolder with date only when the flag is set, so current BD Azure pushes will be not impacted
    #    sf.get('name') + (('/' + filedate + '/') if sf.get('autoSourceFolderPrefix') == True else '')
###
def getOutboundRequiredAzureFiles(source, frequency, filedate=_today):

	data_loaded = getConfig()	
	arr = []
    
	if data_loaded.get(source) is None or data_loaded.get(source).get(frequency) is None or data_loaded.get(source).get(frequency).get('outboundRequiredAzurefiles') is None:
		return arr

	frequencyData = data_loaded.get(source).get(frequency).get('outboundRequiredAzurefiles')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
	if frequencyData is None:
		return arr
	fidofolder = getFidoFolder(source, frequency)
	for x in range(0, len(frequencyData.get('destinationfolders'))):
		sf = frequencyData.get('destinationfolders')[x].get('destinationfolder')
		destinationfolder = sf.get('name') + (('/' + filedate + '/') if sf.get('autoSourceFolderPrefix') == True else '')
		files = sf.get('files') 
		for y in range(0, len(files)):
			fidoName   = files[y].get('file').get('fidoname')
			required   = True
			if sf.get('destinationExtensionMissing') != None and sf.get('destinationExtensionMissing') == True:
				destinationExtension = ''
			else:
				destinationExtension  = getDestinationExtension(sf, frequencyData) 
				
			fidoExtension  = getFidoExtension(frequencyData) 
			destinationName = files[y].get('file').get('destinationname') 
			if destinationName == None :
				absDestinationFileName = ''
			else :
				absDestinationFileName = destinationName + (('_' + filedate ) if (sf.get('filedateInNameSuffix') == True or sf.get('filedateInNameSuffix') == None) else '') + destinationExtension
			absFidoFileName = fidoName + (('_' + filedate ) if (sf.get('filedateInNameSuffix') == True) else '') + fidoExtension  
			AzurePushStartTime = ''
			AzurePushEndTime = ''
			AzurePushTimeTakenInMins = ''
			arr.append(commonOutbound(source, frequency, filedate, destinationName, fidoName, required, destinationExtension, fidoExtension, absDestinationFileName, absFidoFileName, destinationfolder, moveUnusedFiles))

	return arr



if __name__ == '__main__':

    data_loaded = getConfig()
    print(getOutboundRequiredAzureFiles('master_recon', 'daily'))
