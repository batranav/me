import codecs
import shutil
import re
import os
from datetime import datetime
import io
##'+datetime.now().strftime('%Y%m%d')

print('start time') 
print(datetime.now())
def pull_files():
    fix='D:\\red\\data\\inbound\\salesforce\\daily'
    # dir_path = "D:\\red\data\\inbound\\salesforce\\daily\" +'raw_' +time.strftime('%Y%m%d')
    dir_path = 'D:\\red\\data\\inbound\\salesforce\\rawfiles\\raw_' + datetime.now().strftime('%Y%m%d')
    file_list = []
    for in_file in os.listdir(dir_path):
    #if in_file.endswith(".txt"):
        file_list.append(in_file)

    for in_file in file_list:
        base=os.path.basename(in_file)
        out_file = os.path.join(dir_path, fix, base)
        in_file = os.path.join(dir_path, base)
        fix_dir = os.path.join(dir_path, fix)
        if not os.path.exists(fix_dir):
            os.makedirs(fix_dir)
        
        print(in_file)
        print(datetime.now())
        text = ""
        with codecs.open(in_file, encoding="utf-8") as f:
            text = f.read()
        f.close()
        pattern = re.compile(r'"[\w\W]*?"\u0001', re.DOTALL)
        res = pattern.sub(lambda x: x.group().replace('\n', ''), text)
     
        with open(out_file,'w',encoding="utf-8", newline="")as f:
            f.write(res)
        f.close()
       
if __name__ == '__main__':
    pull_files()
    print(datetime.now())


    # target='D:\\red\\data\\inbound\\salesforce\\archive'
    # original= 'D:\\red\\data\\inbound\\salesforce\\daily\\raw_' + datetime.now().strftime('%Y%m%d')
    # shutil.move(original,target)

