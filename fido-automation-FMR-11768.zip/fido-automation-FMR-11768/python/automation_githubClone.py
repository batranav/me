from send_email import *
import os
import platform
from git import Repo
from datetime import datetime
from github import GithubIntegration   
import parseYamlProperty
import commonArgs
from pathlib import Path
import get_vault_ssh

dt = datetime.now().strftime('%Y%m%d%H%M%S%f')  # datetime now (all in UTC)
dtstr = datetime.now().strftime('%m-%d-%Y_%H%M%S')
print(dtstr)
myApplication = commonArgs.getSource()  

def removeRsaKey(rsa_key_path):
    '''remove temporary rsa key file at rsa_key_path if it exists'''
    print(f"removing RSA key at {rsa_key_path}")
    try:
        if os.path.exists(rsa_key_path):
            os.chmod(rsa_key_path, 0o700)
            os.remove(rsa_key_path)
            print(f"RSA Key removed at {rsa_key_path}")
        else:
            print(f"No RSA Key found at {rsa_key_path}")
    except Exception as e:
        print(f"Error while removing RSA key at {rsa_key_path}. Error: {e}")

def get_github_token(github_owner, github_repo, app_id):
    '''returns github api auth token for provided repo, app, and ssh auth key'''
    try:
        # getting ssh key to connect to github api
        get_vault_ssh.get_ssh_key()
        # read the temp ssh key file
        rsa_key_path = parseYamlProperty.get_github_rsa_key_path()
        with open(rsa_key_path, "r") as secret:
            priv_key = secret.read()
        # remove the temp key
        removeRsaKey(rsa_key_path)
        # instantiate the github app object
        app = GithubIntegration(app_id, priv_key)
        # instantiate the github installation object
        installation = app.get_installation(github_owner, github_repo)
        # return the github api token
        return app.get_access_token(installation.id).token
    except Exception as e:
        print(f"Error retrieving github token. Error: {e}")

def pullRepo(repoName, gitToken, localRepoPath, owner):
    '''Pulls the repo using the provided token and local repo path'''
    try:
        # create the repo url with the token
        repo_url = f"https://x-access-token:{gitToken}@github.com/{owner}/{repoName}"
        # instantiate the local repo object
        _repo = Repo(localRepoPath)
        # Stash any changes
        _repo.git.stash('save')
        # reset remote using the new token
        o = _repo.remotes.origin
        o.set_url(repo_url)
        # Pull in changes
        o.pull()
        # _repo.git.stash('pop')
        return True
    except Exception as e:
        print(f"Error during git Pull {localRepoPath}. Error: {e}")
        return False

def ensure_dir(directory):
    '''Create a directory if it doesn't already exist'''
    if not os.path.exists(directory):
        os.makedirs(directory)

def process():
    try:
        # globals
        global dt, myApplication
        print(dt)  
        # base script path: where local code resides
        base_script_path = str(Path(parseYamlProperty.get_base_script_dir()).resolve())
        ensure_dir(base_script_path)

        # get github api token
        app_id = 137109 # GitHub App app-svc-fido-automation, #137109
        owner = "LexisNexis-RBA"  #os.getenv("GITHUB_OWNER")"
        repoName = "fido-automation"
        token = get_github_token(owner, repoName, app_id)
    except Exception as e:
        sendMail(f'{myApplication} - Error during git Pull')

    # stash any local changes and pull down updated code
    print("Pulling repo...")
    returncode = pullRepo(repoName, token, base_script_path, owner)
    print("Repo pull Sucess")

    strReturnCode = str(returncode)
    print('Whats my return code -- {0}'.format(strReturnCode))

    processInfo = []

    if not returncode:
        processInfo.append(strReturnCode)
        sendMail(processInfo)
        exit(1)


def sendMail(email_body) :
    servername = platform.node()

    EmailSubject = servername + '-- ' + myApplication +' GitHubPull - ' + dtstr 

    ErrorEmailSubject = 'ERROR / WARNING : ' + EmailSubject

    emailFrom = 'fido-' + myApplication + '-gitpull.automation@lexisnexisrisk.com'
    emailTo = ['fido.operations@lexisnexisrisk.com']
    emailCC = ['raju.nagarajan@lexisnexisrisk.com', 'brandon.wood11@lexisnexisrisk.com']

    send_mail(emailFrom,emailTo,emailCC,ErrorEmailSubject,'' + '\n'.join(email_body))


if __name__ == "__main__":
    start_time = datetime.now()
    process()
    print(f'All Done! - Finished in {(datetime.now() - start_time)}')