import json
import sys
from collections import namedtuple
import getProperties, traceback
MyS3Source = namedtuple('MyS3Source', ['mys3source', 'env', 'profile', 'bucket','process'])
ftp_file_name = getProperties.getS3JsonFilename()

def getSourcePullInfo(source, environment):

    jsonRef = json.load(open(ftp_file_name))
    MyS3SourceList = []
    for index in range(len(jsonRef)):
        for key in jsonRef[index]:
            if (key == source):
                src = jsonRef[index][key]
                for index2 in range(len(src)):
                    src2 = src[index2]
                    if(src2['env'] == environment):
                        process = 'inbound'
                        try:
                            process = src2['process']
                        except:
                            pass

                        MyS3SourceList.append(MyS3Source(source, src2['env'], src2['profile'], src2['bucket'], process))
                return [mysource for mysource in MyS3SourceList if mysource.process == 'inbound']

def getSourcePushInfo(source, environment):

    jsonRef = json.load(open(ftp_file_name))
    MyS3SourceList = []
    for index in range(len(jsonRef)):
        for key in jsonRef[index]:
            if (key == source):
                src = jsonRef[index][key]
                for index2 in range(len(src)):
                    src2 = src[index2]
                    if(src2['env'] == environment):
                        process = 'outbound'
                        try:
                            process = src2['process']
                        except:
                            pass

                        MyS3SourceList.append(MyS3Source(source, src2['env'], src2['profile'], src2['bucket'], process))
                return [mysource for mysource in MyS3SourceList if mysource.process == 'outbound']
if __name__ == "__main__":

    try:
        # S3pullJSONData = getSourcePullInfo('icisdashboard', 'prod')
        S3pushJSONData = getSourcePushInfo('icisdashboard', 'prod')
        # print(S3pullJSONData)
        print(S3pushJSONData)
        

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print(processerrorMsg)