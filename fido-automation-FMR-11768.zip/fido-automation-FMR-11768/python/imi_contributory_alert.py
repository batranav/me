import pandas as pd
import parseYamlProperty
import csv
import numpy as np
#import matplotlib as plt
from pandas import Timestamp
from datetime import datetime, timedelta
import time
#import papermill
import pyodbc
from sendEmail import *
import os

end_date = pd.to_datetime(datetime.today() - pd.DateOffset(months=2))
end_year_month =end_date.strftime('%Y%m')

start_year_month = 202001

path =''

printList = []
def printwrapper(str):
    print(str)
    printList.append(str)


def pull_all_data():
    success_flag = True
    thrownthing = None

    try :
       #end_date = pd.to_datetime(datetime.today() - pd.DateOffset(months=2))
        
        
       #end_year_month =end_date.strftime('%Y%m')
        
        server = 'ALAWPREDSQLCL1.RISK.REGN.NET,50750'
        database = 'red' # enter database name
        
        cnxn  = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=ALAWPREDSQLCL1.RISK.REGN.NET,50750;DATABASE=red;Trusted_Connection=yes;')
        cursor = cnxn.cursor()
        #start_year_month = 202001
        #%%time
        
        query1 = ''' 
        select * from fact_alert_contributory_seasonality
        ''';
        data1 = pd.read_sql(query1, cnxn)
        query = '''
        with base_pol_cte as (select e.year_month,e.ambest_sk, e.coverage_type_sk, e.policy_state_sk,a.groupname, a.shopgroup_sk,
        sum(e.cy_exposure) as earned_exposure
        from fact_imi_auto_policy_exposure e
        inner join dim_imi_ambest a on a.ambest_sk = e.ambest_sk
        where year_month >= {} and year_month <= {}
        group by e.year_month,e.ambest_sk,e.coverage_type_sk, e.policy_state_sk,a.groupname, a.shopgroup_sk),
        
        
        
        base_clm_wd_cte as (select w.year_month,w.ambest_sk,w.coverage_type_sk, w.policy_state_sk,w.window_sk,a.groupname, a.shopgroup_sk,
        sum(w.claim_reported_count) as claim_reported_count_window,
        sum(w.claim_paid_count) as paid_count_window,
        sum(w.claim_paid_closed_count) as claim_paid_closed_count_window, 
        sum(w.paid_closed_claim_amount) as paid_closed_claim_amount_window
        from fact_imi_auto_claim_window w
        left join dim_imi_ambest a on a.ambest_sk = w.ambest_sk
        where w.year_month >= {} and w.year_month <= {}
        group by w.year_month,w.ambest_sk,w.coverage_type_sk, w.policy_state_sk,w.window_sk,a.groupname, a.shopgroup_sk)
        
        
        select w.year_month,w.policy_state_sk, w.coverage_type_sk, w.shopgroup_sk, w.window_sk, s.shopgroup_name, C.coverage_desc, g.state_province_cd,
        sum(e.earned_exposure) as earned_exposure , 
        sum(w.claim_paid_closed_count_window) as claim_paid_closed_count_window, 
        sum(w.claim_reported_count_window) as claim_reported_count_window , 
        sum(paid_closed_claim_amount_window) as paid_closed_claim_amount_window,
        sum(w.paid_count_window) as paid_count_window
        from base_pol_cte e
        FULL OUTER JOIN base_clm_wd_cte w on w.ambest_sk = e.ambest_sk and w.coverage_type_sk = e.coverage_type_sk and w.policy_state_sk = e.policy_state_sk and w.shopgroup_sk = e.shopgroup_sk
        FULL OUTER JOIN dim_imi_auto_coverage_type c ON  w.coverage_type_sk = c.coverage_type_sk
        FULL OUTER JOIN  dim_geography_v g ON w.policy_state_sk = g.geography_sk
        FULL OUTER JOIN dim_imi_shopgroup S ON W.shopgroup_sk = s.shopgroup_sk
        where w.year_month >= {} and w.year_month <= {}
        and w.coverage_type_sk in (1,2,3,8,9)
        group by w.year_month,w.policy_state_sk, w.coverage_type_sk, w.shopgroup_sk,w.window_sk, s.shopgroup_name, c.coverage_desc, g.state_province_cd
        
        
        
        
        ''';
        #%%time
        query = query.format(start_year_month, end_year_month, start_year_month,end_year_month,start_year_month,end_year_month)
        data = pd.read_sql(query, cnxn)
        data.head()
        cnxn.close()  
        data.shape
        data['window_sk'].value_counts()
        min(data['year_month'])
        max(data['year_month'])
        data.head()
        
        
        
        season_closed_counts = {
            'Bodily Injury':   {'01': 1, '02': .97, '03': 1.08, '04': 1.06, '05': 1.1,  '06': 1.02, '07': 1.00, '08': 1.10, '09': 1.10, '10': 1.19, '11': 1.10, '12': 1.10},
            'Collision':       {'01': 1, '02': .94, '03': 0.99, '04': 0.94, '05': 0.98, '06': 0.95, '07': 0.97, '08':  .99, '09': 0.96, '10': 1.01, '11': 0.93, '12': 1.0},
            'Comprehensive':   {'01': 1, '02': .94, '03': 1.25, '04': 1.28, '05': 1.38, '06': 1.36, '07': 1.29, '08': 1.23, '09': 1.08, '10': 1.20, '11': 1.14, '12': 1.0},
            'Property Damage': {'01': 1, '02': .97, '03': 1.06, '04': 1.04, '05': 1.07, '06': 1.02, '07': 1.02, '08': 1.07, '09': 1.04, '10': 1.08, '11': 0.97, '12': 1.02},
        'Personal Injury Protection': {'01': 1, '02': .93, '03': 1.02, '04': 1.00, '05': 1.07, '06': 1.00, '07': 1.02, '08': 1.06, '09': 1.05, '10': 1.08, '11': 1.09, '12': 1.1}}
        data['month'] = data['year_month'].astype(str).apply(lambda x: x[-2:])
        season_closed_counts['Bodily Injury']['01']
        season_closed_counts[data['coverage_desc'][0]][data['month'][0]]
        adj_closed_counts = []
        for i in range(5):
            adj = round(data['claim_paid_closed_count_window'][i] / season_closed_counts[data['coverage_desc'][i]][data['month'][i]],2)
            adj_closed_counts.append(adj)
        adj_closed_counts
        adj_closed_counts = []
        for i in range(data.shape[0]):
            adj = round(data['claim_paid_closed_count_window'][i] / season_closed_counts[data['coverage_desc'][i]][data['month'][i]],2)
            adj_closed_counts.append(adj)
        data['adj_closed_counts'] = adj_closed_counts
        season_reported_counts = {
            'Bodily Injury':   {'01': 1, '02': .96, '03': 1.08, '04': 1.08, '05': 1.14, '06': 1.08, '07': 1.06, '08': 1.14, '09': 1.13, '10': 1.23, '11': 1.13, '12': 1.13},
            'Collision':       {'01': 1, '02': .95, '03':  1.02,'04': 1.00, '05': 1.06, '06': 1.03, '07': 1.04, '08': 1.08, '09': 1.04, '10': 1.10, '11': 1.03, '12': 1.08},
            'Comprehensive':   {'01': 1, '02': .95, '03': 1.24, '04': 1.29, '05': 1.41, '06': 1.39, '07': 1.32, '08': 1.30, '09': 1.13, '10': 1.23, '11': 1.17, '12': 1.03},
            'Property Damage': {'01': 1, '02': .96, '03': 1.06, '04': 1.06, '05': 1.13, '06': 1.08, '07': 1.08, '08': 1.13, '09': 1.10, '10': 1.17, '11': 1.09, '12': 1.13},
        'Personal Injury Protection': {'01': 1, '02': .93, '03': 1.02, '04': 1.00, '05': 1.08, '06': 1.03, '07': 1.02, '08': 1.06, '09': 1.05, '10': 1.15, '11': 1.08, '12': 1.10}}
        adj_reported_counts = []
        for i in range(data.shape[0]):
            adj = round(data['claim_reported_count_window'][i] / season_reported_counts[data['coverage_desc'][i]][data['month'][i]],2)
            adj_reported_counts.append(adj)
        data['adj_reported_counts'] = adj_reported_counts
        df = pd.DataFrame(data['year_month'].tolist(), columns = ['year_month_list']) 
        df['year_month_str'] = df['year_month_list'].astype(str) 
        df['year_month_format'] = df['year_month_str'].apply(lambda x: datetime.strptime(x, '%Y%m'))
        data['year_month_format'] = df['year_month_format']
        max_date = max(data['year_month_format'])
        data['max_date'] = max_date
        print(max_date)
        def month_diff(a, b):
            return 12 * (a.dt.year - b.dt.year) + (a.dt.month - b.dt.month)
        months_diff = month_diff(data['max_date'], data['year_month_format'])
        data['months_diff'] = months_diff
        prior = ['Prior-Month-']*data.shape[0]    
        date_reverse_str = months_diff.astype(str)        
        data['month_label'] = prior + date_reverse_str
        data['month_label'] [data['month_label'] =='Prior-Month-0'] = 'Current-Month'
        data['month_label'].value_counts()
        data['year_month_format'].value_counts()
        
        cols = [
        'year_month_format',
        'month_label',
        'claim_reported_count_window',
        'paid_closed_claim_amount_window',
        'claim_paid_closed_count_window',
        'adj_reported_counts',
        'adj_closed_counts',
        'earned_exposure',
        'policy_state_sk',
        'coverage_type_sk',
        'shopgroup_sk',
        'window_sk',
        'shopgroup_name',
        'coverage_desc',
        'state_province_cd']
        data2 = data[cols]
        
        zero_claims= data2[(data2['paid_closed_claim_amount_window'] ==0) ]
        zero_claims.shape
        print('The percent of the claims have either $0 claim amount or 0 claim count',round(len(zero_claims) / len(data2) *100,0),'%')
        
        
        good_data = data2[(data2['paid_closed_claim_amount_window'] >0) & (data2['claim_paid_closed_count_window'] >0)]
        good_data.shape
        Current_Month_units = pd.DataFrame(good_data[good_data['month_label'] == 'Current-Month'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                    margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts', 'earned_exposure'],
                        aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        Current_Month_units.columns= [ 'claim_paid_closed_count_window_cur_mos','claim_reported_count_window_cur_mos', 'earned_exposure_cur_mos','paid_closed_claim_amount_window_cur_mos']
        Current_Month_units['paid_closed_severity_window_cur_mos'] =  Current_Month_units['paid_closed_claim_amount_window_cur_mos']/Current_Month_units['claim_paid_closed_count_window_cur_mos']
        Current_Month_units['reported_frequency_window_cur_mos'] =  Current_Month_units['claim_reported_count_window_cur_mos']/Current_Month_units['earned_exposure_cur_mos']
        prior_month1_units = pd.DataFrame(good_data[good_data['month_label'] == 'Prior-Month-1'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                        margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts','earned_exposure'],
                    aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        prior_month1_units
        prior_month1_units.columns= ['claim_paid_closed_count_window_prior_1mos', 'claim_reported_count_window_prior_1mos','earned_exposure_prior_1mos','paid_closed_claim_amount_prior_1mos']
        prior_month1_units['paid_closed_severity_window_prior_1mos'] =  prior_month1_units['paid_closed_claim_amount_prior_1mos']/prior_month1_units['claim_paid_closed_count_window_prior_1mos']
        prior_month1_units['reported_frequency_window_prior_1mos'] =  prior_month1_units['claim_reported_count_window_prior_1mos']/prior_month1_units['earned_exposure_prior_1mos']
        prior_month2_units = pd.DataFrame(good_data[good_data['month_label'] == 'Prior-Month-2'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                        margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts','earned_exposure'],
                    aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        prior_month2_units.columns= ['claim_paid_closed_count_window_prior_2mos', 'claim_reported_count_window_prior_2mos','earned_exposure_prior_2mos','paid_closed_claim_amount_prior_2mos']
        prior_month2_units['paid_closed_severity_window_prior_2mos'] =  prior_month2_units['paid_closed_claim_amount_prior_2mos']/prior_month2_units['claim_paid_closed_count_window_prior_2mos']
        prior_month2_units['reported_frequency_window_prior_2mos'] =  prior_month2_units['claim_reported_count_window_prior_2mos']/prior_month2_units['earned_exposure_prior_2mos']
        prior_month3_units = pd.DataFrame(good_data[good_data['month_label'] == 'Prior-Month-3'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                        margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts','earned_exposure'],
                    aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        prior_month3_units.columns= ['claim_paid_closed_count_window_prior_3mos', 'claim_reported_count_window_prior_3mos','earned_exposure_prior_3mos','paid_closed_claim_amount_prior_3mos']
        prior_month3_units['paid_closed_severity_window_prior_3mos'] =  prior_month3_units['paid_closed_claim_amount_prior_3mos']/prior_month3_units['claim_paid_closed_count_window_prior_3mos']
        prior_month3_units['reported_frequency_window_prior_3mos'] =  prior_month3_units['claim_reported_count_window_prior_3mos']/prior_month3_units['earned_exposure_prior_3mos']
        prior_month4_units = pd.DataFrame(good_data[good_data['month_label'] == 'Prior-Month-4'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                        margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts','earned_exposure'],
                    aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        prior_month4_units.columns= ['claim_paid_closed_count_window_prior_4mos', 'claim_reported_count_window_prior_4mos','earned_exposure_prior_4mos','paid_closed_claim_amount_prior_4mos']
        prior_month4_units['paid_closed_severity_window_prior_4mos'] =  prior_month4_units['paid_closed_claim_amount_prior_4mos']/prior_month4_units['claim_paid_closed_count_window_prior_4mos']
        prior_month4_units['reported_frequency_window_prior_4mos'] =  prior_month4_units['claim_reported_count_window_prior_4mos']/prior_month4_units['earned_exposure_prior_4mos']
        prior_month5_units = pd.DataFrame(good_data[good_data['month_label'] == 'Prior-Month-5'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                        margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts','earned_exposure'],
                    aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        prior_month5_units.columns= ['claim_paid_closed_count_window_prior_5mos', 'claim_reported_count_window_prior_5mos','earned_exposure_prior_5mos','paid_closed_claim_amount_prior_5mos']
        prior_month5_units['paid_closed_severity_window_prior_5mos'] =  prior_month5_units['paid_closed_claim_amount_prior_5mos']/prior_month5_units['claim_paid_closed_count_window_prior_5mos']
        prior_month5_units['reported_frequency_window_prior_5mos'] =  prior_month5_units['claim_reported_count_window_prior_5mos']/prior_month5_units['earned_exposure_prior_5mos']
        prior_month6_units = pd.DataFrame(good_data[good_data['month_label'] == 'Prior-Month-6'].pivot_table(index=['policy_state_sk','coverage_type_sk','shopgroup_sk','window_sk','shopgroup_name','coverage_desc','state_province_cd'],
                        margins=False,
                    #margins_name='total',  # defaults to 'All'
                        values=['paid_closed_claim_amount_window','adj_closed_counts','adj_reported_counts','earned_exposure'],
                    aggfunc={'paid_closed_claim_amount_window':np.sum,
                            'adj_closed_counts':np.sum,
                                'adj_reported_counts':np.sum,
                                'earned_exposure':np.sum}))
        prior_month6_units.columns= ['claim_paid_closed_count_window_prior_6mos', 'claim_reported_count_window_prior_6mos','earned_exposure_prior_6mos','paid_closed_claim_amount_prior_6mos']
        prior_month6_units['paid_closed_severity_window_prior_6mos'] =  prior_month6_units['paid_closed_claim_amount_prior_6mos']/prior_month6_units['claim_paid_closed_count_window_prior_6mos']
        prior_month6_units['reported_frequency_window_prior_6mos'] =  prior_month6_units['claim_reported_count_window_prior_6mos']/prior_month6_units['earned_exposure_prior_6mos']
        frames = [Current_Month_units, prior_month1_units, prior_month2_units, prior_month3_units,prior_month4_units,prior_month5_units, prior_month6_units]
        result = pd.concat(frames,axis=1, sort=False)
        
        result2 = pd.DataFrame(result).fillna(0)
        result2.head()
        final_result = result2
        
        final_result['avg_severity_6mos'] =  final_result[['paid_closed_severity_window_prior_1mos',
                                                        'paid_closed_severity_window_prior_2mos',
                                                        'paid_closed_severity_window_prior_3mos',
                                                        'paid_closed_severity_window_prior_4mos',
                                                        'paid_closed_severity_window_prior_5mos',
                                                        'paid_closed_severity_window_prior_6mos']].mean(axis=1)
        final_result['std_severity_6mos'] = final_result[['paid_closed_severity_window_prior_1mos',
                                                        'paid_closed_severity_window_prior_2mos',
                                                        'paid_closed_severity_window_prior_3mos',
                                                        'paid_closed_severity_window_prior_4mos', 
                                                        'paid_closed_severity_window_prior_5mos',
                                                        'paid_closed_severity_window_prior_6mos']].std(axis=1)
                                                        
        final_result['severity_threshold_up'] = final_result['avg_severity_6mos'] + 7*final_result['std_severity_6mos']
        severity_threshold_low = final_result['avg_severity_6mos'] - 5*final_result['std_severity_6mos']
        final_result['severity_threshold_low'] = severity_threshold_low.apply(lambda x: 0 if x < 0 else x)
        
        final_result['avg_freq_6mos'] =  final_result[['reported_frequency_window_prior_1mos',
        'reported_frequency_window_prior_2mos',
        'reported_frequency_window_prior_3mos',
        'reported_frequency_window_prior_4mos',
        'reported_frequency_window_prior_5mos',
        'reported_frequency_window_prior_6mos']].mean(axis=1)
        final_result['std_freq_6mos'] =  final_result[['reported_frequency_window_prior_1mos',
        'reported_frequency_window_prior_2mos',
        'reported_frequency_window_prior_3mos',
        'reported_frequency_window_prior_4mos',
        'reported_frequency_window_prior_5mos',
        'reported_frequency_window_prior_5mos',
        'reported_frequency_window_prior_6mos']].std(axis=1)
        final_result['freq_threshold_up'] = final_result['avg_freq_6mos'] + 5*final_result['std_freq_6mos']
        freq_threshold_low = final_result['avg_freq_6mos'] - 5*final_result['std_freq_6mos']
        final_result['freq_threshold_low'] = freq_threshold_low.apply(lambda x: 0 if x < 0 else x)
        
        final_result['sum_report_counts_6mos'] = final_result[['claim_reported_count_window_prior_1mos',
                                                            'claim_reported_count_window_prior_2mos',
                                                            'claim_reported_count_window_prior_3mos',
                                                            'claim_reported_count_window_prior_4mos',
                                                            'claim_reported_count_window_prior_5mos',
                                                            'claim_reported_count_window_prior_6mos']].sum(axis=1)
        final_result['avg_report_counts_6mos'] = final_result[['claim_reported_count_window_prior_1mos',
                                                            'claim_reported_count_window_prior_2mos',
                                                            'claim_reported_count_window_prior_3mos',
                                                            'claim_reported_count_window_prior_4mos',
                                                            'claim_reported_count_window_prior_5mos',
                                                            'claim_reported_count_window_prior_6mos']].mean(axis=1)
        final_result['std_report_counts_6mos'] = final_result[['claim_reported_count_window_prior_1mos',
                                                            'claim_reported_count_window_prior_2mos',
                                                            'claim_reported_count_window_prior_3mos',
                                                            'claim_reported_count_window_prior_4mos',
                                                            'claim_reported_count_window_prior_5mos',
                                                            'claim_reported_count_window_prior_6mos']].std(axis=1)
        final_result['report_counts_threshold_up'] = final_result['avg_report_counts_6mos'] + 5*final_result['std_report_counts_6mos'] 
        report_counts_threshold_low= final_result['avg_report_counts_6mos'] - 5*final_result['std_report_counts_6mos'] 
        final_result['report_counts_threshold_low'] = report_counts_threshold_low.apply(lambda x: 0 if x < 0 else x)
        
        
        final_result['sum_closed_counts_6mos'] =  final_result[['claim_paid_closed_count_window_prior_1mos', 
        'claim_paid_closed_count_window_prior_2mos', 
        'claim_paid_closed_count_window_prior_3mos', 
        'claim_paid_closed_count_window_prior_4mos', 
        'claim_paid_closed_count_window_prior_5mos',
        'claim_paid_closed_count_window_prior_6mos']].sum(axis=1)
        final_result['avg_closed_counts_6mos'] =  final_result[['claim_paid_closed_count_window_prior_1mos', 
        'claim_paid_closed_count_window_prior_2mos', 
        'claim_paid_closed_count_window_prior_3mos', 
        'claim_paid_closed_count_window_prior_4mos', 
        'claim_paid_closed_count_window_prior_5mos',
        'claim_paid_closed_count_window_prior_6mos']].mean(axis=1)
        final_result['std_closed_counts_6mos'] =  final_result[['claim_paid_closed_count_window_prior_1mos', 
        'claim_paid_closed_count_window_prior_2mos', 
        'claim_paid_closed_count_window_prior_3mos', 
        'claim_paid_closed_count_window_prior_4mos', 
        'claim_paid_closed_count_window_prior_5mos',
        'claim_paid_closed_count_window_prior_6mos']].std(axis=1)
        final_result['closed_counts_threshold_up'] = final_result['avg_closed_counts_6mos'] + 5*final_result['std_closed_counts_6mos'] 
        closed_counts_threshold_low= final_result['avg_closed_counts_6mos'] - 5*final_result['std_closed_counts_6mos'] 
        final_result['closed_counts_threshold_low'] = closed_counts_threshold_low.apply(lambda x: 0 if x < 0 else x)
        ## Add shift attribute to check the flutuate percentage 
        final_result['severity_shift'] = (final_result['paid_closed_severity_window_cur_mos'] - final_result['avg_severity_6mos'])/final_result['avg_severity_6mos']
        final_result['reported_frequency_shift'] = (final_result['reported_frequency_window_cur_mos'] - final_result['avg_freq_6mos'])/final_result['avg_freq_6mos']
        final_result['report_counts_shift'] = (final_result['claim_reported_count_window_cur_mos'] - final_result['avg_report_counts_6mos'])/final_result['avg_report_counts_6mos']
        final_result['closed_counts_shift'] = (final_result['claim_paid_closed_count_window_cur_mos'] - final_result['avg_closed_counts_6mos'])/final_result['avg_closed_counts_6mos']
        
        #final_result[['reported_frequency_window_cur_mos','claim_reported_count_window_cur_mos' ,'avg_freq_6mos','avg_report_counts_6mos', 'reported_frequency_shift','report_counts_shift' ]]
        #final_result[['earned_exposure_prior_6mos', 'earned_exposure_prior_5mos', 'earned_exposure_prior_4mos', 'earned_exposure_prior_3mos','earned_exposure_prior_2mos', 'earned_exposure_prior_1mos']]
        round(final_result[['sum_closed_counts_6mos','sum_report_counts_6mos']].describe(), 2)
        sum_closed_counts_6mos_median = final_result[['sum_closed_counts_6mos']].median()[0]
        sum_closed_counts_6mos_mean = final_result[['sum_closed_counts_6mos']].mean()[0]*0.5
        sum_report_counts_6mos_mean = final_result[['sum_report_counts_6mos']].mean()[0]*0.5
        sum_report_counts_6mos_median = final_result[['sum_report_counts_6mos']].median()[0]
        
        good_result  = final_result[(final_result['sum_closed_counts_6mos'] >sum_closed_counts_6mos_mean) & (final_result['sum_report_counts_6mos'] >sum_closed_counts_6mos_mean)]
        #good_result  = final_result[(final_result['sum_closed_counts_6mos'] >sum_closed_counts_6mos_median) & (final_result['sum_report_counts_6mos'] >sum_report_counts_6mos_median)]
        
        good_final_result = good_result.reset_index()
        
        closed_counts_alerts = []
        for i in range(len(good_final_result)):
            if good_final_result['claim_paid_closed_count_window_cur_mos'][i] > good_final_result['closed_counts_threshold_up'][i] :
                results = 'high-closed-counts-alerts'
            elif (good_final_result['claim_paid_closed_count_window_cur_mos'][i] < good_final_result['closed_counts_threshold_low'][i]) & (good_final_result['claim_paid_closed_count_window_cur_mos'][i] >0):
                results = 'low-closed-counts-alerts'
            elif (good_final_result['claim_paid_closed_count_window_cur_mos'][i] == 0):
                results = 'zero-closed-counts-alerts'
            else:
                results = 'no-alerts'
            closed_counts_alerts.append(results)
        good_final_result['closed_counts_alerts'] = closed_counts_alerts
        good_final_result['closed_counts_alerts'].value_counts()
        reported_counts_alerts = []
        for i in range(len(good_final_result)):
            if good_final_result['claim_reported_count_window_cur_mos'][i] > good_final_result['report_counts_threshold_up'][i] :
                results = 'high-reported-counts-alerts'
            elif (good_final_result['claim_reported_count_window_cur_mos'][i] < good_final_result['report_counts_threshold_low'][i]) & (good_final_result['claim_reported_count_window_cur_mos'][i] >0):
                results = 'low-reported-counts-alerts'
            elif (good_final_result['claim_reported_count_window_cur_mos'][i] == 0):
                results = 'zero-reported-counts-alerts'
            else:
                results = 'no-alerts'
            reported_counts_alerts.append(results)
        good_final_result['reported_counts_alerts'] = reported_counts_alerts
        good_final_result['reported_counts_alerts'].value_counts()
        severity_alerts = []
        for i in range(len(good_final_result)):
            if good_final_result['paid_closed_severity_window_cur_mos'][i] > good_final_result['severity_threshold_up'][i] :
                results = 'high-severity-alerts'
            elif (good_final_result['paid_closed_severity_window_cur_mos'][i] < good_final_result['severity_threshold_low'][i]) & (good_final_result['paid_closed_severity_window_cur_mos'][i] >0):
                results = 'low-severity-alerts'
            elif (good_final_result['paid_closed_severity_window_cur_mos'][i] == 0):
                results = 'zero-severity-alerts'
            else:
                results = 'no-alerts'
            severity_alerts.append(results)
        good_final_result['severity_alerts'] = severity_alerts
        good_final_result['severity_alerts'].value_counts()
        freq_alerts = []
        for i in range(len(good_final_result)):
            if good_final_result['reported_frequency_window_cur_mos'][i] > good_final_result['freq_threshold_up'][i] :
                results = 'high-freq-alerts'
            elif (good_final_result['reported_frequency_window_cur_mos'][i] < good_final_result['freq_threshold_low'][i]) & (good_final_result['reported_frequency_window_cur_mos'][i] >0):
                results = 'low-freq-alerts'
            elif (good_final_result['reported_frequency_window_cur_mos'][i] == 0):
                results = 'zero-freq-alerts'
            else:
                results = 'no-alerts'
            freq_alerts.append(results)
        good_final_result['frequency_alerts'] = freq_alerts
        good_final_result['frequency_alerts'].value_counts()
        only_alerts = good_final_result[~((good_final_result['reported_counts_alerts'] == 'no-alerts')& (good_final_result['closed_counts_alerts'] == 'no-alerts') & (good_final_result['frequency_alerts'] == 'no-alerts') & (good_final_result['severity_alerts'] == 'no-alerts') & (good_final_result['closed_counts_alerts'] == 'no-alerts')) ]
        good_final_result = only_alerts
        
        good_final_result['alert_year_month'] = str(end_year_month)
        good_final_result.shape
        good_final_result.replace([np.inf, -np.inf], np.nan, inplace = True)
        good_final_result.fillna(0, inplace=True)
        # good_final_result.to_csv('/home/autumn/contributory/data_results/good_results.csv', sep='\t', encoding='utf-8')
        # for col in good_final_result:
        #     print(col)
        
        contributory = good_final_result.drop(['shopgroup_name', 'coverage_desc', 'state_province_cd'], axis = 1)
        contributory.to_csv(parseYamlProperty.get_outbound_dir() +'\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality_'+str(end_year_month)+'.tsv', sep="\t",header=False, index=False)
        print("File created succesfully")
        
        data1.to_csv(parseYamlProperty.get_outbound_dir() +'\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality_all.tsv', sep="\t",header=False, index=False)

        with open('D:\\red\\data\\outbound\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality_all.tsv') as fp:
            data = fp.read()
        ## Reading data from file2
        with open('D:\\red\\data\\outbound\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality_'+str(end_year_month)+'.tsv') as fp:
            data2 = fp.read()
        data += "\n"
        data += data2
        with open ('D:\\red\\data\\outbound\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality.tsv', 'w') as fp:
            fp.write(data)
        
        os.remove('D:\\red\\data\\outbound\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality_all.tsv')
        os.remove('D:\\red\\data\\outbound\\sql\\dm\\imi_alert\\fact_alert_contributory_seasonality_'+str(end_year_month)+'.tsv')
        
        success_flag = True
        thrownthing = None
        

    except Exception as ex:
        printwrapper('Exception raised : {0}'.format(ex))
        success_flag = False
        thrownthing = ex
        
    finally:
        printwrapper('**********')
        printwrapper('All Done!')
        printwrapper('**********')
        email_subject = 'IMI Contributory Alert from ' + str(start_year_month)  + ' to ' + str(end_year_month)
        email_from    =  'FIDO-Alerts@lexisnexis.com'
        email_to      = 'vishal.borhade@lexisnexisrisk.com,abhishek.shrivastav@lexisnexisrisk.com'
        if success_flag:
            subject = 'Success: ' + email_subject
        else:
            subject = 'ERROR / WARNING: ' + email_subject
        #send_email.send_mail(email_from, email_to, '', subject, '' + '')
        send(email_from, email_to, '', subject, '' + '\n'.join(printList))
        if thrownthing:
            raise thrownthing
            
if __name__ == '__main__':
    pull_all_data()