import gzip
import json
import os
import re
import sys
import traceback
import urllib.parse
import urllib.request
from datetime import datetime
import pandas as pd
import requests

import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret

currentdate = datetime.today().strftime("%Y%m%d")

json_folder = parseYamlProperty.get_inbound_dir() + "\\infosec\\importFiles"
csv_folder = parseYamlProperty.get_inbound_dir() + "\\infosec\\importFiles\\csv"

def getToken():
    logger = AutomationLogging.getLogger('preprocess_pull_msdefender_es')
    tenantId = get_api_secret(logger, 'msdefender_tenantId', secret='pwd')
    appId = get_api_secret(logger, 'msdefender_appId', secret='pwd')
    appSecret = get_api_secret(logger, 'msdefender_appSecret', secret='pwd')
    url = "https://login.microsoftonline.com/%s/oauth2/token" % (tenantId)
    
    resourceAppIdUri = "https://api.securitycenter.microsoft.com"
    
    body = {
        "resource": resourceAppIdUri,
        "client_id": appId,
        "client_secret": appSecret,
        "grant_type": "client_credentials",
    }
    
    data = urllib.parse.urlencode(body).encode("utf-8")
    
    req = urllib.request.Request(url, data)
    response = urllib.request.urlopen(req)
    jsonResponse = json.loads(response.read())
    aadToken = jsonResponse["access_token"]
    return aadToken


def getData(endpoint, header):
    endpoint_request = urllib.request.Request(endpoint, None, header)
    endpoint_response = urllib.request.urlopen(endpoint_request)
    endpoint_jsonResponse = json.loads(endpoint_response.read())
    return endpoint_jsonResponse


def json_to_csv(in_dir, out_dir):
    if os.stat(in_dir).st_size == 0:
        open(out_dir, "w")
    df = pd.read_json(in_dir)
    p = re.compile(r"(\r|\n|\r\n|\n\r|\t)")
    for i in df.columns:
        df[i] = [p.sub('', str(x)) for x in df[i].tolist()]
    df.to_csv(out_dir, index=False)


def process(token):
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Bearer " + token,
    }
    endpoints = [
        ("https://api.securitycenter.microsoft.com/api/exposurescore", "exposure_score"),
        ("https://api.securitycenter.microsoft.com/api/exposureScore/ByMachineGroups", "exposure_score_by_machine_groups")
    ]    

    for eachendpoint in endpoints:
        jsonresp = getData(eachendpoint[0], header)

        while("@odata.nextLink" in jsonresp.keys()):
            newresp = getData(jsonresp.pop("@odata.nextLink"), header)
            newresp["value"].extend(jsonresp["value"])
            jsonresp = newresp

        jsonFilename = os.path.join(json_folder, eachendpoint[1] + "_" + currentdate + ".json")

        with open(jsonFilename, "w", encoding="utf-8") as a_file:
            if eachendpoint[1] == "exposure_score":
                # Remove the odata column
                jsonresp.pop("@odata.context")
                # Write the json string to the json file
                a_file.write("[" + json.dumps(jsonresp) + "]")
            else:
                a_file.write(json.dumps(jsonresp["value"]))
        a_file.close()

        csvFilename = os.path.join(csv_folder, eachendpoint[1] + "_" + currentdate + ".csv")
        json_to_csv(jsonFilename, csvFilename)


if __name__ == "__main__":
    try:
        if not os.path.isdir(json_folder):
            os.mkdir(json_folder)
        if not os.path.isdir(csv_folder):
            os.mkdir(csv_folder)
        token = getToken()
        process(token)
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print("\n\n{0}".format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = "".join(line for line in lines)
        print(processerrorMsg)
