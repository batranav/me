import shutil
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-file', '--file_name', help='file name', required=True)
parser.add_argument('-source_path', '--source_path', help='source path', required=True)
parser.add_argument('-dest', '--dest', help='destination path', required=True)
args = parser.parse_args()
file_name = args.file_name  
source = os.path.normpath(args.source_path)
destination = args.dest
print('Inside File copy function')
print(file_name)
print(source)
print(destination)
try:
    shutil.copy(os.path.join(source,file_name),destination)
    print('File copied from LZ to shared drive')

except Exception as ex:
    print("Files not copied")
    print(ex)