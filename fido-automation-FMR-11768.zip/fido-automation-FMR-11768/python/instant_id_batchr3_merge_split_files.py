import gzip
import time
import zipfile
import shutil
import re
import io
import os
import glob
import subprocess
from subprocess import Popen, PIPE
import shutil
from os.path import isfile, join
from os import listdir
import fido_utils
import parseYamlProperty
from csv import writer
from csv import reader
import redSourceInfo
import commonArgs

def get_date_list(freqfolder):

    datelist = []
    #files = os.listdir(freqfolder)
    files = [f for f in os.listdir(freqfolder) if os.path.isfile(os.path.join(freqfolder, f))]
    for file in files:
        if os.path.splitext(file)[-1].lower() == '.dat':
            filenamewithoutextn = os.path.splitext(file)[0]
            revfilename = filenamewithoutextn[::-1]
            daterev = revfilename[0:8]
            date = daterev[::-1]
            if date not in datelist:
                datelist.append(date)
    return datelist

def add_column_in_csv(input_file, output_file, transform_row):
    """ Append a column in existing csv using csv.reader / csv.writer classes"""
    # Open the input_file in read mode and output_file in write mode
    with open(input_file, 'r') as read_obj, \
            open(output_file, 'w', newline='') as write_obj:
        # Create a csv.reader object from the input file object
        csv_reader = reader(read_obj,delimiter='|')
        # Create a csv.writer object from the output file object
        csv_writer = writer(write_obj,delimiter='|')
        # Read each row of the input csv file as list
        for row in csv_reader:
            # Pass the list / row in the transform function to add column text for this row
            transform_row(row, csv_reader.line_num)
            # Write the updated row / list to the output file
            csv_writer.writerow(row)

            
def mergesplitparts(redsourcefiles, source, frequency):
    inbounddir = parseYamlProperty.get_inbound_dir(source) + source + '\\'
    
    freqfolder = inbounddir + '\\' + frequency
    print('Source Folder is {0} : '.format(freqfolder))
    source_dir = freqfolder#inbounddir# + '\\' + frequency + '\\' + '2017' #today[0:4] 
    print('date to be processed : ')
    print(get_date_list(freqfolder))
    #todaydate = date_list[1]
    for today in get_date_list(freqfolder):
        print(today)
        #today =  '20200828'#fido_utils.today
        workingfolder = inbounddir + '\\' + frequency + '\\working\\' + today
        archivefolder = inbounddir + '\\' + frequency + '\\archived\\' + today
        incomingfolder = inbounddir + '\\' + frequency + '\\incoming\\' + today
        tempfolder = inbounddir + '\\' + frequency + '\\temp\\' + today
        sourcefiles = []
        sourcefilesnew = []
        sourcefilesnewmanifest = []
        #files1 = os.listdir(source_dir)
        files = [f for f in os.listdir(source_dir) if os.path.isfile(os.path.join(source_dir, f))]
        print(files)
        for file in files:
            if os.path.splitext(file)[-1].lower() in ['.dat','.txt']:
                sourcefiles.append(file)
                if os.path.splitext(file)[-1].lower() in ['.dat']:
                    sourcefilesnew.append(os.path.splitext(file)[0]+".dat")
                else:
                    sourcefilesnewmanifest.append(os.path.splitext(file)[0]+".txt")
                os.makedirs(incomingfolder, exist_ok=True)
                os.makedirs(workingfolder, exist_ok=True)
                os.makedirs(tempfolder, exist_ok=True)
                shutil.move(os.path.join(source_dir, file),os.path.join(incomingfolder, os.path.splitext(file)[0]+".dat"))
            else:
                continue
          
        #filenames = ['iid_archiving_ciid_delta_report']
        filename = 'iid_archiving_ciid_delta_report'
        for x in range(0, len(sourcefilesnew)):
                if sourcefilesnew[x].lower().find(filename.lower()) >= 0:
                     default_text = sourcefilesnew[x] 
                     header_of_new_col = 'file_name'
                     add_column_in_csv(os.path.join(incomingfolder, sourcefilesnew[x] ),
                                   os.path.join(tempfolder, sourcefilesnew[x] ), 
                                   lambda row, 
                                   line_num: row.append(header_of_new_col) if line_num == 1 else row.append(default_text)
                                   )
                 

        read_files = glob.glob(tempfolder+"//*iid_archiving_ciid_delta_report_daily*.dat")

        header_saved = False

        with open(freqfolder+"//"+"iid_archiving_combined_delta_report_daily"+"_"+today+".dat", "wb") as outfile:
            for f in read_files:
                with open(f, "rb") as infile:
                    header =  next(infile)
                    if not header_saved:
                        outfile.write(header)
                        header_saved = True
                    outfile.write(infile.read())

        read_files_manifest = glob.glob(incomingfolder+"//*iid_archiving_manifest_daily*.dat")
        print(read_files_manifest)

        header_saved_manifest = False

        with open(freqfolder+"//"+"iid_archiving_manifest_daily"+"_"+today+".txt", "wb") as outfile:
            for f in read_files_manifest:
                with open(f, "rb") as infile:
                    header =  next(infile)
                    if not header_saved_manifest:
                        outfile.write(header)
                        header_saved_manifest = True
                    outfile.write(infile.read()) 

        #combinedfiles = [f for f in os.listdir(source_dir) if os.path.isfile(os.path.join(source_dir, f))]
        #print(combinedfiles)
        #for combinedfile in combinedfiles:
        #    print(os.path.splitext(combinedfile)[0])
        #    if os.path.splitext(combinedfile)[0].find(today) != -1:
        #        shutil.move(os.path.join(source_dir, combinedfile),os.path.join(workingfolder, combinedfile))
        #    else:
        #        continue

def main():
    source = 'instant_id'
    frequency = 'daily'
    #source = args.source
    #frequency = args.frequency
    redsourcefiles = redSourceInfo.getPushOptionalFeedFiles('instant_id_boca_batch', frequency)
    print(redsourcefiles)
    mergesplitparts(redsourcefiles,
                    source,frequency)  

if __name__ == "__main__":
    try:
        main()   
    except Exception as ex:
        print('Exception raised : {0}'.format(ex))
        success_flag = False
        thrownthing = ex