class WorkunitInfo(object):
    workunit = ""
    state = ""
    flag = False
    message = ""
    results = ""
    searchInput = ""
    
    def __init__(self, _workunit):
        self.workunit = _workunit
        self.state = ""
        self.flag = False
        self.message = ""
        self.results = ""
        self.searchInput = ""
    
    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 

    def __lt__(self, other):
        return self.workunit < other.workunit
