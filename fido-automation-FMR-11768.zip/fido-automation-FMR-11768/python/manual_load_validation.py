import os
import sys
import json
import time
import math
import random
import shutil 
import openpyxl
import commonArgs
import sqlalchemy
import pandas as pd

from fido_utils import *
from datetime import datetime
from AutomationLogging import getLogger
from vault.secrets import get_api_secret
from dateutil.relativedelta import relativedelta
from manual_load_send_email import send_to_teams_channel


global env
env = commonArgs.getEnv()


class Validation():
    workbook = None
    txt_content = None
    current_sheet = 'N/A'
    errors_occurred = False
    validation_passed = True
    df = debug_df = temp_debug_df = report_df = report_value_df = pd.DataFrame()

    def __init__(self, **kwargs):
        self.teams_webhook_path=kwargs['teams_webhook_path']
        self.file_path = kwargs['file_path']
        self.source_path = kwargs['source_path']
        self.engine: sqlalchemy = kwargs['engine']
        self.json_file_path = kwargs['json_file_path']
        self.start_datetime = kwargs['program_timestamp']
        self.hpcc_landing_zone = kwargs['hpcc_landing_zone']
        self.working_timestamp = kwargs['working_timestamp']
        self.source_file_archive = kwargs['source_file_archive']
        self.inbound_forcast_adhoc=kwargs['inbound_forcast_adhoc']
        self.logger = getLogger(f"{self.template}_{self.username}")
        self.inbound_forcast_working=kwargs['inbound_forcast_working']
        self.inbound_forcast_archive=kwargs['inbound_forcast_archive']


    @property
    def filename(self) -> str:
        """
        filename
            Returns the name of the file from the current submitted file path.
        """
        return os.path.basename(self.file_path)


    @property
    def path(self) -> str:
        """
        path
            Returns the directory path from the current submitted file path.
        """
        return os.path.dirname(self.file_path)


    @property
    def current_templates(self) -> list:
        """
        current_templates
            Return a list of all implemented templates mentioned in the configuration.
        """
        with open(self.json_file_path) as json_file:
            data = json.load(json_file)
        return list(dict(data["validations"]).keys())


    @property
    def template(self) -> str:
        """
        template
            Returns the name of the template being processed.
        """
        fileNameLower = self.filename.lower()
        
        # https://jira.rsi.lexisnexis.com/browse/FMR-10603 
        # Files from forecast folder are always forecast template files
        if self.source_folder.lower() == 'forecast':
            return "fact_forecast_details"
        
        # https://jira.rsi.lexisnexis.com/browse/FMR-10595
        # Files from VC folder are always vc template files
        elif self.source_folder.lower() == 'vc':
            return "vc"
        
        elif all(key in fileNameLower for key in ['vertical','unassigned']):
            return "customer_attributes"
        else: 
            for t in self.current_templates:
                if all(key in fileNameLower for key in t.split("_")) and t not in ["fact_forecast_details","vc"]:
                    return t
            else:
                return 'unknown'

        
    @property
    def validations(self) -> dict:
        """
        validations
            Returns the validation configuration for the current template.
        """
        with open(self.json_file_path) as json_file:
            data = json.load(json_file)
            return data["validations"][self.template]


    @property
    def communications(self) -> dict:
        """
        communications
            Returns the communication configuration.
        """
        with open(self.json_file_path) as json_file:
            data = json.load(json_file)
            return data["communications"]
        

    @property
    def username(self) -> str:
        """
        username
            Returns the username from the submitted files name.
        """
        fileNameLower = self.filename.lower().lstrip(self.source_folder.lower() + '_')
        fileNameLower = fileNameLower.rstrip('.xlsx')
        fileNameLower = fileNameLower.rstrip('.txt')
        fileNameLower = fileNameLower.rstrip('.csv')
        name = fileNameLower.split('_')
        user = '-'.join(name[-2:]).upper().strip()
        return self.source_folder + '-' + user


    @property
    def source_folder(self) ->str:
        """
        source_folder
            Determine the name of the folder that the submitted file was submitted to.
        """
        with open(self.json_file_path) as json_file:
            data = json.load(json_file)
            drop_zone_folders = dict(data["communications"]["drop_zone_folders"])

        for _, val in drop_zone_folders.items():
            if self.filename.lower().find(str(val).lower()) != -1:
                return val
        

    def get_dataframe(self, sheetname:str=None) -> pd.DataFrame:
        """
        get_dataframe 
            Function that gets a data frame from a submitted file. Returns a pandas data frame.
        """
        self.write_to_log(f"Getting dataframe for {sheetname}")
        data_columns = self.validations[sheetname.lower()]["data_columns"]
        columns_dtype = self.validations[sheetname.lower()]['columns_dtype']

        if self.filename.lower().endswith('.xlsx') and sheetname:
            df = pd.read_excel(self.file_path, engine='openpyxl', keep_default_na=False, na_values=['', ' '],  sheet_name=sheetname, dtype=columns_dtype) 
        else:
            if self.template == "vc":
                if self.filename.lower().endswith('.csv'):
                    df = pd.read_csv(self.file_path, keep_default_na=False, skipinitialspace = True, low_memory=False) 
                else:
                    df = pd.read_csv(self.file_path, delimiter='\t', keep_default_na=False, skipinitialspace = True, low_memory=False) 
            else:
                df = pd.read_csv(self.file_path, delimiter='\t', keep_default_na=False, skipinitialspace = True, low_memory=False, header=None) 

        # remove white spaces from each column
        for column in list(df.columns):
            if df[column].dtype == "object":
                df[column] = df[column].str.strip()
                df[column] = df[column].str.strip("\n")

        # remove rows that are completely blank or all have a va lue of 'NaN'
        df.dropna(axis=0, how='all', subset=None, inplace=True)
        
        # There are templates whose data section has the headers a few line before the 
        # data itself such as trans_type_sub_trans_category_mapping this section checks 
        # if the first row matches the columns for the template then we set the dataframe 
        # to start after the forst row
        if not df.empty: 
            row1 = [str(r).lower() for r in list(df.iloc[0])]
            row_idx = 1 if all(c in row1 for c in [str(d).lower() for d in data_columns]) else 0
            df = df.iloc[row_idx:,:len(data_columns)] 
            df.columns = data_columns

        return df


    def get_txt_lines(self, sheetname:str=None):
        """
        get_txt_lines
            Function that gets a text line object from a submitted text file. Return text object.
        """
        self.write_to_log(f"Getting text file content for {sheetname}")

        if self.filename.lower().endswith('.txt'):
            with open(self.file_path) as fp:
                txt_content = fp.read()
            return txt_content


    def get_workbook(self) -> openpyxl:
        """
        get_workbook
            Function that gets a workbook object from a submitted excel file. Returns workbook object.
        """
        try:
            self.write_to_log("Getting workbook from source file")
            return openpyxl.load_workbook(filename=self.file_path, data_only=True)
        except Exception as err:
            # raise Exception(f'File {self.filename} can not be openned or is corrupt!')
            return None


    def get_validation_tabs(self) -> list:
        """
        get_validation_tabs
            Functions that get the submitted workbook file worksheets 
            or the template layouts for submitted text files. Returns 
            results as a list.
        """
        fileNameLower = self.filename.lower()
        if fileNameLower.endswith('.xlsx'):
            try:
                workbook = self.get_workbook()
                return list(workbook.sheetnames)
            except:
                raise Exception(f'File {self.filename} can not be openned or is corrupt!')
        else:
            if self.template == "fact_forecast_details":
                # https://jira.rsi.lexisnexis.com/browse/FMR-8477
                for layout in self.validations.keys():
                    if all(l in fileNameLower for l in layout.split('_')):
                        return list([layout])
                else:
                #######################################################
                # https://jira.rsi.lexisnexis.com/browse/FMR-10603
                # Added inc and hc key word in determining the control file
                    if 'control' in fileNameLower and any(i in fileNameLower for i in ['insurance','inc']):
                        return list(['ins_control_forecast_fact_details'])
                    elif 'control' in fileNameLower and any(i in fileNameLower for i in ['healhcare','hc']):
                        return list(['hc_control_forecast_fact_details'])
                    else:
                        source = fileNameLower.lstrip(self.source_folder.lower() + '_').split('_')[0]
                        if any(ins in source for ins in ['ins', 'insurance']):
                            return list(['ins_forecast_fact_details'])
                        elif any(hc in source for hc in ['hc', 'healthcare']):
                            return list(['hc_forecast_fact_details'])
                        else:
                            raise Exception(f'File {self.filename} does not seem to have the correct naming structure.')
                #######################################################
            elif self.template == "vc":
                for key in self.validations.keys():
                    if all(k in fileNameLower for k in key.split('_')):
                        return list([key])
                else:
                    raise Exception(f'File {self.filename} does not have a valid template name.')


    def __template_validations(self, common_validations: dict):
        """
        __template_validations
            Function that runs the common validation functions specified for the file template being processed.
        """
        self.write_to_log(f"Running template validations for {self.template}")

        for key, validation in common_validations.items():
            if key == "number_of_columns":
                self.number_of_columns_validation(validation)
            elif key == "number_of_rows":
                self.number_of_rows_validation(validation)
            elif key == "headers":
                self.headers_validation(validation)
            elif key == "required_values":
                self.required_data_value_validation(validation)
            elif key == "date_format":
                self.date_format_validation(validation)
            elif key == "remove_record":
                self.remove_record_validation(validation)
            elif key == "replace_value":
                self.replace_value_validation(validation)
            elif key == "helper_file":
                self.helper_file_validation(validation)
            elif key == "column_value":
                self.column_value_validation(validation)
            elif key == "prefix":
                self.prefix_validation(validation)


    def number_of_columns_validation(self, number_of_columns: dict):
        """
        number_of_columns_validation
            Validation function that checks the data collected from the 
            source file and check to see if the data from the submitted 
            has more columns than required. Creates a warning message 
            instead of an error.
        """
        valid = True
        try:
            self.write_to_log("Validating number of columns")

            required_count = int(number_of_columns["value"])
            
            if len(self.df.columns) > required_count:
                self.write_to_log(
                    f"There are rows that contain more than {required_count} cols. Data after {required_count}th column are abandoned", 
                    validation_type=number_of_columns["validation_type"]
                )
                valid = False
        except Exception as err:
            valid=False
            self.teams_alert(err, "Number of columns validation")
        finally:
            self.write_to_log("End of validation")
            if str(number_of_columns["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def number_of_rows_validation(self, number_of_rows: dict):
        """
        number_of_rows_validation
            Validation function that checks the data collected from the 
            source file and confirms that the current layout or worksheet 
            data has the right number of data rows.
        """
        valid = True
        try:
            self.write_to_log("Validating number of rows")
            required_count = int(number_of_rows["value"])
            
            if len(self.df) < required_count:
                self.write_to_log(f"Tab {self.current_sheet} contains less than required {required_count} rows", validation_type=number_of_rows["validation_type"])
                valid = False
        except Exception as err:
            valid=False
            self.teams_alert(err, f"No. of rows validation")
        finally:
            self.write_to_log("End of validation")
            if str(number_of_rows["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def headers_validation(self, headers: dict):
        """
        headers_validation
            Validation function that checks the data collected from the source 
            file and confirms that there's no missing required header order 
            according to specified fields.
        """
        valid=True
        self.write_to_log("Validating required headers")
        try:
            required_headers = dict(headers["value"])
            dataframe_headers = {str(index): title for index, title in enumerate(self.df.columns)}
            missing_headers = []
            
            for postition, header in required_headers.items():
                if postition in dataframe_headers and str(dataframe_headers[postition]).lower() != str(header).lower():
                    self.write_to_log(f"Data sheet '{self.current_sheet}' file format is not correct! Missing header {header}", validation_type=headers["validation_type"])
                    valid=False
                elif postition not in dataframe_headers:
                    self.write_to_log(f"Data sheet '{self.current_sheet}' file format is not correct! Missing header {header} position", validation_type=headers["validation_type"])
                    valid=False
        except Exception as err:
            valid=False
            self.teams_alert(f"Required headers validation")
        finally:
            self.load_temp_log()
            self.write_to_log("End of validation")
            if str(headers["validation_type"]).lower() == "error":
                assert valid==True, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def required_data_value_validation(self, required_values: dict):
        """
        required_data_value_validation
            Validation function that checks the data collected from the source 
            file and confirms that there's no missing required data according to 
            specified fields.
        """
        valid=True
        
        try:
            self.write_to_log("Validating required data")
            required_columns = list(required_values["value"])

            data_columns = self.validations[self.current_sheet.lower()]["data_columns"]
            self.df = self.df.iloc[:,:len(data_columns)]
            self.df.columns = data_columns

            for column in required_columns:
                if self.df[column].isnull().values.any():
                    self.write_to_log(f"There is missing required data in column {column}", validation_type=required_values["validation_type"])
                    valid=False
        except Exception as err:
            valid=False
            self.teams_alert(f"Required data validation")
        finally:
            self.write_to_log("End of validation")
            if str(required_values["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def date_format_validation(self, date_format: dict):
        """
        date_format_validation
            Validation function that checks the data collected from the source file and 
            confirms whether or not the date format of a specified field is correct.
        """
        valid=True
        try:
            self.write_to_log("Starting date format validation")
            value = date_format["value"]
            self.df[value["column"]] = self.df[value["column"]].astype(int)
            #Test date iso format 
            for line, transaction_date in enumerate(list(self.df[value["column"]])):
                try:
                    assert not pd.isna(transaction_date)
                    string_date = str(int(transaction_date))
                    assert len(string_date) == value["length"]
                    datetime.strptime(string_date, value["format"])
                except Exception as err:
                    valid=False
                    self.write_to_temp_log(
                        summary="There are invalid transaction date in this file. Below is a sample", 
                        message=f"Transaction date '{transaction_date}' is not in correct date format", 
                        validation_type=date_format["validation_type"], 
                        line=line+2
                    )
        except Exception as err:
            valid=False
            self.teams_alert(err, "Date format validation", True)
        finally:
            self.load_temp_log()
            self.write_to_log("Ending date format validation")
            if str(date_format["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def remove_record_validation(self, remove_record: dict):
        """
        remove_record_validation
            Validation function that checks the data collected from the source 
            file and removes data according to the settings in the remove_record configuration.
        """
        valid=True
       
        try:
            self.write_to_log("Starting remove text validation")
            patterns = dict(remove_record["value"])
    
            for column, pattern in patterns.items():
                if self.df.empty:
                    dirtLists = re.findall(pattern, self.txt_content, re.MULTILINE)
                    for dirtList in dirtLists:
                        self.txt_content = self.txt_content.replace(dirtList, '')
                    self.txt_content = self.txt_content.replace('\n\n', '')
                else:
                    filter = self.df[column].str.contains(pattern)
                    self.df = self.df[~filter]

        except Exception as err:
            valid=False
            self.teams_alert(err, "Remove record validation")
        finally:
            self.write_to_log("Ending remove text validation")
            if str(remove_record["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def replace_value_validation(self, replace_value: dict):
        """
        replace_value_validation
            Validation function that checks the data collected from the source 
            file and replaces data according to the settings in the replace_value configuration.
        """
        valid=True
       
        try:
            self.write_to_log("Starting replace text validation")
            patterns = dict(replace_value["value"])
    
            for old, new in patterns.items():
                if self.df.empty:
                    self.txt_content = self.txt_content.replace(old, new)
                else:
                    self.df = self.df.replace(old, new)

        except Exception as err:
            valid=False
            self.teams_alert(err, "Replace value validation")
        finally:
            self.write_to_log("Ending replace text validation")
            if str(replace_value["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def helper_file_validation(self, helper_file: dict):
        """
        helper_file_validation
            Validation function that checks if corresponding files have been 
            submitted together with the main file.
        """
        valid=True
       
        try:
            self.write_to_log("Starting auxiliary file check validation")
            value = dict(helper_file["value"])

            # get the helper file type like control or exchange rate
            for name, name_keys in value.items(): 
                source_files = os.listdir(self.path)

                # Search through the current date work folder 
                # created in the manual adjustment folder
                for filename in source_files: 
                    # loop through the value list of the helper file 
                    file_found = False
                    for key_file in name_keys: 
                        # break loop if the current file has all key words in the helper file 
                        if all(key in filename.lower() for key in str(key_file).split("_")): 
                            file_found = True
                            self.write_to_log(f"{name} file found")
                            break 

                    # stop looping through files if control file is found
                    if file_found:
                        break
                else:
                    # if we can't find file in the source folder. 
                    # it may have already been processed and in the landing zone 
                    # just have to follow the same process above
                    time.sleep(random.randint(1,3))
                    lz_dir = self.inbound_forcast_adhoc + today + '\\' if self.template == "fact_forecast_details" else self.hpcc_landing_zone + today + '\\'
                    if os.path.isdir(lz_dir):
                        land_z_files = os.listdir(lz_dir)

                        for filename in land_z_files:
                            # loop through the value list of the helper file 
                            file_found = False
                            for key_file in name_keys: 
                                # break loop if the current file has all key words in the helper file 
                                if all(key in filename.lower() for key in str(key_file).split("_")): 
                                    file_found = True
                                    self.write_to_log(f"{name} file found")
                                    break 

                            # stop looping through files if control file is found
                            if file_found:
                                break 
                        else: 
                            self.write_to_log(f"Failed to find {name} file.", validation_type=helper_file["validation_type"])
                    else: 
                        self.write_to_log(f"Failed to find {name} file.", validation_type=helper_file["validation_type"])
        except Exception as err:
            valid=False
            self.teams_alert(err, "Helper file validation")
        finally:
            self.write_to_log("Ending control file check validation")
            if str(helper_file["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def column_value_validation(self, column_value: dict):
        '''
        column_value_validation
            Function that validates specified numerical values 
            in select columns of the data being processed.
        '''
        valid=True
        try:
            self.write_to_log("Starting column value validation")
            settings = dict(column_value["value"])
            
            for column, setup in settings.items():
                if setup["condition"] == 'more_than':
                    invalid_rec = self.df[~(self.df[column] > setup["value"])]
                elif setup["condition"] == 'less_than':
                    invalid_rec = self.df[~(self.df[column] < setup["value"])]
                elif setup["condition"] == 'equal_to':
                    invalid_rec = self.df[~(self.df[column] == setup["value"])]
                elif setup["condition"] == 'more_than_or_equal_to':
                    invalid_rec = self.df[~(self.df[column] >= setup["value"])]
                elif setup["condition"] == 'less_than_or_equal_to':
                    invalid_rec = self.df[~(self.df[column] <= setup["value"])]

                if len(invalid_rec) >= 1:
                    for i, v in zip(invalid_rec.index, invalid_rec[column]):
                        self.write_to_temp_log(
                            summary=f"There are rows with invalid conditional value(s). {len(invalid_rec)} record(s) found.", 
                            message=f"{column} value '{v}' is not {' '.join(setup['condition'].split('_'))} '{setup['value']}'", 
                            validation_type=column_value["validation_type"], 
                            line=i+2
                        )
        except Exception as err:
            valid=False
            self.teams_alert(err, "Column value validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending column value validation")
            if str(column_value["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def prefix_validation(self, prefix: dict):
        # prefix data validation
        valid=True
        try:
            self.write_to_log("Starting prefix data validation")

            column_dict = dict(prefix["value"])

            for column, config in column_dict.items():
                sep = str(config["seperator"])
                prefixes = dict(config["prefixes"])
                invalid_rec = self.df[self.df.apply(lambda d: d[column].split(sep)[0].strip() not in prefixes, axis=1)]

                if len(invalid_rec) >= 1:
                    for i, v in zip(invalid_rec.index, invalid_rec[column]):
                        self.write_to_temp_log(
                            summary=f"There are invalid prefix value(s) found. {len(invalid_rec)} record(s) found.", 
                            message=f"The prefix value for column '{column}', '{v}', is invalid. Use either of the following: '{', '.join(list(prefixes.keys()))}'", 
                            validation_type=prefix["validation_type"], 
                            line=i+2
                        )
                    self.load_temp_log()

        except Exception as err:
            valid=False
            self.teams_alert(err, "prefix data validation")
        finally:
            self.write_to_log("Ending Prefix data validation")
            if str(prefix["validation_type"]).lower() == "error":
                assert valid, f"Worksheet {self.current_sheet} skipped due to primary errors"


    def revenue_adjustment(self, sheet_validations: dict):
        """
        revenue_adjustment
            Function that run template specific validation for vertical_allocation. Below are the validations being processed.
                1. Prefix data validation.              
                2. Sub account Id format validation.               
                3. Transaction type validation.               
                4. Date format validation.
                5. Scenario validation.
                6. Revenue sign validation.
                7. Revenue amount validation.
        """

        # prefix data validation
        try:
            self.write_to_log("Starting replace prefix data validation")

            prefix = sheet_validations["prefix"]
            prefix_dict = dict(prefix["value"])
            for key, prefixes in prefix_dict.items():
                for line, attrValue in enumerate(list(self.df[key])):
                    if not pd.isna(attrValue) and attrValue != '':
                        try:
                            if key == "cost_center_id":
                                assert attrValue[0].upper() == 'C'
                            elif key == "search_type_id":
                                assert (attrValue.split("-")[0].strip() in prefixes) or (attrValue.split("-")[0].strip().endswith('S'))
                            elif "-" in attrValue:
                                assert attrValue.split("-")[0].strip() in prefixes
                            elif "_" in attrValue:
                                assert attrValue.split("_")[0].strip() in prefixes
                        except:
                            self.write_to_temp_log(
                                summary="There are invalid prefix value in this file. Below is a sample", 
                                message=f"Prefix for {key} is incorrect : '{attrValue}'", 
                                validation_type=prefix["validation_type"], 
                                line=line+2
                            )
        except Exception as err:
            self.teams_alert(err, "prefix data validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending Prefix data validation")

        # sub account Id format validation
        try:
            self.write_to_log("Starting sub account Id format validation")

            id_format = sheet_validations["id_format"]

            for line, sub_acct_id in enumerate(list(self.df["sub_acct_id"])):
                content = str(sub_acct_id).split("-")

                if len(content) >= id_format['value']['count'] and len(content[0]) != id_format['value']["prefix_count"]:
                    self.write_to_temp_log(
                        summary="There are invalid subaccount id(s) in this file. Below is a sample", 
                        message=f"Sub acct id '{sub_acct_id}', is not in the correct format", 
                        validation_type=id_format["validation_type"], 
                        line=line+2
                    )
        except Exception as err:
            self.teams_alert(err, "subaccountId format validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending sub account Id format validation")

        # transaction type validation
        try:
            self.write_to_log("Starting transaction type validation")

            transaction_type = sheet_validations["transaction_type"]

            for line, trans_type_id in enumerate(list(self.df["trans_type_id"])):
                if pd.isna(trans_type_id) or len(str(trans_type_id)) == 0:
                    continue
                elif len(str(trans_type_id).split("-")) not in [3, 4]:
                    self.write_to_temp_log(
                        summary="There are invalid transaction type id(s) in this file. Below is a sample", 
                        message=f"Trans type Id '{trans_type_id}', is not in the correct format", 
                        validation_type=transaction_type["validation_type"], 
                        line=line+2
                    )
        except Exception as err:
            self.teams_alert(err, "transaction type validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending transaction type validation")

        # scenario validation
        try:
            self.write_to_log("Starting scenario validation")
            scenario = sheet_validations["scenario"]

            for line, (sub_acct_id, scenario_name, search_type_id, trans_type_id) in enumerate(zip(list(self.df["sub_acct_id"]), list(self.df["scenario_name"]), list(self.df["search_type_id"]), list(self.df["trans_type_id"]))):
                if sub_acct_id not in ['IND-999999MTH', 'IND-000001'] and sub_acct_id[:4] == 'IND-' and (pd.isna(search_type_id) or pd.isna(trans_type_id)) and scenario_name not in scenario['value']:
                    self.write_to_temp_log(
                        summary="There are invalid scenarios in this file. Below is a sample", 
                        message=f'Scenario is not equal to DAILY RF1, 2, 3, budget, flash or DAILY RF1, 2, 3, DAILY FLASH and DAILY BUDGET, therefore trans type and search type cannot be empty', 
                        validation_type=scenario["validation_type"], 
                        line=line+2
                    )
        except Exception as err:
            self.teams_alert(err, "scenario validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending scenario validation")


        # date format validation
        try:
            self.write_to_log("Starting date format validation")
            date_format = sheet_validations["date_format"]

            for (line, transaction_date, scenario_name) in zip(range(len(self.df)), list(self.df["transaction_date"]), list(self.df["scenario_name"])):
                # transaction_date, scenario_name = str(int(self.df.iloc[line, 2])), str(self.df.iloc[line, 3]).upper()
                if scenario_name.upper() == 'ACTUAL ADJUSTMENTS':
                    try:
                        string_date = str(int(transaction_date)) # Confirm that date is an integer and convert to string
                        assert len(string_date) == 8
                        dateTime = datetime.strptime(str(string_date), '%Y%m%d')
                        currentMonth = dateTime + relativedelta(months=1)
                
                        if currentMonth.month != datetime.now().month:
                            self.write_to_temp_log(
                                summary="There are dates that are not of the closed date. Below is a sample", 
                                message=f"Transaction date '{string_date}' is not the closed date", 
                                validation_type=date_format["validation_type"], 
                                line=line+2
                            )

                    except Exception as err:
                        self.write_to_temp_log(
                                summary="There are dates that are not of the correct format. Below is a sample", 
                                message=f"Transaction date '{string_date}' is not in correct date format", 
                                validation_type="Error", 
                                line=line+2
                            )
        except Exception as err:
            self.teams_alert(err, "date format validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending date format validation")
        

        # Currency sign validation
        try:
            self.write_to_log("Starting billed revenue sign validation")

            revenue_sign = sheet_validations["revenue_sign"]

            self.df["USD_billed_revenue"] = self.df['USD_billed_revenue'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)
            self.df["LOCAL_currency_billed_revenue"] = self.df['LOCAL_currency_billed_revenue'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)
            self.df["GL_billed_revenue"] = self.df['GL_billed_revenue'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)

            for (
                    line, USD_billed_revenue, LOCAL_currency_billed_revenue, GL_billed_revenue
                ) in zip(
                    range(len(self.df)), list(self.df["USD_billed_revenue"]), list(self.df["LOCAL_currency_billed_revenue"]), list(self.df["GL_billed_revenue"])
                ):
                if USD_billed_revenue < 0 and LOCAL_currency_billed_revenue > 0:
                    self.write_to_temp_log(
                        summary="There are invalid billed revenue sign(s) in this file. Below is a sample", 
                        message=f"LOCAL currency billed revenue '{LOCAL_currency_billed_revenue}' doesn't have the same sign as USD billed revenue '{USD_billed_revenue}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
                if USD_billed_revenue < 0 and GL_billed_revenue > 0:
                    self.write_to_temp_log(
                        summary="There are invalid billed revenue sign(s) in this file. Below is a sample", 
                        message=f"GL billed revenue '{GL_billed_revenue}' doesn't have the same sign as USD billed revenue '{USD_billed_revenue}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
                if USD_billed_revenue > 0 and LOCAL_currency_billed_revenue < 0:
                    self.write_to_temp_log(
                        summary="There are invalid billed revenue sign(s) in this file. Below is a sample", 
                        message=f"LOCAL currency billed revenue '{LOCAL_currency_billed_revenue}' doesn't have the same sign as USD billed revenue '{USD_billed_revenue}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
                if USD_billed_revenue > 0 and GL_billed_revenue < 0:
                    self.write_to_temp_log(
                        summary="There are invalid billed revenue sign(s) in this file. Below is a sample", 
                        message=f"GL billed revenue '{GL_billed_revenue}' doesn't have the same sign as USD billed revenue '{USD_billed_revenue}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
        except Exception as err:
            self.teams_alert(err, "billed revenue validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending billed revenue sign validation")


        try:
            self.write_to_log("Starting OOP currency sign validation")

            revenue_sign = sheet_validations["revenue_sign"]

            self.df["USD_oop"] = self.df['USD_oop'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)
            self.df["LOCAL_currency_oop"] = self.df['LOCAL_currency_oop'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)
            self.df["GL_oop"] = self.df['GL_oop'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)

            for (
                    line, USD_oop, LOCAL_currency_oop, GL_oop
                ) in zip(
                    range(len(self.df)), list(self.df["USD_oop"]), list(self.df["LOCAL_currency_oop"]), list(self.df["GL_oop"])
                ):
                if USD_oop < 0 and LOCAL_currency_oop > 0:
                    self.write_to_temp_log(
                        summary="There are invalid OOP currency sign(s) in this file. Below is a sample", 
                        message=f"LOCAL currency OOP '{LOCAL_currency_oop}' doesn't have the same sign as USD OOP '{USD_oop}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
                if USD_oop < 0 and GL_oop > 0:
                    self.write_to_temp_log(
                        summary="There are invalid OOP currency sign(s) in this file. Below is a sample", 
                        message=f"GL OOP '{GL_oop}' doesn't have the same sign as USD OOP '{USD_oop}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
                if USD_oop > 0 and LOCAL_currency_oop < 0:
                    self.write_to_temp_log(
                        summary="There are invalid OOP currency sign(s) in this file. Below is a sample", 
                        message=f"LOCAL currency OOP '{LOCAL_currency_oop}' doesn't have the same sign as USD OOP '{USD_oop}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
                if USD_oop > 0 and GL_oop < 0:
                    self.write_to_temp_log(
                        summary="There are invalid OOP currency sign(s) in this file. Below is a sample", 
                        message=f"GL OOP '{GL_oop}' doesn't have the same sign as USD OOP '{USD_oop}'.", 
                        validation_type=revenue_sign["validation_type"], 
                        line=line+2
                    )
        except Exception as err:
            self.teams_alert(err, "OOP currency validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending OOP currency sign validation")
    
        # https://jira.rsi.lexisnexis.com/browse/FMR-10934
        # Currency ammount validation
        try:
            self.write_to_log("Starting currency ammount validation") 
            revenue_amount = sheet_validations["revenue_amount"]

            for (
                    line, LOCAL_currency_code, GL_currency_code, 
                    USD_billed_revenue, LOCAL_currency_billed_revenue, GL_billed_revenue, 
                    LOCAL_currency_oop, GL_oop, USD_oop
                ) in zip(
                    range(len(self.df)), list(self.df["LOCAL_currency_code"]), list(self.df["GL_currency_code"]), 
                    list(self.df["USD_billed_revenue"]), list(self.df["LOCAL_currency_billed_revenue"]), list(self.df["GL_billed_revenue"]), 
                    list(self.df["LOCAL_currency_oop"]), list(self.df["GL_oop"]), list(self.df["USD_oop"]) # Bug fix 9/12/2023 https://jira.rsi.lexisnexis.com/browse/FMR-11744 
                ):

                # 1. If local_currency_code == gl_currency_code and both are USD, then the amount fields (including oop amount) should be the same
                if 'USD' in LOCAL_currency_code.upper() and 'USD' in GL_currency_code.upper():
                    if LOCAL_currency_billed_revenue != GL_billed_revenue:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"LOCAL_currency_billed_revenue, {LOCAL_currency_billed_revenue}, does not equal GL_billed_revenue, {GL_billed_revenue}, where local_currency_code and gl_currency_code are USD.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )

                    if (not math.isnan(LOCAL_currency_oop) or not math.isnan(GL_oop)) and LOCAL_currency_oop != GL_oop:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"LOCAL_currency_oop, {LOCAL_currency_oop}, does not equal GL_oop, {GL_oop}, where local_currency_code and gl_currency_code are USD.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )

                # 2. If local_currency_code == gl_currency_code, the local and gl section amount should be the same
                if LOCAL_currency_code == GL_currency_code:
                    if LOCAL_currency_billed_revenue != GL_billed_revenue:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"LOCAL_currency_billed_revenue, {LOCAL_currency_billed_revenue}, does not equal GL_billed_revenue, {GL_billed_revenue}, where local_currency_code and gl_currency_code are the same.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )
                    
                    if (not math.isnan(LOCAL_currency_oop) or not math.isnan(GL_oop)) and LOCAL_currency_oop != GL_oop:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"LOCAL_currency_oop, {LOCAL_currency_oop}, does not equal GL_oop, {GL_oop}, where local_currency_code and gl_currency_code are the same.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )

                # 3. If local_currency_code = “USD”, the local and usd section should be the same
                if 'USD' in LOCAL_currency_code.upper():
                    if LOCAL_currency_billed_revenue != USD_billed_revenue:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"LOCAL_currency_billed_revenue, {LOCAL_currency_billed_revenue}, does not equal USD_billed_revenue, {USD_billed_revenue}, where local_currency_code is USD.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )

                    if (not math.isnan(LOCAL_currency_oop) or not math.isnan(USD_oop)) and LOCAL_currency_oop != USD_oop:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"LOCAL_currency_oop, {LOCAL_currency_oop}, does not equal USD_oop, {USD_oop}, where local_currency_code is USD.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )

                # 4. If gl_currency_code = “USD”, the gl and usd section should be the same
                if 'USD' in GL_currency_code.upper():
                    if GL_billed_revenue != USD_billed_revenue:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"GL_billed_revenue, {GL_billed_revenue}, does not equal USD_billed_revenue, {USD_billed_revenue}, where gl_currency_code is USD.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )
                    
                    if (not math.isnan(GL_oop) or not math.isnan(USD_oop)) and GL_oop != USD_oop:
                        self.write_to_temp_log(
                            summary="There are invalid revenue amounts. Below is a sample", 
                            message=f"GL_oop, {GL_oop}, does not equal USD_oop, {USD_oop}, where gl_currency_code is USD.", 
                            validation_type=revenue_amount["validation_type"], 
                            line=line+2
                        )

        except Exception as err:
            self.teams_alert(err, "Currency ammount validation", err=False)
        finally:
            self.load_temp_log()
            self.write_to_log("Ending currency ammount validation")
        

    def vertical_allocation(self, sheet_validations: dict):
        """
        vertical_allocation
            Function that run template specific validation for vertical_allocation. Below are the validations being processed.
                1. Check if all ratios sum up to 1.
                2. Check if id and date are the same but ratios are different.            
        """
        self.write_to_log("Vertical allocation adjustment validation ")

        ## check if all ratios sum up to 1
        try:
            self.write_to_log("Starting ratios sum validation")
            total_ratios = sheet_validations["total_ratios"]
            ratio_total = lambda a, h, l, c : round(a+h+l+c, 5)
            self.df["total_ratios"] = ratio_total(self.df["auto_ratio"], self.df["home_ratio"], self.df["life_ratio"], self.df["commercial_ratio"])


            ## Filter out the data with the growth metric value not in the desired list
            invalid_total_ratios_df = self.df[self.df["total_ratios"] != total_ratios["value"]]

            if len(invalid_total_ratios_df) >= 1:
                for line, total in zip(list(invalid_total_ratios_df.index), list(invalid_total_ratios_df["total_ratios"])):
                    self.write_to_temp_log(
                        summary="There are invalid respective ratios totals in this file. Below is a sample", 
                        message=f"The sum of the respective ratios does not add up to 1, '{total}'", 
                        validation_type=total_ratios["validation_type"], 
                        line=line+2
                    )

        except Exception as err:
            self.teams_alert(err, "scenario validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending ratios sum validation")

        ## check if id and date are the same but ratios are different
        try:
            self.write_to_log("Starting id, date and ratios validation")
            ratio_set = sheet_validations["ratio_set"]
            first = self.df.duplicated(keep='first', subset=['year_month','hist_subaccount_id'])
            last = self.df.duplicated(keep='last', subset=['year_month','hist_subaccount_id'])
            
            for i in list(first[first == True].index):
                for j in list(last[last == True].index):
                    if list(self.df.iloc[j, :2]) == list(self.df.iloc[i, :2]) and list(self.df.iloc[j, 2:6]) != list(self.df.iloc[i, 2:6]):
                        self.write_to_temp_log(
                            summary="There are invalid ratios in this file. Below is a sample", 
                            message=f"Ratios conflicts for the same ID and date of line {j+1} and line {i+1}", 
                            validation_type=ratio_set["validation_type"], 
                            line=j+1
                        )

        except Exception as err:
            self.teams_alert(err, "date and ratios validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending id, date and ratios validation")


    def ins_growth_metric_override(self, sheet_validations: dict):
        """
        ins_growth_metric_override
            Function that run template specific validation for ins_growth_metric_override. Below are the validations being processed
                1. Growth metrics validation
                2. trans_nontrans_flag validation            
                3. Transaction date totals validation               
        """
        ##growth metrics QA
        try:
            self.write_to_log("Starting growth metrics validation")

            metrics = sheet_validations["metrics"]

            ## Filter out the data with the growth metric value not in the desired list
            invalid_metric_df = self.df[~self.df["growth_metrics"].isin(list(metrics["value"]))]

            if len(invalid_metric_df) >= 1:
                for line, metric in zip(list(invalid_metric_df.index), list(invalid_metric_df["growth_metrics"])):
                    self.write_to_temp_log(
                        summary="There are invalid growth metrics. Below is a sample", 
                        message=f"Growth_metrics value '{metric}', is not in growth metric list", 
                        validation_type=metrics["validation_type"], 
                        line=line+2
                    )

        except Exception as err:
            self.teams_alert(err, "Growth metrics validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending growth metrics validation")

        #trans_nontrans_flag should always be 1 or 2 --- 1 for yes and 2 for no
        try:
            self.write_to_log("Starting trans_nontrans_flag validation")
            trans_nontrans_flag = sheet_validations["trans_nontrans_flag"]

            ## Filter out the data with the incorrect trans_nontrans_flag
            invalid_trans_nontrans_flag_df = self.df[~self.df["trans_nontrans_flag"].isin(list(trans_nontrans_flag["value"]))]
            if len(invalid_trans_nontrans_flag_df) >= 1:
                for line, trans_nontrans_flag in zip(list(invalid_trans_nontrans_flag_df.index), list(self.df["trans_nontrans_flag"])):
                    self.write_to_temp_log(
                        summary="There are invalid Trans_nontrans_flags in this file. Below is a sample.", 
                        message=f"Trans_nontrans_flag value '{trans_nontrans_flag}', is not 1 or 2.", 
                        validation_type=trans_nontrans_flag["validation_type"], 
                        line=line+2
                    )

        except Exception as err:
            self.teams_alert(err, "Trans_nontrans_flag validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending trans_nontrans_flag validation")

        ## Transaction date totals
        try:
            self.write_to_log("Starting total revenue by date validation")
            total_revenue_by_date = sheet_validations["total_revenue_by_date"]

            self.df["OVERRIDE USD_billed_revenue"] = self.df['OVERRIDE USD_billed_revenue'].replace('[\$,)]','', regex=True).replace( '[(]','-', regex=True ).astype(float)
            total_revenues = self.df[["transaction_date", "OVERRIDE USD_billed_revenue"]].groupby("transaction_date")[["OVERRIDE USD_billed_revenue"]].sum().round(2)
            invalid_total_revenues = total_revenues[total_revenues["OVERRIDE USD_billed_revenue"] != total_revenue_by_date['value']]

            if len(invalid_total_revenues) >= 1:
                for transaction_date, total in zip(list(invalid_total_revenues.index), list(invalid_total_revenues["OVERRIDE USD_billed_revenue"])):
                    string_date = str(int(transaction_date))
                    self.write_to_temp_log(
                        summary="There are invalid total revenues per transaction date in this file. Below is a sample", 
                        message=f"Total of Transaction date '{string_date}', is not equal to {total_revenue_by_date['value']}. Current total '{total}'", 
                        validation_type=total_revenue_by_date["validation_type"]
                    )
        except Exception as err:
            self.teams_alert(err, "Total revenue by date validation")
        finally:
            self.load_temp_log()
            self.write_to_log("Ending total revenue by date validation")


    def create_datafile(self, template_config: dict, round = 5):
        '''
        create_datafile
            Function that creates landing zone file for HPCC spray functions to pick up  
        '''
        try:
            time.sleep(random.randint(0, 3))
            self.write_to_log(f"Creating/modifying {self.current_sheet} datafile for {self.template}")
            time.sleep(random.randint(3, 6))

            # forecast inbound files have a different path  from other files 
            if self.template == "fact_forecast_details":
                data_file_path = f"{self.inbound_forcast_adhoc}{today}\\{template_config['data_file']}.txt"
            else:
                data_file_path = f"{self.hpcc_landing_zone}{today}\\{template_config['data_file']}_{today}.txt"

            time.sleep(random.randint(6, 9))
            if not os.path.exists(data_file_path):
                if not os.path.exists(os.path.dirname(data_file_path)):
                    self.write_to_log(f"Creating folder in LZ ")
                    os.makedirs(os.path.dirname(data_file_path))

                # non forecast files require header columns to be picked up by HPCC
                if self.template != "fact_forecast_details":
                    columns = list(template_config['data_columns'])
                    if template_config['hpcc_validation']:
                        if "User" not in columns:
                            columns.extend(["User","Filename", "Recordnumber"])
                        else:
                            columns.extend(["Filename", "Recordnumber"])
                
                    with open(data_file_path, 'w+') as dat_file:
                        self.write_to_log(f"Adding columns to file")
                        dat_file.writelines("\t".join(columns))
                        dat_file.write("\n")

            time.sleep(random.randint(0, 3))
            if template_config['hpcc_validation'] and self.template != "fact_forecast_details":
                if "User" not in self.df.columns:
                    self.df["User"] = [self.username.split('-')[1] for _ in range(len(self.df))]
                self.df["Filename"] = [self.filename for _ in range(len(self.df))]
                self.df["Recordnumber"] = [ i+2 for i in range(len(self.df))]

            self.write_to_log(f"Appending {self.current_sheet} data from dataframe.")
            if self.template == "fact_forecast_details":
                with open(data_file_path, 'a+') as dat_file:
                    dat_file.write(self.txt_content)
            else:
                self.df.to_csv(data_file_path, header=None, index=None, sep="\t", mode='a+')
            self.write_to_log(f"Appending complete.")

        except Exception as err:
            # self.teams_alert(err, 'create_datafile')
            if round >= 1:
                self.create_datafile(template_config, round-1)
            else:
                self.teams_alert(err, 'create_datafile part 2')


    def create_report(self):
        '''
        create_report
            Function that create report data for the file or file tab being processed. 
        '''
        try:
            df_to_add = pd.DataFrame({
                'input_filename'                    :[self.filename], 
                'username'                          :[self.username.split('-')[1]], 
                'worksheet'                         :["Invalid Sheet" if self.current_sheet is None else self.current_sheet], 
                'template'                          :[self.template], 
                'record_count'                      :[len(self.df) if not self.df.empty else len(self.txt_content.splitlines()) if self.txt_content else 0], 
                'prevalidation'                     :[1 if self.validation_passed else 0], 
                'eclvalidation'                     :[""],
                'validation_wuid'                   :[""],
                'stage_fact_wuid'                   :[""],
                'working_timestamp'                 :[self.working_timestamp],
                'start_datetime'                    :[self.start_datetime],
                'is_fact_built'                     :[0],
                'build_fact_wuid_failure_msg'       :[""],
                'data_validation_wuid_failure_msg'  :[""]
            })
            if self.report_df.empty:
                self.report_df = df_to_add
            else:
                self.report_df = pd.concat([self.report_df, df_to_add], ignore_index=True)

            value_df_to_add = self.get_template_key_value_pairs()
            if self.report_value_df.empty:
                self.report_value_df = value_df_to_add
            else:
                self.report_value_df = pd.concat([self.report_value_df, value_df_to_add], ignore_index=True)
        except Exception as err:
            self.write_to_log(err)
            self.teams_alert(err, 'create_report')


    def get_template_key_value_pairs(self) -> pd.DataFrame:
        """
        get_template_key_value_pairs
            Function that is called by ManualLoadReportValues function 
            to get specified report data for specific templates
        """
        value_dict = {
            'working_timestamp':    [self.working_timestamp],
            'input_filename':       [self.filename], 
            'worksheet':            ["Invalid Sheet" if self.current_sheet is None else self.current_sheet],
            'template_key':         [''], 
            'template_val':         ['']
        }

        if not self.df.empty:
            if self.template == "revenue_adjustment":
                USD_billed_revenue = '${:,.2f}'.format(sum(self.df['USD_billed_revenue']))

                value_dict.update({
                    'working_timestamp':    [self.working_timestamp for _ in range(2)],
                    'input_filename':       [self.filename for _ in range(2)], 
                    'worksheet':            ["Invalid Sheet" if self.current_sheet is None else self.current_sheet for _ in range(2)],
                    'template_key':         ["total_billed_revenue", "scenario_name"], 
                    'template_val':         [
                                                '' if USD_billed_revenue == '$nan' else USD_billed_revenue, 
                                                self.df["scenario_name"][0]
                                            ] 
                })

            elif self.template == "ins_growth_metric_override":
                USD_billed_revenue = '${:,.2f}'.format(sum(self.df['OVERRIDE USD_billed_revenue']))

                value_dict.update({
                    'working_timestamp':    [self.working_timestamp],
                    'input_filename':       [self.filename], 
                    'worksheet':            ["Invalid Sheet" if self.current_sheet is None else self.current_sheet],
                    'template_key':         ["total_billed_revenue"], 
                    'template_val':         ['' if USD_billed_revenue == '$nan' else USD_billed_revenue] 
                })

            elif self.template == "external_billed_revenue":
                revenue_amount_le = '${:,.2f}'.format(sum(self.df['revenue_amount_le']))
                revenue_amount_local = '${:,.2f}'.format(sum(self.df['revenue_amount_local']))

                value_dict.update({
                    'working_timestamp':    [self.working_timestamp for _ in range(3)],
                    'input_filename':       [self.filename for _ in range(3)], 
                    'worksheet':            ["Invalid Sheet" if self.current_sheet is None else self.current_sheet for _ in range(3)],
                    'template_key':         ["source_scenario", "total_operational_currency", "total_billing_currency"], 
                    'template_val':         [
                                                self.df["source_scenario"][0], 
                                                '' if revenue_amount_le == '$nan' else revenue_amount_le,
                                                '' if revenue_amount_local == '$nan' else revenue_amount_local
                                            ]
                })

        return pd.DataFrame(value_dict)

    
    def write_to_log(self, message, error=False, warning=False, validation_type:str="", line=0):
        """
        write_to_log
            Function that logs the process of the automation program to the terminal, 
            the applog debugger and a log data frame 
        """
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_style = " ERROR " if error or validation_type.lower() == "error" else "WARNING" if warning or validation_type == "Warning" else " DEBUG "
        log = f'[{timestamp}]:[{log_style}]:[{self.username}] {message}'
        log_no_stamp = f"{message}"
        print(log)

        try:
            if error or validation_type == "Error":
                self.logger.error(f"{message}")
                self.validation_passed = False
            else:
                self.logger.debug(f"{message}")
        except Exception as err:
            print(err)
            self.teams_alert(err, 'write_to_log Logger')

        try:
            df_to_add = pd.DataFrame({
                'input_filename'    :[self.filename], 
                'username'          :[self.username.split('-')[1]], 
                'worksheet'         :["Invalid Sheet" if self.current_sheet is None else self.current_sheet], 
                'template'          :[self.template], 
                'record_number'     :[line], 
                'log_type'          :[log_style.strip()], 
                'log_message'       :[log_no_stamp], 
                'wuid'              :[""],
                'source'            :['Pre-HPCC'],
                'log_datetime'      :[timestamp],
                'start_datetime'    :[self.start_datetime],
                'working_timestamp' :[self.working_timestamp],
                'log_timestamp'     :[datetime.fromisoformat(timestamp).strftime("%Y%m%d_%H%M%S")]
            })

            if self.debug_df.empty:
                self.debug_df = df_to_add 
            else:
                self.debug_df = pd.concat([self.debug_df, df_to_add], ignore_index=True)

        except Exception as err:
            self.teams_alert(err, 'write_to_log dataframe')


    def write_to_temp_log(self, message, summary="", error=False, warning=False, validation_type:str="", line=0):
        """
        write_to_temp_log
            Function that creates a temporary log data frame for error logs. This is to prevent 
            large sets of the same error logs being recorded and overflow the report email. 
        """
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_style = " ERROR " if error or validation_type.lower() == "error" else "WARNING" if warning or validation_type == "Warning" else " DEBUG "
        log = f'[{timestamp}]:[{log_style}]:[{self.username}] {message}'
        log_no_stamp = f"{message}"
        print(log)

        try:
            if error or validation_type == "Error":
                self.logger.error(f"{message}")
                self.validation_passed = False
            else:
                self.logger.debug(f"{message}")
        except Exception as err:
            print(err)
            self.teams_alert(err, 'write_to_temp_log Logger')

        try:
            if self.temp_debug_df.empty:
                self.temp_debug_df = pd.DataFrame({
                    'input_filename'    :[self.filename], 
                    'username'          :[self.username.split('-')[1]], 
                    'worksheet'         :["Invalid Sheet" if self.current_sheet is None else self.current_sheet], 
                    'template'          :[self.template], 
                    'record_number'     :[line], 
                    'log_type'          :[log_style.strip()], 
                    'log_message'       :[summary], 
                    'wuid'              :[""],
                    'source'            :['Pre-HPCC'],
                    'log_datetime'      :[timestamp],
                    'start_datetime'    :[self.start_datetime],
                    'working_timestamp' :[self.working_timestamp],
                    'log_timestamp'     :[datetime.fromisoformat(timestamp).strftime("%Y%m%d_%H%M%S")]
                })

            df_to_add = pd.DataFrame({
                'input_filename'    :[self.filename], 
                'username'          :[self.username.split('-')[1]], 
                'worksheet'         :["Invalid Sheet" if self.current_sheet is None else self.current_sheet], 
                'template'          :[self.template], 
                'record_number'     :[0  if line == None else int(line) ], 
                'log_type'          :[log_style.strip()], 
                'log_message'       :[log_no_stamp], 
                'wuid'              :[""],
                'source'            :['Pre-HPCC'],
                'log_datetime'      :[timestamp],
                'start_datetime'    :[self.start_datetime],
                'working_timestamp' :[self.working_timestamp],
                'log_timestamp'     :[datetime.fromisoformat(timestamp).strftime("%Y%m%d_%H%M%S")]
            })
            self.temp_debug_df = pd.concat([self.temp_debug_df, df_to_add], ignore_index=True)

        except Exception as err:
            self.teams_alert(err, 'write_to_temp_log dataframe')
        

    def load_temp_log(self):
        """
        load_temp_log
            Function that loads the summarized temporary data frame logs, created by 
            write_to_temp_log function, into the main data frame log.
        """
        try:
            if not self.temp_debug_df.empty:
                if len(self.temp_debug_df) >= 11:
                    self.temp_debug_df = self.temp_debug_df.drop_duplicates(subset=['log_type','log_message'])
                    self.temp_debug_df = self.temp_debug_df.iloc[:11]    
                else:
                    self.temp_debug_df = self.temp_debug_df.iloc[0:]

                self.debug_df = self.temp_debug_df if self.debug_df.empty else pd.concat([self.debug_df, self.temp_debug_df], ignore_index=True)
                self.temp_debug_df = pd.DataFrame()

        except Exception as err:
            self.teams_alert(err, 'write_to_temp_log dataframe')
       

    def archive(self, error=False, files=[]):
        """
        archive
            Function that archives files to depending on whether an error occurred with the related files 
        """
        try:
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            if self.template == "fact_forecast_details":
                archive_folder= f"{self.inbound_forcast_archive}DataWithError\\Python\\{today}\\{timestamp}\\" if error else f"{self.inbound_forcast_archive}\\NoError\\{today}\\{timestamp}\\"
            else:
                archive_folder= f"{self.source_file_archive}DataWithError\\Python\\{today}\\{timestamp}\\" if error else f"{self.source_file_archive}\\NoError\\{today}\\{timestamp}\\"

            if not os.path.exists(archive_folder):
                os.makedirs(archive_folder)
            else:
                os.chmod(archive_folder, 0o777)

            if os.path.exists(self.file_path):
                shutil.move(self.file_path, os.path.join(archive_folder, self.filename))

            for file in files:
                if os.path.exists(os.path.join(self.path, file)):
                    shutil.move(os.path.join(self.path, file), os.path.join(archive_folder, file))
        except:
            self.archive(error, files)


    def end_processing(self):
        """
        end_processing
            Function that closes any existing current workbook. Archives 
            the file that was being processed and runs three functions that 
            updates the reporting table in SQL; ManualLoadReport, ManualLoadReportValues and ManualLoadLogs.
        """
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        # close workbook
        if self.workbook is not None:
            self.workbook.close()

        if os.path.exists(self.file_path):
            self.archive(error=(self.validation_passed==False))

        if self.report_df.empty:
            self.report_df = pd.DataFrame({
                'input_filename'                    :[self.filename], 
                'username'                          :[self.username.split('-')[1]], 
                'worksheet'                         :["Invalid Sheet" if self.current_sheet is None else self.current_sheet], 
                'template'                          :[self.template], 
                'record_count'                      :[0], 
                'prevalidation'                     :[1 if self.validation_passed else 0], 
                'eclvalidation'                     :[""],
                'validation_wuid'                   :[""],
                'stage_fact_wuid'                   :[""],
                'working_timestamp'                 :[self.working_timestamp],
                'start_datetime'                    :[self.start_datetime],
                'is_fact_built'                     :[0],
                'build_fact_wuid_failure_msg'       :[""],
                'data_validation_wuid_failure_msg'  :[""]
            })
        
        if self.report_value_df.empty:
            self.report_value_df = self.get_template_key_value_pairs()


    def teams_alert(self, msg, function='', err=False):
        """
        teams_alert
            Function that gets the file and line details when a caught 
            exception occurs and log the details including a teams alert message.
        """
        _, _, exc_tb = sys.exc_info()
        line_no = exc_tb.tb_lineno
        message = f"line:{line_no}\t{msg}"
        self.write_to_log(message, error=err)
        send_to_teams_channel(
            webhook=self.communications["teams_webhook_url"].format(self.teams_webhook_path),
            title=f"Alert :: Manual Load :: Validation :: {function}",
            message=message
        )


    def run(self):
        '''
        run
            Function that reads the source file, determine template and loop through the 
            sheetnames or layouts of the source. In this loop we run through all possible 
            validations and create a data file in the landing zone. Function that updates 
            the data base with logs and reports are also called here.
        '''
        try:
            self.write_to_log(f"Pre-processing file {self.filename}")
            
            try:
                self.write_to_log(f"Template found: {self.template}")
                assert self.template != 'unknown' and self.template in self.current_templates, f"This file's template has not been implemented."
                
                sheetnames =  self.get_validation_tabs()
                required_set = {tab.lower() for tab in self.validations.keys() if self.validations[tab]["required_tab"]} 
                datasheet_set = {tab.lower() for tab in sheetnames}
                validation_set = {tab.lower() for tab in self.validations.keys()}

                if len(required_set) >= 1:
                    assert required_set.issubset(datasheet_set), f"This file is missing the required worksheets: '{', '.join(required_set)}'"

                assert any(t in datasheet_set for t in validation_set), f"This file is missing the required worksheets, options: '{', '.join(validation_set)}'"
            except Exception as err:
                self.current_sheet = None
                self.errors_occurred = True
                raise Exception(err)

            worksheet_check = { wrksht:True for wrksht in datasheet_set if wrksht in validation_set}

            for sheet in sheetnames:
                if sheet.lower() in self.validations:
                    self.write_to_log(f"Found Data sheet {sheet}")
                    try:
                        self.validation_passed = True
                        self.current_sheet = sheet

                        if self.template == "fact_forecast_details":
                            self.txt_content = self.get_txt_lines(sheet)
                        else:
                            self.df = self.get_dataframe(sheetname=sheet)

                        configurations = self.validations[sheet.lower()]
                        if configurations["common_validations"]:
                            self.__template_validations(configurations["common_validations"])
                            
                        if configurations["sheet_validations"]:
                            if self.template == "revenue_adjustment" and self.current_sheet.lower() == "input":
                                self.revenue_adjustment(configurations["sheet_validations"])
                            elif self.template == "ins_growth_metric_override" and self.current_sheet.lower() == "input":
                                self.ins_growth_metric_override(configurations["sheet_validations"])
                            elif self.template == "vertical_allocation" and self.current_sheet.lower() == "sheet1":
                                self.vertical_allocation(configurations["sheet_validations"])

                        assert self.validation_passed, f"'{self.current_sheet}' worksheet data not collected."
                    except Exception as err:
                        self.write_to_log(err, error=True)
                    else:
                        # Creating data file
                        self.create_datafile(configurations)
                    finally:
                        worksheet_check[sheet.lower()] = self.validation_passed
                        self.create_report()

            if len(worksheet_check) > 1:
                if all(val == False for val in worksheet_check.values()):
                    self.current_sheet = "All Sheets"
                    self.df = pd.DataFrame()
                    self.write_to_log(f"All worksheet tab(s) in the source file contain invalid data.", error=True)
                    self.create_report()
                else:
                    self.validation_passed = True

        except Exception as err:
            self.write_to_log(err, error=True)
        finally:
            self.write_to_log(f"End of pre-process validation for {self.username}")
            self.end_processing()
            return self.debug_df, self.report_df, self.report_value_df