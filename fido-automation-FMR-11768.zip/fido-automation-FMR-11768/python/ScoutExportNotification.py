class ScoutExportNotification(object):
    searchId = ""
    searchInputStartDate = ""
    searchName = ""
    requestedUser = ""
    requestedUserEmail = ""
    workunit = ""
    workunitStatus = ""
    workUnitMsg = ""
    startTime = ""
    completionTime = ""
    elapsedTime = ""
    folderPath = ""
    searchInputEndDate = ""
    product_id = ""
    list_of_exportedFiles = []
    searchInput = {}
    
    def __init__(self, _searchId, _searchInputStartDate, _requestedUser, _requestedUserEmail, _searchName, _searchInputEndDate, _product_id):
        self.searchId = _searchId
        self.searchName = _searchName
        self.requestedUser = _requestedUser
        self.requestedUserEmail = _requestedUserEmail
        self.searchInputStartDate = _searchInputStartDate
        self.searchInputEndDate = _searchInputEndDate
        self.workunit = ""
        self.workunitStatus = ""
        self.workUnitMsg = ""
        self.startTime = ""
        self.completionTime = ""
        self.elapsedTime = ""
        self.folderPath = ""
        self.product_id = _product_id
        self.set_of_exportedFiles = set()
        self.searchInput = {}
    
    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 

    def __lt__(self, other):
        return self.searchId < other.searchId
