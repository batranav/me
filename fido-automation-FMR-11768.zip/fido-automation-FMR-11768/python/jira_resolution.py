from jira import JIRA
import sys, http.client, os
import json
import csv
from collections import defaultdict
from datetime import datetime, timedelta
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret
from commonArgs import getSource


def main():
	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_resolution', True)
	source = getSource()
	uname = get_api_secret(logger, source, secret='uname')
	pwd= get_api_secret(logger, source, secret='pwd')
	jira = JIRA(options, basic_auth=(uname, pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   updated >= -3d and updated <= 1d order by updated' , startidx, blocksize)
		numissues=len(newissues)
		if  numissues==0 or  blocknum==1000:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0	
	resolutionfile=open(os.path.join(parseYamlProperty.get_inbound_dir() ,'jira//daily//resolution_'+ datetime.now().strftime('%Y%m%d') + '.csv'),"w+", encoding='utf-8',newline="")
	resolutionwriter=csv.writer(resolutionfile)
		
	for resultlist in issues:
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
				
			fields=dict['fields']
			del dict['fields']
			fields['issue']=issueId
		
			resolution=fields['resolution']
			if resolution is not None:
				del fields['resolution']
		
				resolution['resolution']=issueId
				if issuecount==0:
						resolutionwriter.writerow(resolution.keys())
				
				resolutionwriter.writerow(resolution.values())	
				
			issuecount=issuecount+1
				
	resolutionfile.close()
if __name__== "__main__" :
     main()





