import pyodbc
import pandas as pd
import re
import os 
import json 
from datetime import datetime
import sys
import numpy as np
import AutomationLogging
import commonArgs
import weekly_release_utils
import generate_weekly_email
import glob

dict_object_type_details = {
                        "table": "U",
                        "view": "V",
                        }

def getLogger():
    return AutomationLogging.getLogger('Weekly_release_rename_table')

def file_check(logger, obj_type, obj_name, file_loc, write_loc):
    try:
        if obj_type.lower().strip() == 'table':
            dev_sql_loc = obj_name+'.Table.sql'
    #         new_sql_loc = write_loc+'\\Table\\'+obj_name+'.sql' #saves to the table folder if object type is table to keep in check with weekly release
        elif obj_type.lower().strip() == 'view':
            dev_sql_loc = obj_name+'.View.sql'
    #         new_sql_loc = write_loc+'\\View\\'+obj_name+'.sql' #saves to the view folder if object type is view to keep in check with weekly release
        logger.debug('file_check function sql file name{0}'.format(dev_sql_loc))
        directory = os.listdir(path = file_loc)
        flag = True
        for i in directory: 
            
            if dev_sql_loc.lower() == i.lower():
                dev_sql_loc = i
                flag = False
                break
            # elif flag and i == directory[-1] and dev_sql_loc.lower() != i.lower():
            #     raise Exception("No such file found.")
        if obj_type.lower().strip() == 'view': 
                      
            if len(glob.glob(file_loc+'\\*' + dev_sql_loc)) > 0:
                dev_sql_loc = glob.glob(file_loc+'\\*' + dev_sql_loc)[0]
                
        else:
            dev_sql_loc = file_loc+'\\'+ dev_sql_loc
            
        if obj_type.lower().strip() == 'table':
            if not os.path.exists(write_loc+'\\Table'):
                os.makedirs(write_loc+'\\Table')
            new_sql_loc = write_loc+'\\Table\\'+obj_name+'.Table.sql' #saves to the table folder if object type is table to keep in check with weekly release
        elif obj_type.lower().strip() == 'view':
            if not os.path.exists(write_loc+'\\View'):
                os.makedirs(write_loc+'\\View')
            new_sql_loc = write_loc+'\\View\\'+obj_name+'.View.sql' #saves to the view folder if object type is view to keep in check with weekly release
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(exc_tb.tb_lineno)
        print(e.args[1])
    return dev_sql_loc, new_sql_loc

def weekly_release_rename_tbl(logger,base_path, release_date, prod, db, file_loc, write_loc):
    logger.debug('weekly_release_rename_tbl function initiated')
    file_path = '{0}\\SQL Changes - ALL.xlsx'.format(base_path)
    df = weekly_release_utils.read_excel(file_path, release_date, 3)
    logger.debug('pandas frame work {0}'.format(df))

    sheet_table_view_name = weekly_release_utils.constant_table_view_name
    sheet_change = weekly_release_utils.constant_change
    sheet_change_type = weekly_release_utils.constant_change_type
    sheet_sql_ecl_type = weekly_release_utils.constant_sql_ecl_type
    sheet_application = weekly_release_utils.constant_application
    sheet_modify_keep = weekly_release_utils.constant_modify_keep   
    sheet_despray_start_month = weekly_release_utils.constant_despray_start_month
    sheet_jira_ticket = weekly_release_utils.constant_jira_ticket

    df = df[df[sheet_sql_ecl_type] != 'ECL']
    downloaded = df.fillna('')
    logger.debug('After cleaning pandas data frame {0}'.format(downloaded))
    application_sql_string = "use {0}".format(db)
    (db_server_name, username, passwd) = weekly_release_utils.read_cred_for_server(logger, prod)
    cnxn = pyodbc.connect('Trusted Connection=yes;DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + db_server_name + ';UID='+ username + ';PWD=' + passwd, timeout=-12000000)             
    status_dict = {}  
    for index, row in downloaded.iterrows():
        table_view_name = row[sheet_table_view_name]           
        change_type = row[sheet_change]
        object_type = row[sheet_change_type]
        jira_task = row[sheet_jira_ticket]

        try:
            table_view_name = re.sub("\[|\]", '', table_view_name)
            partition_column = ''
            tbl_name = ''
            schema = ''
            obj_name = ''
            if change_type.lower()[:3] != 'new' and object_type.lower().strip() == 'table':               
                obj_name = table_view_name
                if '.' not in obj_name:
                    obj_name = "dbo." + obj_name
                tbl_name = obj_name.split('.')[1]
                schema = obj_name.split('.')[0]
                                
                (dev_sql_loc, new_sql_loc) = file_check(logger, object_type, obj_name, file_loc, write_loc)    
                if os.path.exists(new_sql_loc) and os.path.getsize(new_sql_loc) > 0:
                    obj_type = 'table'    
                    original_table = "{0}".format(tbl_name)
                    backup_table = "{0}_backup".format(tbl_name)
                    release_table = "release_{0}".format(tbl_name)
                    backup_tbl_str = "sp_rename '{0}', '{1}'".format(original_table, backup_table)
                    rename_tbl_str = "sp_rename '{0}', '{1}'".format(release_table, original_table)                    
                    delete_record_load_file_grop = "delete from load_tables_filegroup where table_name = '{0}'".format(original_table)
                    update_record_load_file_grop = "update load_tables_filegroup set table_name = '{0}' where table_name = '{1}'".format(original_table, release_table)
                    drop_query = "IF OBJECT_ID('{0}', '{2}') IS NOT NULL \n DROP {3} {1};\n".format(original_table, backup_table, dict_object_type_details[obj_type], obj_type)
                    listsstatus = []
                    sql_list = [application_sql_string, backup_tbl_str, rename_tbl_str, delete_record_load_file_grop, update_record_load_file_grop, drop_query]
                    print(sql_list) 
                    try:
                        with cnxn.cursor() as cur:
                            if sql_list:
                                for i in sql_list:
                                    if i:
                                        cur.execute(i)
                                        logger.debug('Rename function executing following query {0} successfully'.format(i))
                                listsstatus = []
                                listsstatus.append('True')
                                listsstatus.append(jira_task.lower())
                                listsstatus.append('')
                                status_dict[new_sql_loc] = listsstatus
                    except Exception  as e:
                        logger.debug('Exception error while execution Table sql file {0}'.format(e.args[1])) 
                        listsstatus = []
                        listsstatus.append('False')
                        listsstatus.append(jira_task.lower())
                        listsstatus.append(format(e.args[1]))
                        status_dict[new_sql_loc] = listsstatus
        
                
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_tb.tb_lineno)
            print('*****************************************************************************')
            print('\n'+'------------'+ table_view_name + " had issue. Pease advise ------------"+'\n')
            print(e)
            print('\n')
            print('*****************************************************************************')
            continue
        
    logger.debug('weekly_release_rename_tbl function Completed')
    return(status_dict)

def weekly_release_rename_procedure():
    logger = getLogger()
    if(commonArgs.getFiledate() == ''):
        sheet_name = datetime.today().strftime('%Y-%m-%d')
    else:
        sheet_name = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
    
    base_path = weekly_release_utils.get_base_path()
    # need to change as PROD_SQL_DB_CRED
    script_status = weekly_release_rename_tbl(logger, base_path, sheet_name, 'PROD_SQl_DB_CRED', commonArgs.getApplication(), weekly_release_utils.get_script_path(), weekly_release_utils.get_script_path())
    logger.debug('generate_weekly_email.notifyEmail going to initiated')
    print(script_status)
    if script_status:
        generate_weekly_email.notifyRenameEmail(script_status)
    logger.debug('generate_weekly_email.notifyEmail going to Completed')

if __name__ == "__main__":
    # sheet_name = datetime.today().strftime('%Y-%m-%d')
    # filedate = datetime.today().strftime('%Y%m%d')
    
    weekly_release_rename_procedure() 