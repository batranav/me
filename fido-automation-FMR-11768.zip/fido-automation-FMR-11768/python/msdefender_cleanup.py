import parseYamlProperty
import AutomationLogging
import commonArgs
import os
import sys
import traceback
from datetime import datetime
import pandas as pd


currentdate = datetime.today().strftime("%Y%m%d")
file_date = commonArgs.getFiledate()
# file_date = currentdate

json_folder = parseYamlProperty.get_inbound_dir() + "infosec\\importFiles"
csv_folder = parseYamlProperty.get_inbound_dir() + "infosec\\importFiles\\csv"
daily_folder = parseYamlProperty.get_inbound_dir() + "infosec\\daily"

files_to_cleanup = ['machines','recommendations','vulnerabilities','software_inventory_by_machine','exposure_score','exposure_score_by_machine_groups','software_vulnerabilities_by_machine','secure_configurations_assessment_by_machine']
filenames_withdate = []
machines_cols = ['id','computerDnsName','firstSeen','lastSeen','osPlatform','osVersion','osProcessor','version','lastIpAddress','lastExternalIpAddress','agentVersion','osBuild','healthStatus','deviceValue','rbacGroupId','rbacGroupName','riskScore','exposureLevel','isAadJoined','aadDeviceId','machineTags','defenderAvStatus','onboardingStatus','osArchitecture','managedBy','ipAddresses','vmMetadata']
recommendations_cols = ['id','productName','recommendationName','weaknesses','vendor','recommendedVersion','recommendedVendor','recommendedProgram','recommendationCategory','subCategory','severityScore','publicExploit','activeAlert','associatedThreats','remediationType','status','configScoreImpact','exposureImpact','totalMachineCount','exposedMachinesCount','nonProductivityImpactedAssets','relatedComponent']
vulnerabilities_cols = ['id','name','description','severity','cvssV3','exposedMachines','publishedOn','updatedOn','publicExploit','exploitVerified','exploitInKit','exploitTypes','exploitUris']
software_inventory_by_machine_cols = ['deviceId','rbacGroupId','rbacGroupName','deviceName','osPlatform','softwareVendor','softwareName','softwareVersion','numberOfWeaknesses','diskPaths','registryPaths','softwareFirstSeenTimestamp','endOfSupportStatus','endOfSupportDate']
exposure_score_cols = ['time','score','rbacGroupName','rbacGroupId']
exposure_score_by_machine_groups_cols = ['time','score','rbacGroupName','rbacGroupId']
software_vulnerabilities_by_machine_cols = ['Id','DeviceId','RbacGroupId','RbacGroupName','DeviceName','OSPlatform','OSVersion','OSArchitecture','SoftwareVendor','SoftwareName','SoftwareVersion','CveId','VulnerabilitySeverityLevel','RecommendedSecurityUpdate','RecommendedSecurityUpdateId','RecommendedSecurityUpdateUrl','DiskPaths','RegistryPaths','LastSeenTimestamp','FirstSeenTimestamp','EndOfSupportStatus','ExploitabilityLevel','RecommendationReference','CvssScore']
secure_configurations_assessment_by_machine_cols = ['DeviceId','DeviceName','OSPlatform','OSVersion','Timestamp','ConfigurationId','ConfigurationCategory','ConfigurationSubcategory','ConfigurationImpact','IsApplicable','ConfigurationName','RecommendationReference','RbacGroupId','RbacGroupName','IsCompliant','IsExpectedUserImpact']

def getLogger():
    return AutomationLogging.getLogger('msdefender_cleanup')

def get_file_cols(filename):
    cols = globals()[f"{filename}_cols"]
    ret_val = []
    for x in cols:
        x=x.lower()
        ret_val.append(x)
    return ret_val

def get_file_name(filename):
    filename_withdate = filename + '_' + file_date
    return filename_withdate

def are_files_present():
    for file in files_to_cleanup:
        fullfile = csv_folder + '\\' + get_file_name(file) + '.csv'
        fileexists = os.path.isfile(fullfile)
        if not fileexists:
            msg = 'Error {0}{1}'.format(fullfile,' file does not exist')
            logger.error(msg)
            return 0
    return 1

def cleanup():
    logger = getLogger()
    logger.info('Inside msdefender_cleanup.py')
    try:
        if not os.path.isdir(json_folder):
            msg = 'Error {0}'.format('infosec\\importFiles folder does not exist')
            logger.info('infosec\\importFiles folder does not exist')
            logger.error(msg)
            raise Exception(msg)
        if not os.path.isdir(csv_folder):
            msg = 'Error {0}'.format('infosec\\daily folder does not exist')
            logger.info('infosec\\daily folder does not exist')
            logger.error(msg)
            raise Exception(msg)
        if are_files_present:
            logger.info('infosec files are present')
            for eachfile in files_to_cleanup:
                file_cols = get_file_cols(eachfile)
                file_path = csv_folder + '\\' + get_file_name(eachfile) + '.csv'
                output_file_path = daily_folder + '\\' + get_file_name(eachfile) + '.csv'
                df = pd.read_csv(file_path)
                df= df.rename(columns=str.lower)
                logger.info('-------------------------------------------------------')
                logger.info('filename: {0}'.format(eachfile))
                logger.info('expected columns: {0}'.format(file_cols))
                logger.info('API columns: {0}'.format(df.columns.values))
                logger.info('-------------------------------------------------------')
                df = df[df.columns[df.columns.isin(file_cols)]]
                df.to_csv(output_file_path,columns=file_cols)
                logger.info('Cleaned up file: {}'.format(file_path))
                logger.info('Added new file: {}'.format(output_file_path))
        else:
            msg = 'Error: Missing files'
            logger.info('infosec files are missing')
            raise Exception(msg)
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print("\n\n{0}".format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = "".join(line for line in lines)
        print(processerrorMsg)


if __name__ == "__main__":
    logger = getLogger()
    try:
        cleanup()
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print("\n\n{0}".format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = "".join(line for line in lines)
        print(processerrorMsg)