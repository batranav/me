import AutomationLogging
import parseYamlProperty
from pathlib import Path
from vault.secrets import get_api_secret

def get_ssh_key(vault_source='github_prvkey', logger=AutomationLogging.getLogger('get_vault_ssh', True)):
    ''' 
    Script built to fetch gitlab ssh rsa private key from vault and write to temp file
    '''
    key = get_api_secret(logger, vault_source, secret='pwd')
    # send to tempfile
    if vault_source == 'github_prvkey':
        rsa_keyfile_path = parseYamlProperty.get_github_rsa_key_path()
    elif vault_source == 'openstack_prvkey':
        rsa_keyfile_path = parseYamlProperty.get_openstack_rsa_key_path()
    elif vault_source == 'gitlab_id_rsa':
        rsa_keyfile_path = parseYamlProperty.get_git_rsa_key_path()
    else:
        raise Exception("VAULT SOURCE RSA KEY NOT SET")
    # check for and remove any older temp files
    key_path = Path(rsa_keyfile_path)
    if Path.exists(key_path):
        Path.chmod(key_path, 0o700)
        Path.unlink(key_path)
    else:
        key_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Path.write_bytes(key_path, str(key).encode())
    with open(f'{rsa_keyfile_path}', 'wb') as outfile:
        outfile.write(str(key).encode())
    # chmod to read only
    key_path.chmod(0o400)

if __name__ == '__main__':
    get_ssh_key()