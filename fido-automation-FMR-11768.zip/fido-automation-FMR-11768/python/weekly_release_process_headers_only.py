import weekly_release_script_creation
import weekly_release_sql_table_execution
import weekly_release_despray_copy_staging
import runSourceBuilds
import commonArgs
import sys
import parseJSONProperty
import traceback
import AutomationLogging
import fido_utils
import parseYamlProperty as parse_props

def getLogger():
    return AutomationLogging.getLogger('runSourceBuilds')

class GracefullyExit(Exception):
    pass

if __name__ == "__main__":
    
    logger = getLogger()

    debug = False
    if commonArgs.getDebugFlag():
        debug = True
    try:
        weekly_release_script_creation.process()
        weekly_release_sql_table_execution.process()        
        runSourceBuilds.process()
        weekly_release_despray_copy_staging.weekly_release_copy_procedure()
        exit(0)
    
    except GracefullyExit as gex:
        logger.error("Process error", exc_info=True)
        exit(-99)

    except Exception as ex:
        logger.error("Fatal error in main loop", exc_info=True)
        exc_type, exc_value, exc_traceback = sys.exc_info()
        sourceInfo = parseJSONProperty.getSourceInfo(commonArgs.getSource(), commonArgs.getFrequency(), commonArgs.getFiledate())
        successEmailTo = sourceInfo.successemailto
        errorEmailTo = sourceInfo.erroremailto
        
        if debug:
            successEmailTo = parse_props.get_debug_email()
            errorEmailTo = parse_props.get_debug_email()
        
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        if commonArgs.getFiledate() != '':
            file_date = commonArgs.getFiledate()
        else:
            file_date = fido_utils.today

        runSourceBuilds.processerror(commonArgs.getSource(), commonArgs.getFrequency(), sourceInfo.processtype, file_date, processerrorMsg, successEmailTo, errorEmailTo)
        exit(-99)