import sys, requests, os, time, ssl, parseYamlProperty
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import AutomationLogging
from vault.secrets import get_api_secret
import commonArgs
yesterday = datetime.now() - timedelta(days=1)
sd='2013/01/01 00:00:01'
ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_objectslog_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
logger = AutomationLogging.getLogger('preprocess_innotas_objects_deleted')

def delete_allcation_update():
	uname, pwd = get_api_secret(logger, 'innotas')
	SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	   <soapenv:Header/>
	   <soapenv:Body>
	      <ser:login>
	         <!--Optional:-->
	         <ser:username>{uname}</ser:username>
	         <!--Optional:-->
	         <ser:password>{pwd}</ser:password>
	      </ser:login>
	   </soapenv:Body>
	</soapenv:Envelope>""".encode(encoding='utf-8')


	#construct and send the header
	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}

	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	with open('delete_all.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_all.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>54</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed).encode(encoding = 'utf-8')

	print(SoapMessage)


	#construct and send the header

	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}

	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	open('delete_all.xml','wb').write(result)

	tree = ET.parse('delete_all.xml')


	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(),'innotas\\Daily\\innotas_allocation_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_all.xml')

def delete_resource_update():
	uname, pwd = get_api_secret(logger, 'innotas')
	SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	   <soapenv:Header/>
	   <soapenv:Body>
	      <ser:login>
	         <!--Optional:-->
	         <ser:username>{uname}</ser:username>
	         <!--Optional:-->
	         <ser:password>{pwd}</ser:password>
	      </ser:login>
	   </soapenv:Body>
	</soapenv:Envelope>""".encode(encoding='utf-8')


	#construct and send the header
	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}

	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)


	with open('delete_res.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_res.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>11</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed)


	#construct and send the header
	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}


	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	open('delete_res.xml','wb').write(result)

	tree = ET.parse('delete_res.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(),'innotas\\Daily\\innotas_resource_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_res.xml')
def delete_changelog_update():
	uname, pwd = get_api_secret(logger, 'innotas')
	SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	   <soapenv:Header/>
	   <soapenv:Body>
	      <ser:login>
	         <!--Optional:-->
	         <ser:username>{uname}</ser:username>
	         <!--Optional:-->
	         <ser:password>{pwd}</ser:password>
	      </ser:login>
	   </soapenv:Body>
	</soapenv:Envelope>""".encode(encoding='utf-8')


	#construct and send the header
	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}


	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	with open('delete_chan.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_chan.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>6</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed)

	print(SoapMessage)


	#construct and send the header

	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}


	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	open('delete_chan.xml','wb').write(result)

	tree = ET.parse('delete_chan.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(),'innotas\\Daily\\innotas_changelog_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_chan.xml')

def delete_project_update():
	uname, pwd = get_api_secret(logger, 'innotas')
	SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	   <soapenv:Header/>
	   <soapenv:Body>
	      <ser:login>
	         <!--Optional:-->
	         <ser:username>{uname}</ser:username>
	         <!--Optional:-->
	         <ser:password>{pwd}</ser:password>
	      </ser:login>
	   </soapenv:Body>
	</soapenv:Envelope>""".encode(encoding='utf-8')


	#construct and send the header
	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}


	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	with open('delete_proj.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_proj.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>4</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed)

	print(SoapMessage)


	#construct and send the header

	proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
	url = "lexisnexis.ppmpro.com"
	post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}

	no_of_attempts = 120
	for x in range(0, no_of_attempts):
		response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
		print("status_code:", response.status_code)
		if response.status_code == 429:
			print(response.headers["Retry-After"])
			time.sleep(int(response.headers["Retry-After"]))
			x += 1
		else:
			break

	print("status_code:", response.status_code)
	print(SoapMessage)
	result = response.content
	print(result)

	open('delete_proj.xml','wb').write(result)

	tree = ET.parse('delete_proj.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_project_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_proj.xml')
def main():
   delete_allcation_update ()
   delete_resource_update ()
   delete_changelog_update ()
   delete_project_update ()
if __name__ == "__main__":
    main()