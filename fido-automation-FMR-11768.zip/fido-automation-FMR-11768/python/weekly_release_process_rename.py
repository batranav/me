import weekly_release_rename_table
import weekly_release_sql_view_execution

if __name__ == "__main__":    
    weekly_release_rename_table.weekly_release_rename_procedure()
    weekly_release_sql_view_execution.process()  