import subprocess
import pyodbc
import pandas as pd
import re
import os 
import json 
from datetime import datetime
import sys
import numpy as np
import AutomationLogging
import commonArgs
import weekly_release_utils
import glob
import codecs
import generate_weekly_email
import parseYamlProperty as parse_props

dict_object_type_details = {
                        "table": "U",
                        "view": "V",
                        }
def getLogger():
    return AutomationLogging.getLogger('Weeklyrelease')

def getDeltas(x, y):
    return (list(set(x) - set(y)))

# def write_file(dev_sql_loc, write_loc, first_col, keep, ignore, file_idx, file_usr, obj_type, obj_name, flag = True, update_table_flag = False):
#     try:
#         if os.path.exists(dev_sql_loc) :
#             with open(dev_sql_loc, 'r') as fp:
#                 lines = fp.readlines()
            
#         with open(write_loc, 'w+') as fp:
#             fp.writelines('')
#             if os.path.exists(dev_sql_loc) :
                
#                 file_content = ''
#                 if '.' not in obj_name:
#                     obj_name = "dbo." + obj_name
#                 schema = obj_name.split('.')[0]
#                 tbl_name = obj_name.split('.')[1]
#                 re_match_str = "\[*{0}\]*\.\[*{1}\]*".format(schema, tbl_name)
#                 re_replace_str = "[{0}].[release_{1}]".format(schema, tbl_name)
#                 for i in lines:
#                     if update_table_flag:
#                         i = re.sub(re_match_str, re_replace_str, i, flags=re.I)                              
#                     if ignore and any(sub in i for sub in ignore) and flag and obj_type.lower().strip() == 'table': #puts rest of commas before as opposed to after so no conflict if last column is ignored
#                         # i = ',' + i.replace(',','')
#                         if i.find(",") < 0:
#                             file_content = re.sub(r'\s*\,\s*$', ' ', file_content)                    
#                         i = "\n"
#                         file_content = "{0}{1}".format(file_content, i)
#                     elif not(any(sub in i for sub in ignore)): #changes the file group index and file group user with specified ones, ignores non specified changes, keeps rest of lines
#                         i = re.sub(r'\w*FG_IDX[0-9][0-9]', file_idx, i) 
#                         i = re.sub(r'\w*FG_USR[0-9][0-9]', file_usr, i)
#                         file_content = "{0}{1}".format(file_content, i)                                    
#                     else:                
#                         file_content = "{0}{1}".format(file_content, i)
#                 fp.writelines(file_content)
#         fp.close()
        
#         if os.path.exists(write_loc) :
#             with codecs.open(write_loc, encoding='utf-8-sig') as open_sql_script:     
#                 data = open_sql_script.read()
#             open_sql_script.close()
#             match_str = re.search("USE\s+[\w\W]+?GO", data)
#             if match_str:
#                 if '.' not in obj_name:
#                     obj_name = "dbo." + obj_name
#                 schema = obj_name.split('.')[0]
#                 tbl_name = obj_name.split('.')[1]
#                 drop_query = "IF OBJECT_ID('{0}.{1}', '{2}') IS NOT NULL \n DROP {3} {0}.{1};\n".format(schema, tbl_name, dict_object_type_details[obj_type], obj_type)
#                 drop_replace_str = "{0}\n{1}".format(match_str[0], drop_query)
#                 data = re.sub("USE\s+[\w\W]+?GO", drop_replace_str, data, 1)
#                 if update_table_flag:
#                     data = re.sub(re_match_str, re_replace_str, data, flags=re.I)  
#                 with open(write_loc,'w', encoding='utf-8-sig', newline="")as f:
#                     f.write(data)
#                 f.close()
                

#     except Exception as e:
#         exc_type, exc_obj, exc_tb = sys.exc_info()
#         print(exc_tb.tb_lineno)
#         print(e.args[1])    

# def column_struct_compare(logger, dserver_name, pserver_name, new_col_sel, sql_prod, sql_dev, file_idx, file_usr, dev_sql_loc, write_loc, flag, obj_type, obj_name, update_table_flag = False):
#     # try:
  
#     if obj_type.lower().strip() == 'table':
#         if sql_dev.empty:
#             raise Exception("There is no table detectedin dev")
#         if sql_prod.empty:
#             raise Exception("There is no table detectedin prod")
#         if(not(sql_dev.equals(sql_prod))): #if the dataframes are not equal, then compares each row to capture any differences (added or modified) compares against the new columns specified to keep. keeps columns in common plus specified while ignoring non specified
#             diff_df = pd.concat([sql_dev,sql_prod]).drop_duplicates(keep=False)
#             unique_df = diff_df.drop_duplicates(subset='Column Name', keep="last")
#             diff_coulmn_list = unique_df['Column Name'].to_list()
#             keep = []
#             ignore = []
#             if flag:
#                 keep = new_col_sel.split(',')
#                 ignore = getDeltas(diff_coulmn_list, keep)
#                 if ignore:
#                     ignore_str = ",".join(ignore)
#                     ignore_str = re.sub(r'\,', '],[', ignore_str)
#                     ignore_str = "[{0}]".format(ignore_str)
#                     ignore = ignore_str.split(',')
#             first_col = ''
#             if obj_type.lower().strip() == 'table':
#                 if '.' not in obj_name:
#                     obj_name = "dbo." + obj_name
#                 without_dbo = obj_name.split('.')[1]
#                 weekly_release_utils.add_record_into_load_table_filegroup_sql_file(logger, dserver_name, pserver_name, without_dbo, True)
#             write_file(dev_sql_loc, write_loc, first_col, keep, ignore, file_idx, file_usr, obj_type, obj_name, flag, update_table_flag)
#         else:
#             raise Exception("Structures are equal. No change detected.") #if no change then exception raised so developer can handle as necessary
#     if obj_type.lower().strip() == 'view':
#         if sql_dev.empty:
#             raise Exception("There is no view detected.")
#         else:   
#             first_col = sql_dev.iloc[0, 0]
#             keep = []
#             ignore = []
#             write_file(dev_sql_loc, write_loc, first_col, keep, ignore, file_idx, file_usr, obj_type, obj_name, flag)
            
#     # except Exception as e:
#     #     exc_type, exc_obj, exc_tb = sys.exc_info()
#     #     print(exc_tb.tb_lineno)
#     #     print(e.args[1])
     
# def file_check(logger, obj_type, obj_name, file_loc, write_loc):
#     try:
#         if obj_type.lower().strip() == 'table':
#             dev_sql_loc = obj_name+'.Table.sql'
#         elif obj_type.lower().strip() == 'view':
#             dev_sql_loc = obj_name+'.View.sql'
#         logger.debug('file_check function sql file name{0}'.format(dev_sql_loc))
#         directory = os.listdir(path = file_loc)
#         flag = True
#         for i in directory: 
            
#             if dev_sql_loc.lower() == i.lower():
#                 dev_sql_loc = i
#                 flag = False
#                 break
#         if obj_type.lower().strip() == 'view': 
                      
#             if len(glob.glob(file_loc+'\\*' + dev_sql_loc)) > 0:
#                 dev_sql_loc = glob.glob(file_loc+'\\*' + dev_sql_loc)[0]
                
#         else:
#             dev_sql_loc = file_loc+'\\'+ dev_sql_loc
            
#         if obj_type.lower().strip() == 'table':
#             if not os.path.exists(write_loc+'\\Table'):
#                 os.makedirs(write_loc+'\\Table')
#             new_sql_loc = write_loc+'\\Table\\'+obj_name+'.Table.sql' #saves to the table folder if object type is table to keep in check with weekly release
#         elif obj_type.lower().strip() == 'view':
#             if not os.path.exists(write_loc+'\\View'):
#                 os.makedirs(write_loc+'\\View')
#             new_sql_loc = write_loc+'\\View\\'+obj_name+'.View.sql' #saves to the view folder if object type is view to keep in check with weekly release
#         return dev_sql_loc, new_sql_loc
#     except Exception as e:
#         exc_type, exc_obj, exc_tb = sys.exc_info()
#         print(exc_tb.tb_lineno)
#         print(e.args[1])
    

# def metadata_exp_comp_create(logger, dserver_name, db, obj_name, obj_type, pserver_name, new_col_sel, file_loc, write_loc):
#     # try:
#     (server, u, p) = weekly_release_utils.read_cred_for_server(dserver_name)
#     (pserver, puid, ppwd) = weekly_release_utils.read_cred_for_server(pserver_name)
#     logger.debug('Insert metadata_exp_comp_create function initiated')
#     if obj_type.lower().strip() == 'table':
#         if '.' not in obj_name:
#             obj_name = "dbo." + obj_name
#     elif obj_type.lower().strip() == 'view':
#         if '.' not in obj_name:
#             obj_name = "dbo." + obj_name
#     logger.debug('Schema and table name values {0}'.format(obj_name))
#     schema = obj_name.split('.')[0]
#     tbl_name = obj_name.split('.')[1]
#     logger.debug('Schema and table name server {0} db  {1} user {2} '.format(obj_name, db, u))
#     weekly_release_utils.sql_metadata_exp(logger, server, db, u, p, obj_name, file_loc) #in this case will get the metadata from the dev
#     tb_dev_struct = weekly_release_utils.table_column_structure(server, db, u, p, schema, tbl_name) #uses the dev credentials that was passed to the metadata extract
#     tb_prod_struct = weekly_release_utils.table_column_structure(pserver, db, puid, ppwd, schema, tbl_name) #uses the prod credentials just to compare current state of prod
#     usr, idx = weekly_release_utils.file_idx_usr_grp(logger, pserver, db, puid, ppwd) #wants to get the top idx and usr group from prod where ordered by free space
#     (dev_sql_loc, new_sql_loc) = file_check(logger, obj_type, obj_name, file_loc, write_loc)
#     if new_col_sel == '':
#         column_struct_compare(logger, dserver_name, pserver_name, new_col_sel, tb_prod_struct, tb_dev_struct, idx, usr, dev_sql_loc, new_sql_loc, False, obj_type.lower().strip(), obj_name, True) #checks the structures, gets the differences and compares to list, ignores differences not on list passed and writes new sql prepped for prod
#     else:
#         column_struct_compare(logger, dserver_name, pserver_name, new_col_sel, tb_prod_struct, tb_dev_struct, idx, usr, dev_sql_loc, new_sql_loc, True, obj_type.lower().strip(), obj_name, True)
#     # except Exception as e:
#     #     exc_type, exc_obj, exc_tb = sys.exc_info()
#     #     print(exc_tb.tb_lineno)
#     #     print(e.args[1])

def weekly_release_checkandreprojectdim(logger,base_path, release_date, dev, prod, db, file_loc, write_loc):
    logger.debug('weekly_release_procedure function initiated')
    file_path = 'C:\\Users\\sundarr6\\LNRISK\\FIDO\\code\\weekly-code-release\\SQL Changes - ALL.xlsx' #'{0}\\SQL Changes - ALL.xlsx'.format(base_path)
    df = weekly_release_utils.read_excel(file_path, release_date, 3)

    logger.debug('pandas frame work {0}'.format(df))
    df = df[['Table/Object/Report', 'Change', 'Object Type', 'Type of change (SQL, OBIEE,ECL)', 'columns to modify and keep', 'Application', 'dim/fact name', 'despray_start_month']]
    # t = df[df['Type of change (SQL, OBIEE,ECL)'] != 'ECL']
    a = df[['Table/Object/Report', 'Change', 'Object Type', 'columns to modify and keep', 'Type of change (SQL, OBIEE,ECL)', 'dim/fact name', 'despray_start_month']]
    downloaded = a.dropna(subset = a.columns[[0,1,2]])
    downloaded.reset_index(inplace = True, drop = True)
    downloaded = downloaded.fillna('')
    logger.debug('After cleaning pandas data frame {0}'.format(downloaded))
    (server, u, p) = weekly_release_utils.read_cred_for_server(logger, dev)
    (pserver, puid, ppwd) = weekly_release_utils.read_cred_for_server(logger, prod)
    status_dict = {}
    reprojected = []
    ecl_reprojection_code = []
    non_reprojected = []
    for i in downloaded.index:
        try:

            downloaded.iloc[i,0] = re.sub("\[|\]", '', downloaded.iloc[i,0])
            if downloaded.iloc[i,1].lower() in ['update record', 'insert record']:
                continue
            if downloaded.iloc[i,2].lower() == 'table':
                obj_name = downloaded.iloc[i,0]
                if '.' not in obj_name:
                    obj_name = "dbo." + obj_name            
                schema = obj_name.split('.')[0]
                tbl_name = obj_name.split('.')[1]                
                thor_logical_file_name = ''
                if downloaded.iloc[i,5].lower() != 'nan' and downloaded.iloc[i,5].strip() != '':
                    year_month =str(downloaded.iloc[i,6])
                    if  year_month.lower() != 'nan' and year_month.strip() != '':                        
                        thor_logical_file_name = "thor::{0}::dm::{1}::{2}::{3}".format(commonArgs.getApplication(), year_month[0:4], year_month[4:6], downloaded.iloc[i,5])
                    else :
                        if downloaded.iloc[i,5].find('.') >= 0:
                            despray_list = downloaded.iloc[i,5].split('.')
                            despray_list = despray_list.reverse()
                            thor_logical_file_name = "thor::{0}::dm::{1}".format(commonArgs.getApplication().lower(), despray_list[1])
                            
                        else:
                            thor_logical_file_name = "thor::{0}::dm::{1}".format(commonArgs.getApplication().lower(), downloaded.iloc[i,5])
                    
                    ecl_prod_column_list = weekly_release_utils.get_logical_filename_layout(thor_logical_file_name, parse_props.getPropFromSource('common','HPCCProd'))
                    ecl_dev_column_list = weekly_release_utils.get_logical_filename_layout(thor_logical_file_name, parse_props.getPropFromSource('common','HPCCDev'))

                    if list(map(lambda x: x.lower(), ecl_dev_column_list)) != list(map(lambda x: x.lower(), ecl_prod_column_list)):
                        ecl_reprojection_code.append("red.dm.fn_promote_dim('~{0}')".format(thor_logical_file_name))
                        reprojected.append(downloaded.iloc[i])
                    else:
                        non_reprojected.append(downloaded.iloc[i])

                    
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_tb.tb_lineno)
            issue_string = 'Object have issue on {0}'.format(e)
            listsstatus =[]
            listsstatus.append('False')
            listsstatus.append('')
            listsstatus.append(issue_string)
            status_dict[downloaded.iloc[i,0]] = listsstatus
            print('*****************************************************************************')
            print('\n'+'------------'+ downloaded.iloc[i,0] + " had issue. Pease advise ------------"+'\n')
            print(e)
            print('\n')
            print('*****************************************************************************')
            continue 
    logger.debug('weekly_release_procedure function Completed')
    print('sequential(' + ",".join(list(set(ecl_reprojection_code))) + ');')
    return status_dict

def process():
    logger = getLogger()
    if(commonArgs.getFiledate() == ''):
        sheet_name = datetime.today().strftime('%Y-%m-%d')
    else:
        sheet_name = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
    
    base_path = weekly_release_utils.get_base_path()
    status_dict = weekly_release_checkandreprojectdim(logger, base_path, sheet_name, 'DEV_SQl_DB_CRED', 'PROD_SQl_DB_CRED', commonArgs.getApplication() , weekly_release_utils.get_script_path(), weekly_release_utils.get_script_path())
    if status_dict:
        generate_weekly_email.notifyScriptCreationEmail(status_dict)

if __name__ == "__main__":
    process() 


# sequential(
#     red.dm.fn_promote_dim('~thor::red::dm::fact_ins_royalty'),
#     red.dm.fn_promote_dim('~thor::red::dm::dim_sf_contact_history')
# );