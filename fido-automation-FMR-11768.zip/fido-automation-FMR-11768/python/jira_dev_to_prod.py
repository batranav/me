from distutils.dir_util import copy_tree 
from shutil import copyfile
import shutil
import datetime
import os
import parseYamlProperty

#fromDirectory = "//alawdred201.risk.regn.net/d$/red/data/inbound/salesforce/daily/raw_" + time.strftime('%Y%m%d')+"/"
# copy all contents

today_date = datetime.datetime.today().strftime('%Y%m%d')
source='jira'
frequency='daily'
host_machine='alawdred201'
target_machine=os.environ['COMPUTERNAME']

# to catch up old days, change the value in the below line: datetime.timedelta(days=2) to number of days before today's date
# yesterday = datetime.datetime.today() - datetime.timedelta(days=2)
# yesterday_date = yesterday.strftime('%Y%m%d')


src_path="\\\\"+host_machine+"\\"+ parseYamlProperty.get_inbound_dir()+source+"\\"+frequency+"\\"
src_path=src_path.replace(':','$')
dest_path="\\\\"+target_machine+"\\"+ parseYamlProperty.get_inbound_dir()+source+"\\"+frequency+"\\"
dest_path=dest_path.replace(':','$')


src1 = src_path+"fields_" + today_date + ".csv"
src2 = src_path+"worklog_" + today_date + ".csv"
src3 = src_path+"issues_" + today_date + ".csv"
src4 = src_path+"resolution_" + today_date + ".csv"
src5 = src_path+"worklog_comment_" + today_date + ".csv"
src6 = src_path+"history_" + today_date + ".csv"
dest1 = dest_path+"fields_" + today_date + ".csv"
dest2 = dest_path+"worklog_" + today_date + ".csv"
dest3 = dest_path+"issues_" + today_date + ".csv"
dest4 = dest_path+"resolution_" + today_date + ".csv"
dest5 = dest_path+"worklog_comment_" + today_date + ".csv"
dest6 = dest_path+"history_" + today_date + ".csv"

shutil.copy2( src1,dest1) 
shutil.copy2( src2,dest2) 
shutil.copy2( src3,dest3) 
shutil.copy2( src4,dest4) 
shutil.copy2( src5,dest5) 
shutil.copy2( src6,dest6)