#from datetime import datetime
import datetime
import binascii
import codecs
import io
import sys
import csv
import pyodbc
from sendEmail import *
import string
import parseYamlProperty
import getSQLdata
import os
import commonArgs
import AutomationLogging


printList = []
cntmismtachList = []
filedate = commonArgs.getFiledate()
filedate = filedate if filedate else datetime.datetime.today().strftime('%Y%m%d')
today     = datetime.datetime.strptime(filedate, '%Y%m%d')
yesterday = datetime.datetime.strptime(filedate, '%Y%m%d') - datetime.timedelta(days=3)
#today     = datetime.datetime.strptime('2019-08-11 00:15:00',"%Y-%m-%d %H:%M:%S")
#yesterday = datetime.datetime.strptime('2019-08-10 00:15:00',"%Y-%m-%d %H:%M:%S")

today_yyyymmdd = today.strftime("%Y-%m-%d")+' 00:00:00'
yesterday_yyyymmdd = yesterday.strftime("%Y-%m-%d")+' 00:00:00'
print(today_yyyymmdd)
print(yesterday_yyyymmdd)

class GracefullyExit(Exception):
    pass
  
def printwrapper(str, errorFlag=False,addcolor=False):
    print(str)
    if addcolor:
        # strtemp = WARNING+str+ENDC
        strtemp = str
    else:
        strtemp = str
    if errorFlag:
        printList.reverse()
        printList.append(strtemp)
        printList.reverse()
    else:
        printList.append(strtemp)

def createlog(source):
    #print(len(printList))
    if len(printList) > 0:
        logfile = open('logs\\datapull\\' + source + '_' + today.strftime('%m-%d-%Y_%H_%M_%S'), 'w')
        for str in printList:
            logfile.write('%s\n' %str)
        logfile.close()

def attempt_strip(x):
    try:
        return x.strip()
    except AttributeError:
        return x

def checkNone(x):
    if x == 'None':
        #print('None condition')
        return ('')
    else:
        return(x)

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1       

def pull_files():
    flag = 1
    nbrofmismatchfiles = 0
    maxcntmismtachList = 0 
    try:
        source = 'cru'
        flag = 1
        nbrofmismatchfiles = 0
        maxcntmismtachList = 0
        logger = AutomationLogging.getLogger('preprocess_cru_pull')
        (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, source,'daily','')
        printwrapper('Calling CRU DB extract process')
        #strttime = today.strftime('%Y%m%d%H%M%S')
        strttime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        #conn = pyodbc.connect("DSN=cru")
        conn = pyodbc.connect(connstr)
        cursor = conn.cursor()
        cursor_cnt = conn.cursor()
        printwrapper('\nConnection to CRU DB extablished')
     
        sqltoexecute_agency = 'SELECT STATE_NBR,  AGENCY_ID,  AGENCY_CHECK_NAME,  AGENCY_NAME,  AGENCY_TYPE,  NCIC,  CONTACT_INFO,  DEPT,  ADDR1,  ADDR2,  CITY,  STATE_ABBR,  ZIPCODE,  COUNTY,  COUNTRY,  PHONE_NBR,  PHONE_EXT,  FAX_NBR,  SAMPLE_RPT1,  SAMPLE_RPT2,  EXPECTED_TURNAROUND,  DELAY,  ACCEPT_FAX,  ON_ACCOUNT,  ACCOUNT_NBR,  CHECK_TYPE,  ENVELOPE_TYPE,  MISC_TYPE,  AMOUNT_TYPE,  ACCIDENT_ONLY,  INCIDENT_ONLY,  OPERATOR_REQUIRED,  COST_OVERRIDE,  REPORT_NOT_RELEASABLE,  CALL_FOR_PRICE,  KEEPS_CHECK,  LOCAL_PRINT,  ASSIGNMENT_COST,  SURCHARGE_COST,  COURIER,  EMAIL,  CALL_REGION_ID,  FAX_RELEASE,  PAYMENT_TYPE,  VERSION,  LAST_CHANGED,  USERID,  DMV_AGENCY,  FORM_COUNT,  INTERNET_PD,  NON_MAIL_AGENCY,  ALLOW_SECOND_REQUEST,  REPROCESS_REPORT,  EMAIL_PD,  ORDER_EMAIL,  EMAIL_IMAGE_TYPE,  ACTIVE,  MAX_EMAIL_DOC_COUNT,  VIN_PD,  VIN_STATE_ABBR,  PREVIOUS_MONTH_TAT,  ALLOWS_CALL,  ALT_EXPECTED_TAT,  ALT_PREV_MONTH_TAT,  ALT_PREV_MONTH_ORDER_VOLUME,  ALT_SPA_AGENCY,  ECRASH_AGENCY,  CRU_GO_FORWARD_DATE,  MISC_REVENUE,  VIDEO_SURVEILLANCE,  CREATION_DATE,  DOC_ROUTING_NOT_ALLOWED,  PREPAY,  PRECOURIER_TAT,  CRASH_TAX,  COURIER_UTL_FEE,  ORI,  INTERNET_ONLY,  RETRY_DAYS,  TIMELY_AGENCY,  DOL_START,  DOL_END,  REQUEST_A_REPORT,  MBS_ID,  VENDOR_SOURCE_ID,  COPLOGIC FROM cruprd.AGENCY ';
        sqltoexecute_client = 'SELECT ACCT_NBR,  CLIENT_ID,  COMPANY_NAME,  BILL_TYPE,  BILL_CYCLE,  EBILL_CLIENT,  ACTIVE,  OPERATOR_REQUIRED,  COVER_PAGE,  FILE_SOURCE,  AUTH_LETTER,  START_DATE,  SEND_COST_TO_CLIENT,  COMMENT1,  COMMENT2,  DIVISION_CLIENT,  ONLINE_SERVICES,  ALT_DELIVERY,  NATIONAL_CLIENT,  SALES_REP,  ACCT_MGR,  CLIENT_NOTICE,  ENVELOPE_ADDR_TYPE,  VERSION,  LAST_CHANGED,  USERID,  DMV_CLIENT,  CLIENT_TYPE_ID,  COMPANY_NBR,  AGREEMENT_NBR,  AGREEMENT_ON_FILE,  ASSOC_COST_RESTRICTED,  ORDER_IMPORT_FORMAT_ID,  WSDL_URL,  WSDL_LAST_CHANGED,  WSDL_LAST_CHANGED_USERID,  INTERNAL_VERTICAL,  AUTH_USERNAME,  AUTH_PASSWORD,  NON_BILLABLE,  INTERNAL_VERTICAL_NAME,  LEGAL_NAME,  TRIGGERED_LAST_CHANGED,  NEW_ORDER_RESTRICTED,  COPY_ORDER_RESTRICTED,  MRR_ACCESS,  AW_ACCT,  TEST_CLIENT,  RESTRICT_NOTICE_REASON  FROM cruprd.CLIENT ';
        sqltoexecute_company = 'SELECT COMPANY_NBR,  COMPANY_NAME,  COMMENT1,  COMMENT2,  LAST_CHANGED,  USERID,  ASSOC_COST_RESTRICTED,  IP_RESTRICTED,  WSDL_URL,  WSDL_LAST_CHANGED,  WSDL_LAST_CHANGED_USERID,  AUTH_USERNAME,  AUTH_PASSWORD,  INTERNAL_VERTICAL,  INTERNAL_VERTICAL_NAME,  NON_BILLABLE,  NEW_ORDER_RESTRICTED,  COPY_ORDER_RESTRICTED,  AW_ALERT,  AW_LOOK_BACK_PERIOD,  AW_DELAY_PERIOD  FROM cruprd.COMPANY ';
        sqltoexecute_client_adjuster = 'SELECT ADJUSTER_ID,  ACCT_NBR,  ACCT_SUFFIX,  FIRST_NAME,  LAST_NAME,  DEPT, EMAIL as EMAIL ,  ACTIVE,  INTERNAL_ID,  EFFECTIVE_DATE,  LAST_CHANGED,  USERID,  ADDR1,  ADDR2,  CITY,  STATE_ABBR,  ZIPCODE,  PHONE,  PHONE_EXT,  FAX_NBR,  MRR_ID,  CREATED_BY,  NEW_PASSWORD_POLICY,  EMPLOYEE_NUMBER  FROM cruprd.CLIENT_ADJUSTER ';
        sqltoexecute_reason = 'SELECT REASON_ID,  REASON_DESC,  NOTICE,  LAST_CHANGED,  USERID,  AVAIL_FOLLOWUP,  REASON_NOTE,  ASSOC_ORDER,  VIEWABLE  FROM cruprd.REASON ';
        sqltoexecute_service = 'SELECT SERVICE_ID,  SERVICE_CAT_ID,  SERVICE_DESC,  DEFAULT_FEE,  OPERATOR_REQUIRED,  INCIDENT,  ACCIDENT,  CP_REPORT_CODE,  BILLING_DESC,  LAST_CHANGED,  USERID,  DMV_SERVICE,  ASSOC_ORDER,  VIN_INCIDENT_INCLUDE,  SORT_ORDER,  SHORT_NAME,  DISPLAY_CAT,  CARFAX_EXTRACT_INCLUDE,  TRIGGERED_LAST_CHANGED,  ALT_CP_REPORT_CODE  FROM cruprd.SERVICE ';
        sqltoexecute_state = 'SELECT STATE_ABBR,  STATE_NBR,  STATE_NAME,  PRINT_REGION_ID,  VALID_STATE,  LAST_CHANGED,  USERID,  VIN_INCIDENT_INCLUDE,  VIN_STATUS,  TAG_INCLUDE,  TRIGGERED_LAST_CHANGED  FROM cruprd.STATE ';
        sqltoexecute_status = 'SELECT STATUS_ID,  STATUS_DESC,  LAST_CHANGED,  USERID,AVAIL_FOLLOWUP,  STATUS_NOTE  FROM cruprd.status ';
        #sqltoexecute_order_version = 'SELECT ORDER_ID,  SEQUENCE_NBR,  DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE,  ACCT_NBR,  ACCT_SUFFIX as ACCT_SUFFIX,  CLIENT_ID as CLIENT_ID,  ADJUSTER_ID as ADJUSTER_ID,  STATE_NBR,  AGENCY_ID as AGENCY_ID,  AGENCY_TYPE as AGENCY_TYPE,  edit_agency_name as edit_agency_name,  SERVICE_ID as SERVICE_ID,  STATUS_ID as STATUS_ID,  REASON_ID as REASON_ID,  QUEUE as QUEUE,  CLAIM_NBR as CLAIM_NBR,  DATE_FORMAT(LOSS_DATE,\'%d-%b-%Y %H:%i:%s\') as LOSS_DATE,  LOSS_TIME as LOSS_TIME,  PRECINCT as PRECINCT,  REPORT_NBR as REPORT_NBR,  HOUSE_NBR as HOUSE_NBR,  STREET as STREET,  APT_NBR as APT_NBR,  CROSS_STREET as CROSS_STREET,  CITY as CITY,  STATE_ABBR as STATE_ABBR,  ZIP5 as ZIP5,  ZIP4 as ZIP4,  COUNTY as COUNTY,  TAG as TAG,  TAG_STATE as TAG_STATE,  VIN as VIN,  MAKE as MAKE,  MODEL as MODEL,  FIRST_NAME_1 as FIRST_NAME_1,  MIDDLE_NAME_1 as MIDDLE_NAME_1,  LAST_NAME_1 as LAST_NAME_1,  SSN_1 as SSN_1,  DATE_FORMAT(DOB_1,\'%d-%b-%Y %H:%i:%s\') as DOB_1,  FIRST_NAME_2 as FIRST_NAME_2,  MIDDLE_NAME_2 as MIDDLE_NAME_2,  LAST_NAME_2 as LAST_NAME_2,  FIRST_NAME_3 as FIRST_NAME_3,  MIDDLE_NAME_3 as MIDDLE_NAME_3,  LAST_NAME_3 as LAST_NAME_3,  DRIVERS_LICENSE as DRIVERS_LICENSE,  DRIVERS_LICENSE_ST as DRIVERS_LICENSE_ST,  DATE_FORMAT(PROCESSED_DATE,\'%d-%b-%Y %H:%i:%s\') as PROCESSED_DATE,  DATE_FORMAT(PRINT_DATE,\'%d-%b-%Y %H:%i:%s\') as PRINT_DATE,  DATE_FORMAT(CHECKIN_DATE,\'%d-%b-%Y %H:%i:%s\') as CHECKIN_DATE,  COST_OVERRIDE,  ADDITIONAL_INFO as ADDITIONAL_INFO,  SPECIAL_NOTE as SPECIAL_NOTE,  SPECIAL_BILLING_ID as SPECIAL_BILLING_ID,  EXPECTED_TURNAROUND,  DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,  USERID as USERID,  ACTUAL_TURNAROUND,  ORDERPOINT_STATUS as ORDERPOINT_STATUS,  YEAR as YEAR,   HISTORICAL_NOTICE,  AGENCY_COST,  HANDLING_FEE,  CLIENT_QUOTEBACK as CLIENT_QUOTEBACK,  DATE_FORMAT(SECOND_REQUEST_PRINT_DATE,\'%d-%b-%Y %H:%i:%s\') as SECOND_REQUEST_PRINT_DATE,  SUFFIX_1 as SUFFIX_1,  GENDER_1 as GENDER_1,  STATE_SERVICE_TYPE_NAME as STATE_SERVICE_TYPE_NAME,  BILLING_RESTRICTED as BILLING_RESTRICTED,  DATE_FORMAT(TRIGGERED_LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as TRIGGERED_LAST_CHANGED,  SEND_TO_PRINT as SEND_TO_PRINT,  DATE_FORMAT(SEND_TO_PRINT_DATE,\'%d-%b-%Y %H:%i:%s\') as SEND_TO_PRINT_DATE,  SEND_TO_PRINT_USERID as SEND_TO_PRINT_USERID,  DONOTASSOCIATE_FLAG  FROM cruprd.ORDER_VERSION where (creation_date >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  creation_date < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR(triggered_last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and triggered_last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and creation_date < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_int_order = 'SELECT ORDER_ID,  DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as creation_date,  ACCT_NBR,  ACCT_SUFFIX,  CLIENT_ID,  ADJUSTER_ID,  SERVICE_ID,  STATUS_ID,  REASON_ID,  QUEUE,  CLAIM_NBR,  DATE_FORMAT(LOSS_DATE,\'%d-%b-%Y %H:%i:%s\') as loss_date,  REPORT_NBR,  CROSS_STREET,  TAG,  TAG_STATE,  VIN,  MAKE,  MODEL,  YEAR,  FIRST_NAME,  MIDDLE_NAME,  LAST_NAME,  SUFFIX,  SSN,  DOB,  GENDER,  DRIVERS_LICENSE,  DRIVERS_LICENSE_ST,  PREVIOUS_DL_NBR,  PREVIOUS_DL_STATE,  DATE_FORMAT(PROCESSED_DATE,\'%d-%b-%Y %H:%i:%s\') as processed_date,  DATE_FORMAT(FULFILLED_DATE,\'%d-%b-%Y %H:%i:%s\') as fulfilled_date,  DATE_FORMAT(CHECKIN_DATE,\'%d-%b-%Y %H:%i:%s\') as checkin_date,  SPECIAL_BILLING_ID,  ORDERPOINT_STATUS,  POLICY_CARRIER_AUTO,  POLICY_NBR_AUTO,  POLICY_CARRIER_PROPERTY,  POLICY_NBR_PROPERTY,  PREVIOUS_POLICY_TYPE,  MORTGAGE_LOAN_NBR,  MORTGAGEE,  ORIG_ORDER_ID,  INITIAL_ORDER,  RULES_STATUS_CD,  DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as last_changed,  USERID,  VERSION,  STATE_SERVICE_TYPE_NAME,  SEARCH_MODE,  PROCESS_STATE,  PROCESSOR, DATE_FORMAT(TRIGGERED_LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as TRIGGERED_LAST_CHANGED,  TIF_IMAGE_HASH,  SOURCE_ID,  RULES_CDE_STATUS_CD  FROM cruprd.INT_ORDER where  creation_date >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and creation_date < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')';
        sqltoexecute_order_billing = 'SELECT ORDER_ID,SEQUENCE_NBR,BILLING_NBR,BILLING_REASON_ID,AMOUNT,DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE,BILL_INDICATOR,INVOICE_NBR,DATE_FORMAT(INVOICE_DATE,\'%d-%b-%Y %H:%i:%s\') as INVOICE_DATE, COST_OR_FEE,VERSION, DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED, USERID,BILLING_CODE FROM cruprd.order_billing where (creation_date >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  creation_date < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and creation_date < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_int_order_billing = 'SELECT ORDER_ID,BILLING_NBR,BILLING_REASON_ID,AMOUNT,DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE,BILL_INDICATOR,INVOICE_NBR,DATE_FORMAT(INVOICE_DATE,\'%d-%b-%Y %H:%i:%s\') as INVOICE_DATE, COST_OR_FEE,VERSION,BILLING_CODE, DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED, USERID FROM cruprd.int_order_billing where (creation_date >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  creation_date < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and creation_date < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_int_order_address = 'SELECT ORDER_ID, ADDR_TYPE, HOUSE_NBR, STREET, APT_NBR, CITY, STATE_ABBR, ZIP5, ZIP4, PHONE_NBR, VERSION FROM cruprd.INT_ORDER_ADDRESS' ;
        sqltoexecute_assoc_order_group = 'SELECT ORDER_ID,SEQUENCE_NBR,GROUP_ID,ALGORITHM_ID,STATUS,DATE_FORMAT(ASSOC_DATE,\'%d-%b-%Y %H:%i:%s\') as ASSOC_DATE,DATE_FORMAT(RESULT_SHIP_DATE,\'%d-%b-%Y %H:%i:%s\') as RESULT_SHIP_DATE,CONFIDENCE_LEVEL,ORIGINAL_ASSOC_METHOD,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED, USERID,ORIGINAL_REASON_ID FROM cruprd.assoc_ordeR_group where (ASSOC_DATE >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  ASSOC_DATE < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and ASSOC_DATE < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_result = 'SELECT RESULT_ID, ORDER_ID,SEQUENCE_NBR,BATCH_ID,PAGE_COUNT,START_INDEX, END_INDEX, STATUS, RESULT_TYPE, DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE, HAS_ORIGINAL_COVER, POOR_QUALITY, BATCH_DOC_NBR, DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,USERID,VIN_ENTRY_STATUS,DATE_FORMAT(TRIGGERED_LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as TRIGGERED_LAST_CHANGED, WORK_TYPE,DATE_FORMAT(DATA_RECEIVED,\'%d-%b-%Y %H:%i:%s\') as DATA_RECEIVED  FROM cruprd.result where (CREATION_DATE >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  CREATION_DATE < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (TRIGGERED_last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and TRIGGERED_last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and CREATION_DATE < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_client_division = 'SELECT ACCT_NBR,ACCT_SUFFIX,DIVISION_NAME,DEFAULT_DIVISION,FAX_NBR, EMAIL, ONLINE_SERVICES, VERSION, DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED, USERID, RETURNED_CHECK_FLAT_FEE, COURIER_ALLOWED, MAIL_AGENCY_REQUIRED, CALL_ALLOWED, REROUTE_ALLOWED, RETURNED_CHECK_TYPE, CLAIMS_MVR, CREDENTIALED, HIGH_PRIORITY_CLIENT, HIGH_PRIORITY_CLIENT_NOTE, CLAIMS_CCFC, CHARGE_CCFC_NRFN_FEE, CCFC_NRFN_FEE_AMT, CUSTOM_FIELD_ACCESS, CLAIMS_DISCOVERY, CHARGE_CLAIMS_DISC_NRFN_FEE, CLAIMS_DISC_FEE_AMT, MRR_ACCESS, CARRIER_ID, CHARGE_CARRIER_ID_NRFN_FEE, CARRIER_ID_FEE_AMT, CCFC_ENH, CCFC_DOL_DAYS, CCFC_PARTIAL_HIT_PCT, CLAIMS_COMPREHENSIVE, COMPREP_NRFN_FEE_AMT, CHARGE_COMPREP_NRFN_FEE, PEOPLE_LOCATOR, PEOLOC_NRFN_FEE_AMT, CHARGE_PEOLOC_NRFN_FEE,ACTIVE  FROM cruprd.CLIENT_DIVISION' ; 
        sqltoexecute_agency_service = 'SELECT STATE_NBR,AGENCY_ID,SERVICE_ID,COST,VERSION,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED, USERID  FROM cruprd.AGENCY_SERVICE ' ; 
        sqltoexecute_order_note = 'SELECT ORDER_NOTE_ID,ORDER_ID,SEQUENCE_NBR,convert(TEXT_INTERNAL using ascii) as TEXT_INTERNAL,convert(TEXT_EXTERNAL using ascii) as TEXT_EXTERNAL ,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED, USERID  FROM cruprd.ORDER_NOTE  where (LAST_CHANGED >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  LAST_CHANGED < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))' ;   
        sqltoexecute_hpcc_order_match = 'SELECT MATCH_ID,ORDER_ID,SEQUENCE_NBR,DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE ,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,USERID FROM cruprd.HPCC_ORDER_MATCH where (CREATION_DATE >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  CREATION_DATE < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and CREATION_DATE < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        #sqltoexecute_hpcc_potential_match = 'SELECT MATCH_ID,ECRASH_INCIDENT_ID,ORDER_ID,SEQUENCE_NBR,MATCH_STATUS,WEIGHT_SCORE,DATA_SOURCE,WORK_TYPE,DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE ,SERVICE_ID,ORI_NBR,STATE_REPORT_NBR,ST_REPORT_NBR_MATCH_TYPE,STATE_ABBR,STATE_MATCH_TYPE,ZIP4,ZIP4_MATCH_TYPE,ZIP5,ZIP5_MATCH_TYPE,loc_report_nbr,LOC_REPORT_NBR_MATCH_TYPE,DATE_FORMAT(LOSS_DATE,\'%d-%b-%Y %H:%i:%s\') as LOSS_DATE,LOSS_DATE_MATCH_TYPE,LOSS_TIME,LOSS_CITY,LOSS_CITY_MATCH_TYPE,LOSS_COUNTY,LOSS_COUNTY_MATCH_TYPE,LOSS_STREET,LOSS_STREET_MATCH_TYPE,LOSS_CROSS_STREET,LOSS_CROSS_STREET_MATCH_TYPE,PRECINCT, AGENCY_ID, AGENCY_NAME, AGENCY_NAME_MATCH_TYPE,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,USERID, RESULT_ID, VENDOR_CODE, VENDOR_REPORT_NUMBER, ECRASH_AGENCY_ID, ECRASH_AGENCY_NAME, ACCT_LOG_TRANSACTION_ID, BATCH_UPDATE, CRU_GENERATED_REPORT_KEY, REPORT_ID, CONTRIB_SOURCE FROM cruprd.HPCC_POTENTIAL_MATCH where (CREATION_DATE is null and (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))) OR (CREATION_DATE is not null and CREATION_DATE >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  CREATION_DATE < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (CREATION_DATE is not null and last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and CREATION_DATE < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_order_payment = 'SELECT ORDER_PAYMENT_ID,ORDER_ID,SEQUENCE_NBR,DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE ,PAYMENT_TYPE,PAYMENT_STATUS_ID,ACCT_NBR,CHECK_NBR,PRINT_AMOUNT,DATE_FORMAT(PRINT_DATE,\'%d-%b-%Y %H:%i:%s\') as PRINT_DATE,DATE_FORMAT(TERM_DATE,\'%d-%b-%Y %H:%i:%s\') as TERM_DATE,DATE_FORMAT(CLEAR_DATE,\'%d-%b-%Y %H:%i:%s\') as CLEAR_DATE,CLEAR_AMOUNT,CLEAR_PROBLEM,BANK_TRACKING_NBR,BILLED_AMT,DATE_FORMAT(BILLED_DATE,\'%d-%b-%Y %H:%i:%s\') as BILLED_DATE,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,USERID,NEW_STATE_NBR,NEW_AGENCY_ID FROM cruprd.ORDER_PAYMENT where (CREATION_DATE >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  CREATION_DATE < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and CREATION_DATE < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_order_version = 'SELECT ORDER_ID,  SEQUENCE_NBR,  DATE_FORMAT(CONVERT(CREATION_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE,  ACCT_NBR,  CONVERT(ACCT_SUFFIX using ascii) as ACCT_SUFFIX,  convert(CLIENT_ID using ascii) as CLIENT_ID,  convert(ADJUSTER_ID using ascii) as ADJUSTER_ID,  STATE_NBR,  convert(AGENCY_ID using ascii) as AGENCY_ID,  convert(AGENCY_TYPE using ascii) as AGENCY_TYPE,  convert(edit_agency_name using ascii) as edit_agency_name,  convert(SERVICE_ID using ascii) as SERVICE_ID,  convert(STATUS_ID using ascii) as STATUS_ID,  convert(REASON_ID using ascii) as REASON_ID,  convert(QUEUE using ascii) as QUEUE,  convert(CLAIM_NBR using ascii) as CLAIM_NBR,  DATE_FORMAT(convert(LOSS_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as LOSS_DATE,  convert(LOSS_TIME using ascii) as LOSS_TIME,  convert(PRECINCT using ascii) as PRECINCT,  convert(REPORT_NBR using ascii) as REPORT_NBR,  convert(HOUSE_NBR using ascii) as HOUSE_NBR,  convert(STREET using ascii) as STREET,  convert(APT_NBR using ascii) as APT_NBR,  convert(CROSS_STREET using ascii) as CROSS_STREET,  convert(CITY using ascii) as CITY,  convert(STATE_ABBR using ascii) as STATE_ABBR,  convert(ZIP5 using ascii) as ZIP5,  convert(ZIP4 using ascii) as ZIP4,  convert(COUNTY using ascii) as COUNTY,  convert(TAG using ascii) as TAG,  convert(TAG_STATE using ascii) as TAG_STATE,  convert(VIN using ascii) as VIN,  convert(MAKE using ascii) as MAKE,  convert(MODEL using ascii) as MODEL,  convert(FIRST_NAME_1 using ascii) as FIRST_NAME_1,  convert(MIDDLE_NAME_1 using ascii) as MIDDLE_NAME_1,  convert(LAST_NAME_1 using ascii) as LAST_NAME_1,  convert(SSN_1 using ascii) as SSN_1,  DATE_FORMAT(convert(DOB_1 using ascii),\'%d-%b-%Y %H:%i:%s\') as DOB_1,  convert(FIRST_NAME_2 using ascii) as FIRST_NAME_2,  convert(MIDDLE_NAME_2 using ascii) as MIDDLE_NAME_2,  convert(LAST_NAME_2 using ascii) as LAST_NAME_2,  convert(FIRST_NAME_3 using ascii) as FIRST_NAME_3,  convert(MIDDLE_NAME_3 using ascii) as MIDDLE_NAME_3,  convert(LAST_NAME_3 using ascii) as LAST_NAME_3,  convert(DRIVERS_LICENSE using ascii) as DRIVERS_LICENSE,  convert(DRIVERS_LICENSE_ST using ascii) as DRIVERS_LICENSE_ST,  DATE_FORMAT(convert(PROCESSED_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as PROCESSED_DATE,  DATE_FORMAT(convert(PRINT_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as PRINT_DATE,  DATE_FORMAT(convert(CHECKIN_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as CHECKIN_DATE,  COST_OVERRIDE,  convert(ADDITIONAL_INFO using ascii) as ADDITIONAL_INFO,  convert(SPECIAL_NOTE using ascii) as SPECIAL_NOTE,  convert(SPECIAL_BILLING_ID using ascii) as SPECIAL_BILLING_ID,  EXPECTED_TURNAROUND,  DATE_FORMAT(convert(LAST_CHANGED using ascii),\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,  convert(USERID using ascii) as USERID,  ACTUAL_TURNAROUND,  convert(ORDERPOINT_STATUS using ascii) as ORDERPOINT_STATUS,  convert(YEAR using ascii) as YEAR,   HISTORICAL_NOTICE,  AGENCY_COST,  HANDLING_FEE,  convert(CLIENT_QUOTEBACK using ascii) as CLIENT_QUOTEBACK,  DATE_FORMAT(convert(SECOND_REQUEST_PRINT_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as SECOND_REQUEST_PRINT_DATE,  convert(SUFFIX_1 using ascii) as SUFFIX_1,  convert(GENDER_1 using ascii) as GENDER_1,  convert(STATE_SERVICE_TYPE_NAME using ascii) as STATE_SERVICE_TYPE_NAME,  convert(BILLING_RESTRICTED using ascii) as BILLING_RESTRICTED,  DATE_FORMAT(convert(TRIGGERED_LAST_CHANGED using ascii),\'%d-%b-%Y %H:%i:%s\') as TRIGGERED_LAST_CHANGED,  convert(SEND_TO_PRINT using ascii) as SEND_TO_PRINT,  DATE_FORMAT(convert(SEND_TO_PRINT_DATE using ascii),\'%d-%b-%Y %H:%i:%s\') as SEND_TO_PRINT_DATE,  convert(SEND_TO_PRINT_USERID using ascii) as SEND_TO_PRINT_USERID,  DONOTASSOCIATE_FLAG  FROM cruprd.ORDER_VERSION where (creation_date >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  creation_date < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR(triggered_last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and triggered_last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and creation_date < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute_hpcc_potential_match = 'SELECT MATCH_ID,ECRASH_INCIDENT_ID,ORDER_ID,SEQUENCE_NBR,convert(MATCH_STATUS using ascii) as MATCH_STATUS,WEIGHT_SCORE,convert(DATA_SOURCE using ascii) as DATA_SOURCE,convert(WORK_TYPE using ascii) as WORK_TYPE,DATE_FORMAT(CREATION_DATE,\'%d-%b-%Y %H:%i:%s\') as CREATION_DATE ,convert(SERVICE_ID using ascii) as SERVICE_ID,convert(ORI_NBR using ascii) as ORI_NBR,convert(STATE_REPORT_NBR using ascii) as STATE_REPORT_NBR,convert(ST_REPORT_NBR_MATCH_TYPE using ascii) as ST_REPORT_NBR_MATCH_TYPE,convert(STATE_ABBR using ascii) as STATE_ABBR,convert(STATE_MATCH_TYPE using ascii) as STATE_MATCH_TYPE,convert(ZIP4 using ascii) as ZIP4,convert(ZIP4_MATCH_TYPE using ascii) as ZIP4_MATCH_TYPE,convert(ZIP5 using ascii) as ZIP5,convert(ZIP5_MATCH_TYPE using ascii) as ZIP5_MATCH_TYPE,convert(LOC_REPORT_NBR using ascii) as LOC_REPORT_NBR,convert(LOC_REPORT_NBR_MATCH_TYPE using ascii) as LOC_REPORT_NBR_MATCH_TYPE,DATE_FORMAT(LOSS_DATE,\'%d-%b-%Y %H:%i:%s\') as LOSS_DATE,convert(LOSS_DATE_MATCH_TYPE using ascii) as LOSS_DATE_MATCH_TYPE,convert(LOSS_TIME using ascii) as LOSS_TIME,convert(LOSS_CITY using ascii) as LOSS_CITY,convert(LOSS_CITY_MATCH_TYPE using ascii) as LOSS_CITY_MATCH_TYPE,convert(LOSS_COUNTY using ascii) as LOSS_COUNTY,convert(LOSS_COUNTY_MATCH_TYPE using ascii) as LOSS_COUNTY_MATCH_TYPE,convert(LOSS_STREET using ascii) as LOSS_STREET,convert(LOSS_STREET_MATCH_TYPE using ascii) as LOSS_STREET_MATCH_TYPE,convert(LOSS_CROSS_STREET using ascii) as LOSS_CROSS_STREET,convert(LOSS_CROSS_STREET_MATCH_TYPE using ascii) as LOSS_CROSS_STREET_MATCH_TYPE,convert(PRECINCT using ascii) as PRECINCT, convert(AGENCY_ID using ascii) as AGENCY_ID, convert(AGENCY_NAME using ascii) as AGENCY_NAME, convert(AGENCY_NAME_MATCH_TYPE using ascii) as AGENCY_NAME_MATCH_TYPE ,DATE_FORMAT(LAST_CHANGED,\'%d-%b-%Y %H:%i:%s\') as LAST_CHANGED,convert(USERID using ascii) as USERID, convert(RESULT_ID using ascii) as RESULT_ID , convert(VENDOR_CODE using ascii) as VENDOR_CODE, convert(VENDOR_REPORT_NUMBER using ascii) as VENDOR_REPORT_NUMBER, convert(ECRASH_AGENCY_ID using ascii) as ECRASH_AGENCY_ID, convert(ECRASH_AGENCY_NAME using ascii) as ECRASH_AGENCY_NAME, convert(ACCT_LOG_TRANSACTION_ID using ascii) as ACCT_LOG_TRANSACTION_ID, BATCH_UPDATE, convert(CRU_GENERATED_REPORT_KEY using ascii) as CRU_GENERATED_REPORT_KEY, REPORT_ID, convert(CONTRIB_SOURCE using ascii) as CONTRIB_SOURCE  FROM cruprd.HPCC_POTENTIAL_MATCH where (CREATION_DATE is null and (last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))) OR (CREATION_DATE is not null and CREATION_DATE >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and  CREATION_DATE < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\')) OR (CREATION_DATE is not null and last_changed >= STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and last_changed < STR_TO_DATE (\''+today_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\') and CREATION_DATE < STR_TO_DATE (\''+yesterday_yyyymmdd+'\', \'%Y-%m-%d %H:%i:%s\'))';
        sqltoexecute = [sqltoexecute_status,sqltoexecute_agency,sqltoexecute_order_version,sqltoexecute_client,sqltoexecute_company,sqltoexecute_client_adjuster,sqltoexecute_reason,sqltoexecute_service,sqltoexecute_state,sqltoexecute_int_order,sqltoexecute_order_billing,sqltoexecute_int_order_billing,sqltoexecute_int_order_address,sqltoexecute_assoc_order_group,sqltoexecute_result,sqltoexecute_client_division,sqltoexecute_agency_service,sqltoexecute_hpcc_order_match,sqltoexecute_hpcc_potential_match,sqltoexecute_order_payment,sqltoexecute_order_note]
        
        #sqltoexecute = [sqltoexecute_hpcc_potential_match]
    
        for sqlquery in sqltoexecute:   
            sqlquery_temp = sqlquery + ' '
            #print(sqlquery_temp)
            tbname = sqlquery_temp[sqlquery.find('FROM ')+5:]
            #print(tbname)
            tbname1 = tbname[tbname.find('.')+1:]
            tbname2 = tbname1[:tbname1.find(' ')]
            printwrapper('\n****************************{0}*********************************'.format(tbname2))
            printwrapper('\nTable being extracted : {0}'.format(tbname2))
            sqlcnttemp = 'select count(*) from '+tbname
            #printwrapper('\nSQL for table count : {0}'.format(sqlcnttemp))
            cursor.execute(sqlquery_temp)
            cursor_cnt.execute(sqlcnttemp)
            count = cursor_cnt.fetchone()[0]
            f = open(os.path.join(parseYamlProperty.get_inbound_dir(), 'cru\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt'), 'w', encoding='utf-8')
            printwrapper('\nFile location : {0}'.format(os.path.join(parseYamlProperty.get_inbound_dir(), 'cru\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt')))
            field_names = str([i[0] for i in cursor.description])
            head = str.replace(str.replace(str.replace(str.replace(str.replace(field_names,'[',''),',','|'),']',''),'\'',''),' ','')
            f.write(head + '\n')
            printwrapper('\nFetching records from table : {0}'.format(tbname2))
            printwrapper('\nCount of records in DB for table {0} is : {1}'.format(tbname2,int(count)))
            while 1:
                row = cursor.fetchone()
                iterator = range(0, len(cursor.description)).__iter__()
                col = ''
                outStr = []
                result = ''
                if not row:
                    break
                for idx in iterator:
                    col = checkNone(attempt_strip((str(row[idx]))))
                    if idx > 0:
                        outStr.append('|')
                        outStr.append(str.replace(str.replace(str(col),'\n',''),'|',''))
                        #outStr.append(str.replace(str(col),'|',''))
                    else:
                        outStr.append(str.replace(str.replace(str(col),'\n',''),'|',''))
                        #outStr.append(str.replace(str(col),'|',''))
                result = ''.join(outStr)
                f.write(result)
                f.write("\n")
            f.close()  
            flength = file_len(os.path.join(parseYamlProperty.get_inbound_dir(), 'cru\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt'))
            printwrapper('\nFile count of file {0} : {1} '.format(os.path.join(parseYamlProperty.get_inbound_dir(), 'cru\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt'),flength-1))
            if flength - count > 1:
                    cntmismtachList.append(1)
            else:
                    cntmismtachList.append(0)
            printwrapper('\nData extract completed for table : {0}'.format(tbname2))
        #endtime = today.strftime('%Y%m%d%H%M%S')
        endtime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        print(strttime)
        print(endtime)
        tdelta = int(endtime) - int(strttime)
        tdelta_min = tdelta/60
        printwrapper('\n*************************************************************')
        printwrapper('\nStart Time : {0}'.format(strttime))
        printwrapper('\nEnd Time : {0}'.format(endtime))
        printwrapper('\nTotal Duration in minutes : {0}'.format(tdelta_min))
        printwrapper('\nCRU Data extract completed...')
        nbrofmismatchfiles = sum(1 for i in cntmismtachList if i == 1)
        maxcntmismtachList = max(cntmismtachList)
    
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        printwrapper('\nException raised : {0}\n'.format(str(e)))
        flag = 0
    
    finally:
        printwrapper('\n**********\nAll Done!\n**********')
        #createlog(source)
        
        EmailSubject = 'data pull from CRU DB for ' + today.strftime('%Y%m%d')
        successEmailSubject = 'Success: ' + EmailSubject;
        systemErrorEmailSubject = 'ERROR / WARNING : ' + EmailSubject;
        cntmismatchErrorEmailSubject = 'ERROR / WARNING : Mismatch in counts for ' +str(nbrofmismatchfiles)+' file(s) in the ' + EmailSubject;
        emailFrom = 'fido-alerts@lexisnexis.com'
        emailTo =['fidoinsproductmgmtsquad@lexisnexisrisk.com','fido.ops@lexisnexisrisk.com']
                     
        if flag == 1 and maxcntmismtachList == 0:
            send(emailFrom,emailTo,'',successEmailSubject,'' + '\n'.join(printList))
        elif flag == 1 and maxcntmismtachList == 1:
            send(emailFrom,emailTo,'',cntmismatchErrorEmailSubject, '' + '\n'.join(printList))
        else:
            send(emailFrom,emailTo,'',systemErrorEmailSubject, '' + '\n'.join(printList))

if __name__ == '__main__':
    pull_files()