import glob, os
import sys
import platform
import essbaseMonitorSendEmail
import fnmatch 
from datetime import datetime
import time
from pathlib import Path
import re
import commonArgs
from commonArgs import getSource
import AutomationLogging
#file_path = r"D:\temp\srivai01-test\Automation101"
#file_path = r"F:\Scripts\Logs"
file_path_101 = '\\\\alawpfido101\\f$\\Scripts\\Logs\\'
file_path_102 = '\\\\alawpfido102\\f$\\Scripts\\Logs\\'

class essbaseMonitor:
  def __init__(self, cube_name, status, errorType, logFileName, file_date, sortFlag):
    self.cube_name = cube_name
    self.status = status
    self.errorType = errorType
    self.logFileName = logFileName
    self.file_date = file_date
    self.sortFlag = sortFlag

def getHostName():
    return platform.node().upper()

def checkKeywords(cube_list, file1, read_data):
    FindKeyWords = {}
    
    ErrorDataLoadKeywords = {'DATAERRORLIMIT reached'}
    #ErrorMemberLoadKeywords = {'fail', 'error', 'same session not allowed'}
    ErrorMemberLoadKeywords = {'Failed to deploy Essbase cube', 'Server Request Fails with error code', 'same session not allowed','BPM Connect Status: Error','..failure'}
    WarnMemberLoadKeywords = {'succeeded with warnings'}
    WarnDataLoadKeywords = {'Z_Rejects_file_is_present'}

    FindKeyWords["Data Load : Warning"] = WarnDataLoadKeywords
    FindKeyWords["Data Load : Error"] = ErrorDataLoadKeywords
    FindKeyWords["Member (Outline) Build : Error"] = ErrorMemberLoadKeywords
    FindKeyWords["Member (Outline) Build : Warning"] = WarnMemberLoadKeywords
    error_type = 'N/A'
    final_flag = 'Success'
    pattern = '*Z_Rejects_*'

    for key in FindKeyWords:
        for x in FindKeyWords[key]:
            if(x == 'Z_Rejects_file_is_present' and fnmatch.fnmatch(file1, pattern)):
                error_type = key.split(':')[0]
                final_flag = key.split(':')[1]

            elif x.lower() in read_data.lower():
                error_type = key.split(':')[0]
                final_flag = key.split(':')[1]

    if ("Error" in final_flag):
        sortFlag = 1
    elif ("Warning" in final_flag ):
        sortFlag = 2
    else:
        sortFlag = 3
    return final_flag , error_type, sortFlag

def process(logger, cube_list):
    logger.info('Start essbase monitor process::Inside process')
    countDict_error = []
    countDict_warn = []
    countDict_success = []
    countDict=[]
    if(cube_list == 'RSG_BSV'):
        file_path = file_path_102
    else:
        file_path = file_path_101
    filepath = os.path.join(file_path,cube_list)
    os.chdir(filepath)
    paths = Path(filepath).glob('**/*.log')
    today_date = datetime.now().strftime("%m/%d/%Y")
    logger.info('Inside process::path'.format(paths))
    status=''
    file_member_load = '*Member_Load*.log'
    cnt_member_load = 0
    
    for file1 in paths:
        with open(file1, 'r',encoding = "ISO-8859-1") as f:
            file_date = time.localtime(os.path.getmtime(file1))
            if (fnmatch.fnmatch(file1, file_member_load) and today_date == time.strftime("%m/%d/%Y", file_date)):
                cnt_member_load = 1
                
            read_data = f.read()
            if(today_date == time.strftime("%m/%d/%Y", file_date)):
                status, error_type, sortFlag = checkKeywords(cube_list, file1, read_data)
                #print('Inside process:: if condition'.format(file_date))

            if(status!=''):
                logger.info('*********************************')
                logger.info('Cube Name ::{0}'.format(cube_list))
                logger.info('Status ::{0}'.format(status))
                logger.info('ErrorType ::{0}'.format(error_type))
                logger.info('File to process ::{0}'.format(file1))
                logger.info('File date ::{0}'.format(time.strftime("%m/%d/%Y, %H:%M:%S", file_date)))
                p1 = essbaseMonitor(cube_list, status, error_type, file1, file_date, sortFlag)
                countDict.append(p1)
                status = ''
                
    if cnt_member_load == 0:
        p1 = essbaseMonitor(cube_list, 'Warning', 'Check frequency of cube refresh', 'NA', 'NA', 2)
        countDict.append(p1)
        
    return countDict            


if __name__ == '__main__':
    source = getSource()
    logger = AutomationLogging.getLogger(source)
    logger.info('Start essbase monitor process::...')
    #print("Start process::")
    global commonList
    commonList = []
    cube_list = commonArgs.getCubeList()
    #cube_list = sys.argv[8:]
    logger.info(cube_list)
    #print(cube_list)
    for i in cube_list:
        commonList.extend(process(logger,i))
    
    #print(len(commonList))
    for t in commonList:
        print(t.cube_name)
        print(t.status)
        print(t.errorType)      
        print(t.logFileName)

    commonList.sort(key=lambda x: x.sortFlag, reverse=False)
    essbaseMonitorSendEmail.notifyEmail(logger, commonList)
    essbaseMonitorSendEmail.loadToDB(logger, commonList)