import os, re
import parseYamlProperty
import glob
import fido_utils
from pathlib import Path
import AutomationLogging
def process():
    source = 'ins_recon'
    logger = AutomationLogging.getLogger(source)
    file_list = glob.glob(os.path.join(parseYamlProperty.get_inbound_dir(), source + '\\daily','*.*' ))
    regex = re.compile(r'(?P<filname>)_(?P<year>\d{1,4})(?P<month>\d{1,2})(?P<day>\d{2})', re.X)
    for file in file_list:
        if regex.search(file) == None:
            os.rename(file, os.path.join(os.path.dirname(file), Path(file).stem + '_' + fido_utils.today + Path(file).suffix))
            logger.debug('File renamed from {0} to {1}'.format(file, os.path.join(os.path.dirname(file), Path(file).stem + '_' + fido_utils.today + Path(file).suffix)))

if __name__ == '__main__':
   process()