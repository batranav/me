from jira import JIRA
import csv
from collections import defaultdict
from datetime import datetime
import requests
from vault.secrets import get_api_secret
from commonArgs import getSource
import AutomationLogging


def main():
	logger = AutomationLogging.getLogger('jira_change_history', True)
	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	source = getSource()
	uname = get_api_secret(logger, source, secret='uname')
	pwd= get_api_secret(logger, source, secret='pwd')
	jira = JIRA(options, basic_auth=(uname,pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   updated >= -3d and updated <= 1d ' , startidx, blocksize)
		numissues=len(newissues)
		if  numissues==0 or  blocknum==60:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0	
	issuesfile=open('change_test' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	issueswriter=csv.writer(issuesfile)
		
	for resultlist in issues:	
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
			fields=dict['fields']
			del dict['fields']
			fields['issue']=issueId
			if issue is not None:
				del fields['issue']			
			if issuecount==0:
						issueswriter.writerow(['key','issueId'])
			issueswriter.writerow([issue.key,issueId])	
			issuecount=issuecount+1			
	issuesfile.close()

	with open("change_test" + datetime.now().strftime('%Y%m%d') + ".csv" ,"r") as file:
		list_ = file.readlines()[1:]
		print(list_)

	changeFile=open('D:\\red\\data\\inbound\\jira\\daily\history_' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	for value in list_:
		link = "https://jira.rsi.lexisnexis.com/rest/api/2/issue/{}?expand=changelog".format(value.split(',')[0])
		data = requests.get(link, auth=(uname,pwd))
		changeFile.write(link + "||")
		changeFile.write(data.text + "\n")
	changeFile.close()
        
    

if __name__== "__main__" :
     main()