import sys, requests, os, ssl
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import parseYamlProperty
import commonArgs
import AutomationLogging
from vault.secrets import get_api_secret

yesterday = datetime.now() - timedelta(days=1)
#ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
sd='2013/01/20 00:00:01'
#ed='2022/05/12 07:00:00'
ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'

logger = AutomationLogging.getLogger('preprocess_innotas_analytics_objects_deleted')
uname, pwd = get_api_secret(logger, 'innotas_analytics')

proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
url = "lninsurancebusinesspmo.ppmpro.com"
post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_analytics_objectslog_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
def delete_allcation_update():

	SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
			<ser:username>{uname}</ser:username>
			<!--Optional:-->
			<ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>""".encode(encoding = 'utf-8')

	#print(SoapMessage)

	#construct and send the header

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	with open('delete_all.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_all.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>54</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed).encode(encoding = 'utf-8')

	print(SoapMessage)


	#construct and send the header

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	open('delete_all.xml','wb').write(result)

	tree = ET.parse('delete_all.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_analytics_allocation_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")

	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_all.xml')

def delete_resource_update():

	SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
			<ser:username>{uname}</ser:username>
			<!--Optional:-->
			<ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>"""

	#print(SoapMessage)

	#construct and send the header

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	with open('delete_res.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_res.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>11</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed)

	print(SoapMessage)


	#construct and send the header

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	open('delete_res.xml','wb').write(result)

	tree = ET.parse('delete_res.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_analytics_resource_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_res.xml')
def delete_changelog_update():

	SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
			<ser:username>{uname}</ser:username>
			<!--Optional:-->
			<ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>"""

	#print(SoapMessage)

	#construct and send the header

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	with open('delete_chan.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_chan.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>6</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed)

	print(SoapMessage)

	#construct and send the header
	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	open('delete_chan.xml','wb').write(result)

	tree = ET.parse('delete_chan.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_analytics_changelog_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_chan.xml')

def delete_project_update():

	SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
			<ser:username>{uname}</ser:username>
			<!--Optional:-->
			<ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>"""

	#print(SoapMessage)

	#construct and send the header
	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	with open('delete_proj.xml','wb') as f:
		f.write(result)
	f.close()
	tree = ET.parse('delete_proj.xml')
    
	sessionId = tree.find('.//{http://services}return').text


	SoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>4</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed)

	print(SoapMessage)

	session = requests.session()
	session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getDeleteHistory"}
	response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

	result = response.content

	open('delete_proj.xml','wb').write(result)

	tree = ET.parse('delete_proj.xml')

	#print(tree)

	datemodifieds=[x.text for x in tree.findall('.//{http://objects.services/xsd}dateModified')]
	entityids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
	entitytypeids=[x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
	modified=[x.text for x in tree.findall('.//{http://objects.services/xsd}modifiedBy')]
	fileoutput = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_analytics_project_deleted_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")
	for i in range(0,len(entityids)):
		fileoutput.write(datemodifieds[i] + '||'+entityids[i] + '||'+ entitytypeids[0]+'||'+ modified[i] +'\n')

	fileoutput.close()
	os.remove('delete_proj.xml')
def main():
   delete_allcation_update ()
   delete_resource_update ()
   delete_changelog_update ()
   delete_project_update ()
if __name__ == "__main__":
    main()