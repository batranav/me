import commonArgs
import fido_utils
from ftplib import FTP
import paramiko
import mmap
import os
import sendEmail
import AutomationLogging
from vault.secrets import get_api_secret

def getSrcFilename (dt):
    return 'D:/red/extract/govt_tier/eloqua_email_govt_tier' + '_' + dt + '.txt'

def convert_bytes(num):
    """
    this function will convert bytes to MB.... GB... etc
    """
    for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
        if num < 1024.0:
            return "%3.1f %s" % (num, x)
        num /= 1024.0


def file_size(file_path):
    """
    this function will return the file size
    """
    if os.path.isfile(file_path):
        file_info = os.stat(file_path)
        return convert_bytes(file_info.st_size)

def mapcount(filename):
    f = open(filename, "r+")
    buf = mmap.mmap(f.fileno(), 0)
    lines = 0
    readline = buf.readline
    while readline():
        lines += 1
    return lines

def push_files(date):
    transport = paramiko.Transport(('transfer.seisint.com', 22))
    app_name = commonArgs.getApplication()
    logger = AutomationLogging.getLogger('preprocess_push_govt_tier')
    uname, pwd = get_api_secret(logger, 'govttier')
    transport.connect(username=uname, password=pwd)
    sftp = paramiko.SFTPClient.from_transport(transport)
    source = getSrcFilename(date)
    destination = '/incoming/Govt/eloqua_email_govt_tier.txt'
    fileRowCount = mapcount(source)
    fileSizeInBytes = file_size(source)
    sftp.put(source,destination)
    sftp.close()
    transport.close()
    return (fileRowCount,fileSizeInBytes, source, destination)

if __name__ == '__main__':
    date = fido_utils.getToday() if commonArgs.getFiledate() == '' else commonArgs.getFiledate()
    
    debug = commonArgs.getDebugFlag()

    emailFrom = 'Fido-uploads@lexisnexisrisk.com'
    emailTo = 'Ed.Dierker@lexisnexisrisk.com,gopala.rudraraju@lexisnexisrisk.com,jacari.witchard@lexisnexisrisk.com'
    emailCc = 'raju.nagarajan@lexisnexisrisk.com'

    prefix = 'Success'
    
    subject = 'Fido Govt Tier file uploaded for {0}'.format(date)

    source = ''
    destination = ''

    try:
        
        (fileRowCount,fileSizeInBytes, source, destination) = push_files(date)
        Msg  = 'Source file {0} is {1}; Has {2} lines and is uploaded to {3}'.format(source,fileSizeInBytes, fileRowCount, destination)

    except FileNotFoundError as e:
        print("Wrong file")
        prefix = 'Error::' 
        Msg = 'Source File {0} cannot be uploaded and the Error is {1}'.format(source, e)

    if debug:
        emailTo = 'raju.nagarajan@lexisnexisrisk.com'

    sendEmail.send(emailFrom, emailTo, emailCc, subject, Msg)  
    