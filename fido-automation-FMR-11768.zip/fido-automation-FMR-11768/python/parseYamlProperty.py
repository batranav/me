'''
Created on Mar 21, 2017

@author: nagararx
'''
import yaml
import io, os, re, yaml
import base64
import platform
# revisit
from commonsourceinbounddtls import commonsourceinbounddtls
import commonArgs
import getProperties
from pathlib import Path

skip_env = commonArgs.getSkipenv()
yaml_file_name = getProperties.getYamlFilename()

config = None

def parse_config(path=None, data=None, tag='!ENV'):
    """
    Load a yaml configuration file and resolve any environment variables
    The environment variables must have !ENV before them and be in this format
    to be parsed: ${VAR_NAME}.
    E.g.:
    database:
        host: !ENV ${HOST}
        port: !ENV ${PORT}
    app:
        log_path: !ENV '/var/${LOG_PATH}'
        something_else: !ENV '${AWESOME_ENV_VAR}/var/${A_SECOND_AWESOME_VAR}'
    :param str path: the path to the yaml file
    :param str data: the yaml data itself as a stream
    :param str tag: the tag to look for
    :return: the dict configuration
    :rtype: dict[str, T]
    """
    # pattern for global vars: look for ${word}
    pattern = re.compile('.*?\${([\w :(\W)*]+)}.*?')
    loader = yaml.SafeLoader

    # the tag will be used to mark where to start searching for the pattern
    # e.g. somekey: !ENV somestring${MYENVVAR}blah blah blah
    loader.add_implicit_resolver(tag, pattern, None)

    def constructor_env_variables(loader, node):
        """
        Extracts the environment variable from the node's value
        :param yaml.Loader loader: the yaml loader
        :param node: the current node in the yaml
        :return: the parsed string that contains the value of the environment
        variable
        """
        value = loader.construct_scalar(node)
        match = pattern.findall(value)  # to find all env variables in line
        if match:
            full_value = value

            for g in match:

                if(commonArgs.getBasePathDir()!='' and g.split(',')[0] == 'FIDO_automation_scripts'):
                   full_value = full_value.replace(f'${{{g}}}', commonArgs.getBasePathDir())
                elif skip_env == True:
                    full_value = full_value.replace(f'${{{g}}}', g.split(',')[1])
                elif len(g.split(',')) == 2:
                    full_value = full_value.replace(f'${{{g}}}', os.environ.get(g.split(',')[0], g.split(',')[1]))
                else:
                    full_value = full_value.replace(f'${{{g}}}', os.environ.get(g, g))
            return full_value
        return value

    loader.add_constructor(tag, constructor_env_variables)

    if path:
        with open(path) as conf_data:
            return yaml.load(conf_data, Loader=loader)
    elif data:
        return yaml.load(data, Loader=loader)
    else:
        raise ValueError('Either a path or data should be defined as input')

def getHostName():
    return platform.node().upper()

def getPlatform():
    plat = getHostName()
    if plat == 'ALAWDRED201':
        return 'dev'
    elif plat == 'ALAWPFIDOLZ301' or plat.upper() == 'ALAWPFIDOLZ201':
        return 'prod'
    elif plat.upper() == 'BCTWPFIDOLZ201':
        return 'dr'
    else:
        return 'dev'
        

def getYamlStream():
    global stream
    with open(yaml_file_name, 'r') as x:
        stream = x.read()
    return stream

def getConfig():
    global config
    if not config:
        config = parse_config(yaml_file_name)	
    return config

def getAllSourceFolders():
    arr = []
    config = getConfig()
    for y in range(0, len(list(config.keys()))):
        sourcename = list(config.keys())[y]
        source = config.get(list(config.keys())[y])
        frequencies = list(source.keys())
        if(sourcename != 'snp'):
            for z in range(0, len(list(source.keys()))):
                if(frequencies[z] == 'daily'):
                    folderpath = get_inbound_dir(sourcename) + source.get(frequencies[z]).get('fidofolder').get('name')
                    arr.append(commonsourceinbounddtls(folderpath, get_retention_period(sourcename)))
                elif(frequencies[z] in ['monthly', 'final', 'prefinal']):
                    folderpath = get_inbound_dir(sourcename) + source.get(frequencies[z]).get('fidofolder').get('name')
                    arr.append(commonsourceinbounddtls(folderpath, get_monthly_retention_period(sourcename)))
    arr.append(commonsourceinbounddtls( get_outbound_dir('sql'),  get_retention_period('sql')))
    arr.append(commonsourceinbounddtls( get_cleanup_dir('logs'),  get_retention_period('logs')))
    arr.append(commonsourceinbounddtls( get_cleanup_dir('weekly_release'),  get_retention_period('weekly_release')))
    return arr

def getPropFromSource(source, propName):
    config = getConfig()
    if(source in config.keys() and propName in config.get(source).keys()):
        return config.get(source).get(propName)
    else:
        return config.get('common').get(propName)

def get_retention_period(source):
    return getPropFromSource(source, 'default_number_of_days_to_retain')

def get_monthly_retention_period(source):
    return getPropFromSource(source, 'default_monthly_number_of_days_to_retain')

def get_sql_script_dir(source):
    return getPropFromSource(source, 'sql_script_dir')
def getCSSPath(source = 'common'):
    return getPropFromSource(source, 'csspath')
def get_bdapkeepasspath(source = 'common'):
    return getPropFromSource(source,'bdapkeepasspath')
def get_azcopypath(source = 'common'):
    return getPropFromSource(source,'azcopypath')
def get_keepass_title(source = 'common'):
    return getPropFromSource(source,'keepass_title')

def get_move_used_files_flag(source, frequency = 'daily'):
    config = getConfig()
    if(config.get(source).get(frequency).get('fidofolder') != None and config.get(source).get(frequency).get('fidofolder').get('moveUnusedFiles') != None):
        return config.get(source).get(frequency).get('fidofolder').get('moveUnusedFiles')
    return getPropFromSource(source, 'moveUnusedFiles')

def get_buildByYearMonth_flag(source, frequency = 'daily'):
    config = getConfig()
    if(config.get(source).get(frequency).get('fidofolder') != None and config.get(source).get(frequency).get('fidofolder').get('buildByYearMonth')):
        return config.get(source).get(frequency).get('fidofolder').get('buildByYearMonth')
    return getPropFromSource(source, 'buildByYearMonth')

def get_threadpool_size(source, frequency = 'daily'):
    config = getConfig()
    if(config.get(source).get(frequency).get('fidofolder') != None and config.get(source).get(frequency).get('fidofolder').get('threadpoolsize')):
        return config.get(source).get(frequency).get('fidofolder').get('threadpoolsize')
    return getPropFromSource(source, 'threadpoolsize')

'''config = getPropFromSource(source)

   if config.has_option(source.upper(), 'move_unused_files'):
      return config.getboolean(source.upper(), 'move_unused_files')
   else:
      return True
'''
# def getClusterName(clusterNameKey, source = 'common'):
#     return getPropFromSource(source,clusterNameKey)

# def getClusterIP(clusterIPKey, source = 'common'):
#     return getPropFromSource(source,clusterIPKey)

# def getHPCCProdCluster(source = 'common'):
#     return getPropFromSource(source,'HPCCProdCluster')

# def getHPCCDevCluster(source = 'common'):
#     return getPropFromSource(source, 'HPCCDevCluster')

# def getHPCCAlphaCluster(source = 'common'):
#     return getPropFromSource(source, 'HPCCAlphaCluster')

# def getHPCCBocaCluster(source = 'common'):
#     return getPropFromSource(source, 'HPCCBocaCluster')

# def getHPCCDRCluster(source = 'common'):
#     return getPropFromSource(source, 'HPCCDRCluster')

# def getHPCCVaultCluster(source = 'common'):
#     return getPropFromSource(source, 'HPCCVaultCluster')

# def getHPCCAlphaQCCluster(source = 'common'):
#     return getPropFromSource(source, 'HPCCAlphaQCCluster')

# def getHPCCAlpha(source = 'common'):
#     return getPropFromSource(source, 'HPCCAlpha')

# def getHPCCBoca(source = 'common'):
#     return getPropFromSource(source, 'HPCCBoca')

# def getHPCCDR(source = 'common'):
#     return getPropFromSource(source, 'HPCCDR')

# def getHPCCProd(source = 'common'):
#     return getPropFromSource(source, 'HPCCProd')

# def getHPCCVault(source = 'common'):
#     return getPropFromSource(source, 'HPCCVault')

# def getHPCCAlphaQC(source = 'common'):
#     return getPropFromSource(source, 'HPCCAlphaQC')

# def getHPCCDev(source = 'common'):
#     return getPropFromSource(source,'HPCCDev')



def getHPCCURLCluster(source = 'common', clustername = ''):
    plat = getPlatform()
    if clustername != '':
        # the IP is defined in yaml with keyname matching with clustername from json and 
        # the clusterNmae is defined in yaml with keyname matching with clustername from json appended with 'Cluster' 
        # Hence making the generic getPropFromSource funtion call to get IP and clustername 
        return (getPropFromSource(source, clustername), getPropFromSource(source, clustername + 'Cluster'))
    elif plat.upper() == 'DEV':
        if commonArgs.getHpccHost().upper() in ['HPCCDR', 'HPCCPROD']:
            raise Exception("Platform is DEV but HPCC host is {0}".format(commonArgs.getHpccHost()))
        return (getPropFromSource(source, 'HPCCDev'), getPropFromSource(source, 'HPCCDevCluster'))
    elif plat.upper() == 'PROD' and commonArgs.getHpccHost().upper() == 'HPCCDR':
        return (getPropFromSource(source, 'HPCCDR'), getPropFromSource(source, 'HPCCDRCluster'))
    elif plat.upper() == 'PROD':
        return (getPropFromSource(source, 'HPCCProd'), getPropFromSource(source, 'HPCCProdCluster'))
    elif plat.upper() == 'DR' :
        return (getPropFromSource(source, 'HPCCDR'), getPropFromSource(source, 'HPCCDRCluster'))

def getSSLFlagForClusterURL(source = 'common', clustername = ''):
    (hpccURL, hpccCluster) = getHPCCURLCluster(source, clustername)
    if hpccURL.find('https://') > -1 :
        return True
    else:
        return False

def getHPCCURL(source = 'common'):
    plat = getPlatform()
    if plat.upper() == 'DEV':
        return getPropFromSource(source, 'HPCCDev')
    elif plat.upper() == 'PROD' and commonArgs.getHpccHost().upper() == 'HPCCDR' :
        return getPropFromSource(source, 'HPCCDR')
    elif plat.upper() == 'PROD':
        return getPropFromSource(source, 'HPCCProd')
    elif plat.upper() == 'DR':
        return getPropFromSource(source, 'HPCCDR')

def get_processing_dir(source = 'common'):
    processing_dir = getPropFromSource(source,'processing_dir')
    if processing_dir != None and processing_dir != '':
        return getPropFromSource(source,'processing_dir')
    else:
        return get_inbound_dir(source)

def get_lock_check_wait_time(source = 'common'):
    return getPropFromSource(source,'lock_check_wait_time')

def get_archive_dir(source = 'common'):
    return getPropFromSource(source,'archive_dir')

def get_inbound_dir(source = 'common'):
    return getPropFromSource(source,'inbound_dir')

def get_outbound_dir(source = 'common'):
    return getPropFromSource(source,'outbound_dir')

def get_cleanup_dir(source = 'common'):
    return getPropFromSource(source,'cleanup_dir')

def get_base_dir(source = 'common'):
    return getPropFromSource(source,'base_script_dir')

def get_src_dir(source = 'common'):
    return getPropFromSource(source, 'src_dir')

def get_fido_dir(source = 'common'):
    return getPropFromSource(source, 'fido_dir')

def get_app_dir(source = 'common'):
    return getPropFromSource(source, 'app_dir')

def get_code_dir(source = 'common'):
    return getPropFromSource(source, 'code_dir')

def get_generated_ecl_dir(source = 'common'):
    return getPropFromSource(source, 'generated_ecl_dir')

def get_generated_ecl_xml_dir(source = 'common'):
    return getPropFromSource(source, 'generated_ecl_xml_dir')

def get_env_path_ecl_compiler(source = 'common'):
    return os.environ.get(getPropFromSource(source, 'env_path_ecl_compiler'))

def get_ecl_script_dir(source = 'common'):
    return getPropFromSource(source,'ecl_script_dir')

def get_gitlab_dir(source = 'common'):
    return getPropFromSource(source,'gitlab_dir')

def get_git_logs_dir(source = 'common'):
    return getPropFromSource(source,'git_logs_dir')

def get_git_rsa_key_path(source = 'common'):
    return getPropFromSource(source,'git_rsa_key_path')

def get_github_rsa_key_path(source = 'common'):
    return getPropFromSource(source,'github_rsa_key_path')

def get_openstack_rsa_key_path(source = 'common'):
    return getPropFromSource(source,'openstack_rsa_key_path')

def get_winrarpath(source = 'common'):
    return getPropFromSource(source, 'winrarpath')

def get_Fido7zpackExecutor(source = 'common'):
    return getPropFromSource(source, 'fidopack7z')

def get_Fido7zunpackExecutor(source = 'common'):
    return getPropFromSource(source, 'fidounpack7z')

def get_powershell_script_dir(source = 'common'):
    return getPropFromSource(source, 'powershell_script_dir')

def get_wu_logs_dir(source = 'common'):
    return getPropFromSource(source,'wu_logs_dir')

def get_build_logs_dir(source = 'common'):
    return getPropFromSource(source, 'build_logs_dir')

def get_ecl_build_logs_dir(source = 'common'):
    return getPropFromSource(source, 'ecl_build_logs_dir')

def get_git_build_logs_dir(source = 'common'):
    return getPropFromSource(source, 'git_build_logs_dir')

def get_base_src_dir(source = 'common'):
    return getPropFromSource(source, 'base_src_dir')

def getLogFileRef(source = 'common'):
    return '\\\\' + getHostName() + '\\\\' + get_build_logs_dir(source).replace(':','')

def get_base_script_dir(source = 'common'):
    #return getPropFromSource(source, 'base_script_dir')
    line = getPropFromSource(source, 'base_script_dir')
    if(commonArgs.getBasePathDir()!=None and commonArgs.getBasePathDir()!=''):
        line = commonArgs.getBasePathDir()
    return line

def get_source_success_email(source = 'common'):
    result = []
    if source.lower() == 'sod':
        line = getPropFromSource(source, 'success_email')
        return line.strip().split(",")
    else:
        return result

def get_success_email(source = 'common'):
    line = getPropFromSource(source, 'success_email')
    source_email_list = line.strip().split(",") + get_source_success_email(source)
    return source_email_list

def get_notify_source_on_file_missing(source = 'common'):
    propValue = getPropFromSource(source, 'notify_source_on_file_missing')
    return propValue

def get_error_cc_email(source = 'common'):
    propValue = getPropFromSource(source, 'error_cc_email')
    return propValue.strip().split(",")

def get_source_extn(source = 'common'):
    line =  getPropFromSource(source, 'Fido_Extn')
    return [line.strip()]

def get_error_email(source = 'common'):
    line = getPropFromSource(source, 'error_email')
    return line.strip().split(",")

def get_list_of_text_file_extn(source = 'common'):

    line = getPropFromSource(source, 'list_of_text_file_extn')
    return [text_extn for text_extn in line]

def get_list_of_gz_file_extn(source = 'common'):
    line = getPropFromSource(source, 'list_of_gz_file_extn')
    return [gz_extn for gz_extn in line]

def get_list_of_done_file(source = 'common'):
    line = getPropFromSource(source, 'list_of_done_file')
    return line.strip().split(",")

def get_debug_email(source = 'common'):
    line = getPropFromSource(source, 'debug_email')
    if(commonArgs.getDebugEmail()!=None and commonArgs.getDebugEmail()!=''):
        line = line + ',' + commonArgs.getDebugEmail()
    return line.strip()


# def get_retention_period(source = 'common'):
    # config = getProperty()
    # if config.has_option(source.upper(), "NUMBER_OF_DAYS_TO_RETAIN"):
    #     line = config.get(source.upper(), "NUMBER_OF_DAYS_TO_RETAIN")
    # elif config.has_option("COMMON", "DEFAULT_NUMBER_OF_DAYS_TO_RETAIN"):
    #     line = config.get("COMMON", "DEFAULT_NUMBER_OF_DAYS_TO_RETAIN")
    # return line
    # line = getPropFromSource(source, 'DEFAULT_NUMBER_OF_DAYS_TO_RETAIN')
    # return line if line.isdigit() else -1

if __name__ == '__main__':
    # '''print(getHPCCURLCluster())
    # print(get_source_extn('mbs_coplogic'))
    # print(getHPCCURL())
    # print(get_error_cc_email('mbs_coplogic'))
    # print(get_error_cc_email())
    # print(get_success_email('mbs_coplogic'))'''
    # print(getHPCCURL())
    # print(get_threadpool_size('mbs'))
    # print(get_threadpool_size('mbs', 'daily'))
    # print(get_move_used_files_flag('mbs_tracesmart', 'daily'))
    # print(get_ecl_script_dir('alpha_insurance'))


    # print(getCSSPath())
    # print(get_inbound_dir())
    # print(getSSLFlagForClusterURL('vault_job_stats', 'HPCCVault'))
    # print(getHPCCURLCluster())
    # print(getPlatform())

    # print(get_notify_source_on_file_missing('mbs'))
    # print(get_processing_dir('mbs').strip()[0])
    #print(get_generated_ecl_dir())
    #     # for source in getAllSourceFolders():
    #     print('Removing the folder and retentiondays are  : ' + source.sourcefolder + '' + str(source.retentiondays))
    pass