import sys, requests, os, ssl
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import datetime
import time as t
import AutomationLogging 
import dateutil.relativedelta
import parseYamlProperty
from datetime import date 
from datetime import time
from datetime import timedelta 
from datetime import date 
from datetime import timedelta 
from datetime import datetime, timedelta
from vault.secrets import get_api_secret

yesterday = datetime.now() - timedelta(days=1)
threemonthsprior = datetime.now() - timedelta(days=10)
threedaysprior = datetime.now() - timedelta(days=3)

# Get today's date 
today = date.today() 
onedays = today - timedelta(days = 1) 
tendays = today - timedelta(days = 10) 


yesterday = datetime.now() - timedelta(days=1)
#sd='2014/01/01 00:00:01'
start=tendays.strftime('%Y/%m/%d')+' 00:00:01'
end=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
# Get today's date 

# get credentials from vault
logger = AutomationLogging.getLogger('preprocess_gtm_ppm')
uname, pwd = get_api_secret(logger, 'innotas_analytics')

def frameMessage(entityId, fieldIds):
    firstpart = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">    <soapenv:Header/> <soapenv:Body> <ser:selectEntity> <ser:sessionId>{sessionID}</ser:sessionId> <ser:entityTypeId>' + entityId + '</ser:entityTypeId> <ser:entityId>{entityID}</ser:entityId> '
    strparts = fieldIds.split(',')
    for y in range(0, len(strparts)):
        firstpart += '<ser:fieldsRequest>' + strparts[y] + '</ser:fieldsRequest>'
    firstpart += '</ser:selectEntity>   </soapenv:Body> </soapenv:Envelope>'

    return firstpart

def pullInnotasDataUsingSOAP(table_name, entity_type_id, start_dt, end_dt, field_list):

    yesterday = datetime.now() - timedelta(days=1)


    sd=start_dt
    ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
    sys.stdout = open(parseYamlProperty.get_inbound_dir()+'\\gtm\\daily\\logs\\gtm_'+ table_name +'log_'+ datetime.now().strftime('%Y%m%d') + '.txt','w')

    SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:login>
            <!--Optional:-->
            <ser:username>{uname}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd}</ser:password>
        </ser:login>
    </soapenv:Body>
    </soapenv:Envelope>"""

    #print(SoapMessage)

    #construct and send the header


    proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
    url = "lninsurancebusinesspmo.ppmpro.com"
    post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

    session = requests.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
    response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

    result = response.content
    print(result)

    with open('temp_' + table_name + '.xml','wb') as f:
        f.write(result)
        
    f.close()
    tree = ET.parse('temp_' + table_name + '.xml')

    sessionId = tree.find('.//{http://services}return').text

    SoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:getUpdateHistory>
            <!--Optional:-->
            <ser:sessionId>""" + sessionId + """</ser:sessionId>
            <!--Optional:-->
            <ser:entityTypeId>""" + entity_type_id + """</ser:entityTypeId>
            <!--Optional:-->
            <ser:startYYYYMMDD>""" + sd + """</ser:startYYYYMMDD>
            <!--Optional:-->
            <ser:endYYYYMMDD>""" + ed + """</ser:endYYYYMMDD>
            <!--Optional:-->
            <ser:showRepeatingPerDay>false</ser:showRepeatingPerDay>
            <!--Optional:-->
            <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
        </ser:getUpdateHistory>
    </soapenv:Body>
    </soapenv:Envelope>"""

    print(SoapMessage)

    #construct and send the header

    proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
    url = "lninsurancebusinesspmo.ppmpro.com"
    post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

    session = requests.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getUpdateHistory"}
    response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

    result = response.content

    open('temp_' + table_name + '.xml','wb').write(result)

    tree = ET.ElementTree(file='temp_' + table_name + '.xml')

    if table_name == 'workgroup':
        entityIds1 = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
        entityIds=set(entityIds1)
    else:
        entityIds = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]     

    DefaultSoapMessage = frameMessage(entity_type_id, field_list)                                                                                                                                                                                           

    output_handle = open(parseYamlProperty.get_inbound_dir()+'\\gtm\\daily\\gtm_' + table_name + '_' + datetime.now().strftime('%Y%m%d') + '.txt','w',encoding='utf-8')

    for entityId in entityIds:
        SoapMessage = DefaultSoapMessage.replace('{entityID}',entityId).replace('{sessionID}',sessionId)
        proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
        url = "lninsurancebusinesspmo.ppmpro.com"
        post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"
        session = requests.session()
        session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:selectEntity"}
        
        no_of_attempts = 25
        for x in range(0, no_of_attempts):
            response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
            print("status_code:", response.status_code)
            if response.status_code == 429:
                print(response.headers["Retry-After"])
                t.sleep(int(response.headers["Retry-After"]))
                x += 1
            else:
                break      

        result = response.content
        print(response)
        
        open('temp_' + table_name + '.xml','wb').write(result)
        
        tree = ET.ElementTree(file='temp_' + table_name + '.xml')
        output_handle.write(entityId + '||')
        '''for x in tree.findall('.//{http://objects.services/xsd}elementValue'):
            print(x.text)
            y = x.text
            output_handle.write(y)
                '''
        output_handle.write('||'.join([(x.text or '').replace('\r\n','    ').replace('\n','     ').replace('\r','     ') for x in tree.findall('.//{http://objects.services/xsd}elementValue')]))
        output_handle.write('\n')
    
    output_handle.close()
    os.remove('temp_' + table_name + '.xml')

def process():
    pullInnotasDataUsingSOAP('request', '307',start,end,'30701,2856354149,30702,30706,30728,30710,30713,30762,2835580569,2831194456,30730,2834676696,2831229613,2834675505,2814154109,2835580218,30707,2833223880,2834084213,2814155271,2834906411,2835345756,2835566151,2834082741,2835345770,2835566198,2834906135,2835345734,2835566313,2814173665,2834905691,2835566360,2834677967,2835306680,2834677541,2835306316,2834677790,2835306413,2834677811,2835306484,2834732688,2834676161,30748,2814154911,2834679654,2834083164,2834907484,2835347713,2835566510,2835346045,2835566673,2834907099,2834907697,2835568221,2834080964,2833234672,2834907733,2834083535,2835386933,2843980581,2834676630,2835567178,2841845510,2833233344,2835304813,2833225958,2834679115,2833223639,2835580397,2835583731,2831195281,2833223990,2834679158,2834681347,2835386892,2834679174,2839210980,2841845872,2794609957,2836003288,2795691201,2830335060,2794544921,2823648868,2831514302,2794643774,2803983849,2828927792,2828926847,2828917525,2828936880,2828933918,2794643417,2794643373,2794643389,2831969431,2794643016,2794515605,2794538489,2794542856,2823649699,2794540054,2794515750,2794545260,2794643511,2794514311,2831527307,2830336322,2829375168,2826332772,2794610136,2828323834,2828319581,2794631734,2794624576,2794630239,2794636537,2794629772,2826333322,2794540304,2803968382,2794512054,2794544625,2821311607,2823650366,2794630728,2823650464,2828943704,2795685957,2795685467,2828927860,2828926957,2795685702,2828938142,2828934314,2795689911,2795690025,2795686636,2795686110,2795689856,2831958110,2828944402,2794633765,2828933099,2828927034,2828921601,2828938805,2831970888,2831959216,2795686014,2795681871,2823652308,2828934544,2794638189,2794638225,2803970907,2794642841,2832236147,2795684906,2805679005,2794624497,2794610120,2794636470,2794547640,2794541344,2831211259,2794636409,2825414246,2825370752,2831522511,2825384968,2794625137,2794629243,2794632356,2794626176,2794632895,2831856161,2821312241,2794511660,2794545008,2794544774,2794512390,2823174720,2823185468,2824220273,2794629740,2829697871,2794638663,2826331220,2823651887,2823654167,2823654710,2850342930,2829843606,2827243765,2794633633,2795454582,2794635081,2794635015,2794628343,2794633708,2794637934,2794631022,2794626075,2794631346,2794632224,2794514519,2794511526,2794637437,2794637592,2794636639,2794636550,2823654085,2794639810,2794639000,2794638843,2826396955,2847023083,2794539939,2826331516,2820329273,2794514770,2805680760,2794512779,2794540400,2794609917,2823185125,2795694707,2821310895,2814166550,2794534545,2829697934,2794609712,2794546928,2794547025,2794547202,2823652536,2794544654,2794547738,2794539715,2794551296,2837802376,2794635731,2794512170,2794624531,2794630177,2794545820,2794636507,2823176068,2794544574,2823665220,2823648461,2826440829,2823176475,2823663881,2839110039,2823652013,2823651840,2838592760,2805680650,2805680506,2823175092,2794631589,2814159127,2831195741,2831195175,2831195004,2834906833,2844048404,2794622743,2833233665,2833226634,2839123095,2834909700,2834907630,2833227451,2833225185,2834678920,2833230602,2834691389,2835305673,2843925245,2834904763,2835344908,2835566713,2834081423,2834905515,2835344968,2835566773,2835344746,2814173399,2835566878,2834903261,2835344672,2835566036,2834077880,2835580671,2835580445,2835580511,2834071805,30724,2833234394,2834910192,2833220209,2814153647,2834909236,2834909067,2834908730,2835348938,2835349059,2835348147,2835305160,2835305024,2835308905,2834678625,2835307156,2834678873,2834678697,2835307186,2834678739,2835307216,2834678767,2835307291,2834678066,2835306742,2834678192,2835306751,2834678429,2835306763,2835580627,2835568789,2834677469,2835306192,2834677156,2835305729,2834677179,2835305746,2834677244,2835305871,2834676340,2834082066,2834679892,2834910278,2834910218,2814153407,2833230499,2834691329,2835305628,2847208121,2814153781,2831235377,2834676062,2834688828,2814155106,2814154551,2833225730,2834676086,2795452716,2831252507,2838989083,2835647044,2846517421,2829958189,2829846160,2829417628,2843328031,2836078166,2834734724,2834734088,2834798897,2835335712,2834803106,2835335772,2834803565,2835335952,2834798286,2835336488,2850218800,2848559343,2848556932,2848559168,2848557564,2845363749,2845363746,2848565760,2850257143,2848680724,2794629959,2850268025,2845363774,2850218984,2850219069,2848554285,2845363646,2805679957,2850424118,2850383242,2850384019,2794642273,2845364378,2848685692,2849459729,2848571908,2850423818,2845364690,2830104255,2845363728,2848678793,2849459707,2907875976,2907876114,2907879427,2910000177,2910000335,2907881034,2907881429,2907881732,2916444021,2916435057,2916436702,2916436783,2916437122,2916446907,2916438168,2916439955,2916445394,2916441070,2916441595,2916447584,2916442177,2916442471,2916443088,2916449580,2916450507,2945822229,2931761431,2982974617,2881401491,2881402503,2881402810,2881405415,2882069980,2882073504,2882074745,2882075295,2882075873,2882076278,2882081969,2882082110,2882082805,2882083337,2882088618,2882092907,2882093286,2882093769,2882093994,2882094249,2882094422,2882094964,2882127967,2882128005,2882128133,2882128208,2882128227,2882128266,2882128746,2882136505,2882136703,2882137866,2882138134,2882139289,2882139819,2882140123,2882140296,2882141723,2882142197,2882144179,2882144504,2882144600,2882144708,2882144744,2882144784,2882144870,2882144910,2882144951,2882150934,2882152329,2887016362,2887020424,2887021465,2887022785,2887023352,2887025247,2887025896,2887026284,2887027807,2887028434,2887047440,2887049591,2887051223,2887053014,2887095741,2887097012,2887097937,2887098661,2887099135,2887100399,2887102352,2887104277,2887106985,2887107602,2887108076,2887108592,2887109084,2887648699,2887651662,2887652877,2887675578,2887676660,2887681537,2887707277,2891077442,2905748041,2905749812,2905750669,2905750879,2905752142,2905752478,2905754242,2905754426,2905760656,2905765915,2906195188,2906197345,2932754497,2933022612,2933052819,2933317187,2933342920,2933914270,2933932528,2933932942,2933933362,2933937484,2933937696,2933938099,2933940354,2933940506,2933941023,2933941651,2933947804,2933948660,2933949228,2933951000,2933952006,2933952531,2933967913,2933968311,2933984617,2934249280,2934669028,2936346709,2936346936,2936347238,2936347310,2936937270,2936956105,2939480506,2939483687,2956682325,2972355909,2986033983,2986114847,2986116257,2986117395,2986118422,2986141344,2986144517,2986145538,2986146452,2986146991,2986147554,2986148596,2986150800,2986151059,2986151363,2986152565,2986152973,2986153254,2986154043,2986154685,2986156074,2986156888,2986157214,2986165552,2988406944')
    pullInnotasDataUsingSOAP('project', '4', start,end, '2843745579,2841316927,2843745564,2843745577,2843745126,418,2843745571,2847855776,2843744962,2856861820,2807290337,2823657882,2804009073,2837803940,2843745166,2843745254,2843745226,2843745128,2843745124,2847864868,2843745144,2847861412,2847861559,2843745113,2826451345,2846920090,2823656392,2823658147,2844168950,2844204640,2807298856,2823659384,2823659586,2844170079,2823658062,2844233008,2823656622,2823658249,2823658537,2823658845,2823656004,2823656937,2823657450,2823658341,2823655663,436,417,408,435,400076,400079,2833127242,2833127294,2890818777,2890818542,2931849720,2931849888,2843744952,2931853255,2931857671,2931858353')
    pullInnotasDataUsingSOAP('resource', '11', start,end, '1164,1133,1130,1115,1103,1104,1111,1198,1135,1131,1168,1169,101102,1101,1195,1196,101132,830414573,2828978133,1136')
    # pullInnotasDataUsingSOAP('resource', '11', '2022/11/01 00:00:01','2022/11/10/23 07:00:00', '1164,1133,1130,1115,1103,1104,1111,1198,1135,1131,1168,1169,101102,1101,1195,1196,101132,830414573,2828978133,1136')


if __name__ == "__main__":
    process()
     