import pandas as pd
import numpy as np
import logging
import os
import datetime
#import utils
from scipy.stats import gaussian_kde
import argparse
import warnings
import sys
import pickle
from Marketing_Forecast_model.model_code import ln_model as lnm
#import ln_model as lnm

warnings.filterwarnings("ignore")

# should be set to true for normal program execution
CV_FLAG = 'True'

## directories path to work with
# input_data_directory = '../Input Data/'
# output_data_directory = '../Output Data/'
# log_directory = 'Logs/'
log_directory = 'D:/red/applogs/marketing_forecast/python/model/'


## types of na values to detect in data
na_values=("", "NA", "NULL")


## Global lists for filtering
# Trade Show
trade_show_campaign_type = "Trade Show"

trade_show_crm_keywords = ["Event - Trade Show","Event - Tradeshow"]
trade_show_campaign_keywords = ["Trade Show","LN Tradeshow","Third Party Tradeshows"]

# Email
email_campaign_type = "LNRS Email"
email_crm_keywords = ["Campaign"]
email_campaign_keywords = ["Email Marketing","LNRS Email"]

# Webinar
webinar_campaign_type = "Webinar"
webinar_crm_keywords = ["Webinar"]
webinar_campaign_keywords = ["Webinar - LNRS", "Webinar", "Webinar - Third Party"]

# Web Contact Form
web_contact_form_campaign_type = None
web_contact_form_crm_keywords = ["Web Contact Form"]
web_contact_form_campaign_keywords = None


def create_log_object(log_level):
    """This function creates a logger object with specified level of logging
    
    Arguments:
        log_level {string} -- Level of logging, taken from user as command line argument
    
    Raises:
        exp_create_log_object: Raised if error occured in creating log object
    
    Returns:
        log object -- Logger object with specified level of logging.
    """    
    try:
        logger = logging.getLogger(__name__)
        
        if log_level.lower() == 'debug':
            logger.setLevel(logging.DEBUG)

        elif log_level.lower() == 'info':
            logger.setLevel(logging.INFO)
        
        elif log_level.lower() == 'warning':
            logger.setLevel(logging.WARNING)
        
        elif log_level.lower() == "error":
            logger.setLevel(logging.ERROR)
        
        elif log_level.lower() == "critical":
            logger.setLevel(logging.CRITICAL)
            
        formatter = logging.Formatter('%(asctime)s::%(levelname)s::%(name)s::%(filename)s::%(lineno)d::%(message)s')

        file_name = os.path.join(log_directory, datetime.datetime.now().strftime('deployment_%Y-%m-%d_%H-%M.log'))
        file_handler = logging.FileHandler(file_name)
        file_handler.setFormatter(formatter)

        logger.addHandler(file_handler)

        logger.debug("Logger object created with level {}".format(log_level))

        return logger

    except Exception as exp_create_log_object:
        print('Problem in creating log object. terminating program')
        raise exp_create_log_object


def date_check(date, date_name, logger):
    """This function accepts a date and checks it against pre-defined format
    
    Arguments:
        date {string} -- date to check
        date_name {string} -- description of date
        logger {object} -- logger object
    
    Raises:
        ValueError: Raises valueError if date is not in pre-defined format
    """    
    try:
        logger.debug('Entered date_check function')

        day, month, year = date.split('-')
        datetime.datetime(int(year), int(month), int(day))

        logger.debug('Completed date_check function')
        logger.info('date check completed')

    except ValueError:
        logger.error('Error', exc_info=True)
        raise ValueError


def data_quality_check(data, forecast_from, logger):
    """This function does all the necessary data quality checks before starting the program execution
    
    Arguments:
        data {dataframe} -- Imported data frame
        forecast_from {string} -- Date from when to start the forecast
        logger {object} -- Logger object
    
    Raises:
        Exception: Raises exception if required columns are not present in the data.
        exp_data_quality_check: Raises exception if there is any problem with data_quality_check function
    """    
    try:
        logger.debug('Entered data_check function')
        columns_to_use = ['lead_date','campaign_type','lead_id','crm_lead_source','sys_siebel_campaign_id','campaign_start_date_sk']
        is_date_valid = True

        columns_difference = list(set(columns_to_use) - set(data.columns))

        if not set(columns_to_use).issubset(data.columns):
            # logger.error('Following columns were not found but are needed to proceed with the program: {}'.format(columns_difference))
            raise Exception('Data quality check failed, following columns not present. terminating program: ' + str(columns_difference))
            
        logger.debug('Columns validated successfully')

        ## date check
        if forecast_from != '':
            date_check(date=forecast_from, date_name='forecast_from', logger=logger)
    
        logger.debug('Completed data_check function')
        logger.info('Data check completed successfully')

    except Exception as exp_data_quality_check:
            logger.error('Error', exc_info=True)
            raise exp_data_quality_check



def read_data(path_to_input, logger):
    """This function reads the input data with specified filename
    
    Arguments:
        file_name {string} -- Data to be used for forecasting, taken from user as command line argument
        logger {object} -- logger object created
    
    Raises:
        Exception: Raises file not found error if invalid file location or name specified
        exp_read_data: Raised if error occured in reading data
    
    Returns:
        data {dataframe} -- returns the imported dataframe
    """
    try:
        logger.debug('Entered read_data function')
        logger.info('Reading data from: ' + path_to_input)

        # input_path = os.path.join(input_data_directory, file_name)

        
        data = pd.read_csv(path_to_input, sep='\t', na_values=na_values)
        data.columns = data.columns.str.lower()
        
        data['lead_date'] = pd.to_datetime(data['lead_date'], format='%Y%m%d')

        logger.info('Reading data completed')
        logger.debug('Shape of read data is: {}'.format(data.shape))
        logger.debug('Completed read_data function')

        return data

    except FileNotFoundError:
        logger.error('Cannot find filename {} in Specified folder(Expecting a .tsv file format)'.format(path_to_input), exc_info=True)
        raise Exception(' Cannot find file in specified folder: ' + path_to_input + ' (Expecting a .tsv file format)')
    
    except Exception as exp_read_data:
        logger.error('Error', exc_info=True)
        raise exp_read_data


def write_data(path_to_output, data, logger):
    """This function writes the final dataframe to specified file format
    
    Arguments:
        file_name {string} -- desired file name of output data
        data {dataframe} -- final dataframe to be saved as file
    
    Raises:
        exp_write_data: raises exception if their is any problem with write_data function
    """    
    try:
        logger.debug('Entered write_data function')
        
        data.to_csv(path_to_output, sep='\t', index=False)

        # reading data to truncate last newline character
        data = open(path_to_output, 'rb').read()
        open(path_to_output, 'wb').write(data[:-2])

        logger.info('Write data successfull to Specified directory {}'.format(path_to_output))
        logger.debug('Completed write_data function')


    except Exception as exp_write_data:
        logger.error('Error', exc_info=True)
        raise exp_write_data


def subset_campaign_data(data, campaign_type, lead_source_keywords, groupby_keyword, 
                            aggregate_keyword, new_col_name, logger,campaign_keywords):
    """This function subsets different campaign types and returns for further analysis
    
    Arguments:
        data {dataframe} -- Basic preprocessed data, input from data_processing function
        campaign_type {string} -- Type of campaign data to subset
        lead_source_keywords {dictionary} -- Keywords defining the crm lead source of respective campaign type
        groupby_keyword {string} -- Column to be used for grouping subset data
        aggregate_keyword {string} -- Column to be used for aggregating subset data 
        new_col_name {string} -- Column name of newly derived column
        logger {log object} -- logger object
        campaign_keywords {dictionary} -- Keywords defining the campaign type
    
    Raises:
        exp_subset_campaign_data: raises exception if their is any problem with subset campaign data function    
    
    Returns:
        dataframe -- campaign subset data 1
        dataframe -- campaign subset data 2
    """    
    try:
        logger.debug('Entered subset_campaign_data function')
        logger.info('subsetting {} data'.format(new_col_name))

        subset_data = data[(data['crm_lead_source'].isin(lead_source_keywords)) & (data['campaign_type'].isin(campaign_keywords))]
        subset_data['start_date'] = pd.to_datetime(subset_data['campaign_start_date_sk'], format='%Y%m%d')

        daily_data = subset_data[subset_data['campaign_type'].isin(campaign_type)].groupby(groupby_keyword, as_index=False)[aggregate_keyword].count()

        logger.debug('shape of {} subset_data is {}'.format(new_col_name, subset_data.shape))
        logger.debug('shape of {} daily_data is {}'.format(new_col_name, daily_data.shape))

        daily_data.rename(columns={aggregate_keyword:new_col_name}, inplace=True)
        
        logger.info('subsetting of {} completed'.format(new_col_name))
        logger.debug('Completed subset_campaign_data function')

        return subset_data, daily_data

    except Exception as exp_subset_campaign_data:
        logger.error('Some error occured, read error info for more details', exc_info=True)
        raise exp_subset_campaign_data


def data_processing(data, train_end_date, logger):
    """This function performs basic pre-processing before passing it to other functions for further processing
    
    Arguments:
        data {dataframe} -- Data on which processing is to be done
        train_end_date {string} -- Date untill which model should be trained on
        logger {object} -- Logger object
    
    Raises:
        exp_data_processing: Raises exception if their is any problem with data_processing function    
    
    Returns:
        camp, trd_shw, web {dataframe} -- Subsetted dataframes for campaign, tradeshow, webinar
        new_dat1 {dataframe} -- Intermediate dataframe to be passed into another function
        train_start_date, train_end_date {dataframe} -- Dates to be considered while training our model
    """    
    try:
        ## Filtering out NA - Shared Lead Source 
        logger.debug('Entered data_processing function')
        logger.debug('Shape of data before processing is {}'.format(data.shape))
        
        bs_dat4 = data[(data['campaign_type'] != "NA - Shared Lead Source") & (data['campaign_type'].notnull())]
        # bs_dat4['start_date'] = bs_dat4['campaign_start_date_sk'].apply(lambda x: pd.to_datetime(str(x), format='%Y%m%d'))
        
        logger.debug('Shape of bs_dat4 after filtering campain type != "NA - Shared Lead Source is" {}'.format(bs_dat4.shape))

        logger.info('bs_dat4 data created')
        logger.info('Creating daily_leads data')

        bs_dat3_temp = data.drop_duplicates(subset=['lead_date', 'lead_id'])
        daily_leads = bs_dat3_temp.groupby('lead_date', as_index=False)['lead_id'].count()
        daily_leads['lead_date'] = pd.to_datetime(daily_leads['lead_date'])
        daily_leads.rename(columns={'lead_id':'leads'}, inplace=True)
        
        logger.debug('Shape after processing daily_leads is {}'.format(daily_leads.shape))
        logger.info('daily_leads data created')
        
        logger.debug('min lead_date from data: {}'.format(str(min(data['lead_date']))))
        logger.debug('max lead_date from data: {}'.format(str(max(data['lead_date']))))

        train_start_date = str(min(data['lead_date']))

        logger.debug('train start date is {}'.format(train_start_date))
        logger.debug('train end date is {}'.format(train_end_date))

        all_dates = pd.date_range(start=train_start_date, end=train_end_date)
        all_dates = pd.DataFrame(all_dates, columns=['lead_date'])

        logger.debug('Shape of all_dates is {}'.format(all_dates.shape))

        new_dat1 = pd.merge(all_dates,daily_leads, on="lead_date", how='left')
        new_dat1 = new_dat1.fillna(0)

        logger.debug('Shape of new_dat1 is {}'.format(new_dat1.shape))

        trd_shw, daily_tshw = subset_campaign_data(data=bs_dat4, campaign_type=[trade_show_campaign_type], campaign_keywords=trade_show_campaign_keywords, 
                                                    lead_source_keywords=trade_show_crm_keywords, groupby_keyword='start_date', 
                                                    aggregate_keyword='sys_siebel_campaign_id', new_col_name='Trade Show', logger=logger)
        

        camp, daily_eml = subset_campaign_data(data=bs_dat4, campaign_type=[email_campaign_type], campaign_keywords=email_campaign_keywords, 
                                                lead_source_keywords=email_crm_keywords, groupby_keyword='start_date', 
                                                aggregate_keyword='sys_siebel_campaign_id', new_col_name='LNRS Email', logger=logger)


        web, daily_web = subset_campaign_data(data=bs_dat4, campaign_type=webinar_campaign_keywords, campaign_keywords=webinar_campaign_keywords, 
                                                lead_source_keywords=webinar_crm_keywords, groupby_keyword='start_date', 
                                                aggregate_keyword='sys_siebel_campaign_id', new_col_name='Webinar', logger=logger)
        

        web_contact_form_campaign_keywords = bs_dat4[bs_dat4['crm_lead_source'] == "Web Contact Form"]['campaign_type'].unique().tolist()

        _wcf_data, wcf_daily = subset_campaign_data(data=bs_dat4, campaign_type=web_contact_form_campaign_keywords, 
                                                        campaign_keywords=web_contact_form_campaign_keywords, 
                                                        lead_source_keywords=web_contact_form_crm_keywords, groupby_keyword="lead_date", 
                                                        aggregate_keyword='lead_id', new_col_name='leads_wcf', logger=logger)

    

        wcf_daily['lead_date'] = pd.to_datetime(wcf_daily['lead_date'])
        
        logger.debug('Shape of wcf_daily data is {}'.format(wcf_daily.shape))
        
        wcf_daily2 = pd.merge(left=all_dates, right=wcf_daily, on="lead_date", how="left")
        wcf_daily2 = wcf_daily2.fillna(0)

        logger.debug('Shape of wcf_daily2 data after merging with all dates data is {}'.format(wcf_daily2.shape))

        wcf_daily3 = wcf_daily2[wcf_daily2['lead_date'].dt.year != 2017] ## ask pankaj if 2017 is constant or not
        wcf_daily3.rename(columns = {'leads':'leads_wcf'}, inplace = True)

        logger.debug('Shape of wcf_daily3 is {}'.format(wcf_daily3.shape))

        ## Merging all data frames in to one
        logger.info('Merging daily_tshw, daily_eml, daily_web into one DataFrame')

        new_dat1 = pd.merge(left=new_dat1, right=daily_tshw, how="left", left_on="lead_date", right_on="start_date")
        new_dat1 = pd.merge(left=new_dat1, right=daily_eml, how="left", left_on="lead_date", right_on="start_date")
        new_dat1 = pd.merge(left=new_dat1, right=daily_web, how="left", left_on="lead_date", right_on="start_date")
        new_dat1 = pd.merge(left=new_dat1, right=wcf_daily3, how="left", on="lead_date")
        new_dat1 = new_dat1.fillna(0)
        
        logger.info('daily_tshw, daily_eml, daily_web and wcf_daily merged')

        logger.debug('Columns before dropping: {}'.format(new_dat1.columns))
        logger.debug('Shape of new_dat1 data before dropping columns is {}'.format(new_dat1.shape))

        new_dat1.drop(['start_date_x','start_date_y','start_date'], axis = 1, inplace = True)

        logger.debug('Columns after dropping: {}'.format(new_dat1.columns))
        logger.debug('Shape of new_dat1 data after dropping columns is {}'.format(new_dat1.shape))
        
        logger.info('creating new columns to calculata distributions')

        new_dat1['email_dist'] = 0
        new_dat1['trade_dist'] = 0
        new_dat1['web_dist'] = 0

        logger.debug('shape of new_dat1 is {}'.format(new_dat1.shape))
        logger.info('Data Processing Finished')
        logger.debug('Completed data_processing function')

        return camp, trd_shw, web, new_dat1, train_start_date, train_end_date

    except Exception as exp_data_processing:
        logger.error('Error', exc_info=True)
        raise exp_data_processing
        

def calculate_density(data, x ,frm, to, logger, n=512):
    """This function calculates the density of given data
    
    Arguments:
        data {dataframe} -- Data on which the density function is to be applied
        x {series} -- Column to be considered for calculating density
        frm {integer} -- Where to start the calculation
        to {integer} --  Where to stop the calculation
        logger {object} -- Logger Object
    
    Keyword Arguments:
        n {integer} -- (default: {512})
    
    Raises:
        e_calculate_density: Raises exception if their is any problem with calculate_density function    
    
    Returns:
        xs, ys[series] -- Corresponding X's and Y's of density calculation
    """    
    try:
        logger.debug('Entered calculate_density function')

        xs = np.linspace(frm, to, n)
        density = gaussian_kde(data[x])
        ys = density(xs)
        
        logger.debug('Completed calculate_density function')

        return xs, ys

    except Exception as exp_calculate_density:
        logger.error('Error', exc_info=True)
        raise exp_calculate_density


def calculate_distribution(data, frm, to, logger, name, type=None):   
    """This function calculates the probability distribution of given data
    
    Arguments:
        data {dataframe} -- Data of which the probability distribution has to be calculated
        frm {integer} -- Where to start the calculation -- passed on to calculate_density function
        to {integer} -- Where to stop the calculation -- passed on to calculate_density function
        logger {object} -- Logger object
        name {string} -- Name of the campaign for which distribution is calculated
    
    Keyword Arguments:
        type {string} -- type of campaign -- only used for tradeshow (default: {None})
    
    Raises:
        exp_calculate_density: Raises exception if their is any problem with calculate_distribution function

    Returns:
        data_dist3 {dataframe} -- Data frame with all distributions calculated
    """    
    try:
        logger.debug('Entered calculate_density function')
        logger.info('Calculating Distribution for {} data'.format(name))
        
        data_dts = data[["lead_date","campaign_type","start_date"]]
        data_dts['diff'] = (pd.to_datetime(data_dts['lead_date']) - pd.to_datetime(data_dts['start_date'])).dt.days
        data_dts = data_dts[data_dts['diff'] >= 0]

        logger.debug('Shape of data after filtering out > 0 time diff is {}'.format(data_dts.shape))

        # Check if name - tradeshow to execute extra command.
        if type != None and type.lower == 'tradeshow':
            logger.debug('Filtering out trade show campaign data')
            data_dts = data_dts[data_dts['campaign_type'] == "Trade Show"]
            
        logger.info('Calculating density function for {}'.format(name))

        # Calling calculateDensity function
        xs, ys = calculate_density(data=data_dts, x='diff', frm=frm, to=to, logger=logger)
        xs = np.round(xs)
        data_dist = pd.DataFrame({'x':xs, 'y':ys})

        logger.debug('Shape of data_dist after density calculation is {}'.format(data_dist.shape))

        data_dist2 = data_dist.groupby('x', as_index=False)['y'].mean()

        logger.debug('Shape of data_dist2 after GroupBy is {}'.format(data_dist2.shape))

        data_dist3 = pd.DataFrame(data_dist2['y'])

        logger.debug('Shape of data_dist3 after converting to DataFrame is {}'.format(data_dist3.shape))
        logger.debug('Completed calculate_distribution function')
        logger.info('Calculating Distribution for {} Data Completed'.format(name))
        
        return data_dist3
    
    except Exception as exp_calculate_density:
        logger.error('Error', exc_info=True)
        raise exp_calculate_density


def add_density_to_data(total_data, campaign_type, campaign_data, no_of_days, logger):
    """This function helps in adding the calculated density to main dataframe
    
    Arguments:
        total_data {dataframe} -- Main data in which the density is to be merged
        campaign_type {string} -- Argument defining type of campaign data
        campaign_data {dataframe} -- Campaign specific data
        no_of_days {integer} -- No of days to forecast in the future
        logger {object} -- Logger object
    
    Raises:
        exp_add_density_to_data: Raises exception if their is any problem with add_density_to_data function
    
    Returns:
        total_data {dataframe} -- Main data with added densities
    """    
    try:
        logger.debug('Entered add_density_to_data function')
        logger.info('adding {} density to new_dat1'.format(campaign_type))

        dates = list(total_data['lead_date'][total_data[campaign_type] > 0])

        column_name = ''

        if campaign_type == 'LNRS Email':
            column_name = 'email_dist'
        
        elif campaign_type == 'Trade Show':
            column_name = 'trade_dist'
        
        elif campaign_type == 'Webinar':
            column_name = 'web_dist'

        for i in range(len(total_data)):
            if(total_data['lead_date'][i] in dates):
                temp = len(total_data) - i
                if(temp >= no_of_days):
                    temp = no_of_days
                    
                data_temp = total_data.iloc[i:(i + temp)][column_name].reset_index(drop=True) + campaign_data.iloc[0:temp]['y'].reset_index(drop=True)   
                data_temp.index = list(range(i, (i+temp)))
                total_data[column_name].iloc[i:(i+temp)] = data_temp
        
        logger.info('{} density added'.format(campaign_type))
        logger.debug('Completed add_density_to_data function')

        return total_data
    
    except Exception as exp_add_density_to_data:
        logger.error('Error', exc_info=True)
        raise exp_add_density_to_data

### write code to save selected model as pickle file.
def load_model(data, logger, forecast_from, train_end_date, train_start_date, days_to_forecast, cv_flag):
    """This function call's all the forecasting models
    
    Arguments:
        data {dataframe} -- Final dataframe on which modelling is to be applied
        logger {object} -- Logger object
        forecast_from {datatime} -- Date to start forecasting from
        train_end_date {datetime} -- Date untill which model should be trained
        days_to_forecast {integer} -- No of days to forecast in future
    
    Raises:
        exc_load_model: Raises exception if their is any problem with load_model function
    
    Returns:
        leads_causal_model {model} -- Forecast model of causal prophet
        forecast_data {dataframe} -- Intermediate forecast_data
        mod_dat2 {dataframe} -- Intermediate dataframe to be passed to another function
        leads_wcf_seasonal_forecast {dataframe} -- Result dataframe for leads forecasting model
    """    
    try:
        logger.debug('Entered load_model function')
        if forecast_from == '':
            logger.debug('forecast from is blank, setting it to max date + 1')
            forecast_from = max(data['lead_date'] + datetime.timedelta(1))
            check_forecast_from = datetime.datetime.strptime(str(forecast_from), '%Y-%m-%d %H:%M:%S')

        else:
            check_forecast_from = datetime.datetime.strptime(forecast_from, '%d-%m-%Y')

        logger.debug('forecast from date is {}'.format(forecast_from))
        logger.debug('train_end_date from date is {}'.format(forecast_from))
        logger.debug('train_start_date is {}'.format(train_start_date))

        
        # logger.debug('check_forecast from date is {}'.format(check_forecast_from))
        check_train_start_date = datetime.datetime.strptime(train_start_date, '%Y-%m-%d %H:%M:%S')        

        days_present = check_forecast_from - check_train_start_date
        logger.debug('days present is {}'.format(days_present))

        if days_present.days / 365 < 2:
            raise Exception('Not enough data for model training, need atleast 2 years of data') 

        forecast_data = pd.DataFrame({'ds':pd.date_range(start=check_forecast_from, periods=days_to_forecast)})
        # logger.debug('forecast data : {}'.format(forecast_data.head(days_to_forecast)))
        logger.info('created forecast_data')
        # write_data(data=forecast_data, file_name='forecast_data_initial', logger=logger)

        data['leads_log'] = np.log(data['leads'] + 1) 
        data['leads_wcf_log'] = np.log(data['leads_wcf'] + 1)

        ## call prophet_model
        ## 1. Seasonality model

        leads_seasonal_data = data[["lead_date","leads_log"]]
        seasonal_cv_params = {'initial':'750 days', 'period':'1 days', 'horizon':'7 days'}
        causal_cv_params = {'initial':'546 days', 'period':'1 days', 'horizon':'7 days'}
        ## fitting prophet seasonal model
        logger.debug('cv flag value is {}'.format(cv_flag))
        
        leads_seasonal_data_test = data[["lead_date","leads_log", "leads"]]
        leads_seasonal_data_test.to_csv('D:/red/applogs/marketing_forecast_model/python/Output Data/seasonal_data.csv', index=False)
        

        leads_seasonal_model = lnm.prophet_model(data=leads_seasonal_data, logger=logger, model_type='seasonal', 
                                                    cv_flag=cv_flag, cv_params=seasonal_cv_params)

        ## forecasting from seasonal model
        forecast_data = lnm.prophet_forecast(model=leads_seasonal_model, futures_dataframe=forecast_data, logger=logger, 
                                            days_to_forecast=days_to_forecast, model_type='seasonal', 
                                            output_column_name='seasonal_prophet_forecast')    
        
        # write_data(data=forecast_data, file_name='f_leads_mod1', logger=logger)
        logger.info('forecasting completed')
        
        ## 2. Holt winters model & forecast
        forecast_data = lnm.holt_winters_model(data=data, logger=logger, futures_dataframe=forecast_data, start_date=check_forecast_from, 
                                        days_to_forecast=days_to_forecast)

        ## 3. Causal model
        leads_causal_data = data[['lead_date','leads_log','email_dist','trade_dist','web_dist','leads_wcf_log']]
        leads_causal_data = leads_causal_data[leads_causal_data['lead_date'].dt.year >= 2018]

        leads_causal_data_test = data[['lead_date','leads','leads_log','email_dist','trade_dist','web_dist','leads_wcf_log']]
        leads_causal_data_test.to_csv('D:/red/applogs/marketing_forecast_model/python/Output Data/causal_data.csv', index=False)

        leads_causal_data = lnm.remove_outlier(data=leads_causal_data, logger=logger)
        logger.info('outliers dropped')
        
        mod_dat2 = leads_causal_data.copy()

        leads_regressor_list = ['email_dist', 'trade_dist', 'web_dist', 'leads_wcf_log']
        leads_causal_model = lnm.prophet_model(data=leads_causal_data, logger=logger, model_type='causal', 
                                                regressor_list=leads_regressor_list, cv_flag=cv_flag,
                                                cv_params=causal_cv_params)

        logger.info('causal model complete')

        ## 3. Leads forecasting model
        leads_wcf_seasonal_data = data[data['lead_date'].dt.year >= 2018][['lead_date','leads_wcf_log']]
        leads_wcf_seasonal_data.rename(columns={"lead_date":"ds", "leads_wcf_log":"y"}, inplace=True)

        leads_wcf_seasonal_model = lnm.prophet_model(data=leads_wcf_seasonal_data, logger=logger, 
                                                        model_type='leads wcf', cv_flag=False)

        leads_wcf_seasonal_forecast = lnm.prophet_forecast(model=leads_wcf_seasonal_model, logger=logger, model_type='leads wcf', 
                                                            days_to_forecast=days_to_forecast)

        logger.debug('shape of leads wcf is {}'.format(leads_wcf_seasonal_forecast.shape))
        return  leads_causal_model, forecast_data, mod_dat2, leads_wcf_seasonal_forecast

    except Exception as exc_load_model:
        logger.error('Error', exc_info=True)
        raise exc_load_model


def main(input_file_name, output_file_name, log_level, forecast_from, days_to_forecast):
    """Main function
    
    Raises:
        exception: Raises exception if there is any problem in main function
    """    
    try:
        

        ## Initializing the logger object
        logger = create_log_object(log_level=log_level)
        
        logger.info('\n')
        logger.info('**************** PARAMETERS FOR THIS RUN ********************')
        logger.info('Program execution started with following parameters')
        
        logger.info('input file name: {}'.format(input_file_name))
        logger.info('output file name: {}'.format(output_file_name))
        logger.info('log level: {}'.format(log_level))
        logger.info('forecast from: {}'.format(forecast_from))
        logger.info('days to forecast: {}'.format(days_to_forecast))
        
        logger.info('*************************************************************\n')

        ## Reading data
        data = read_data(path_to_input=input_file_name, logger=logger)
    
        ## Processing data to subset different campaigns
        train_end_date = str(max(data['lead_date']))
        if forecast_from != '':
            train_end_date = datetime.datetime.strptime(forecast_from, '%d-%m-%Y') - datetime.timedelta(1)

        data_quality_check(data=data, forecast_from=forecast_from, logger=logger)

        logger.debug('training data end date is {}'.format(train_end_date))

        camp, trd_shw, web, new_dat1, train_start_date, train_end_date = data_processing(data=data, train_end_date=train_end_date, logger=logger)

        logger.debug('train_end_date in main {}'.format(train_end_date))

        ## Calculating distributions
        eml_dist3 = calculate_distribution(data=camp, frm=0, to=100, logger=logger, name='eml_dist3')
        trd_dist3 = calculate_distribution(data=trd_shw, frm=0, to=100, logger=logger, name='trd_dist3', type='tradeshow')
        web_dist3 = calculate_distribution(data = web, frm=0, to=40, logger=logger, name='web_dist3')

        ## adding densities to campaign data
        new_dat1 = add_density_to_data(total_data=new_dat1, campaign_type=email_campaign_type, campaign_data=eml_dist3, 
                                        no_of_days=100, logger=logger)

        new_dat1 = add_density_to_data(total_data=new_dat1, campaign_type=trade_show_campaign_type, campaign_data=trd_dist3, 
                                        no_of_days=100, logger=logger)

        new_dat1 = add_density_to_data(total_data=new_dat1, campaign_type=webinar_campaign_type, campaign_data=web_dist3, 
                                        no_of_days=40, logger=logger)
        
        # write_data(file_name='new_dat1.csv', data=new_dat1, logger=logger)

        # if args.cv_flag.lower == 'false':
        if CV_FLAG == 'true':
            cv_flag = True
        else:
            cv_flag = False

        leads_causal_model, forecast_data, leads_causal_data, leads_wcf_seasonal_forecast = load_model(data=new_dat1, logger=logger, 
                                                                                                        forecast_from=forecast_from, 
                                                                                                        train_end_date=train_end_date,
                                                                                                        train_start_date=train_start_date,
                                                                                                        days_to_forecast=days_to_forecast,
                                                                                                        cv_flag=cv_flag)


        logger.debug('leads causal data columns: {}'.format(leads_causal_data.columns))
        logger.debug('intermediate forecast_data shape is {}'.format(forecast_data.shape))
        
        # calculating density for futures
        future_dates = pd.DataFrame({"lead_date":pd.date_range(start=max(leads_causal_data['lead_date']) + datetime.timedelta(days=1), 
                                        end=max(leads_causal_data['lead_date']) + datetime.timedelta(days=days_to_forecast)), 
                                        "leads":0, "Trade Show":0, "LNRS Email":0, 
                                        "Webinar":0, "leads_wcf":0, "email_dist":0, 
                                        "trade_dist":0, "web_dist":0, "leads_log":0, 
                                        "leads_wcf_log":0})

        logger.debug('new_dat1 column names are : {}'.format(new_dat1.columns))
        logger.debug('future_dates column names are : {}'.format(future_dates.columns))

        new_dat2_future = new_dat1.append(future_dates).reset_index(drop=True)

        logger.info('futures data created')

        new_dat2_future = add_density_to_data(total_data=new_dat2_future, campaign_type=email_campaign_type, 
                                                campaign_data=eml_dist3, no_of_days=100, logger=logger)

        new_dat2_future = add_density_to_data(total_data=new_dat2_future, campaign_type=trade_show_campaign_type, 
                                                campaign_data=trd_dist3, no_of_days=100, logger=logger)

        new_dat2_future = add_density_to_data(total_data=new_dat2_future, campaign_type=webinar_campaign_type, 
                                                campaign_data=web_dist3, no_of_days=40, logger=logger)

        logger.debug('future densities added and shape is {}'.format(new_dat2_future.shape))

        new_dat2_future = new_dat2_future.loc[len(new_dat2_future)-days_to_forecast:len(new_dat2_future), 
                                                ['lead_date','email_dist','trade_dist','web_dist']]

        logger.info('new futures dataframe created')

        forecast_all_models = lnm.prophet_forecast(model=leads_causal_model, logger=logger, days_to_forecast=days_to_forecast, 
                                                    model_type='causal', futures_dataframe=forecast_data, 
                                                    output_column_name='causal_prophet_forecast', causal_futures_dataframe=new_dat2_future, 
                                                    leads_wcf_seasonal_forecast=leads_wcf_seasonal_forecast)

        logger.info('final data created')
        
        forecast_all_models.rename(columns={'ds':'date'}, inplace=True)
        pickle.dump(forecast_all_models, open("D:/red/applogs/marketing_forecast_model/python/Output Data/forecast_all_models.pickle.dat", "wb"))
        write_data(path_to_output=output_file_name, data=forecast_all_models, logger=logger)

        logger.info('Program completed successfully')

    except Exception as e_main:
        logger.error('Code execution was not completed due to Error: {}'.format(str(e_main)))
        sys.exit(1)

    
if __name__ == "__main__":
    
    try:
        parser = argparse.ArgumentParser(description='Input information...')
        
        parser.add_argument('--input_file_name', type=str, required=True, help="Enter the input file name")
        parser.add_argument('--output_file_name', type=str, required=True, help="Enter the desired output file name")
        parser.add_argument('--log_level', type=str, help="Define logging level to be used", default='info')
        parser.add_argument('--forecast_from', type=str, help="Enter the date to begin forecasting from (DD-MM-YYYY)", default='')
        parser.add_argument('--days_to_forecast', type=int, help="Enter how many days to forecast in future", default=28)

        args = parser.parse_args()

        main(input_file_name=args.input_file_name, output_file_name=args.output_file_name, 
                log_level=args.log_level, forecast_from=args.forecast_from, days_to_forecast=args.days_to_forecast)

    except Exception as exc_args_parse:
        raise Exception('Some problem with arguments passed, terminating program')
    
    
