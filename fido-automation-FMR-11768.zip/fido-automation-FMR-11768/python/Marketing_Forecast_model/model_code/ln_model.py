import pandas as pd
import numpy as np
import logging
import os
import datetime
#from fbprophet import Prophet
from prophet import Prophet
#from fbprophet.diagnostics import cross_validation
from prophet.diagnostics import cross_validation
#from fbprophet.diagnostics import performance_metrics
from prophet.diagnostics import performance_metrics
from statsmodels.tsa.holtwinters import ExponentialSmoothing, Holt
from sklearn.preprocessing import StandardScaler
from sklearn.covariance import EllipticEnvelope
from pandas.core.window import Rolling

CONTAMINATION = 0.03

class suppress_stdout_stderr(object):
    '''
    A context manager for doing a "deep suppression" of stdout and stderr in
    Python, i.e. will suppress all print, even if the print originates in a
    compiled C/Fortran sub-function.
       This will not suppress raised exceptions, since exceptions are printed
    to stderr just before a script exits, and after the context manager has
    exited (at least, I think that is why it lets exceptions through).

    '''
    def __init__(self):
        # Open a pair of null files
        self.null_fds = [os.open(os.devnull, os.O_RDWR) for x in range(2)]
        # Save the actual stdout (1) and stderr (2) file descriptors.
        self.save_fds = (os.dup(1), os.dup(2))

    def __enter__(self):
        # Assign the null pointers to stdout and stderr.
        os.dup2(self.null_fds[0], 1)
        os.dup2(self.null_fds[1], 2)

    def __exit__(self, *_):
        # Re-assign the real stdout/stderr back to (1) and (2)
        os.dup2(self.save_fds[0], 1)
        os.dup2(self.save_fds[1], 2)
        # Close the null files
        os.close(self.null_fds[0])
        os.close(self.null_fds[1])

def write_model_accuracy(rmse, model_name, logger):
    """This function writes all the model accuracy metrics to text file
    
    Arguments:
        rmse {string} -- Number specifying the root mean square error of the model
        model_name {string} -- Type of forecast model
        logger {log object} -- Logger object
    
    Keyword Arguments:
        new_run_flag {bool} -- Is it a new run or not (default: {False})
    
    Raises:
        exc_write_model_accuracy: Raises exception if there is any problem with write_model_accuracy function
    """    
    try:
        logger.debug('Entering write_model_accuracy function')
        logger.info('Opening ModelAccuracy.txt file')

        file = open('D:/red/applogs/marketing_forecast_model/python/Output Data/ModelAccuracy.txt', 'a+')

        logger.info('Writing model accuracy to ModelAccuracy.txt file')
        
        if model_name == 'seasonal':
            file.write('\n\n***************************************************************************************************************************\n')
            file.write('*********************************************************NEW RUN **********************************************************\n')
            file.write('***************************************************************************************************************************\n')
            file.write('Time: {} \n\n'.format(datetime.datetime.now().strftime('%Y-%m-%d::%H::%M')))
    
        file.write('RMSE of {} model is {}\n'.format(model_name, rmse))

        logger.info('Writing completed')

        file.close()

        logger.debug('Completed write_model_accuracy function')
    
    except Exception as exc_write_model_accuracy:
        logger.error('Error', exc_info=True)
        raise exc_write_model_accuracy



def prophet_model(data, logger, model_type, cv_flag, regressor_list=None, cv_params=None):
    """This function build's the prophet model on given data with specified parameters
    
    Arguments:
        data {dataframe} -- Data on which model is to be built
        logger {object} -- Logger object
        model_type {string} -- Type of prophet model
        cv_flag {bool} -- Cross-validation to be performed or not
    
    Keyword Arguments:
        regressor_list {list} -- List of regressor variables to be used in causal model (default: {None})
        cv_params {dictionary} -- Parameters for cross validation (default: {None})
    
    Raises:
        exc_prophet_model: Raises exception if there is any problem in prophet_model function
    
    Returns:
        model {model} -- prophet forecasting model
    """    
    try:
        logger.debug('Entering prophet_model function')
        # rename
        data.rename(columns={data.columns[0]:'ds', data.columns[1]:'y'}, inplace=True)

        # model
        logger.info('starting the {} model'.format(model_type))
        model = Prophet(yearly_seasonality=True, weekly_seasonality=True, daily_seasonality=False)

        logger.debug('adding country holidays to the model')
        model = model.add_country_holidays(country_name="US")

        logger.debug('adding seasonality to the model')
        model = model.add_seasonality(name="monthly", period=30.5, fourier_order=5)
        model = model.add_seasonality(name="quarterly", period=91.5, fourier_order=7)
        model = model.add_seasonality(name="mid_week", period=3.5, fourier_order=1)
        
        # add regressors
        if model_type == 'causal':
            logger.info('adding regressors to causal model')
            for i in range(len(regressor_list)):
                model = model.add_regressor(name=regressor_list[i], standardize=False, prior_scale=0.1)

        # fit
        logger.info('fitting prophet model')

        with suppress_stdout_stderr():
            model = model.fit(df=data)  

        # cross validation
        if cv_flag:
            logger.debug('starting cross validation')
            model_cv = cross_validation(model=model, initial=cv_params['initial'], 
                                        period=cv_params['period'], horizon=cv_params['horizon'])


            ## write code to convert exp from log
            model_cv1 = model_cv.copy()
            model_cv1[['yhat','yhat_lower','yhat_upper','y']] = np.exp(model_cv1[['yhat','yhat_lower','yhat_upper','y']])

            logger.debug('evaluating performance metrics')

            model_cv1_res = performance_metrics(df = model_cv1, rolling_window = 1)
            rmse_model_cv1 = str(round(model_cv1_res['rmse'][0], 2))

            logger.debug("RMSE of {} model is {}".format(model_type, rmse_model_cv1))

            write_model_accuracy(rmse=rmse_model_cv1, model_name=model_type, logger=logger)

        logger.debug('Completed prophet_model function')
            
        return model

    except Exception as exc_prophet_model:
        logger.error('Error', exc_info=True)
        raise exc_prophet_model


def holt_winters_model(data, logger, futures_dataframe, start_date, days_to_forecast):
    """This function builds holts-winter forecasting model
    
    Arguments:
        data {dataframe} -- Data on which forecasting is to be done
        logger {object} -- Logger object
        futures_dataframe {dataframe} -- Futures dataframe to add predicted values
        start_date {date} -- Forecasting start date
        days_to_forecast {integer} -- How many days to forecast in future
    
    Raises:
        exc_holt_winters_model: Raises exception if there is any problem in holt_winters_model function
    
    Returns:
       futures_dataframe {dataframe} -- forecasted values
    """    
    try:
        logger.debug('Entering holt_winters_model function')
        logger.info('Building holts winter model')
        
        holt_winters_data = pd.DataFrame(data, columns=['lead_date','leads_log']).set_index('lead_date')
        holt_winters_model = ExponentialSmoothing(np.asarray(holt_winters_data['leads_log']) ,seasonal_periods=7, seasonal='add').fit()

        logger.info('Predicting values')
        forecast_values = np.round(np.exp(holt_winters_model.forecast(days_to_forecast)), 1)

        model_future_forecast = pd.DataFrame({'ds':pd.date_range(start=start_date, periods=days_to_forecast)})
        model_future_forecast['holts_winter_forecast'] = forecast_values

        futures_dataframe = pd.merge(left=futures_dataframe, right=model_future_forecast, how="left", on="ds")

        logger.debug('Shape of futures_dataframe holt_winters is {}'.format(futures_dataframe.shape))
        logger.info('Holts winter model completed')
        logger.debug('Completed holt_winters_model function')

        return futures_dataframe
    
    except Exception as exc_holt_winters_model:
        logger.error('Error', exc_info=True)
        raise exc_holt_winters_model


def remove_outlier(data, logger):
    """This function removes outlier from given data
    
    Arguments:
        data {dataframe} -- Data from which outlier are to be removed
        logger {object} -- Logger object
    
    Raises:
        exc_remove_outlier: Raises exception if there is any problem with remove_outlier function
    
    Returns:
        data {dataframe} -- data with outlier removed
    """    
    try:
        logger.debug('Entered remove_outlier function')
        logger.info('identifying outliers from data')

        envelope =  EllipticEnvelope(contamination = CONTAMINATION) 

        X_train = data[['leads_log']].values.reshape(-1,1)
        envelope.fit(X_train)
        data['deviation'] = envelope.decision_function(X_train)
        data['anomaly2'] = envelope.predict(X_train)

        logger.info('writing outliers to a file')
        
        outlier_file_name = datetime.datetime.now().strftime('statistical_outlier_%Y-%m-%d_%H_%M.tsv')
        outlier_data = data[data['anomaly2'] == -1][['lead_date', 'leads_log']]
        outlier_data['leads'] = np.exp(outlier_data['leads_log']).round()
        outlier_data.drop('leads_log', axis=1, inplace=True)

        outlier_data.to_csv('D:/red/applogs/marketing_forecast_model/python/Output Data/Outliers/' + outlier_file_name, sep='\t', index=False)

        logger.info('dropping outliers from data')
        data.loc[data['anomaly2'] == -1, 'leads_log'] = np.nan
        data.drop(['anomaly2', 'deviation'], axis=1 ,inplace=True)

        logger.debug('Shape of data after dropping outliers is {}'.format(data.shape))
        logger.debug('Completed remove_outlier function')

        return data

    except Exception as exc_remove_outlier:
        logger.error('Error', exc_info=True)
        raise exc_remove_outlier


def prophet_forecast(model, logger, days_to_forecast, model_type=None, futures_dataframe=None, 
                output_column_name=None, causal_futures_dataframe=None, leads_wcf_seasonal_forecast=None):
    """This function uses prophet model to forecast values
    
    Arguments:
        model {model} -- Prophet forecast model
        logger {object} -- Logger object
        days_to_forecast {integer} -- No of days to forecast in future
    
    Keyword Arguments:
        model_type {string} -- Type of prophet model (default: {None})
        futures_dataframe {dataframe} -- Futures dataframe to add forecasted values (default: {None})
        output_column_name {string} -- Name of output column (default: {None})
        causal_futures_dataframe {dataframe} -- Futures dataframe for causal prophet model (default: {None})
        leads_wcf_seasonal_forecast {dataframe} -- Leads wcf forecast dataframe (default: {None})
    
    Raises:
        exc_prophet_forecast: Raises exception if there is any problem with prophet_forecast function
    
    Returns:
        futures_dataframe {dataframe} -- Dataframe with forecasted values
    """    
    try:                
        logger.debug('Entering prophet_forecast function')        
        logger.info('starting prophet forecast')

        model_future_data = model.make_future_dataframe(periods=days_to_forecast, freq='D', include_history=False)

        if model_type == 'causal':
            model_future_data = pd.merge(left=model_future_data, right=causal_futures_dataframe, how="left", left_on="ds", right_on="lead_date")
            model_future_data.drop(['lead_date'], axis=1, inplace=True)
            model_future_data = pd.merge(left=model_future_data, right=leads_wcf_seasonal_forecast, how="left", on="ds")

        logger.info('Forecasting values')
        model_future_forecast = model.predict(model_future_data)
        model_future_forecast = model_future_forecast[['ds','yhat']]

        if model_type != 'leads wcf':
            model_future_forecast[output_column_name] = np.exp(model_future_forecast['yhat']).round(1)
            futures_dataframe = pd.merge(left=futures_dataframe, right=model_future_forecast[["ds",output_column_name]], how="left", on="ds")
            logger.debug('Shape of futures_dataframe is {}'.format(futures_dataframe.shape))

            return futures_dataframe

        elif model_type == 'leads wcf':
            model_future_forecast.rename(columns={'yhat':'leads_wcf_log'}, inplace=True)
            logger.debug('Shape of leads_wcf_dataframe is {}'.format(model_future_forecast.shape))

            return model_future_forecast
        
        logger.info('Prophet forecast completed')
        logger.debug('Completed prophet_forecast function')
    
    except Exception as exc_prophet_forecast:
        logger.error('Error', exc_info=True)
        raise exc_prophet_forecast