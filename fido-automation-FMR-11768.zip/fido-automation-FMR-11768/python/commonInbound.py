class commonInbound(object):
    source = ""  
    frequency = ""
    sourcename = ""
    fidoname = ""
    required = ""
    pullOrPush = ""
    sourceExtension   = ""
    fidoExtension   = ""
    found = False
    foundServer = ""
    relativeSourceFolder = ""
    absSourceFileName = ""
    absFidoFileName = ""
    absFidoCompressedFileName = ""
    fileDate = ""
    autoSourceFolderPrefix = False
    completedFlagFileName = ""
    actualFileNameAtSource = "" 
    error_cc_email_on_missingfile = ""
    match_latest_file = False
    def __init__(self, _source, _frequency, _filedate, _relativesourcefolder, _sourcename , _fidoname, _required, _pullOrPush, _sourceExtension, _fidoExtension, _error_cc_email_on_missingfile,_absSourceFileName, _absFidoFileName, _absFidoCompressedName,_completedFlagFileName = "", _autoSourceFolderPrefix = True, _moveUnusedFiles = True, _match_latest_file = False):
        self.source = _source
        self.frequency = _frequency
        self.sourcename = _sourcename
        self.fidoname = _fidoname
        self.required = _required
        self.pullOrPush = _pullOrPush
        self.sourceExtension  = _sourceExtension
        self.fidoExtension  = _fidoExtension
        self.relativeSourceFolder = _relativesourcefolder
        self.found = False
        self.foundServer = ''
        self.fileDate = _filedate
        self.completedFlagFileName = _completedFlagFileName
        self.absSourceFileName = _absSourceFileName
        self.absFidoFileName = _absFidoFileName
        self.absFidoCompressedFileName = _absFidoCompressedName
        self.autoSourceFolderPrefix = _autoSourceFolderPrefix
        self.error_cc_email_on_missingfile = _error_cc_email_on_missingfile
        self.match_latest_file = _match_latest_file

    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 
