import io
import os
import gc
import time
from datetime import datetime
import logging
import platform
import subprocess
from git import Repo 
from git import RemoteProgress
from github import GithubIntegration
import parseYamlProperty
import commonArgs
from pathlib import Path
import get_vault_ssh
from send_email import *

dt = datetime.now().strftime("%Y%m%d%H%M%S%f")  # datetime now (all in UTC)
_processInfo = []

class CloneProgress(RemoteProgress):
    def update(self, op_code, cur_count, max_count=None, message=''):
        global _processInfo
        _processInfo.append(self._cur_line)
        #print(self._cur_line)

def logException(app_name, exception):

    # Create log vars
    logDirPath = str(Path(os.path.join(parseYamlProperty.get_git_logs_dir(), app_name)).resolve())
    logFileName = f"githublock_{str(dt)}.log"
    logFilePath = os.path.join(logDirPath, logFileName)
    repoPath = str(Path(os.path.join(parseYamlProperty.get_base_src_dir(), app_name)).resolve())

    # Ensure log dir exists
    ensure_dir(logDirPath)

    # Create logger and log exception
    logging.basicConfig(filename=logFilePath, level=logging.INFO)
    logging.error(exception)

    # Start handle64 subprocess to pipe out a list of processes and
    # users that are operating in the repo dir at the time of execution
    proc = subprocess.Popen(["handle64", "/accepteula", "-u", repoPath], stdout=subprocess.PIPE, shell=True)

    killPIDList = []
    prevPID = 0
    processInfo = []

    # Iterate through handler64 output to format entries
    if proc.stdout is not None:
        for line in io.TextIOWrapper(proc.stdout, encoding="utf-8"):
            if "pid" in line:
                pid_line = line.rstrip()
                print("Pid Line {0}".format(pid_line))
                logging.info(pid_line)
                words = pid_line.split()
                print("Words {0}".format(words))
                prevword = ""
                for word in words:
                    if prevword == "pid:":
                        pidvalue = word
                        print(pidvalue)
                        killPIDList.append(pidvalue)
                        if prevPID != pidvalue:
                            processInfo.append(line)
                        prevPID = pidvalue
                    prevword = word
                print("Process Info {0}".format(processInfo))

    # Send error email to listed participants
    sendMail(processInfo, app_name)
    exit()

def get_github_token(github_owner, github_repo, app_id, rsa_key_path):
    '''returns github api auth token for provided repo, app, and ssh auth key'''
    try:
        with open(rsa_key_path, "r") as secret:
            priv_key = secret.read()
        app = GithubIntegration(app_id, priv_key)
        installation = app.get_installation(github_owner, github_repo)
        return app.get_access_token(installation.id).token
    except Exception as e:
        print(f"Error retrieving github token")
        logException(github_repo, e)

def removeRsaKey(rsa_key_path):
    # remove temporary rsa key file at rsa_key_path
    if os.path.exists(rsa_key_path):
            os.chmod(rsa_key_path, 0o700)
            os.remove(rsa_key_path)

def cloneRepo(app_name, repo_name, gitToken, base_src_path, owner):

    # path to time stamped folder
    tsFolder = os.path.join(base_src_path , dt, app_name)
    tsFolder = str(Path(tsFolder).resolve())

    if not os.path.exists(tsFolder):
        # make time stamped folder
        os.makedirs(tsFolder)
        try:
            repo_url = f"https://x-access-token:{gitToken}@github.com/{owner}/{repo_name}"
            # clone to timestamped folder
            repo = Repo.clone_from(repo_url, tsFolder, progress=CloneProgress())
            del repo
            return True
        except:
            raise Exception('Error during git Clone {0}'.format(str(tsFolder)))
    return False

def ensure_dir(directory):
    print('Ensure Dir {0}'.format(directory))
    if not os.path.exists(directory):
        os.makedirs(directory)

def rename_with_retry(src, dst, attempts=24, delay=5):
    '''os.rename with delayed n try attempts before failing'''
    for _ in range(attempts):
        try:
            os.rename(src, dst)
            break
        except Exception as e:
            print(f"Move failed: {e}, retrying in {delay} seconds...")
            time.sleep(delay)
    else:
        print(f"Move failed after {attempts} attempts, aborting.")
        #raise

def rename_fido_folder(base_src_path):
    '''backs up existing code dir and replaces with the timestamped clone code'''
    fidofolder  = base_src_path + '\\fido'
    backupfolder = base_src_path + '\\fido' + dt
    timestampfolder = base_src_path + '\\' + dt  
    ensure_dir(fidofolder)
    # back up current code by renaming code dir to backup folder
    print('Going to rename {0} to {1}'.format(fidofolder, backupfolder))
    assert os.access(fidofolder, os.W_OK), f'{fidofolder} cannot be renamed! ...aborting'
    rename_with_retry(fidofolder, backupfolder)
    # replace with cloned code by renaming timestamped dir to code dir
    print('Going to rename {0} to {1}'.format(timestampfolder, fidofolder))
    assert os.access(timestampfolder, os.W_OK), f'{timestampfolder} cannot be renamed! ...aborting'
    assert not os.path.exists(fidofolder), f'{fidofolder} already exists! ...aborting'
    rename_with_retry(timestampfolder, fidofolder)

def process():
    # globals
    global dt, app_name
    print(dt)
    app_name = commonArgs.getApplication()    
    # base script path: where local code resides
    base_src_path = str(Path(parseYamlProperty.get_base_src_dir()).resolve())
    ensure_dir(base_src_path)

    #try:
    # getting ssh key to connect to github api
    rsa_key_path = parseYamlProperty.get_github_rsa_key_path()
    get_vault_ssh.get_ssh_key()  # create temporary rsa key file at rsa_key_path
    # get github api token
    app_id = 137109 # GitHub App app-svc-fido-automation, #137109
    owner = "LexisNexis-RBA"  #os.getenv("GITHUB_OWNER")"
    repo_name = 'fido-' + app_name
    print('Getting GitHub access token...')
    token = get_github_token(owner, repo_name, app_id, rsa_key_path)
    # remove the temp
    removeRsaKey(rsa_key_path)

    # stash any local changes and pull down updated code
    print("Cloning repo...")
    returncode = cloneRepo(app_name, repo_name, token, base_src_path, owner)
    print("Repo clone Sucess")

    strReturnCode = str(returncode)

    print(_processInfo)
    print('Whats my return code -- {0}'.format(strReturnCode))

    if not returncode:
        sendMail([strReturnCode,], app_name)
        exit(1)

    # garbage collect to resolve gitpython locking files in cloned repo
    gc.collect()
    # rename cloned dir to proper code dir
    rename_fido_folder(base_src_path)

    # Don't need try/except as we are already capturing std err in the batch script
    # except Exception as e:
    #     print("Process error! Logging error results...")
    #     logException(app_name, e)


def sendMail(processInfo, app_name):
    servername = platform.node()
    EmailSubject = servername + "-- " + app_name + " GitHubPull - " + dt
    ErrorEmailSubject = "ERROR / WARNING : " + EmailSubject
    emailFrom = "fido-" + app_name + "-repo-gitpull.automation@lexisnexisrisk.com"
    emailTo = ['fido.operations@lexisnexisrisk.com']
    emailCC = ['raju.nagarajan@lexisnexisrisk.com', 'brandon.wood11@lexisnexisrisk.com']
    print("EmailTo -- {0}".format(emailTo))
    send_mail(emailFrom, emailTo, emailCC, ErrorEmailSubject, "" + "\n".join(processInfo))


if __name__ == "__main__":
    start_time = datetime.now()
    process()
    print(f'All Done! - Finished in {(datetime.now() - start_time)}')