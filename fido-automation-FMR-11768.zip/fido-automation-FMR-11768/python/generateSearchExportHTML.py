import ScoutExportNotification
import scoutUtils
import os

def xstr(s):
    return '' if s is None else str(s)

htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>#scoutsearchexp {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }
                #scoutsearchexp td, 
                #scoutsearchexp 
                th {   border: 1px solid #ddd;   padding: 8px;}
                #scoutsearchexp 
                th {    padding-top: 10px;   padding-bottom: 10px;   text-align: left;   background-color: #357040;   color: white;}  
                #scoutsearchexpsuccess {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }  
                #scoutsearchexpsuccess td, #scoutsearchexp th { border: 1px solid #ddd;   padding: 8px;} 
                #scoutsearchexpsuccess th { padding-top: 10px;   padding-bottom: 10px; 
                text-align: left;   background-color: #354c70;   color: white;} 
                #scoutsearchexperror {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }
                #scoutsearchexperror td, #scoutsearchexp th {   border: 1px solid #ddd;   padding: 8px;}
                #scoutsearchexperror th {    padding-top: 10px;   padding-bottom: 10px;   text-align: left;   background-color: #f25d5d;   color: white;}  
                </style>"""

def generateAudit(exportSearchList):
    
    searchDataRow = ""

    searchTable = """ <TABLE id="scoutsearchexp"> 
                            <TR> 
                            <th>Search Id</th> 
                            <th>Search Name</th>
                            <th>Requested By</th>
                            <th>Workunit</th>
                            <th>Status</th>
                            <th>Number of files</th>
                            <th>Start Time</th> 
                            <th>End Time</th> 
                            <th>Elapsed Time</th> 
                            </tr> """
    
    for exportSearch in exportSearchList:
        searchDataRow += (' <tr> ' 
                        '<td>' + xstr(exportSearch.searchId) + '</td>' 
                        '<td>' + xstr(exportSearch.searchName) + '</td>'
                        '<td>' + xstr(exportSearch.requestedUser) + '</td>'                        
                        '<td>' + xstr(exportSearch.workunit) + '</td>' 
                        '<td>' + xstr(exportSearch.workunitStatus) + '</td>' 
                        '<td>' + xstr(len(exportSearch.set_of_exportedFiles)) + '</td>' 
                        '<td>' + xstr(exportSearch.startTime) + '</td>' 
                        '<td>' + xstr(exportSearch.completionTime) + '</td>' 
                        '<td>' + xstr(exportSearch.elapsedTime) + '</td>' 
                        '</tr>')

    if exportSearchList:
        searchDataRow += '</TABLE>'
        return (htmlHeader + searchTable + searchDataRow)
    else: 
        return htmlHeader + '<table><tr><td>No Data exported</td></tr></table>'

def generate(exportSearch):
    searchTable = """ <TABLE id="scoutsearchexp"> 
                    <TR> 
                    <th>Search Id</th> 
                    <th>Search Name</th> 
                    <th>Workunit</th> 
                    <th>Start Time</th> 
                    <th>End Time</th> 
                    <th>Elapsed Time</th> 
                    </tr> """

    print('ExportSearch {0}'.format(exportSearch))

    print(exportSearch.searchId)
    print(exportSearch.searchName)
    print(exportSearch.startTime)
    print(exportSearch.completionTime)
    print(exportSearch.elapsedTime)

    searchDataRow = (' <tr> ' 
                     '<td>' + xstr(exportSearch.searchId) + '</td>' 
                     '<td>' + xstr(exportSearch.searchName) + '</td>' 
                     '<td>' + xstr(exportSearch.workunit) + '</td>' 
                     '<td>' + xstr(exportSearch.startTime) + '</td>' 
                     '<td>' + xstr(exportSearch.completionTime) + '</td>' 
                     '<td>' + xstr(exportSearch.elapsedTime) + '</td>' 
                     '</tr> </TABLE>')

    searchListRow = ''
    lines = ''
    if exportSearch.set_of_exportedFiles:
        searchListRow = """<table id='scoutsearchexpsuccess'>
                          <tr>
                          <th>Export file name</th>
                          <th>File size</th>
                          </tr>"""
        for filename in exportSearch.set_of_exportedFiles:
            try:
                fileSize = scoutUtils.sizeof_fmt(os.path.getsize('{0}'.format(filename)))
            except FileNotFoundError:
                fileSize = 'N/A'
            lines += '<tr><td>' + filename + '</td><td>' + fileSize + ' </td></tr>'
        lines += '</TABLE>'
        searchListRow += lines

    if searchListRow == '':
        searchListRow = """<table id='scoutsearchexpsuccess'>
                          <tr>
                          <th>Search returned No rows</th>
                          </tr></table>"""

    errorTable = ""
    if exportSearch.workunitStatus in ['failed', 'aborted']:
        errorTableTemp =  """<table id='scoutsearchexperror'>
                            <tr>
                            <th>Error:</th>
                            </tr><tr><td>""" 
        errorTable = errorTableTemp + exportSearch.workUnitMsg + '</td></tr></table>' 

    searchInputTable = """<table id='scoutsearchexpsuccess'>
                          <th colspan='2'>Search Parameters</th>"""

    for k, v in exportSearch.searchInput.items():
        searchInputTable += '<tr><td>{0}</td><td>{1}</td></tr>'.format(k, v)
    
    searchInputTable += '</table>'
    

    return (htmlHeader + searchTable + searchDataRow + searchInputTable + searchListRow + errorTable)