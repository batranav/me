import sendEmail
import parseYamlProperty as parse_props
import fido_utils

def xstr(s):
    return '' if s is None else str(s)

def generateemailmsg(exportSearchList):

    sourceTable = """ <TABLE id="build"> """ 

    maindetails =  ('' 
                        '<tr><th>Source</th><td>' + xstr(exportSearchList[1].source) + '</td></tr>' 
                        '<tr><th>Frequency</th><td>' + xstr(exportSearchList[1].frequency) + '</td></tr>' 
                        '<tr><th>File Date</th><td>' + xstr(exportSearchList[1].fileDate) + '</td></tr></tr>')

    endPart = '</TABLE>'

    htmlHeader = """<html>
                    <head> 
                    <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                    </head>
                    <style>#checkandpull {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }
                    #checkandpull td, 
                    #checkandpull 
                    th {   border: 1px solid #ddd;   padding: 8px;}
                    #checkandpull 
                    th {    padding-top: 10px;   padding-bottom: 10px;   text-align: left;   background-color: #357040;   color: white;}  
                    #checkandpullsuccess {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }  
                    #checkandpullsuccess td, #checkandpull th { border: 1px solid #ddd;   padding: 8px;} 
                    #checkandpullsuccess th { padding-top: 10px;   padding-bottom: 10px; 
                    text-align: left;   background-color: #354c70;   color: white;} 
                    #checkandpullerror {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }
                    #checkandpullerror td, #checkandpull th {   border: 1px solid #ddd;   padding: 8px;}
                    #checkandpullerror th {    padding-top: 10px;   padding-bottom: 10px;   text-align: left;   background-color: #f25d5d;   color: white;}  
                    </style>"""

    searchDataRow = ""

    searchTable = """ <TABLE id="checkandpull"> """ +  maindetails + """<tr></tr>""" + """
                            <TR> 
                            <th>Source Name</th> 
                            <th>Fido FileName</th>
                            <th>Found</th>
                            <th>Found Server</th>
                            <th>Push OR Pull</th>
                            </tr> """
    
    for exportSearch in exportSearchList:
        searchDataRow += (' <tr> ' 
                        '<td>' + xstr(exportSearch.source) + '</td>' 
                        '<td>' + xstr(exportSearch.fidoname) + '</td>'
                        '<td>' + xstr(exportSearch.found) + '</td>'
                        '<td>' + xstr(exportSearch.foundServer) + '</td>'                        
                        '<td>' + xstr(exportSearch.pullOrPush) + '</td>' 
                        '</tr>')

    if exportSearchList:
        searchDataRow += '</TABLE>'
        return (htmlHeader + searchTable + searchDataRow)
    else: 
        return htmlHeader + '<table><tr><td>No Data exported</td></tr></table>'

def notifyEmail(ssFiles):
    successEmailFrom = 'SUCESS-Fido.red.automation@lexisnexisrisk.com'
    errorEmailFrom  = 'ERROR-Fido.red.automation@lexisnexisrisk.com'
    # emailFrom = successEmailFrom if ssFiles.status else errorEmailFrom
    # emailTo = ssFiles.successEmailTo if ssFiles.status else ssFiles.errorEmailTo
    PlatformPrefix = parse_props.getPlatform() + ' :: ' 

    if any([x for x in ssFiles if x.found == False]):
        subjectPrefix =  'Error ::' 
    else:
        subjectPrefix = 'Success :: '
    
    subject = subjectPrefix + PlatformPrefix + 'RED Build for ' + ssFiles[1].source + "-" + ssFiles[1].frequency + "-" + ssFiles[1].fileDate
    msg = generateemailmsg(ssFiles)
    sendEmail.send('raja.sundarrajan@lexisnexis.com', 'raja.sundarrajan@lexisnexis.com', 'raja.sundarrajan@lexisnexis.com', subject, msg)  
    print('Printing in NotifyEmail {0}'.format(ssFiles))
