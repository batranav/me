import sys, requests, os, time, ssl
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import parseYamlProperty
import commonArgs
import AutomationLogging
from vault.secrets import get_api_secret

yesterday = datetime.now() - timedelta(days=1)
threemonthsprior = datetime.now() - timedelta(days=180)
threedaysprior = datetime.now() - timedelta(days=3)

logger = AutomationLogging.getLogger('preprocess_innotas_analytics_extract_tables')
uname, pwd = get_api_secret(logger, 'innotas_analytics')

def frameMessage(entityId, fieldIds):
    firstpart = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">    <soapenv:Header/> <soapenv:Body> <ser:selectEntity> <ser:sessionId>{sessionID}</ser:sessionId> <ser:entityTypeId>' + entityId + '</ser:entityTypeId> <ser:entityId>{entityID}</ser:entityId> '
    strparts = fieldIds.split(',')
    for y in range(0, len(strparts)):
        firstpart += '<ser:fieldsRequest>' + strparts[y] + '</ser:fieldsRequest>'
    firstpart += '</ser:selectEntity>   </soapenv:Body> </soapenv:Envelope>'

    return firstpart

def pullInnotasDataUsingSOAP(table_name, entity_type_id, start_dt, end_dt, field_list):

    yesterday = datetime.now() - timedelta(days=1)


    sd=start_dt
    ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
    sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_analytics_'+ table_name +'log_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')

    SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:login>
            <!--Optional:-->
            <ser:username>{uname}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd}</ser:password>
        </ser:login>
    </soapenv:Body>
    </soapenv:Envelope>""".encode(encoding='utf-8')

    #print(SoapMessage)

    #construct and send the header


    proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
    url = "lninsurancebusinesspmo.ppmpro.com"
    post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

    session = requests.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
    response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

    result = response.content
    print(result)

    with open('temp_' + table_name + '.xml','wb') as f:
        f.write(result)
        
    f.close()
    tree = ET.parse('temp_' + table_name + '.xml')

    sessionId = tree.find('.//{http://services}return').text

    SoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:getUpdateHistory>
            <!--Optional:-->
            <ser:sessionId>""" + sessionId + """</ser:sessionId>
            <!--Optional:-->
            <ser:entityTypeId>""" + entity_type_id + """</ser:entityTypeId>
            <!--Optional:-->
            <ser:startYYYYMMDD>""" + sd + """</ser:startYYYYMMDD>
            <!--Optional:-->
            <ser:endYYYYMMDD>""" + ed + """</ser:endYYYYMMDD>
            <!--Optional:-->
            <ser:showRepeatingPerDay>false</ser:showRepeatingPerDay>
            <!--Optional:-->
            <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
        </ser:getUpdateHistory>
    </soapenv:Body>
    </soapenv:Envelope>"""

    print(SoapMessage)

    #construct and send the header

    proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
    url = "lninsurancebusinesspmo.ppmpro.com"
    post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

    session = requests.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getUpdateHistory"}
    response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)

    result = response.content

    open('temp_' + table_name + '.xml','wb').write(result)

    tree = ET.ElementTree(file='temp_' + table_name + '.xml')

    if table_name == 'workgroup':
        entityIds1 = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
        entityIds=set(entityIds1)
    else:
        entityIds = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]     

    DefaultSoapMessage = frameMessage(entity_type_id, field_list)                                                                                                                                                                                           

    output_handle = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_analytics_' + table_name + '_' + datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding='utf-8')

    for entityId in entityIds:
        SoapMessage = DefaultSoapMessage.replace('{entityID}',entityId).replace('{sessionID}',sessionId)
        proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
        url = "lninsurancebusinesspmo.ppmpro.com"
        post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"
        session = requests.session()
        session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:selectEntity"}
        
        no_of_attempts = 25
        for x in range(0, no_of_attempts):
            response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
            print("status_code:", response.status_code)
            if response.status_code == 429:
                print(response.headers["Retry-After"])
                time.sleep(int(response.headers["Retry-After"]))
                x += 1
            else:
                break        
        
        result = response.content
        print(response)
        
        open('temp_' + table_name + '.xml','wb').write(result)
        
        tree = ET.ElementTree(file='temp_' + table_name + '.xml')
        output_handle.write(entityId + '||')
        '''for x in tree.findall('.//{http://objects.services/xsd}elementValue'):
            print(x.text)
            y = x.text
            output_handle.write(y)
                '''
        output_handle.write('||'.join([(x.text or '').replace('\r\n','    ').replace('\n','     ').replace('\r','     ') for x in tree.findall('.//{http://objects.services/xsd}elementValue')]))
        output_handle.write('\n')
    
    output_handle.close()
    os.remove('temp_' + table_name + '.xml')

if __name__ == "__main__":
    #pullInnotasDataUsingSOAP('resource', '11', threemonthsprior.strftime('%Y/%m/%d') +' 23:59:59', '2022/05/11 07:00:00', '1117,1102,1110,1124,1151,1198')
    #pullInnotasDataUsingSOAP('allocation', '54', '2021/12/01 00:00:01',                            '2022/05/11 07:00:00', '5452,5425,5495,5424,5405,5429,5401,5498,5421,5417,5440,5422,5411,5406,5423,5419')
    #pullInnotasDataUsingSOAP('project', '4',     '2021/12/01 00:00:01',                            '2022/05/11 07:00:00', '962689914,962698323,962697562,436,411,498,1002652070,2607757697,400027,2597603791,445,405,412,430,435,459,100442,100444,400026,12425015,15797646,830461011,962693920,962696419,962698139,966292297,967014366,968731585,969000812,970203994,971709224,971718733,975190756,1727172729,1745212414,1989485604,1989488265,1989489908,1989495311,1989497366,1996802987,2417510915,2417917782,2452897869,2546265892,2552678318,2552678884,2597175665,2597603424,2597603883,2597605539,2597605692,2597605782,2597605965,2597606232,2597606310,2597606811,2597607335,2597607461,2597608065,2597608234,2597609153,2597609166,2597609677,2597610578,2597610681,2597811813,2598696231,2598700065,2612943052,2615724238,2620188617,2620193688,2627606525,2627614871,2627615503,2627616315,2658930732,2661679273,2664058862,2667399115,2667424986,414')
    #pullInnotasDataUsingSOAP('project_log', '6',     '2021/12/01 00:00:01',                            '2022/05/11 07:00:00','435,2667405402,2597811695,2667406324,2667405916,2597811778,616,100602,1031912414,2597811953,2597812031,2597812053,644,600002,603,646,695,696,2597804259,2597803528,2597803557,2597803640,2597803823,2597803870,605,1031913432,648,699,698,600000,2597805685,2597805639,2597805970,2597805366,2597805210,2597805731,2598687743,692,2597800924,625,2655309129,2655310114,659,2667401931,2597806155,1031913027,655,2601470075,2597800716,2597812131,628')
    pullInnotasDataUsingSOAP('resource', '11', threemonthsprior.strftime('%Y/%m/%d') +' 23:59:59', yesterday.strftime('%Y/%m/%d')+' 23:59:59', '1117,1102,1110,1124,1151,1198,1136,1126')
    pullInnotasDataUsingSOAP('project', '4', threedaysprior.strftime('%Y/%m/%d')+' 00:00:01',yesterday.strftime('%Y/%m/%d')+' 23:59:59', '962689914,962698323,962697562,436,411,498,1002652070,2607757697,400027,2597603791,445,405,412,430,435,459,100442,100444,400026,12425015,15797646,830461011,962693920,962696419,962698139,966292297,967014366,968731585,969000812,970203994,971709224,971718733,975190756,1727172729,1745212414,1989485604,1989488265,1989489908,1989495311,1989497366,1996802987,2417510915,2417917782,2452897869,2546265892,2552678318,2552678884,2597175665,2597603424,2597603883,2597605539,2597605692,2597605782,2597605965,2597606232,2597606310,2597606811,2597607335,2597607461,2597608065,2597608234,2597609153,2597609166,2597609677,2597610578,2597610681,2597811813,2598696231,2598700065,2612943052,2615724238,2620188617,2620193688,2627606525,2627614871,2627615503,2627616315,2658930732,2661679273,2664058862,2667399115,2667424986,414,2690119075,438,425,428,2615723979,2530643466,968739872,403,2597608772,408,411,417')
    pullInnotasDataUsingSOAP('project_log', '6',threedaysprior.strftime('%Y/%m/%d')+' 00:00:01',yesterday.strftime('%Y/%m/%d')+' 23:59:59','435,2667405402,2597811695,2667406324,2667405916,2597811778,616,100602,1031912414,2597811953,2597812031,2597812053,644,600002,603,646,695,696,2597804259,2597803528,2597803557,2597803640,2597803823,2597803870,605,1031913432,648,699,698,600000,2597805685,2597805639,2597805970,2597805366,2597805210,2597805731,2598687743,692,2597800924,625,2655309129,2655310114,659,2667401931,2597806155,1031913027,655,2601470075,2597800716,2597812131,628')
    pullInnotasDataUsingSOAP('allocation', '54', threedaysprior.strftime('%Y/%m/%d')+' 00:00:01',yesterday.strftime('%Y/%m/%d')+' 23:59:59', '5452,5425,5495,5424,5405,5429,5401,5498,5421,5417,5440,5422,5411,5406,5423,5419') 
