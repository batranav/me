from distutils.filelist import FileList
class RedSourceFiles(object):
    source = ""
    processtype = ""
    source_file_date = ""
    file_date = 0
    build_month = 0
    frequency = ""
    working_dir = ""
    archive_dir = ""
    base_dir = ""
    log_filename = ""
    status = True
    workunit = ""
    workunitstatus = 'No WU Available'
    workunitMsg = ""
    msg = ""
    archivedFileName = ""
    platform = ""
    requestorId = ""
    hpcc = ""
    preProcessStartTime = ""
    preProcessEndTime = ""
    processStartTime = ""
    processEndTime = ""
    HPCCStartTime = ""
    HPCCEndTime = ""
    postProcessStartTime = ""
    postProcessEndTime = ""
    processerrorMsg = ""
    move_unused_files=True
    text_file_extn = []
    list_of_gz_files = []
    list_of_done_files = []
    list_of_working_files = []
    list_of_expected_files = []
    list_of_optional_files = []
    list_of_text_files = []
    list_of_missing_files = []
    list_of_expected_but_missing_files = []
    list_of_optional_but_missing_files = []
    list_of_extra_files = []
    postProcessFlag = True
    errorEmailTo = ''
    successEmailTo = ''
    hostname = ''

    def __init__(self, source, frequency, processtype):
        self.source = source
        self.frequency = frequency
        self.processtype = processtype
        self.working_dir = ""
        self.archive_dir = ""
        self.base_dir = ""
        self.log_filename = ""
        self.status = True
        self.workunit = ""
        self.workunitstatus = 'No WU Available'
        self.workunitMsg = ""
        self.msg = ""
        self.platform = ""
        self.requestorId = ""
        self.preProcessStartTime = ""
        self.preProcessEndTime = ""        
        self.processStartTime = ""
        self.processEndTime = ""
        self.HPCCStartTime = ""
        self.HPCCEndTime = ""
        self.postProcessStartTime = ""
        self.postProcessEndTime = ""
        self.archivedFileName = ""
        self.text_file_extn = []
        self.source_file_date = ""
        self.file_date = 0
        self.build_month = 0
        self.list_of_gz_files = []
        self.list_of_done_files = []
        self.list_of_working_files = []
        self.list_of_text_files = []
        self.list_of_missing_files = []
        self.list_of_expected_but_missing_files = []
        self.list_of_optional_but_missing_files = []
        self.list_of_extra_files = []
        self.postProcessFlag = True
        self.errorEmailTo = ''
        self.successEmailTo = ''
        self.hostname = ''
    
    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 

    def __lt__(self, other):
        return self.file_date < other.file_date
