import sendEmail
import os
from datetime import datetime
import parseYamlProperty as parse_props
import commonArgs
# import fido_utils
 
def scripts_run_info(scripts_run):
    
    is_success = True
    searchInputTable = """ <TABLE id="buildsuccess">
                        <TR>
                        <th>Script Name</th>
                        <th>Success</th>
                        <th>Jira number</th>
                        <th>Error</th>
                        </tr> """
       
    values_list = list(scripts_run.values())
    print(values_list)
    # subject = "Success Message"
    sorted_keys = sorted(scripts_run, key=lambda x: scripts_run[x][1])
    for k in sorted_keys:
        v =  scripts_run[k]
        searchInputTable += '<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>'.format(os.path.basename(k), v[0], v[1], v[2])
        if 'False' == v[0]:
            # subject = "Error Message"  
            is_success = False 
       
    searchInputTable += '</table>'

    if not is_success:
        searchInputTable = searchInputTable.replace("TABLE id=\"buildsuccess\"", "TABLE id=\"builderror\"")
 
    # 2 return values : 1. HTML formatted script execution details    
    #                 2. flag success / failure
    return (searchInputTable, is_success)
 
def generate(scripts_run_details):
 
    cssdata = open(parse_props.getCSSPath(), 'r').read()
 
    htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>""" + cssdata + "</style>"""
    
    (searchInputTable, is_success) = scripts_run_info(scripts_run_details)
    return (htmlHeader + searchInputTable, is_success)
 
def notifyEmail(scripts_run_details):
 
    successEmailFrom = 'SUCCESS-Fido.rbi.automation@lexisnexisrisk.com'
    errorEmailFrom  = 'ERROR-Fido.rbi.automation@lexisnexisrisk.com'
    errorEmailTo    = 'fidocoreteam@lexisnexisrisk.com'
    (msg, is_success) = generate(scripts_run_details)
    emailFrom = successEmailFrom if is_success else errorEmailFrom
    emailTo = errorEmailTo
    PlatformPrefix = commonArgs.getEnv() + ' :: '  
    subjectPrefix = ('Success :: ' if is_success else 'Error :: ') + PlatformPrefix
    subject = subjectPrefix + 'Weekly Release Scripts Executions - for {0}'.format(datetime.today().strftime('%Y-%m-%d'))
    
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com,sathishkumar.seenivasan@lexisnexisrisk.com', subject, msg)
    
def notifyRenameEmail(scripts_run_details):
 
    successEmailFrom = 'SUCCESS-Fido.rbi.automation@lexisnexisrisk.com'
    errorEmailFrom  = 'ERROR-Fido.rbi.automation@lexisnexisrisk.com'
    errorEmailTo    = 'fidocoreteam@lexisnexisrisk.com'
    (msg, is_success) = generate(scripts_run_details)
    emailFrom = successEmailFrom if is_success else errorEmailFrom
    emailTo = errorEmailTo
    PlatformPrefix = commonArgs.getEnv() + ' :: '  
    subjectPrefix = ('Success :: ' if is_success else 'Error :: ') + PlatformPrefix
    subject = subjectPrefix + 'Weekly Release Rename Executions - for {0}'.format(datetime.today().strftime('%Y-%m-%d'))
    
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com,sathishkumar.seenivasan@lexisnexisrisk.com', subject, msg)

def notifyScriptCreationEmail(scripts_run_details):
 
    successEmailFrom = 'SUCCESS-Fido.rbi.automation@lexisnexisrisk.com'
    errorEmailFrom  = 'ERROR-Fido.rbi.automation@lexisnexisrisk.com'
    errorEmailTo    = 'fidocoreteam@lexisnexisrisk.com'
    (msg, is_success) = generate(scripts_run_details)
    emailFrom = successEmailFrom if is_success else errorEmailFrom
    emailTo = errorEmailTo
    PlatformPrefix = commonArgs.getEnv() + ' :: '  
    subjectPrefix = ('Success :: ' if is_success else 'Error :: ') + PlatformPrefix
    subject = subjectPrefix + 'Weekly Release Scripts Creation - for {0}'.format(datetime.today().strftime('%Y-%m-%d'))
    
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com,sathishkumar.seenivasan@lexisnexisrisk.com', subject, msg)
