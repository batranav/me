import time
import datetime
import os
import parseYamlProperty
import AutomationLogging
import sys
import traceback
import commonArgs
import commonSourceInfo
import s3PushEmailAlert
import file_utils
import shutil
import fido_utils
import fnmatch
import re
import subprocess
import getkeepassdata

def getDestinationFiles(source, frequency, date):
    global rbiOutboundFiles
    global rbiOutboundAzureFiles
    rbiOutboundFiles = commonSourceInfo.getOutboundFilesAzure(source, frequency, date)
    rbiOutboundAzureFiles = commonSourceInfo.getOutboundAzureFiles(source, frequency, date)

def getOutboundRequiredAzureFiles(source, frequency, found):
    return [x for x in commonSourceInfo.getOutboundAzureFiles(source, frequency) if x.destination == source and x.frequency == frequency]

def getOutboundAzureRequiredFiles(source, frequency, found):
    return [x for x in commonSourceInfo.getOutboundFilesAzure(source, frequency) if x.destination == source and x.frequency == frequency]

def outbound_files(logger, source, frequency, date, env):

    global rbiInboundFiles
    global SFTPCallList
    global optionalFiles
    global requiredFiles
    global MissingRequiredFiles
    global ThreadPoolsize
    try:
        
        ThreadPoolsize = parseYamlProperty.get_threadpool_size(source, frequency)
        abort_after = 14400 #seconds
        sleep_time = 60

        timer_start = datetime.datetime.now().strftime('%Y%m%d%H%M%S')

        outboundFilesList = []
                
        requiredFiles = getOutboundAzureRequiredFiles(source, frequency, False)
        requiredAzureFiles = getOutboundRequiredAzureFiles(source, frequency, False) 

        required_azure_files_list = []
        MissingRequiredFiles = []

        for azurefileobject in requiredAzureFiles:
            azure_outgoing_folder = azurefileobject.relativedestinationFolder
            required_azure_files_list.append(azurefileobject.absFidoFileName)
            # s3_working_folder = s3_outgoing_folder + 'working/'  

        path = os.path.join(parseYamlProperty.get_outbound_dir(), 'azure', source)
        os_file_list = os.listdir(path)
        filter_file_type = "*{0}".format(requiredAzureFiles[0].fidoExtension)
        txt_only_list_all = fnmatch.filter(os_file_list, filter_file_type) 

        azcopy_path = parseYamlProperty.get_azcopypath(commonArgs.getSource())
        
        MissingRequiredFiles = getDeltas(required_azure_files_list, txt_only_list_all)
        requiredFilesCount = len(required_azure_files_list)
        missingRequiredFilesCount = len(MissingRequiredFiles)
             
        return(requiredFilesCount, missingRequiredFilesCount)
        
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        print('\nException raised Azure push : {0}\n'.format(str(e)))
        flag = 0

def getDeltas(x, y):
    return (list(set(x) - set(y)))

def push_Azure_files(logger, market, frequency, env):
    global MissingRequiredFiles
    try:
        # azure_outgoing_folder = commonSourceInfo.getAzureOutboundFolder(market, frequency)
        
        azure_folder_file_list = []
        azure_file_keys = []
        path = os.path.join(parseYamlProperty.get_outbound_dir(), 'azure', market)
        path_working = os.path.join(path, 'working')
        path_archive = os.path.join(os.path.join(path, 'archive'),commonArgs.getTimestamp())
        azcopy_path = parseYamlProperty.get_azcopypath(commonArgs.getSource())
        os_file_list = os.listdir(path)
        # txt_only_list = fnmatch.filter(os_file_list, '*.txt')
        requiredAzureFiles = commonSourceInfo.getOutboundRequiredAzureFiles(market, 'daily')

        requiredFiles = getOutboundAzureRequiredFiles(market, frequency, False)
        MissingRequiredFiles = []
                
        
        timing_list = [['FileName', 'Start_Time', 'End_Time', 'Compression_Time', 'Upload_Time', 'Total_Time_Taken']]
        time_format = '%Y-%m-%d %H:%M:%S'
        starttime = datetime.datetime.now().strftime(time_format)
        logger.debug('\n \nUploading ' + market + ' started \n')
        totalcompressionfiletdelta = datetime.timedelta(0)
        totaluploadfiletdelta = datetime.timedelta(0)
        filter_file_type = requiredAzureFiles[0].fidoExtension
        required_azure_files_list = []
        myuniquedests = set()
        for Azurefileobject in requiredAzureFiles:
            required_azure_files_list.append(Azurefileobject.absFidoFileName)
            azure_outgoing_folder = Azurefileobject.relativedestinationFolder
            myuniquedests.add(Azurefileobject.relativedestinationFolder)
            logger.debug(Azurefileobject)
            
            file_path = os.path.join(path, Azurefileobject.absFidoFileName)
            path_working_file = os.path.join(path_working, Azurefileobject.fileDate, Azurefileobject.absDestinationFileName)
            path_archive_file = os.path.join(path_archive, Azurefileobject.absFidoFileName)
            logger.debug('Azure upload initiated .....')
            Uploadfilestarttime = datetime.datetime.now().strftime(time_format)
            logger.debug('start time : ' + Uploadfilestarttime)

            azure_working_filename_account_url = "{0}{1}{2}{3}".format(azure_account_url_container, azure_outgoing_folder, Azurefileobject.absDestinationFileName, azure_sas_token)
            stdout = subprocess.run([azcopy_path, "copy", file_path, azure_working_filename_account_url], capture_output=True, text=True).stdout            
            logger.debug('Azure upload details : ' + stdout)
            Uploadfileendtime = datetime.datetime.now().strftime(time_format)
            logger.debug('end time : ' + Uploadfileendtime)
            Uploadfiletdelta = datetime.datetime.strptime(Uploadfileendtime, time_format) - datetime.datetime.strptime(Uploadfilestarttime, time_format)
            totaluploadfiletdelta = totaluploadfiletdelta + Uploadfiletdelta
            logger.debug('Upload completed in : {0}'.format(Uploadfiletdelta))
            
            logger.debug('archive initiated....')
            logger.debug('Compression initiated .....')
            compressionfilestarttime = datetime.datetime.now().strftime(time_format)
            logger.debug('start time : ' + compressionfilestarttime)
            file_utils.compressfilewith7z(path_archive_file.replace('.txt', '.7z').replace('.tsv', '.7z'), file_path)
            compressionfileendtime = datetime.datetime.now().strftime(time_format)
            logger.debug('end time : ' + compressionfileendtime)
            compressionfiletdelta = datetime.datetime.strptime(compressionfileendtime, time_format) - datetime.datetime.strptime(compressionfilestarttime, time_format)
            logger.debug('Compression completed in : {0}'.format(compressionfiletdelta))
            totalcompressionfiletdelta = totalcompressionfiletdelta + compressionfiletdelta
            totalfiletdelta = datetime.datetime.strptime(compressionfileendtime, time_format) - datetime.datetime.strptime(Uploadfilestarttime, time_format)
            logger.debug('Compress + Upload completed in : {0}'.format(totalfiletdelta))

            timing_list.append([Azurefileobject.absDestinationFileName, '{0}'.format(compressionfilestarttime) , '{0}'.format(Uploadfileendtime) , '{0}'.format(compressionfiletdelta) , '{0}'.format(Uploadfiletdelta) , '{0}'.format(totalfiletdelta)])
                        
            logger.debug('archive completed')
        # shutil.rmtree(path_working)
        endtime = datetime.datetime.now().strftime(time_format)
        tdelta = datetime.datetime.strptime(endtime, time_format) - datetime.datetime.strptime(starttime, time_format)
        timing_list.append(['Total Time', '{0}'.format(starttime) , '{0}'.format(endtime) , '{0}'.format(totalcompressionfiletdelta), '{0}'.format(totaluploadfiletdelta) , '{0}'.format(tdelta)])
        logger.debug('\n*************************************************************')        
        azure_working_folder_file_list =[] 
        for outgoingfolder in myuniquedests:
            azure_outgoing_folder = outgoingfolder.replace('//','/')
            azure_account_url = "{0}{1}{2}".format(azure_account_url_container, azure_outgoing_folder, azure_sas_token)
            stdout = subprocess.run([azcopy_path, "list", azure_account_url], capture_output=True, text=True).stdout
            date = commonArgs.getFiledate()
            market = commonArgs.getSource()
            if date == '':
                date  = datetime.datetime.now().strftime('%Y%m%d')
            regex_string = "info\s*\:\s*[\w]+?{0}\;".format(filter_file_type)
            replace_string = "_{0}|INFO:\s*|\;".format(date)
            replace_string_master_recon = "INFO:\s*|\;".format(date)
            if market == 'master_recon':
                azure_working_folder_file_list += [re.sub(replace_string_master_recon, '', sub) for sub in re.findall(regex_string, stdout, re.IGNORECASE)]
            else:
                azure_working_folder_file_list += [re.sub(replace_string, '', sub) for sub in re.findall(regex_string, stdout, re.IGNORECASE)]
        
        MissingRequiredFiles = getDeltas(required_azure_files_list, azure_working_folder_file_list)

        for f in timing_list:
            logger.debug(f)

        return timing_list   

    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        print('\nException raised Azure push : {0}\n'.format(str(e)))
        flag = 0

def process():
    args = commonArgs.parse()
    logger = AutomationLogging.getLogger('checkAndPushFiles_Azure')
    global azure_account_url_container
    global azure_sas_token
    azure_sas_token_path = parseYamlProperty.get_bdapkeepasspath(args.source)
    azure_keepass_list = getkeepassdata.getSourcekeepassinfo(logger, args.source, args.frequency)
    azure_sas_token_path_file_name = os.path.join(azure_sas_token_path, azure_keepass_list.keepassfilename)
    sas_url = fido_utils.get_sas_token(azure_sas_token_path_file_name, azure_keepass_list.password, azure_keepass_list.title)
    azure_sas_token = "".join(re.findall('\?[\w\W]+?$', sas_url))
    # azure_account_url_container = "".join(re.findall('[\w\W]+?\?', sas_url)).replace('?', '/')
    azure_account_url_container = "".join(re.findall('[\w\W]+?\?', sas_url)).replace('/?', '/').replace('?', '/')
    source = args.source
    frequency = args.frequency
    debug = args.debug
    date = args.date
    env = args.env   
    global requiredFiles   

    if not commonSourceInfo.hasOutboundFiles(source, frequency):
        logger.debug('No push files defined for {0} - {1}'.format(source, frequency))
        return

    logger.debug('Inside PushFiles Process')
    if date == '':
        date = datetime.datetime.now().strftime("%Y%m%d")

    logger.debug('Processing for {0}'.format(date))

    requiredFilesCount = 0
    missingRequiredFilesCount = 0

    [requiredFilesCount, missingRequiredFilesCount] = outbound_files(logger, source, frequency, date, env) 
    
    push_timings = []
    if len(commonSourceInfo.getOutboundAzureFiles(source, frequency, date)) > 0 and missingRequiredFilesCount == 0:
        push_timings = push_Azure_files(logger, source, frequency, env)
    requiredfiles_missing = []
    
    for f in requiredFiles:
        if f.absFidoFileName in MissingRequiredFiles:
            requiredfiles_missing.append(f)

    if missingRequiredFilesCount == 0:
        missingRequiredFilesCount = len(requiredfiles_missing)
    
    countDict = {}
    countDict['RequiredFilesCount'] = requiredFilesCount
    countDict['OptionalFilesCount'] = 0
    countDict['Missing-RequiredFilesCount'] = missingRequiredFilesCount
    countDict['Missing-OptionalFilesCount'] = 0

    if missingRequiredFilesCount  > 0 :
        s3PushEmailAlert.notifyEmail(debug, countDict, requiredfiles_missing, push_timings, len(MissingRequiredFiles) > 0 , ['destination','fileDate','frequency'], 'azure', args.application)
    else :
        s3PushEmailAlert.notifyEmail(debug, countDict, requiredFiles, push_timings, len(MissingRequiredFiles) > 0 , ['destination','fileDate','frequency'], 'azure', args.application)
if __name__ == "__main__":
    try:
        
        process()

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print("Error : ", processerrorMsg)   
        