import ecl_call_wrapper
import sys, argparse
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Call an ECL and wait Asynchronously to finish!')
    parser.add_argument('-i', '--inputecl', help='Input ECL Code to execute', required=True)
    args = parser.parse_args()
    print(args)
    print(args.inputecl)
    ecl_call_wrapper.invoke_ecl_by_filename(args.inputecl)