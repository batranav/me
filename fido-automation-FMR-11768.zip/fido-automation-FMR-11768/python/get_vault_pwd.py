import AutomationLogging
from commonArgs import getSource
from vault.secrets import get_api_secret

''' 
Script is built to return vault creds to terminal
Don't use outside of this case as script prints creds to console
Calling script should capture output such as >$pass = python .\get_vault_pwd.py
'''
logger = AutomationLogging.getLogger('get_vault_pwd', True)
source = getSource()
pwd = get_api_secret(logger, source, secret='pwd')
print(pwd)
