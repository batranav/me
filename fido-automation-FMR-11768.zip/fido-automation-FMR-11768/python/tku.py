import fido_utils, os
import parseYamlProperty

import xlrd
import csv

global folder_path
folder_path = os.path.join(parseYamlProperty.get_inbound_dir(), 'tku\\adhoc')

def csv_from_excel(filename, fileExtension):
    wb = xlrd.open_workbook(folder_path + '\\' + filename)
    sh = wb.sheet_by_index(0)
    your_csv_file = open(folder_path + '\\emp_' + filename.replace(fileExtension, '.txt'), 'w')
    wr = csv.writer(your_csv_file, quoting=csv.QUOTE_ALL)

    for rownum in range(sh.nrows):
        wr.writerow(sh.row_values(rownum))

    your_csv_file.close()


def main():
    
    results_excels = [filename for filename in os.listdir(folder_path) if filename.endswith(".xlsx") or filename.endswith(".xls")]
    for filename in results_excels:
        if filename.endswith(".xlsx"):
            csv_from_excel(filename, ".xlsx")
        elif filename.endswith(".xls"):
            csv_from_excel(filename, ".xls")

if __name__ == "__main__":
    main()