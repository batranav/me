import compileall

compileall.compile_dir('C:/red/scripts_all_apps/python/', force=True)