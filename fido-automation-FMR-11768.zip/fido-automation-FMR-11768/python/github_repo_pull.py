from send_email import *
import os
import traceback
import platform
from git import Repo
from datetime import datetime
from github import GithubIntegration   
import parseYamlProperty
import commonArgs
from pathlib import Path
import get_vault_ssh

dt = datetime.now().strftime('%Y%m%d%H%M%S%f')
dtstr = datetime.now().strftime('%m-%d-%Y_%H%M%S')
print(dtstr)

def removeRsaKey(rsa_key_path):
    '''remove temporary rsa key file at rsa_key_path if it exists'''
    print(f"removing RSA key at {rsa_key_path}")
    try:
        if os.path.exists(rsa_key_path):
            os.chmod(rsa_key_path, 0o700)
            os.remove(rsa_key_path)
            print(f"RSA Key removed at {rsa_key_path}")
        else:
            print(f"No RSA Key found at {rsa_key_path}")
    except Exception as e:
        print(f"Error while removing RSA key at {rsa_key_path}. Error: {e}")

def get_github_token(github_owner, github_repo, app_id):
    '''returns github api auth token for provided repo, app, and ssh auth key'''
    try:
        # getting ssh key to connect to github api
        get_vault_ssh.get_ssh_key()
        # read the temp ssh key file
        rsa_key_path = parseYamlProperty.get_github_rsa_key_path()
        with open(rsa_key_path, "r") as secret:
            priv_key = secret.read()
        # remove the temp key
        removeRsaKey(rsa_key_path)
        # instantiate the github app object
        app = GithubIntegration(app_id, priv_key)
        # instantiate the github installation object
        installation = app.get_installation(github_owner, github_repo)
        # return the github api token
        return app.get_access_token(installation.id).token
    except Exception as e:
        print(f"Error retrieving github token. Error: {e}")

def check_for_changes(repository):
    '''Check if there are any new commits on remote to be pulled'''
    try:
        # get the remote repo object
        remote = repository.remote()
        fetch_info = remote.fetch('master')

        # Ensure that we have fetched information
        if not fetch_info:
            print("Failed to fetch from remote.")
            return False
        
        # Since we're only fetching master, the first (and only) item in fetch_info will be for master
        remote_commit = fetch_info[0].commit

        # get the local repo commit
        local_commit = repository.head.commit

        # compare the two commits
        if remote_commit == local_commit:
            return False
        else:
            return True
    except Exception as e:
        print(f"Error checking for changes. Error: {e}")

def backup_repo(source_dir, dest_dir):
    '''copy repo to backup folder prior to pull'''
    print(f'Copying files from {source_dir} to backup dir: {dest_dir}')
    start = datetime.now()
    #dir_util.copy_tree(source_dir, dest_dir)
    #os.system(f'xcopy /E /I {source_dir} {dest_dir}')
    os.system(f'robocopy {source_dir} {dest_dir} /E /MT:8 > NUL 2>&1')
    print(f'Finished copy. Time elapsed: {datetime.now() - start}')

def pullRepo(repoName, gitToken, localRepoPath, owner, my_app, backup_repo_path):
    '''Pulls the repo using the provided token and local repo path'''
    try:
        # create the repo url with the token
        repo_url = f"https://x-access-token:{gitToken}@github.com/{owner}/{repoName}"
        # instantiate the local repo object
        _repo = Repo(localRepoPath)
        # Stash any changes
        _repo.git.stash('save')
        # Checkout to master
        _repo.git.checkout('master')
        # reset remote using the new token
        o = _repo.remotes.origin
        o.set_url(repo_url)
        if check_for_changes(_repo):
            # back up repo
            backup_repo(backup_repo_path, backup_repo_path + '_' + dt)
            # Pull in changes
            o.pull()
            returncode = "Repo pull Success"
        else:
            returncode = f"No changes detected for {repoName}. Aborting..."
        stash_list = _repo.git.stash('list')
        if stash_list:
            _repo.git.stash('clear')
        #     _repo.git.stash('pop')
        return returncode
    except Exception as e:
        print(f"Error during git Pull {localRepoPath}. Error: {e}")
        error_message = traceback.format_exc()
        sendMail(error_message, my_app)
        return False

def ensure_dir(directory):
    '''Create a directory if it doesn't already exist'''
    if not os.path.exists(directory):
        os.makedirs(directory)

def sendMail(body, app_name):
    servername = platform.node()
    EmailSubject = servername + "-- " + app_name + " GitHubPull - " + dt
    ErrorEmailSubject = "ERROR / WARNING : " + EmailSubject
    emailFrom = "fido-" + app_name + "-repo-gitpull.automation@lexisnexisrisk.com"
    emailTo = ['fido.operations@lexisnexisrisk.com']
    emailCC = ['raju.nagarajan@lexisnexisrisk.com', 'brandon.wood11@lexisnexisrisk.com']
    print("EmailTo -- {0}".format(emailTo))
    send_mail(emailFrom, emailTo, emailCC, ErrorEmailSubject, body)

def process():
    try:
        # globals
        global dt, my_app
        print(dt)
        my_source = commonArgs.getSource()
        if my_source == 'automation':
            my_app = my_source
            base_repo_path = str(Path(parseYamlProperty.get_base_script_dir()).resolve())
            backup_repo_path = base_repo_path

        else:
            my_app = commonArgs.getApplication()
            fido_folder_path = str(Path(parseYamlProperty.get_fido_dir()).resolve())
            backup_repo_path = fido_folder_path
            base_repo_path = str(Path(parseYamlProperty.get_src_dir()).resolve())

        # get github api token
        app_id = 137109 # GitHub App app-svc-fido-automation, #137109
        owner = "LexisNexis-RBA"  #os.getenv("GITHUB_OWNER")"
        repoName = 'fido-' + my_app
        token = get_github_token(owner, repoName, app_id)

        # stash any local changes and pull down updated code
        print("Pulling repo...")
        returncode = pullRepo(repoName, token, base_repo_path, owner, my_app, backup_repo_path)
        if returncode:
            print(returncode)
        else:
            print("Repo pull Failed")

        strReturnCode = str(returncode)
        print('Whats my return code -- {0}'.format(strReturnCode))

    except Exception:
        error_message = traceback.format_exc()
        sendMail(error_message, my_app)


if __name__ == "__main__":
    start_time = datetime.now()
    process()
    print(f'All Done! - Finished in {(datetime.now() - start_time)}')