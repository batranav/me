import requests
import json 
import pprint
from collections import OrderedDict
from requests.auth import HTTPBasicAuth
import AutomationLogging
from vault.secrets import get_api_secret

def getDictionaryData(dictionaryList) :
    strOut = ''
    counter = 0
    for dict in dictionaryList:
        for k, v in dict.items():
            if counter > 0:
                strOut += ','
            strOut += '{0}\n'.format(v.strip())
            counter += 1
    return strOut

def getInput(workunit):

        
    url = 'https://fido-prod.hpcc.risk.regn.net:18010/WsWorkunits/WUFullResult.json?Wuid=' + workunit # + '&ResultName=input'
    head = {'Content-type':'application/json; charset=UTF-8', 'Accept':'application/json'}
    print(url)

    logger = AutomationLogging.getLogger('alertWUResults', True)
    uname, pwd = get_api_secret(logger, 'hpccthor')
    ret = requests.post(url,auth=HTTPBasicAuth(uname, pwd))
    #print(ret.text)
    json1_data = json.loads(ret.text, object_pairs_hook=OrderedDict)
    #print(json1_data)
    json_dict = OrderedDict(json1_data['WUFullResultResponse']['Results']['Results']['VarianceDiff'])
    #print(json_dict)
    export_count = (getDictionaryData(json_dict['Row']))
    print(export_count)

if __name__ == "__main__":
    print(getInput('W20181108-190419'))
