from requests.auth import HTTPBasicAuth
import requests
import json
import csv
import sys
import datetime
import os
import array as arr
import sys, http.client, os, os.path
import xml.etree.ElementTree as ET
from send_email import *
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret
import commonArgs

today = datetime.date.today()
yr_mnth = today.strftime('%Y%m%d')

rep1 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2068990219@lexisnexis%27%29/Fields?'
rep2 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2068992724@lexisnexis%27%29/Fields?'
rep3 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2068994359@lexisnexis%27%29/Fields?'
rep4 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2068995044@lexisnexis%27%29/Fields?'
rep5 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2068995591@lexisnexis%27%29/Fields?'
rep6 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2069000661@lexisnexis%27%29/Fields?'
rep7 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2069001375@lexisnexis%27%29/Fields?'
rep8 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2069004997@lexisnexis%27%29/Fields?'
rep9 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2069006028@lexisnexis%27%29/Fields?'
rep10 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024367750@lexisnexis%27%29/Fields?'
rep11 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2035128481@lexisnexis%27%29/Fields?'
rep12 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024369448@lexisnexis%27%29/Fields?'
rep13 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2401617189@lexisnexis%27%29/Fields?'
rep14 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024369921@lexisnexis%27%29/Fields?'
rep15 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024370011@lexisnexis%27%29/Fields?'
rep16 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024370223@lexisnexis%27%29/Fields?'
rep17 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024371882@lexisnexis%27%29/Fields?'
rep18 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024372378@lexisnexis%27%29/Fields?'
rep19 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024386536@lexisnexis%27%29/Fields?'
rep20 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2038714059@lexisnexis%27%29/Fields?'
rep21 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2035120773@lexisnexis%27%29/Fields?'
rep22 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2042029506@lexisnexis%27%29/Fields?'
rep23 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2027210161@lexisnexis%27%29/Fields?'
rep24 = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource%20Planning__2024369110@lexisnexis%27%29/Fields?'

data_array = [['Resource_id', 'Date', 'Capacity_hours']]


def get_capacity(url):
    logger = AutomationLogging.getLogger('innotas_capacity_hours', True)
    uname, pwd = get_api_secret(logger, 'innotas')
    r = requests.get(url, auth=(uname, pwd))
    data_parsed = json.loads(r.text)
    values_parsed = data_parsed['value']

    for data in values_parsed:
        this_array = [data['Resource\nID'], data['Date'], data['Capacity\nHrs']]
        data_array.append(this_array)

error_email_list = ['stephen.rosser@lexisnexis.com']

try:
        get_capacity(rep1)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep1 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep1 Failed")
        sys.exit(1)
try:
        get_capacity(rep2)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep2 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep2 Failed")
        sys.exit(1)  
try:             
        get_capacity(rep3)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep3 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep3 Failed")
        sys.exit(1)
try:             
        get_capacity(rep4)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep4 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep4 Failed")
        sys.exit(1)
try:             
        get_capacity(rep5)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep5 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep5 failed")
        sys.exit(1)
try:             
        get_capacity(rep6)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep6 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep6 Failed")
        sys.exit(1)
try:
        get_capacity(rep7)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep7 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep7 Failed")
        sys.exit(1)
try:
        get_capacity(rep8)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep8 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep8 Failed")
        sys.exit(1)  
try:             
        get_capacity(rep9)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep9 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep9 Failed")
        sys.exit(1)
try:             
        get_capacity(rep10)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep10 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep10 Failed")
        sys.exit(1)
try:             
        get_capacity(rep11)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep11 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep11 Failed")
        sys.exit(1)
try:             
        get_capacity(rep12)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep12 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep12 Failed")
        sys.exit(1)
try:             
        get_capacity(rep13)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep13 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep13 Failed")
        sys.exit(1)
try:             
        get_capacity(rep14)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep14 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep14 Failed")
        sys.exit(1)
try:             
        get_capacity(rep15)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep15 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep15 Failed")
        sys.exit(1)                                                  
try:             
        get_capacity(rep16)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep16 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep16 Failed")
        sys.exit(1)
try:             
        get_capacity(rep17)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep17 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep17 Failed")
        sys.exit(1)
try:             
        get_capacity(rep18)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep18 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep18 failed")
        sys.exit(1)
try:             
        get_capacity(rep19)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep19 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep19 Failed")
        sys.exit(1)
try:
        get_capacity(rep20)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep20 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep20 Failed")
        sys.exit(1)
try:
        get_capacity(rep21)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep21 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep21 Failed")
        sys.exit(1)  
try:             
        get_capacity(rep22)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep22 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep22 Failed")
        sys.exit(1)
try:             
        get_capacity(rep23)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep23 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep23 Failed")
        sys.exit(1)
try:             
        get_capacity(rep24)
except:
        send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','ERROR -- Failed for Rep24 --  Innotas Capacity Load Failure on ' + yr_mnth,'')
        print("Rep24 Failed")
        sys.exit(1)

with open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_capacity_hours_' + yr_mnth + '.txt'), 'w') as f:

        for item in data_array:
                line = "{}\t{}\t{}\n".format(item[0], item[1], item[2])
                f.write(line)