import os
import shutil
from github import GithubIntegration
from git import Repo

def get_github_auth_token(github_owner, github_repo, app_id, sshkey_path):
    with open(sshkey_path, "r") as secret:
        priv_key = secret.read()
    app = GithubIntegration(app_id, priv_key)
    installation = app.get_installation(github_owner, github_repo)
    return app.get_access_token(installation.id).token

def process(github_owner, github_repo, app_id, sshkey_path, repo_local_path):
    if os.path.exists(repo_local_path):
        shutil.rmtree(repo_local_path)
    token = get_github_auth_token(github_owner, github_repo, app_id, sshkey_path)
    repo_url = f"https://x-access-token:{token}@github.com/{github_owner}/{github_repo}"
    Repo.clone_from(repo_url, repo_local_path)

if __name__ == '__main__':
    process(
        github_owner = "LexisNexis-RBA" , 
        github_repo = "fido-models", 
        app_id = 137109, 
        sshkey_path = "/home/centos/fido/github_prvkey.pem", 
        repo_local_path = "/home/centos/fido-models"
    )