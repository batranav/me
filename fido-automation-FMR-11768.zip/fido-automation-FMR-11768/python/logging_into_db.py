import pyodbc
# revisit
from commonSourceFiles import commonSourceFiles
from datetime import datetime
from sendEmail import *
import getSQLdata
import os
import AutomationLogging

sp_upsert_sql = """ EXECUTE [red].[dbo].[csp_upsert_automation_python_stats] ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?"""

def cleantext(txt):
    if txt.strip() == "":
        ret = "UA"
    else:
        ret = txt.strip()
    return ret

def format_datetime(txt):
    print('TXT is {0}, {1}'.format(txt, isinstance(txt, str)))

    if isinstance(txt, str):
        if txt.strip() in ['','UA','NA']:
            return txt.strip()
    else:
        df1 = datetime.strptime(str(txt), '%Y-%m-%d %H:%M:%S.%f')
        return datetime.strftime(df1, '%b %d %Y %H:%M%p')

def text_cnt(txt):
    if txt.strip() == "":
        ret = "0"
    else:
        ret = str(txt.count(','))
    return ret

def process(commonSourceFiles,run_date_time):
    try:
        sql = sp_upsert_sql
        logger = AutomationLogging.getLogger('preprocess_loggingintodb')
        (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, 'loggingintodb','','')
        conn = pyodbc.connect(connstr)
        conn.execute(sql,
                        run_date_time.strftime("%b-%d-%Y %H:%M:%S"),
                        run_date_time.strftime('%Y%m%d'),
                        cleantext(commonSourceFiles.workunit.upper()),
                        cleantext(commonSourceFiles.file_date),
                        cleantext(commonSourceFiles.source.upper()),
                        cleantext(commonSourceFiles.processtype.upper()), 
                        cleantext(commonSourceFiles.frequency.upper()),
                        format_datetime(commonSourceFiles.processStartTime),
                        format_datetime(commonSourceFiles.preProcessStartTime),
                        format_datetime(commonSourceFiles.preProcessEndTime),
                        format_datetime(commonSourceFiles.HPCCStartTime),
                        format_datetime(commonSourceFiles.HPCCEndTime),
                        format_datetime(commonSourceFiles.postProcessStartTime),
                        format_datetime(commonSourceFiles.postProcessEndTime),
                        format_datetime(commonSourceFiles.processEndTime),
                        cleantext(str(commonSourceFiles.status)),
                        cleantext(commonSourceFiles.workunitstatus.upper()),
                        cleantext(commonSourceFiles.workunitMsg.upper()),
                        cleantext(''.join(commonSourceFiles.list_of_expected_but_missing_files).upper()), 
                        text_cnt(''.join(commonSourceFiles.list_of_expected_but_missing_files)), 
                        cleantext(commonSourceFiles.processerrorMsg))
        conn.commit()
        conn.close()
        print('comment this after dev DB updgrade is done')
    except Exception as e:
        email_subject = 'SQL python logging error for source ' + cleantext(commonSourceFiles.source.upper()) + ' with frequency '+ cleantext(commonSourceFiles.frequency.upper()) + ' for file date '+ cleantext(commonSourceFiles.file_date)+ ' at log_date_timestamp '+ run_date_time.strftime("%b-%d-%Y %H:%M:%S")
        email_from    =  'gopala.rudraraju@lexisnexisrisk.com'
        email_to      = 'fidoinsproductmgmtsquad@lexisnexisrisk.com,fido.ops@lexisnexisrisk.com' 
        subject = 'ERROR : ' + email_subject
        send(email_from, email_to, '', subject, '' + '\n'.join(str(e)))
    finally:
        #conn.commit()
        #conn.close()
        print('logging is done')
        

    