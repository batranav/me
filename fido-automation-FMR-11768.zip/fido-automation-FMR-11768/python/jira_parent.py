from jira import JIRA
import json
import csv
from collections import defaultdict
from datetime import datetime, timedelta
import AutomationLogging
from vault.secrets import get_api_secret
#'project != EMPTY and updatedDate > startOfDay()'

def main():

	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_parent', True)
	uname, pwd = get_api_secret(logger, 'jira')
	jira = JIRA(options, basic_auth=(uname, pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		print('working')
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   updated >= -7d and updated <= 1d order by updated' , startidx, blocksize)
		#'project !=EMPTY and updatedDate >  startOfDay()'
		numissues=len(newissues)
		if  numissues==0 or  blocknum==100:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0	

	parentfile=open('parent' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	parentwriter=csv.writer(parentfile)
		
	for resultlist in issues:	
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
				
			fields=dict['fields']
			del dict['fields']
			fields['issue']=issueId
			
		if 'parent' in fields:
				parent = fields['parent']			
				#if parent is not None:				
				del fields['parent']							
			
		#if parent is not None:
				#del fields['parent']	
				#parent['issue']=issueId				
				if issuecount==0:
						parentwriter.writerow(parent.keys())	
				parentwriter.writerow(parent.values())						
				issuecount=issuecount+1
				
	parentfile.close()
	
if __name__== "__main__" :
     main()



