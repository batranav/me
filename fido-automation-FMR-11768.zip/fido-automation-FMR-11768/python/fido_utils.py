import gzip
import zlib
import re
import parseYamlProperty
import io
import os
import subprocess
from subprocess import Popen, PIPE
import platform
import time
import datetime
import shutil
from xml.dom import minidom
from os.path import isfile, join
from os import listdir
import math
import pathlib
from pathlib import Path
import sys
from send_email import *
from pykeepass import PyKeePass
from datetime import date, timedelta
import AutomationLogging
from vault.secrets import get_api_secret
# pylint: disable=E1101

base_script_dir = parseYamlProperty.get_base_script_dir()

github_email_from = 'raju.nagarajan@lexisnexis.com'
github_email_to = ['gopala.rudraraju@lexisnexis.com', 'raju.nagarajan@lexisnexis.com', 'jacob.pellock@lexisnexis.com', 'ed.dierker@lexisnexis.com', 'george.Triarhos@lexisnexis.com', 'Gerry.Green@lexisnexis.com']

''' DON'T MOVE THIS BLOCK -- Begin'''

def formatDate(dtDateTime, strFormat="%Y%m%d"):
    # format a datetime object as YYYY-MM-DD string and return
    return dtDateTime.strftime(strFormat)

def getToday():
    today = datetime.date.today()
    return (today.strftime("%Y%m%d"))

today = getToday()
''' DON'T MOVE THIS BLOCK -- End'''

''' DON'T MOVE THIS BLOCK -- Begin'''
def getTomorrow(dtDatetime = datetime.date.today()):
    one_day = datetime.timedelta(days=1)
    newDate = formatDate(dtDatetime + one_day)
    #print('TOMORRROW!!!!')
    return newDate

tomorrow = getTomorrow()
''' DON'T MOVE THIS BLOCK -- End'''

''' DON'T MOVE THIS BLOCK -- Begin'''
def getprevyrmonth(_today = ''):
    today = datetime.date.today() if _today == '' else _today 
    first = datetime.date(day=1, month=today.month, year=today.year)
    print(first)
    lastmonth = first - datetime.timedelta(days=1)
    return (lastmonth.strftime("%Y%m"))

def getBuildMonth(_today = ''):
    today = datetime.date.today() if _today == '' else _today
    print(today) 
    return getprevyrmonth(today) 
    # Always returns the last month based on today
    # today = datetime.date.today()
    # day = '{:02d}'.format(today.day)
    # if (day == '01'):
    #     return getprevyrmonth()
    # else:
    #     return getMonth()
buildmonth = getBuildMonth()
''' DON'T MOVE THIS BLOCK -- End'''

def getCurrentTimeStamp():
    st = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
    return st

def is_feed_file_non_empty(path):
    f = open(path, 'rb')
    buf_size = 1024 * 1024
    read_f = f.raw.read
    buf = read_f(buf_size)
    if(buf.count(b'\n') > 1):
        return True
    else:
        return False

def removeUnpackFiles(sourcefile):
    if os.path.exists(sourcefile):
        os.remove(sourcefile)

def getWUErrorMessage(workunit):
    wuErroLog = os.path.join(parseYamlProperty.get_wu_logs_dir(), workunit + '.wuinfo')
    server = '10.194.93.3'
    logger = AutomationLogging.getLogger('preprocess_fido_utils')
    uname, pwd = get_api_secret(logger, 'hpccthor')
    p = Popen(['eclplus', 'action=view', 'format=xml', 'wuid=' + workunit, 'server=' + server, 'user=' + uname,
               'password=' + pwd, 'output=' + wuErroLog], stdout=PIPE, stderr=PIPE)

    output, errors = p.communicate()
    wuMsg = ''
    if p.returncode == 1:
        # doc = minidom.parse("C:\\temp\\testerror.xml")
        with open(wuErroLog, 'r') as myfile:
            data = '<root>' + myfile.read().replace('\n', '') + '</root>'
            doc = minidom.parseString(data)
            wuMsg = ''
            errors = doc.getElementsByTagName('Error')
            # print(errors)
            for error in errors:
                code = error.getElementsByTagName('code')[0].firstChild.data
                message = error.getElementsByTagName('message')[0].firstChild.data
                wuMsg = wuMsg + '''Code {0} Message {1}'''.format(code, message)
                # print(wuMsg)
    return wuMsg

def removeFiles(folder):
    shutil.rmtree(folder)

def compressFolderPattern(archiveFile, sourcefolder, pattern):
    p = Popen([parseYamlProperty.get_winrarpath(), "a", "-m5", "-ed", "-ep1", archiveFile, sourcefolder + "\\*" + pattern + "*.*"], shell=True, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    return p.returncode

def compressFolder(archiveFile, sourcefolder):
    p = Popen([parseYamlProperty.get_winrarpath(), "a", "-m5", "-ed", "-ep1", archiveFile, sourcefolder + "\\*"], shell=True, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    return p.returncode
    # if p.returncode == 0:
        # removeFiles(sourcefolder)

def file_base_name(file_name):
    if '.' in file_name:
        separator_index = file_name.index('.')
        base_name = file_name[:separator_index]
        return base_name
    else:
        return file_name

def path_base_name(path):
    file_name = os.path.basename(path)
    return file_base_name(file_name)
   
def safeMoveFiles(folder, filename):

    if not os.access(folder, os.F_OK):
        os.mkdir(folder)  
    
    print ('In safeMovefiles...{0} ... {1}'.format(folder, filename))
    basename = os.path.basename(filename)
    absfilename = folder + '\\' + basename
    try:
        os.remove(absfilename)
    except OSError:
        pass
    shutil.move(filename, folder)

def getMonth():
    today = datetime.date.today()
    return (today.strftime("%Y%m"))

def getPreviousWeekStartDate(numberOfWeeks=1, fromDate = today):
    dt = datetime.datetime.strptime(fromDate, '%Y%m%d') - datetime.timedelta(days=7*numberOfWeeks)
    print(dt)
    start = dt - datetime.timedelta(days=dt.weekday())
    end = start + datetime.timedelta(days=6)
    print(start)
    print(end)



def mkDateTime(dateString, strFormat="%Y%m%d"):
    eSeconds = time.mktime(time.strptime(dateString, strFormat))
    return datetime.datetime.fromtimestamp(eSeconds)

def getTodayTS():
    return datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

def getYesterday(dtDatetime = datetime.date.today()):
    one_day = datetime.timedelta(days=1)
    return formatDate(dtDatetime - one_day)

def getLastDayOfMonth(dtDateTimeStr):
    dtDateTime = mkDateTime(dtDateTimeStr)
    dYear = dtDateTime.strftime("%Y")  # get the year
    dMonth = str(int(dtDateTime.strftime("%m")) % 12 + 1)  # get next month, watch rollover
    dDay = "1"  # first day of next month
    nextMonth = mkDateTime("%s%s%s" % (dYear, dMonth, dDay))  # make a datetime obj for 1st of next month
    delta = datetime.timedelta(seconds=1)  # create a delta of 1 second
    return formatDate(nextMonth - delta)  # subtract from nextMonth and return

def convert_timedelta(duration):
    days = duration.days
    hours = (duration.seconds // 3600) % 24
    minutes = (duration.seconds // 60) % 60
    seconds = duration.seconds % 60
    
    days_str = ''
    hours_str = ''
    minutes_str = ''
    seconds_str = ''
    
    if days > 0:
        days_str = str(days) + ' day' + 's' if days != 1 else ''
    if hours > 0:
        hours_str = str(hours) + ' hour' + 's' if hours != 1 else ''
    if minutes > 0:
        minutes_str = str(minutes) + ' minute' + 's' if minutes != 1 else ''
    if seconds > 0:
        seconds_str = str(seconds) + ' seconds'
                  
    return days_str + ' ' + hours_str + ' ' + minutes_str + ' ' + seconds_str

def deCompressFile(compressedFileName):
    uncompressedFileName = compressedFileName[:compressedFileName.index('.gz')]
    decompress(compressedFileName, uncompressedFileName)
    return uncompressedFileName
    # for line in io.BufferedReader(gzip.open(compressedFileName)):
        

def decompress_zlib(compressedFileName, uncompressedFileName):
      # decompressor = zlib.decompressobj(16+zlib.MAX_WBITS)
    print('Decompressing .. {0}'.format(compressedFileName))
    decompressor = zlib.decompressobj()
    compressedFile = open(compressedFileName, 'rb')
    buffer = compressedFile.read(512)
    uncompressedFile = open(uncompressedFileName, 'wb')
    while buffer:
       uncompressedData = decompressor.decompress(buffer)
       uncompressedFile.write(uncompressedData)
       buffer = compressedFile.read(512)
       decompressor.flush()
    uncompressedFile.close()
    compressedFile.close()

def decompress_2(compressedFileName, uncompressedFileName):
    compressedFile = gzip.open(compressedFileName, 'rb')
    uncompressedFile = open(uncompressedFileName, 'wb')
    try:
        uncompressedFile.write(compressedFile.read())
    finally:
        compressedFile.close()
        uncompressedFile.close()

def decompressToFolder(compressedFileName, folderToUncompress, renameUncompressedFileName):
    print(folderToUncompress)
    p = Popen([parseYamlProperty.get_winrarpath(), "-o+", "x", compressedFileName, folderToUncompress], shell=True, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    compressedFile = os.path.split(compressedFileName)
    uncompressedFolder = os.path.dirname(renameUncompressedFileName)
    uncompressedFileName = uncompressedFolder + "\\" + compressedFile[1].replace(".gz", "") 
    print('Compressed File {0}'.format(compressedFile))
    print('Uncompressed Folder {0}'.format(uncompressedFolder))
    print('CompressedFileName ..{0}'.format(compressedFileName))
    print('UncompressedFileName .. {0}'.format(uncompressedFileName))
    print('Rename UncompressedFileName .. {0}'.format(renameUncompressedFileName))
    if p.returncode == 0:
            os.replace(uncompressedFileName, renameUncompressedFileName)
            
def decompress(compressedFileName, uncompressedFileName):
    folderToUncompress = os.path.dirname(compressedFileName)
    print(folderToUncompress)
    p = Popen([parseYamlProperty.get_winrarpath(), "-o+", "x", compressedFileName, folderToUncompress], shell=True, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    print('CompressedFileName ..{0}'.format(compressedFileName))
    print('UncompressedFileName .. {0}'.format(uncompressedFileName))
    if p.returncode == 0:
        if compressedFileName.endswith('.gz'):
            os.rename(os.path.splitext(compressedFileName)[0], uncompressedFileName)

'''def compress(fileName, compressedFileName):
      data = open(fileName, 'rb').read()
      compressor = zlib.compress(data, zlib.Z_BEST_COMPRESSION)
      compressedFile = open(compressedFileName, 'wb')
      compressedFile.write(compressor)
'''
def compress(fileName, compressedFileName):
      f_in = open(fileName, 'rb')
      f_out = gzip.open(compressedFileName, 'wb')
      f_out.writelines(f_in)
      f_out.close()
      f_in.close()

def getDateStr(dateStr):
    if dateStr != '':
       return '_' + dateStr
    else:
       return dateStr

def compare_string_lists(list1, list2):
    '''Compare two lists of strings. Ignore order, spaces and case.'''
    clean1 = sorted(x.strip().lower() for x in list1)
    clean2 = sorted(x.strip().lower() for x in list2)
    return clean1 == clean2
	
def getWorkUnit(source, dateStr):
    logfileName = base_script_dir + 'logs\\' + source + getDateStr(dateStr) + '.ecllog'
    logfile = open(logfileName.strip(), 'r')
    for line in logfile:
        if 'workunit' in line.lower():
            return line
    return 'No WorkUnit found!'

def getError(source, dateStr):
    logfileName = base_script_dir + 'logs\\' + source + getDateStr(dateStr) + '.ecllog'
    logfile = open(logfileName.strip(), 'r')
    errorList = []
    for line in logfile:
        if 'error' in line.lower():
            errorList.append(line + '\n')
    return ''.join(errorList)

def getGitStatusLog(gitstatusfilename):
    errorList = []
    logfile = open(gitstatusfilename.strip(), 'r')
    for line in logfile:
        print (line)
        errorList.append(line + '\n')
    return errorList

def moveUnExpectedFilesByPattern(folder, filenamePattern, unexpectedDirPath):
    print('In MoveUnExpectedFilesByPattern {0}, {1}'.format(folder, filenamePattern))
    for f in os.listdir(folder):
        if re.search(filenamePattern, f, re.IGNORECASE):
            filename = os.path.join(folder, f)
            unexpectedFileName = os.path.join(unexpectedDirPath, f)
            print(filename)
            print(unexpectedFileName)
            if os.path.exists(unexpectedFileName):
                os.remove(unexpectedFileName)
            shutil.move(filename, unexpectedDirPath)
            print('Moving file {0}'.format(filename))
            
def removeFilesByPattern(folder, filenamePattern):
    print('In removeFilesByPattern {0}, {1}'.format(folder, filenamePattern))
    for f in os.listdir(folder):
        if re.search(filenamePattern, f, re.IGNORECASE):
            filename = os.path.join(folder, f)
            os.remove(filename)
            print('Removing file {0}'.format(filename))


def getWUStatus(source, dateStr):
    logfileName = base_script_dir + 'logs\\' + source + getDateStr(dateStr) + '.ecllog'
    logfile = open(logfileName.strip(), 'r')
    for line in logfile:
        if '<error>' in line.lower():
            return False
    return True

def format_timedelta(value, time_format="{days} days, {hours2}:{minutes2}:{seconds2}"):

    if hasattr(value, 'seconds'):
        seconds = value.seconds + value.days * 24 * 3600
    else:
        seconds = int(value)

    seconds_total = seconds

    minutes = int(math.floor(seconds / 60))
    minutes_total = minutes
    seconds -= minutes * 60

    hours = int(math.floor(minutes / 60))
    hours_total = hours
    minutes -= hours * 60

    days = int(math.floor(hours / 24))
    days_total = days
    hours -= days * 24

    years = int(math.floor(days / 365))
    years_total = years
    days -= years * 365

    return time_format.format(**{
        'seconds': seconds,
        'seconds2': str(seconds).zfill(2),
        'minutes': minutes,
        'minutes2': str(minutes).zfill(2),
        'hours': hours,
        'hours2': str(hours).zfill(2),
        'days': days,
        'years': years,
        'seconds_total': seconds_total,
        'minutes_total': minutes_total,
        'hours_total': hours_total,
        'days_total': days_total,
        'years_total': years_total,
    })

def elapsedTime(newerDt, olderDt):
    if not newerDt:
        newerDt = datetime.datetime.now()
    if not olderDt:
        olderDt = datetime.datetime.now()

    newerDtFormatted = newerDt.strftime('%Y-%m-%d %H:%M:%S')
    OlderDtFormatted = olderDt.strftime('%Y-%m-%d %H:%M:%S')
    date_format = "%Y-%m-%d %H:%M:%S"
    a = datetime.datetime.strptime(str(OlderDtFormatted), date_format)
    b = datetime.datetime.strptime(str(newerDtFormatted), date_format)
    c = b - a
    return format_timedelta(c, '{hours_total}:{minutes2}:{seconds2}')

def dayName():
    return datetime.datetime.today().strftime('%A')

# revisit - waitForFile in prepsrcfiles.py
 
def checkFiles(file_path, filename):
    directory = Path(file_path)
    for i in range(len(filename)):
        file_to_find = directory / filename[i]
        print("This file {0}".format(file_to_find))
        file_found = file_to_find.exists()
        print("Status{0}".format(file_found))
        if(not file_found):
            break
    return file_found, file_to_find

def sendEmailNotification(message, file_to_find, sourceInfo):
    servername = platform.node()
    EmailSubject = servername + '-- Files for -- '+ sourceInfo.source + ', ' + sourceInfo.frequency + ', ' + sourceInfo.filedate + ' -- not present -- ' + getCurrentTimeStamp() 
    if(message == 'Warning'):
        ErrorEmailSubject = '  WARNING : ' + EmailSubject
    elif(message == 'Error'):
        ErrorEmailSubject = '  ERROR : ' + EmailSubject
    
    emailFrom = 'FIDO@risk.lexisnexis.com'
    emailTo = ['FIDOCoreTeam@lexisnexisrisk.com']

    emailBody = 'Source:\t\t' + sourceInfo.source + '\n\nFrequency:\t' + sourceInfo.frequency + '\n\n' + file_to_find + '\n'
    send_mail(emailFrom,emailTo,[], ErrorEmailSubject, emailBody)

def get_sas_token(keepasspath, keepasspassword, title):
    kp = PyKeePass(keepasspath, password= keepasspassword)
    title_password =kp.find_entries(title=title, first=True).password
    return title_password

def get_start_end_date_list(arg_start_date, arg_end_date):
    start_date = date(int(arg_start_date[0:4]), int(arg_start_date[4:6]), int(arg_start_date[6:8]))
    end_date = date(int(arg_end_date[0:4]), int(arg_end_date[4:6]), int(arg_end_date[6:8]))

    delta = timedelta(days=1)
    date_list = []
    while start_date <= end_date:
        date_list.append(start_date.strftime("%Y%m%d"))
        start_date += delta

    return date_list

def unpack(sourcefile, uncompressedfilename):
    with gzip.open(sourcefile, 'rb') as f_in:
        with open(uncompressedfilename, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out, length=16*1024*1024)

    if os.path.exists(sourcefile):
        os.remove(sourcefile)
    
    f_in.close()
    f_out.close()
    #return f_out


# An object that behaves like a function, since it has a "__call__" method.
class SortDate(object):

    def __init__(self, pattern):
        self.pattern = pattern

    def __call__(self, file_name):
        match = re.match(self.pattern, file_name, re.I)
        (prefix, date) = match.group(1, 2)
        print('For "{0}", key = ("{1}", "{2}")'.format(file_name, date, prefix))
        return (date, prefix)

if __name__ == '__main__':
    print(getBuildMonth())
    print(tomorrow)
