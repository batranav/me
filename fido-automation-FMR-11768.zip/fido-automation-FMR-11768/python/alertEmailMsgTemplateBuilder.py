import sendEmail
import parseYamlProperty
import fido_utils
import commonArgs
import generateBuildNotification
import parseYamlProperty as parse_props
def xstr(s):
    return "" if s is None else str(s)

def generateemailmsg(countDict, exportSearchList, headerfields, tablefields):

    cssdata = open(parseYamlProperty.getCSSPath(), "r").read()

    htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>""" + cssdata + "</style>"""

    maindetails = """ <TABLE id="pull"> """ 

    lines = ""
    lines += """<table id="buildsuccess">
                        <tr>
                        <th># of Expected Files</th>
                        <th># of Optional Files</th>
                        <th># of Missing Files</th>
                        <th># of Missing(Expected) Files</th>
                        <th># of Missing(Optional) Files</th>
                        </tr>"""
    lines += "<td>" +  xstr(countDict["RequiredFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["OptionalFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["Missing-OptionalFilesCount"] + countDict["Missing-RequiredFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["Missing-RequiredFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["Missing-OptionalFilesCount"]) + "</td>"
    lines += "</tr></TABLE>"

    for x in  headerfields:
        maindetails += "<tr><th>"+ x + "</th><td>" + xstr(getattr(exportSearchList[0], x)) + "</td></tr>"
    maindetails += """ </TABLE> """ + lines

    searchDataRow = ""

    searchTable = maindetails + """ <TABLE id="pull"> """  + """
                            <tr> """

    for y in  tablefields:                        
        searchTable += "<th>" + y + "</th>"

    searchTable += """</tr> """
    
    for exportSearch in exportSearchList:
        searchDataRow += " <tr> " 
        for y in  tablefields: 
            #print(xstr(getattr(exportSearch, y)))
            #print(getattr(exportSearch, y))
            searchDataRow +=  " <td> " + xstr(getattr(exportSearch, y)) + " </td> " 
        searchDataRow += " </tr> "

    if exportSearchList:
        searchDataRow += "</TABLE>"
        return (htmlHeader + searchTable + searchDataRow)
    else: 
        return htmlHeader + "<table><tr><td>No Data exported</td></tr></table>"

def notifyEmail(debug, countDict, ssFiles, MissingRequiredFiles, headerfieldsList="", tablefieldsList=""):
    if len(ssFiles) == 0 or tablefieldsList == "":
        return None
    if(parseYamlProperty.get_notify_source_on_file_missing(commonArgs.getSource())):
        generateBuildNotification.special_email_missing_files( MissingRequiredFiles)

    successEmailFrom = "SUCESS-Fido."+ commonArgs.getApplication() + ".automation@lexisnexisrisk.com"
    errorEmailFrom  = "ERROR-Fido."+ commonArgs.getApplication() + ".automation@lexisnexisrisk.com"

    PlatformPrefix = parseYamlProperty.getPlatform() + " :: " 
    actionFailed = len(MissingRequiredFiles) > 0
    if actionFailed:
        subjectPrefix =  parse_props.getHostName() + "Error ::" 
        emailFrom = errorEmailFrom
        emailTo = ",".join(parseYamlProperty.get_error_cc_email(ssFiles[0].source))
    else:
        subjectPrefix = parse_props.getHostName() + "Success :: "
        emailFrom = successEmailFrom
        emailTo = ",".join(parseYamlProperty.get_success_email(ssFiles[0].source)) 

    if debug:
        emailTo = "raju.nagarajan@lexisnexisrisk.com,raja.sundarrajan@lexisnexis.com"
        emailFrom = "debug-fido@lexisnexisrisk.com"

    subject = subjectPrefix + PlatformPrefix + commonArgs.getApplication() + " Pull for " + ssFiles[0].source + "-" + ssFiles[0].frequency + "-" + ssFiles[0].fileDate
    msg = generateemailmsg(countDict, ssFiles, headerfieldsList, tablefieldsList)
    sendEmail.send(emailFrom, emailTo, "raju.nagarajan@lexisnexis.com", subject, msg)  
    print("Printing in NotifyEmail {0}".format(ssFiles))
