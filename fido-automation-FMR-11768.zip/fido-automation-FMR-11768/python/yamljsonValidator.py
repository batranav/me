import json
import yaml
import parseYamlProperty, getProperties
import os
def json_validator(datafile):
    try:
        if os.path.exists(datafile):
            json_data = str(json.load(open(datafile)))
        return True
    except Exception as ex:
        print("invalid jsonn: {0} - failed for - {1}".format(datafile, ex))
        return False

def yaml_validator(datafile):
    try:
        if os.path.exists(datafile):
            yaml_data = parseYamlProperty.parse_config(datafile)
        return True
    except Exception as ex:
        print("invalid yaml: {0} - failed for - {1}".format(datafile, ex))
        return False

if __name__ == "__main__":
    #global sourceInfo
    try:
        json_file_name = getProperties.getJsonFilename()
        ftp_json_file_name = getProperties.getFTPJsonFilename()
        yaml_file_name = getProperties.getYamlFilename()
        sql_json_file_name  = getProperties.getSQLJsonFilename()
        sql_cred_json_file_name = getProperties.getSQL_credJsonFilename()
        keepass_json_file_name = getProperties.getKeepassJsonFilename()
        keepass_cred_json_file_name = getProperties.getKeepass_credJsonFilename()
        is_json_valid = json_validator(json_file_name)             
        is_yaml_valid = yaml_validator(yaml_file_name)
        is_ftp_json_valid = json_validator(ftp_json_file_name)
        is_sql_json_file_valid = json_validator(sql_json_file_name)
        is_sql_cred_json_file_valid = json_validator(sql_cred_json_file_name)
        is_keepass_json_file_valid = json_validator(keepass_json_file_name)
        is_keepass_cred_json_file_valid = json_validator(keepass_cred_json_file_name)
        
        if is_json_valid and is_yaml_valid and is_ftp_json_valid and is_sql_json_file_valid and is_sql_cred_json_file_valid and is_keepass_json_file_valid and is_keepass_cred_json_file_valid:
            print('Congratulations!!! All config files are good')
            print(json_file_name)
            print(yaml_file_name)
            print(ftp_json_file_name)
            print(sql_json_file_name)
            print(sql_cred_json_file_name)
            print(keepass_json_file_name)
            print(keepass_cred_json_file_name)
            exit(0)
        else:
            exit(1)
    except Exception as valErr:
        print('The config files are not correct, Please check... {0}'.format(valErr))
