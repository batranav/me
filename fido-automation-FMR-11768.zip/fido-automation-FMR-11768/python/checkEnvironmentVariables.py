import os, sys

def validate_variables():



    if os.environ.get('RED_automation_appname') is None or os.path.isdir(os.environ.get('RED_automation_appname')) != True:
        print('Environment variable RED_automation_appname is not created')
        raise Exception('Environment variable RED_automation_appname is not created')

    if os.environ.get('FIDO_automation_scripts') is None or os.path.isdir(os.environ.get('FIDO_automation_scripts')) != True:
        print('Environment variable FIDO_automation_scripts is not created')
        raise Exception('Environment variable FIDO_automation_scripts is not created')

    if os.environ.get('RED_automation_Cdrive') is None or os.path.isdir(os.environ.get('RED_automation_Cdrive')) != True:
        print('Environment variable RED_automation_Cdrive is not created')
        raise Exception('Environment variable RED_automation_Cdrive is not created')

    if os.environ.get('RBI_automation_appname') is None or os.path.isdir(os.environ.get('RBI_automation_appname')) != True:
        print('Environment variable RBI_automation_appname is not created')
        raise Exception('Environment variable RBI_automation_appname is not created')

    if os.environ.get('RBI_automation_Cdrive') is None or os.path.isdir(os.environ.get('RBI_automation_Cdrive')) != True:
        print('Environment variable RBI_automation_Cdrive is not created')
        raise Exception('Environment variable RBI_automation_Cdrive is not created')

    if os.environ.get('SCOUT_automation_Cdrive') is None or os.path.isdir(os.environ.get('SCOUT_automation_Cdrive')) != True:
        print('Environment variable SCOUT_automation_Cdrive is not created')
        raise Exception('Environment variable SCOUT_automation_Cdrive is not created')

    if os.environ.get('SCOUT_automation_appname') is None or os.path.isdir(os.environ.get('SCOUT_automation_appname')) != True:
        print('Environment variable SCOUT_automation_appname is not created')
        raise Exception('Environment variable SCOUT_automation_appname is not created')

    if os.environ.get('FIDO_automation_apps') is None or os.path.isdir(os.environ.get('FIDO_automation_apps')) != True:
        print('Environment variable FIDO_automation_apps is not created')
        raise Exception('Environment variable FIDO_automation_apps is not created')

    if os.environ.get('FIDO_automation_generated_scripts') is None or os.path.isdir(os.environ.get('FIDO_automation_generated_scripts')) != True:
        print('Environment variable FIDO_automation_generated_scripts is not created')
        raise Exception('Environment variable FIDO_automation_generated_scripts is not created')

    print('All the environment variables are available')

    return

if __name__ == "__main__":
    validate_variables()
