import os
import json
import time
import shutil
import random
import warnings
import sqlalchemy
import getSQLdata
import commonArgs
import numpy as np
import pandas as pd
import urllib.parse
import datetime as dt
import runSourceBuilds
import parseYamlProperty

from fido_utils import *
from string import Template
from datetime import datetime
from vault.secrets import get_api_secret
from AutomationLogging import getLogger
from getProperties import getPropertyDir
from distutils.command.build import build
from manual_load_validation import Validation
from multiprocessing.dummy import Pool as ThreadPool
from manual_load_send_email import send_mail, send_to_teams_channel, send_mail_with_table

# Set up program - get global variables and setting i.e. todaysdate, env, host, landing zones
global engine, logger, file_count
global debug_log, report_df, values_df

# program_timestamp = datetime.fromisoformat('2023-07-13 18:18:48').strftime('%Y-%m-%d %H:%M:%S') # for testing purposes
program_timestamp = getCurrentTimeStamp()
email_timestamp   = formatDate(datetime.fromisoformat(program_timestamp), "%m/%d/%Y %I:%M %p")
process_timestamp = formatDate(datetime.fromisoformat(program_timestamp), "%Y%m%d%H%M%S")
working_timestamp = formatDate(datetime.fromisoformat(program_timestamp), "%Y%m%d_%H%M%S")

debug_log = report_df = values_df = pd.DataFrame()
logger = getLogger('main')
logger.debug("Running set up")

#app, env and freq
env  = commonArgs.getEnv()
app  = commonArgs.getApplication()
freq = commonArgs.getFrequency()

# vault secrets
teams_webhook_path = get_api_secret(logger, f"manual_load_{env if env == 'dev' else 'user'}_webhook_path", secret='pwd')
admin = get_api_secret(logger, 'hpccthor', secret='uname')

# Subject environment
env_subj = f"{ env.upper() + ' :: ' if env == 'dev' else ''}{app.upper()} :: "

#json configuration file 
json_file_path = getPropertyDir() + f'\\{app}_manual_load_config.json'

with open(json_file_path, 'r') as json_file:
    data = json.load(json_file)

validations = dict(data["validations"])
communications = dict(data["communications"])
current_templates = list(data["current_templates"])
hpcc_configurations = dict(data["hpcc_configurations"])

#current envirmant path files
outbound_manual = parseYamlProperty.get_outbound_dir() + 'manual\\'
inbound_forcast = parseYamlProperty.get_inbound_dir() + 'forecast\\'
inbound_manual_adhoc = parseYamlProperty.get_inbound_dir() + 'manual\\adhoc\\'
manual_adjustment = parseYamlProperty.get_inbound_dir() + 'manual_adjustment\\'
report_template = parseYamlProperty.get_base_dir() + '\python\manual_load_template_report.html'

# Landing zones and archives
source_file_archive = manual_adjustment + 'archive\\'
hpcc_landing_zone = inbound_manual_adhoc + 'working\\'
inbound_forcast_working = inbound_forcast + 'working\\'
inbound_forcast_adhoc = inbound_forcast + 'adhoc\\working\\'
hpcc_landing_zone_archive = inbound_manual_adhoc + 'archive\\'
inbound_forcast_archive = inbound_forcast_working + 'Archive\\'
hpcc_outbound_landing_zone_archive = outbound_manual + 'archive\\'

# Source file folders
drop_zone_folder_paths = [manual_adjustment + v for _,v in dict(communications["drop_zone_folders"]).items()]

#database connection string
connection_string = getSQLdata.getSourcePullInfo(logger, "fido_dev" if env=='dev' else "fido_prod", "daily", "trial")
if app.upper() == "RBI":   
    modified_conn_string = str(connection_string[0]).replace("DEV_SQl_DB_CRED", "rbi").replace("PROD_SQl_DB_CRED", "rbi")
    modified_conn_string = modified_conn_string.replace("ALAWDREDSQL201", "alawdredsql201.risk.regn.net,50255")
    modified_conn_string = modified_conn_string.replace("ALAWPREDSQLCL1\SQLPRD01", "ALAWPREDSQLCL1\\SQLPRD01,50750")
    connection_uri = f"mssql+pyodbc://?odbc_connect={urllib.parse.quote_plus(''.join(modified_conn_string))}"
else:
    connection_string = getSQLdata.getSourcePullInfo(logger, "fido_dev" if env=='dev' else "fido_prod", "daily", "trial")
    connection_uri = f"mssql+pyodbc://?odbc_connect={urllib.parse.quote_plus(''.join(connection_string))}" 
engine = sqlalchemy.create_engine(connection_uri, fast_executemany=True)

file_count = 0

def pre_setup_check():
    '''
    pre_setup_check
        Function that creates archive parent folders if they don't exist. Checks the existing landing zones 
        in the inbound forecast folder, manual folder and the current working folder in the 
        manual adjustment folder to see if they have any files from previous session to 
        prevent double date from being re-processed.
    '''
    write_to_log("Running pre-setup check")
    if not os.path.isdir(hpcc_landing_zone):
        os.makedirs(hpcc_landing_zone)
    if not os.path.isdir(source_file_archive):
        os.makedirs(source_file_archive)
    if not os.path.isdir(hpcc_landing_zone_archive):
        os.makedirs(hpcc_landing_zone_archive)
    if not os.path.isdir(hpcc_outbound_landing_zone_archive):
        os.makedirs(hpcc_outbound_landing_zone_archive)

    try:
        if os.path.isdir(hpcc_landing_zone + today + '\\'):
            t_files = os.listdir(hpcc_landing_zone + today + '\\')
            if len(t_files) >= 1:
                for t_file in t_files:
                    t = t_file.rstrip(f'{today}.txt').rstrip("_")
                    if t in hpcc_configurations:
                        if os.path.exists(hpcc_landing_zone + today + '\\' + t_file):
                            os.remove(hpcc_landing_zone + today + '\\' + t_file)

        if os.path.isdir(inbound_forcast_adhoc + today + '\\'):
            t_files = os.listdir(inbound_forcast_adhoc + today + '\\')
            if len(t_files) >= 1:
                for t_file in t_files:
                    t = t_file.rstrip(f'.txt').rstrip("_")
                    if t in hpcc_configurations:
                        if os.path.exists(inbound_forcast_adhoc + today + '\\' + t_file):
                            os.remove(inbound_forcast_adhoc + today + '\\' + t_file)

        if os.path.isdir(manual_adjustment + str(today) + '\\'):
            t_files = os.listdir(manual_adjustment + str(today) + '\\')
            if len(t_files) >= 1:
                for t_file in t_files:
                    if os.path.exists(manual_adjustment + str(today) + '\\' + t_file):
                        os.remove(manual_adjustment + str(today) + '\\' + t_file)
    except Exception as err:
        teams_alert(err, 'Pre setup. Removing previous files!')

    
def initial_transfer():
    '''
    initial_transfer
        Function that checks the designated business unit folders for any excel 
        files or txt files. If any are found transfer is initiated to a 
        manual_adjustment current working folder. An alert is sent via teams and send an
        email to alert concerned parties that their file has been picked up for processing.
    '''
    global file_count
    write_to_log("Checking and transfering source files")
    destination = manual_adjustment + str(today) + '\\'
    if not os.path.exists(destination):
        os.makedirs(destination)

    source_files = []
    source_folders = []
    notify_email = {}

    for folder_path in drop_zone_folder_paths:
        if os.path.isdir(folder_path):
            allfiles = os.listdir(folder_path)
            folder_name = str(os.path.basename(folder_path))
            input_data_files = [folder_path + '\\' + f for f in allfiles if f.lower().endswith("xlsx") or f.lower().endswith("txt") or f.lower().endswith("csv")]
            source_files.extend([f for f in allfiles if f.lower().endswith("xlsx") or f.lower().endswith("txt") or f.lower().endswith("csv")])
            file_count += len(input_data_files)

            if len(input_data_files) >= 1:
                write_to_log(f"File(s) found in {folder_name} folder")
                notify_email[folder_name] = {
                    "count" : len(input_data_files),
                    "email" : communications["distribution_list"][folder_name],
                    "files" : []
                }
                
                source_folders.append(folder_name)
                count = 0
                for i, source in enumerate(input_data_files):
                    try:
                        count += 1
                        basename = str(os.path.basename(source)).replace("'", "")

                        #### https://jira.rsi.lexisnexis.com/browse/FMR-8560
                        #-> remove folder name from resubmited files apart from vc files
                        #-> add hypens to filename to distinguish username
                        basename = basename.replace(folder_name + "_", '') if folder_name.lower() != 'vc' else basename 
                        notify_email[folder_name]["files"].append(basename)
                        basename = "_".join(basename.split(" ")) 
                        newfilename = folder_name + '_' + basename if folder_name.lower() != 'vc' else basename
                        #### 

                        shutil.move(source, os.path.join(destination, newfilename))
                    except Exception as err:
                        teams_alert(err, 'Manual Load File Transfer')
                        continue

    forecast_source = inbound_forcast_working + str(today) + '\\'
    if os.path.isdir(forecast_source):
        allfiles = os.listdir(forecast_source)
        folder_name = "Forecast"
        input_data_files = [forecast_source + f for f in allfiles if f.lower().endswith("txt")]
        source_files.extend([f for f in allfiles if f.lower().endswith("txt")])
        file_count += len(input_data_files)

        if len(input_data_files) >= 1:
            write_to_log(f"File(s) found in {folder_name} folder")
            notify_email[folder_name] = {
                "count" : len(input_data_files),
                "email" : communications["distribution_list"][folder_name],
                "files" : []
            }
            source_folders.append(folder_name)
            for i, source in enumerate(input_data_files):
                try:
                    basename = str(os.path.basename(source))

                    ## https://jira.rsi.lexisnexis.com/browse/FMR-8560 
                    ## remove folder name from resubmited files
                    basename = basename.replace(folder_name + "_", '') 

                    ## https://jira.rsi.lexisnexis.com/browse/FMR-9795 
                    ## remove username from resubmited files
                    basename = basename.replace(f"_{admin}_{i+1:02d}", '').replace("'", "")

                    notify_email[folder_name]["files"].append(basename)
                    newfilename = folder_name + '_' + basename.replace(".txt", f"_{admin}_{i+1:02d}.txt")
                    shutil.move(source, os.path.join(destination, newfilename))
                except Exception as err:
                    teams_alert(err, 'Forecast File Transfer')
                    continue


    write_to_log(f"File(s) collected - {len(source_files)}")
    if len(source_files) >= 1:

        for i, folder in enumerate(notify_email):
            files = f'\n\t\t* '.join(list(notify_email[folder]["files"]))
            send_mail(
                send_from=communications["send_from"],
                send_to=communications['team_list'] if env=='dev' else notify_email[folder]["email"],
                send_cc=[] if env=='dev' else communications["CC"],
                subject=env_subj + communications['report']['alert'] + f'{folder} file(s) found.',
                text=f"""
                Automation system has began {email_timestamp}. Processing {notify_email[folder]['count']} file(s) from {folder} folder.
                Files collected:
                \t* {files}
                """
            )
            
        send_to_teams_channel(
            webhook=communications["teams_webhook_url"].format(teams_webhook_path),
            title=env_subj + communications['report']['alert'] + f'File(s) found.',
            message=f"Automation system has began. Processing {len(source_files)} file(s)."
        )


def pre_process_validation():
    """
    pre_process_validation
        Function gets all files from the working folder in the manual_adjustment 
        folder passes that list though the pre-validation function that is executed 
        in a multithread process.
    """

    allFiles = os.listdir(manual_adjustment + str(today) + '\\')
    source_files = [manual_adjustment + str(today) + '\\' + f for f in allFiles if f.lower().endswith("xlsx") or f.lower().endswith("txt") or f.lower().endswith("csv")]
    allFiles = [os.path.basename(source) for source in source_files]

    if len(source_files) >= 1:
        start_time = time.time()

        write_to_log("Running multithread preprocess validation")

        with ThreadPool(len(source_files)) as pool:
            pool.starmap(run_pre_process_validation, zip(source_files))

        end_time = time.time() - start_time
        write_to_log(f'Pre-processing {len(source_files)} input files took {str(dt.timedelta(seconds=end_time))} time using multiprocessing')
    else:
        write_to_log("No file(s) available for pre-validation", warning=True)


def run_pre_process_validation(file_path):
    """
    run_pre_process_validation
        Function that instantiates an object of the of Validation class from 
        the manual load validation file and executes the main validation class method. 
    """
    global debug_log, report_df, values_df

    try:
        validate = Validation(
            engine=engine,
            teams_webhook_path=teams_webhook_path,
            file_path=file_path,
            source_path=manual_adjustment,
            json_file_path=json_file_path,
            hpcc_landing_zone=hpcc_landing_zone,
            program_timestamp=program_timestamp,
            working_timestamp=working_timestamp,
            source_file_archive=source_file_archive,
            inbound_forcast_adhoc=inbound_forcast_adhoc,
            inbound_forcast_working=inbound_forcast_working,
            inbound_forcast_archive=inbound_forcast_archive
        )

        log, report, values = validate.run()
        debug_log = log if debug_log.empty else pd.concat([debug_log, log], ignore_index=True)        
        report_df = report if report_df.empty else pd.concat([report_df, report], ignore_index=True)
        values_df = values if values_df.empty else pd.concat([values_df, values], ignore_index=True)
    except Exception as err:
        teams_alert(f"{os.path.basename(file_path)}\t{err}", 'Prevalidation Error')


def ecl_validation():
    """
    ecl_validation
        Function that gets the data files from the manual and forecast adhoc working folders and 
        process them through the hpcc_hthor_validation function. The file list is filtered out to 
        keep the names for files in the HPCC Configuration. The files collected are processed through 
        the hpcc_hthor_validation function in a multithread process.
    """
    hpcc_files = []
    # check for files in the manual inbound landing zone folder
    if os.path.isdir(hpcc_landing_zone + str(today) + '\\'):
        data_folders = os.listdir(hpcc_landing_zone + str(today) + '\\')
        files = ['_'.join(file.rstrip('.txt').split('_')[:-1]) for file in data_folders]
        manual_files = [f for f in files if f in hpcc_configurations and hpcc_configurations[f]["validation"]]
        if len(manual_files) >= 1:
            hpcc_files.extend(manual_files)
        else:
            write_to_log("No manual inbound file(s) available for validation.", warning=True)
    else:
        write_to_log("No manual inbound file(s) available for validation.", warning=True)

    # check for files in the forecast inbound landing zone folder
    if os.path.isdir(inbound_forcast_adhoc + str(today) + '\\'):
        data_folders = os.listdir(inbound_forcast_adhoc + str(today) + '\\')
        files = [file.rstrip('.txt') for file in data_folders]
        forecast_files = [f for f in files if f in hpcc_configurations and hpcc_configurations[f]["validation"]]
        if len(forecast_files) >= 1:
            hpcc_files.extend(forecast_files)
        else:
            write_to_log("No forecast inbound file(s) available for validation.", warning=True)
    else:
        write_to_log("No forecast inbound file(s) available for validation.", warning=True)

    # run ECL validations 
    if len(hpcc_files) >= 1:
        write_to_log("Running multithread forecast ecl hthor validation")
        start_time = time.time()

        with ThreadPool(len(hpcc_files)) as pool:
            pool.starmap(hpcc_hthor_validation, zip(hpcc_files))

        end_time = time.time() - start_time
        write_to_log(f'ECL validations {len(hpcc_files)} input files took {str(dt.timedelta(seconds=end_time))} time using multiprocessing')
    

def hpcc_hthor_validation(hpcc_file: str, attempts=5):
    """
    hpcc_hthor_validation: 
        Function gets the data sheet name and the source build name related to the data file collected and executes the 
        validation source build. Once the build is completed, we update the ManualLoadReport table and the ManualLoadLog 
        table with the result attained from the source build.
    """
    global debug_log, report_df, values_df

    try:
        validation = dict(hpcc_configurations[hpcc_file]["validation"])
        template = hpcc_configurations[hpcc_file]['template']
        time.sleep(int(validation["sleep_time"]))
        write_to_log(f"Starting validation for hpcc_file {hpcc_file}")

        #get the worksheet/tab/layout that contained the dat to be validated
        for sheet, config in dict(validations[template]).items():
            if config["data_file"] == hpcc_file:
                current_sheet = sheet.split('_')[0] if template == "fact_forecast_details" else sheet
                break

        workunit = wuMsg = status = ""

        try:
            time.sleep(int(validation["sleep_time"]))
            sourceRun = runSourceBuilds.commonSourceFiles(validation["build"], freq, 'fromHPCC')
            sourceRun.file_date = today
            time.sleep(int(validation["sleep_time"]))
            (workunit, status, wuMsg) = runSourceBuilds.eclCall(sourceRun)
        except Exception as err:
            teams_alert(err, f"{validation['build']} source run")
            if attempts >= 1:
                time.sleep(1)
                write_to_log(f"Re-attempting source run function execution. {attempts-1} more attempts left.")
                hpcc_hthor_validation(hpcc_file, attempts-1)
            else:
                teams_alert("hpcc_hthor_validation function attempts failed")
        else:
            write_to_log(f"Validation build for {hpcc_file} status: {status}!", error=(status != "completed"))

            if wuMsg is not None and len(wuMsg) > 0:
                wuMsg = wuMsg.replace('\n', '').replace('\r','')
                write_to_log(wuMsg, error=(status != "completed"))

            # Archive the file if the validation status is not complete
            # for forecast data there are a group of files involved so all file will need to be archived as well 
            if status != "completed":
                update_report(wuid=workunit, template=template, sheet=current_sheet, ecl_validation=0, validation_wumsg=wuMsg)
                if template == "fact_forecast_details":
                    group = hpcc_configurations[hpcc_file]['group']
                    data_folders = os.listdir(inbound_forcast_adhoc + str(today) + '\\')
                    files = [file.rstrip('.txt') for file in data_folders]
                    lz_files = [f for f in files if f in hpcc_configurations and hpcc_configurations[f]["group"] == group]
                    for lz_file in lz_files:
                        archive_file(target='DataWithErrors',source_file=lz_file + '.txt', t_source='forecast')
                else:
                    archive_file(target='DataWithErrors',source_file=hpcc_file + f'_{today}.txt')
            else:   
                # Forecast validation involves more than one related submited file 
                # so we update all records involved 
                if template == "fact_forecast_details":
                    update_report(wuid=workunit, template=template, sheet=current_sheet, ecl_validation=1, validation_wumsg=wuMsg)
                else:
                    try:
                        # HPCC validation desprays a summary file in the outbound folder 
                        # summary file contains report level details attained from the vlaidation process
                        # we update these details in the manualloadreport table 
                        write_to_log(f"Getting summary logs from HPCC for {hpcc_file} and updating the report Dataframe")

                        despray_summary_file = outbound_manual + today + "\\" + hpcc_file + "_summary.tsv"
                        assert os.path.exists(despray_summary_file), f"Summary data for {hpcc_file} was not desprayed"
                        df_from_hpcc = pd.read_csv(despray_summary_file, delimiter='\t')
                        df_from_hpcc["eclvalidation"] = df_from_hpcc["eclvalidation"].map(dict(passed=1, failed=0))
                        
                        for f, w, v, t in zip(list(df_from_hpcc["input_filename"]), list(df_from_hpcc["worksheet"]), list(df_from_hpcc["eclvalidation"]), list(df_from_hpcc["template"])):
                            update_report(wuid=workunit,template=t, sheet=w,ecl_validation=v,validation_wumsg=wuMsg,input_filename=f)

                        if (df_from_hpcc["eclvalidation"] == 0).all():
                            archive_file(target='DataWithErrors',source_file=hpcc_file + f'_{today}.txt')

                        archive_file('', hpcc_file + "_summary.tsv", lz='outbound')
                    except Exception as err:
                        teams_alert(err, "Updating ManualLoadReport")

                    try:
                        # HPCC validation desprays a error log file in the outbound folder 
                        # this file contains any possible error logs from the ecl validation
                        # we update these details in the ManualLoadLog table
                        write_to_log(f"Getting error logs from HPCC for {hpcc_file} and updating the report Dataframe")

                        despray_log_file = outbound_manual + today + "\\" + hpcc_file + "_error_logs.tsv"
                        assert os.path.exists(despray_log_file), f"Log data for {hpcc_file} was not desprayed"
                        hpcc_errors_ds = pd.read_csv(despray_log_file, delimiter='\t')
                        hpcc_errors_ds['start_datetime'] = [program_timestamp for _ in range(len(hpcc_errors_ds))]
                        hpcc_errors_ds['working_timestamp'] = [working_timestamp for _ in range(len(hpcc_errors_ds))]
                        debug_log = hpcc_errors_ds if debug_log.empty else pd.concat([debug_log, hpcc_errors_ds], ignore_index=True)

                        archive_file('', hpcc_file + "_error_logs.tsv", lz='outbound')
                    except Exception as err:
                        teams_alert(err, "Updating ECL Validation errors")
    except Exception as err:
        teams_alert(err, "running hpcc_hthor_validation")


def ecl_stage_facts():
    """
    ecl_stage_facts
        Function that gets the data files from the manual and forecast adhoc 
        working folders. The file list is filtered out to keep the names for 
        files in the HPCC Configuration. The files from the manual adhoc folder 
        are processed first through the main_run_stage_fact function then the 
        file in the forecast adhoc folder is processed next.
    """
    start_time = time.time()

    manual_load_lz = hpcc_landing_zone + str(today) + '\\'
    forecast_lz = inbound_forcast_adhoc + str(today) + '\\'
    count = 0
    manual_load_lz_data_files = os.listdir(manual_load_lz) if os.path.isdir(manual_load_lz) else []
    if len(manual_load_lz_data_files) >= 1:
        manual_load_lz_templates = ['_'.join(file.rstrip('.txt').split('_')[:-1]) for file in manual_load_lz_data_files]
        manual_load_files = [ t for t in manual_load_lz_templates if t in hpcc_configurations ]
        if len(manual_load_files) >= 1:
            count += len(manual_load_files)
            main_run_stage_fact(False, manual_load_files)

    forecast_lz_data_files = os.listdir(forecast_lz) if os.path.isdir(forecast_lz) else []
    if len(forecast_lz_data_files) >= 1:
        forecast_lz_templates = ['_'.join(file.rstrip('.txt').split('_')) for file in forecast_lz_data_files]
        fact_forecast_files = [ t for t in forecast_lz_templates if t in hpcc_configurations ]
        if len(fact_forecast_files) >= 1:
            count += len(fact_forecast_files)
            main_run_stage_fact(True, fact_forecast_files)

    if count >= 1:
        end_time = time.time() - start_time
        write_to_log('Building {0} data file(s) took {1}.'.format(count, str(dt.timedelta(seconds=end_time))))
    else:
        write_to_log("No build file(s) available.", warning=True)


def main_run_stage_fact(forecast=False, t_files=[]):
    """
    main_run_stage_fact: 
        Run stage and fact for manual load and forecast files. 
        Builds are executed sequentially for run that should neither 
        be on the same WUID nor executed at the same time 
    """
    time.sleep(random.randint(0, 3))
    
    source_template_map = {}

    for t_file in t_files:
        if t_file in hpcc_configurations and hpcc_configurations[t_file]["build"]:
            source = hpcc_configurations[t_file]["build"]
            if source in source_template_map:
                source_template_map[source].append(hpcc_configurations[t_file]["template"])
            else:
                source_template_map[source] = [hpcc_configurations[t_file]["template"]]

    source_files = list(source_template_map.keys()) ## remove duplicate sourcefile names
    source_files.sort()
    write_to_log(f"Running the following sources {', '.join(source_files)}")
    
    for source in source_files:
        # Run ECL build and get WUID status and possible message from WU
        workunit = wuMsg = status = ""
        templates = ','.join(set(source_template_map[source]))

        try:
            sourceRun = runSourceBuilds.commonSourceFiles(source, freq, 'fromHPCC')
            sourceRun.file_date = today
            (workunit, status, wuMsg) = runSourceBuilds.eclCall(sourceRun)
        except Exception as err:
            teams_alert(err, "main_run_stage_fact")
        
        if wuMsg is not None and len(wuMsg) > 0:
            wuMsg = wuMsg.replace('\n', '').replace('\r', '')
            write_to_log(wuMsg, error=(status != "completed"))

        write_to_log(f"Stage and fact build status {status}!", error=(status != "completed"))

        # Update the report table with the build results
        update_report(
            validation=False, 
            wuid=workunit, 
            template=templates, 
            sheet="bsv_" if 'forecast_bsv' in source else "ins_" if 'forecast_insurance' in source else "hc_" if 'forecast_healthcare' in source else None,
            ecl_stage_fact= 1 if status == "completed" else 0,
            stage_fact_wumsg=wuMsg
        )

        for t in t_files:
            if hpcc_configurations[t]["build"] == source:
                f = f"{t}.txt" if forecast else f"{t}_{today}.txt"
                error_archive_target = 'DataWithError\\ECL' if forecast else 'DataWithError'
                archive_file(
                    target= error_archive_target if status != "completed" else 'NoError',
                    source_file=f,
                    t_source = "forecast" if forecast else "manual_load"
                )


def update_db_report(
        wuid=None, validation=True, template='', sheet='', 
        ecl_validation=0, validation_wumsg='', ecl_stage_fact=0, stage_fact_wumsg='', 
        input_filename='', attempts=10
    ):
    '''
    update_db_report
        Function that updates the ManualLoadReport table in the database 
        with either validation data or stage and facts data from HPCC builds
    '''
    try:
        if validation and wuid:
            update = f"""
            EXEC UpdateManualLoadReport 
            @working_timestamp='{working_timestamp}', 
            @validation_wuid='{wuid}', 
            @ecl_validation={ecl_validation}, 
            @template='{template}', 
            @validation_wumsg={'NULL' if validation_wumsg=='' or not validation_wumsg else "'"+validation_wumsg+"'" }, 
            @worksheet={'NULL' if sheet=='' or not sheet else "'"+sheet+"'" }, 
            @input_filename={'NULL' if input_filename=='' or not input_filename else "'"+input_filename+"'" }
            """
        elif not validation and wuid:
            update = f"""
            EXEC UpdateManualLoadReport 
            @working_timestamp='{working_timestamp}', 
            @stage_fact_wuid='{wuid}', 
            @ecl_stage_fact={ecl_stage_fact}, 
            @template='{template}', 
            @stage_fact_wumsg={'NULL' if stage_fact_wumsg=='' or not stage_fact_wumsg else "'"+stage_fact_wumsg+"'" },
            @worksheet={'NULL' if sheet=='' or not sheet else "'"+sheet+"'" };
            """
        else:
            update = f"""
            EXEC UpdateManualLoadReport 
            @working_timestamp='{working_timestamp}', 
            @end_datetime='{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}';
            """

        with engine.begin() as conn:
            write_to_log(f"Running sql script: {update}")
            conn.execute(update)
    except Exception as err:
        teams_alert(err, "update_report")
        if attempts >= 1:
            time.sleep(60)
            write_to_log(f"Re-attempting sql function execution. {attempts-1} more attempts left.")
            update_report(wuid, validation, template, sheet, ecl_validation, validation_wumsg, ecl_stage_fact, stage_fact_wumsg, input_filename, attempts-1)
        else:
            teams_alert("SQL UpdateManualLoadReport function attempts failed")
    

def update_report(
        wuid=None, validation=True, template='', sheet='', 
        ecl_validation=0, validation_wumsg='', ecl_stage_fact=0, stage_fact_wumsg='', 
        input_filename='', attempts=10
    ):
    '''
    update_report
        Function that updates the report data frame table with either 
        validation data or stage and facts data from HPCC builds
    '''
    global debug_log, report_df, values_df

    try:
        if validation and wuid:
            if template == "fact_forecast_details":
                condition = (
                    (report_df['template'] == template) & 
                    (report_df['prevalidation'] == 1) & 
                    (report_df['worksheet'].str.startswith(sheet))
                )
            else:
                if validation_wumsg and ecl_validation==0:
                    condition = (
                        (report_df['template'] == template) & 
                        (report_df['prevalidation'] == 1) & 
                        (report_df['worksheet'].str.lower() == sheet.lower())
                    )
                else:
                    condition = (
                        (report_df['input_filename'] == input_filename) & 
                        (report_df['template'] == template) & 
                        (report_df['prevalidation'] == 1) & 
                        (report_df['worksheet'].str.lower() == sheet.lower())
                    )
            
            report_df['eclvalidation'] = np.where(condition, ecl_validation, report_df['eclvalidation'])
            report_df['validation_wuid'] = np.where(condition, wuid, report_df['validation_wuid'])
            report_df['data_validation_wuid_failure_msg'] = np.where(condition, validation_wumsg, report_df['data_validation_wuid_failure_msg'])
        elif not validation and wuid:
            if template == "fact_forecast_details":
                condition = (
                    (report_df['prevalidation'] == 1) & 
                    (report_df['template'] == template) & 
                    (report_df['worksheet'].str.startswith(sheet)) & (
                        ((report_df['validation_wuid'] != "") & (report_df['eclvalidation'] == 1)) | 
                        ((report_df['validation_wuid'] == "") & (report_df['eclvalidation'] == ""))
                    )
                )
            else:
                condition = (
                    (report_df['prevalidation'] == 1) & 
                    (report_df['template'].isin(template.split(","))) & (
                        ((report_df['validation_wuid'] != "") & (report_df['eclvalidation'] == 1)) | 
                        ((report_df['validation_wuid'] == "") & (report_df['eclvalidation'] == ""))
                    )
                )

            report_df['is_fact_built'] = np.where(condition, ecl_stage_fact, report_df['is_fact_built'])
            report_df['stage_fact_wuid'] = np.where(condition, wuid, report_df['stage_fact_wuid'])
            report_df['build_fact_wuid_failure_msg'] = np.where(condition, stage_fact_wumsg, report_df['build_fact_wuid_failure_msg'])
        else:
            report_df['end_datetime'] = [datetime.now().strftime('%Y-%m-%d %H:%M:%S') for _ in range(len(report_df))]
    except Exception as err:
        teams_alert(err, "update_report")
        if attempts >= 1:
            time.sleep(60)
            write_to_log(f"Re-attempting report dataframe update. {attempts-1} more attempts left.")
            update_report(wuid, validation, template, sheet, ecl_validation, validation_wumsg, ecl_stage_fact, stage_fact_wumsg, input_filename, attempts-1)
        else:
            teams_alert("update_report function attempts failed")


def get_report_from_df():
    global debug_log, report_df, values_df
    warnings.filterwarnings("ignore", 'This pattern is interpreted as a regular expression, and has match groups')
    try:
        try:
            assert not report_df.empty, "No data to report"
            write_to_log("Getting reports and logs from dataframe")

            ## filter out logs to get the individual file validation error logs only
            validation_logs = debug_log[(debug_log['input_filename'] != 'manual_load_main') & (debug_log['log_type'] == 'ERROR')]

            db_errors_df = validation_logs[~validation_logs['log_message'].str.contains('|'.join(communications['report']['skipped_log_errors']))]
            db_errors_df = db_errors_df.replace('', "N/A")
            db_errors_df.fillna("N/A", inplace=True)

            ## Pivot the records template specific values
            db_values_df=values_df.pivot(index=['input_filename', 'worksheet'], columns='template_key', values='template_val')
            db_values_df=db_values_df.reset_index().dropna(axis=1, how='all')
            db_values_df.fillna("N/A", inplace=True)

            ## add template values to report DF adjust values to match final report view
            db_report_df = report_df.merge(db_values_df, left_on=['input_filename', 'worksheet'], right_on=['input_filename', 'worksheet'])
            db_report_df["prevalidation"] = db_report_df["prevalidation"].map({1:"PASSED", 0:"FAILED"})
            db_report_df["eclvalidation"] = db_report_df["eclvalidation"].map({1:"PASSED", 0:"FAILED"})
            db_report_df["is_fact_built"] = db_report_df["is_fact_built"].map({1:"PASSED", 0:"FAILED"})
            db_report_df["record_count"]  = db_report_df["record_count"].replace(0, 'N/A')
            db_report_df = db_report_df.replace('', "N/A").replace('$nan', "N/A")
            db_report_df.fillna("N/A", inplace=True)

            ## Filter out files and worksheets from the report DF 
            non_reprt_errs = validation_logs[
                validation_logs['log_message'].str.contains('|'.join(communications['report']['skipped_report_errors']))
            ][['input_filename', 'worksheet']]
            non_reprt_keys = list(non_reprt_errs.columns.values)
            non_reprt_idx = non_reprt_errs.set_index(non_reprt_keys).index
            db_report_idx = db_report_df.set_index(non_reprt_keys).index
            db_report_df = db_report_df[~db_report_idx.isin(non_reprt_idx)]

            db_errors_df = db_errors_df.rename(mapper=communications['report']['debug_column_map'], axis='columns')
            db_report_df = db_report_df.rename(mapper=communications['report']['report_column_map'], axis='columns')
        except Exception as err:
            if str(err) == "No data to report":
                write_to_log(err, warning=True)
            else:
                teams_alert(err, "get_report_from_df")
        else:
            # Create a report for all templates submitted in each folder
            for _, current_folder in dict(communications["drop_zone_folders"]).items():
                distribution_list = communications['distribution_list'][current_folder]

                folder_report = db_report_df[db_report_df['Filename'].str.startswith(current_folder)]
                folder_errors = db_errors_df[db_errors_df['Filename'].str.startswith(current_folder)]

                if not folder_report.empty:
                    # Loop through all implemented templates
                    # Determine if the template was submitted for that folder and create report
                    for current_template in current_templates:
                        template_report = folder_report[folder_report['Template'] == current_template]
                        template_errors = folder_errors[folder_errors['Template'] == current_template]

                        if not template_report.empty:
                            write_to_log(f"Creating {current_template} report for {current_folder}")
                            send_template_report(
                                email=distribution_list,
                                folder=current_folder, 
                                template=current_template,
                                template_report=template_report, 
                                template_errors=template_errors,
                            )
    except Exception as err:
        teams_alert(err, "get_report_from_df")


def get_reports_from_db(attempts=5):
    '''
    get_reports_from_db
        Function creates a report from two tables by loading data into a 
        report and log data frame. Reports are to be sent to different 
        distribution lists based on the source folder. The folder name is 
        in each record in the "Filename" column of both data frames therefore 
        we filter out the data frame for each folder distribution and further 
        filter the data frames based on the template name.
    '''
    global debug_log, report_df, values_df

    try:
        write_to_log("Getting reports and logs from Database")

        try:
            # Execute store procedures that will return a process report and error logs 
            get_reports = f"EXEC GetManualLoadReport @program_timestamp='{working_timestamp}'"
            get_logs = f"EXEC GetManualLoadErrorLogs @program_timestamp='{working_timestamp}'"

            db_report_df = pd.read_sql_query(get_reports, con=engine)
            db_report_df = db_report_df.replace(np.NAN, "N/A")
            db_report_df = db_report_df.replace('$nan', "N/A")
            db_report_df["Total Billed Revenue"] = db_report_df["Total Billed Revenue"].replace("N/A", "Not Calculated")
            
            db_errors_df = pd.read_sql_query(get_logs, con=engine)
            db_errors_df = db_errors_df.replace(np.NAN, "N/A")
            db_errors_df["Line Number"] = db_errors_df["Line Number"].replace(0, 'N/A')

        except Exception as err:
            teams_alert(err, "get_reports_from_db red_sql_query")
            if attempts >= 1:
                time.sleep(30)
                write_to_log(f"Re-attempting sql function execution. {attempts-1} more attempts left.")
                get_reports_from_db(attempts-1)
            else:
                teams_alert("SQL read_report_sql query function attempts failed")
        else:
            # Create a report for all templates submitted in each folder
            for _, current_folder in dict(communications["drop_zone_folders"]).items():
                distribution_list = communications['distribution_list'][current_folder]

                folder_report = db_report_df[db_report_df['Filename'].str.startswith(current_folder)]
                folder_errors = db_errors_df[db_errors_df['Filename'].str.startswith(current_folder)]

                if not folder_report.empty:
                    # Loop through all implemented templates
                    # Determine if the template was submitted for that folder and create report
                    for current_template in current_templates:
                        template_report = folder_report[folder_report['Template'] == current_template]
                        template_errors = folder_errors[folder_errors['Template'] == current_template]

                        if not template_report.empty:
                            write_to_log(f"Creating {current_template} report for {current_folder}")
                            send_template_report(
                                template_report=template_report, 
                                template_errors=template_errors,
                                email=distribution_list,
                                folder=current_folder, 
                                template=current_template
                            )
    except Exception as err:
        teams_alert(err, "get_reports_from_db")


def send_template_report(email: list, folder: str, template: str, template_report: pd.DataFrame, template_errors: pd.DataFrame):
    '''
    send_template_report
        Function that creates a report that includes a summary of all files collected, the files 
        that passed the entire process, files that failed to be processed and error logs related to 
        the files that failed. 
    '''
    try:
        # Get the worksheets that required to go through ECL data validation
        if template != 'unknown':
            validation_config   = dict(validations[template])
            template_sheets     = list(validation_config.keys())
            hpcc_worksheets     = [sh for sh in template_sheets if validation_config[sh]['hpcc_validation'] == True]
            non_hpcc_worksheets = [sh for sh in template_sheets if validation_config[sh]['hpcc_validation'] == False]
        else:
            hpcc_worksheets     = []
            non_hpcc_worksheets = [template]

        # Get the report column configuration
        report_config = dict(communications['report'])
        column_config = report_config[
            template if template in report_config else "general_report_columns" if len(hpcc_worksheets) <= 0 else "detailed_report_columns"
        ]
 
        # Remove the name of the folder
        if folder.lower() != 'vc': 
            template_report['Filename'] = template_report['Filename'].map(lambda x: x.lstrip(folder + "_"))
            template_errors['Filename'] = template_errors['Filename'].map(lambda x: x.lstrip(folder + "_"))

        # Create Dataframes for files in the report, whose processing either passed or failed.
        passed_files = template_report[
            (template_report["Pre-HPCC Validation"] == "PASSED") &
            (((template_report["Worksheet"].str.lower().isin(hpcc_worksheets)) & (template_report["HPCC Validation"] == "PASSED")) | 
             (template_report["Worksheet"].str.lower().isin(non_hpcc_worksheets))
            ) & (template_report["HPCC Stage_Fact"] == "PASSED")
        ][column_config['data']]

        failed_files = template_report[
            (template_report["Pre-HPCC Validation"] != "PASSED") |
            ((template_report["Worksheet"].str.lower().isin(hpcc_worksheets)) & (template_report["HPCC Validation"] != "PASSED")) | 
            (template_report["HPCC Stage_Fact"] != "PASSED")
        ][column_config['data']]

        # Add any message received and recorded from HPCC validation and Stage fact process to the logs
        ## -> Get the validation messages in temp Dataframes 
        failed_stage_fact = template_report[(template_report["HPCC Stage_Fact"] != "PASSED") & (template_report["Stage_Fact WuMSG"] != 'N/A')]
        failed_validation = template_report[
            (template_report["Worksheet"].str.lower().isin(hpcc_worksheets)) & 
            (template_report["HPCC Validation"] != "PASSED") & 
            (template_report["Validation WuMSG"] != 'N/A')
        ]  

        ## -> Function that adds data from the temp files above to the error log DF 
        def hpcc_error_log(hpcc_df: pd.DataFrame, wuid_step ) -> pd.DataFrame :
            if not hpcc_df.empty:
                add_error_log = pd.DataFrame({
                    'Source'        : ['HPCC' for _ in range(len(hpcc_df))],
                    'Template'      : hpcc_df['Template'],
                    'User'          : hpcc_df['User'],
                    'Filename'      : hpcc_df['Filename'],
                    "Worksheet"     : hpcc_df["Worksheet"],
                    'Message'       : hpcc_df[f'{wuid_step} WuMSG'],
                    'Line Number'   : ['N/A' for _ in range(len(hpcc_df))],
                    'WUID'          : hpcc_df[f'{wuid_step} WUID']}
                )
                # check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else  msg
                # add_error_log['Message'] = check_sys_message(add_error_log['Message'])
                return add_error_log
            else:
                return pd.DataFrame()

        ## -> Call the function
        template_errors = pd.concat([template_errors, hpcc_error_log(failed_validation, "Validation")], ignore_index=True) 
        template_errors = pd.concat([template_errors, hpcc_error_log(failed_stage_fact, "Stage_Fact")], ignore_index=True)

        # Rename the Worksheet column to layout for files that are not submitted in txt format
        report_layout   = 'Layout' if template == "fact_forecast_details" else 'Worksheet'
        passed_files    = passed_files.rename(mapper={"Worksheet":report_layout}, axis='columns')
        failed_files    = failed_files.rename(mapper={"Worksheet":report_layout}, axis='columns')
        template_errors = template_errors[report_config["debug_columns"]]
        template_errors = template_errors.rename(mapper={"Worksheet":report_layout}, axis='columns')

        # Create dataframe containing a summary of the files collected and processed in the current session
        report_summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template"          : [' '.join([str(w).capitalize() for w in template.split('_')])],
            "Folder"            : [folder],
            "Files Collected"   : [len(set(list(template_report['Filename'])))],
            "Files Loaded"      : [len(set(list(passed_files['Filename'])))],
            "Files Rejected"    : [len(set(list(failed_files['Filename'])))],
            "Stage/Fact WUID"   : ['N/A' if len(template_report[template_report["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else template_report[template_report["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        if len(hpcc_worksheets) >= 1:
            Validation_WUID = 'N/A' if len(template_report[template_report["Validation WUID"] != "N/A"]["Validation WUID"]) <= 0 else template_report[template_report["Validation WUID"] != "N/A"]["Validation WUID"].iloc[0]
            report_summary_df.insert(loc=6, column='Validation WUID', value=Validation_WUID)

        # Set the data values for the report 
        data = {
            'timestamp'         : email_timestamp,
            'summary_table'     : report_summary_df.to_html(index=False, table_id="aop"),
            'passed_desc'       : '' if len(passed_files) <= 0 else 'Below are file(s) that completed processing',
            'passed_files'      : '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aopsuccess"),
            'failed_desc'       : '' if len(failed_files) <= 0 else 'Below are file(s) that were rejected.',
            'failed_files'      : '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc'    : '' if len(template_errors) <= 0 else 'Below are error logs from processing the submitted files.',
            'error_log_table'   : '' if len(template_errors) <= 0 else template_errors.to_html(index=False, table_id="aoperror")
        }

        # Open the html template and instert the above data values
        with open(report_template, 'r') as T:
            email_template = Template(T.read())
            email_report = email_template.substitute(data)
            subject = env_subj + communications['report']['error' if len(failed_files) >= 1 else 'success']
            subject += ' '.join([str(w).capitalize() for w in template.split('_')]) + f' :: {folder}'

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=subject,
                dataframe=email_report.replace("\n", "")
            )
    except Exception as err:
        teams_alert(err, f"Creating {folder} {template} report")


def write_to_log(message, error=False, warning=False, validation_type="", t_function='Automation'):
    """
    write_to_log
        Function that logs the process of the automation program to the terminal, 
        the applog debugger and a log data frame.
    """
    global debug_log

    timestamp = getCurrentTimeStamp()
    log_style = " ERROR " if error or validation_type == "Error" else "WARNING" if warning or validation_type == "Warning" else " DEBUG "
    log = f"[{timestamp}]:[{log_style}]: {message}"
    print(log)

    try:
        if error or validation_type == "Error":
            logger.error(f"{message}")

            send_to_teams_channel(
                webhook=communications["teams_webhook_url"].format(teams_webhook_path),
                title=env_subj + communications['report']['errors'] + t_function,
                message=f"{message}"
            )
        else:
            logger.debug(f"{message}")
    except Exception as err:
        teams_alert(err, "File Logger")

    try:
        df_to_add = pd.DataFrame({
            'input_filename'    :["manual_load_main"],
            'username'          :["ADMIN"],
            'worksheet'         :["N/A"],
            'template'          :["N/A"],
            'record_number'     :[0],
            'log_type'          :[log_style.strip()],
            'log_message'       :[f"{message}"],
            'source'            :["Automation"],
            'log_datetime'      :[timestamp],
            'start_datetime'    :[program_timestamp],
            'working_timestamp' :[working_timestamp],
            'log_timestamp'     :[datetime.fromisoformat(timestamp).strftime("%Y%m%d_%H%M%S")]
        })

        if debug_log.empty:
            debug_log = df_to_add
        else:
            debug_log = pd.concat([debug_log, df_to_add], ignore_index=True)
    except Exception as err:
        teams_alert(err, "Logger DB")


def teams_alert(msg, function=''):
    """
    teams_alert
        Function that gets the file and line details when a caught exception occurs and log the details including a teams alert message.
    """
    _, _, exc_tb = sys.exc_info()
    line_no = exc_tb.tb_lineno
    message = f"Line:{line_no}\t{msg}"
    write_to_log(message, error=True, t_function=function)
    

def archive_file(target: str, source_file: str, lz='inbound', t_source="manual_load"):
    '''
    archive_file
        Function that archives files to depending on whether an error occurred 
        with the related files or if the file is for the outbound or inbound folder.
    '''
    write_to_log(f"Archiving {source_file} to {t_source} {lz} archive")
    if lz == 'inbound':
        archive = hpcc_landing_zone_archive if t_source=="manual_load" else inbound_forcast_archive
        archive_folder = archive + target + '\\' + today + '\\' + process_timestamp + '\\'
        source_path = hpcc_landing_zone if t_source=="manual_load" else inbound_forcast_adhoc 
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)
        shutil.move(source_path + today + '\\' + source_file, archive_folder)
    else:
        archive_folder = hpcc_outbound_landing_zone_archive + today + '\\' + process_timestamp + '\\'
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)
        shutil.move(outbound_manual + today + '\\' + source_file, archive_folder)


def ManualLoadReport(attempts=5):
    """
    ManualLoadReport
        Function that appends to the ManualLoadReport table contain 
        general report data for file currently being processed
    """
    global report_df
    try:
        write_to_log(f"Inserting into ManualLoadReport tables")
        report_df = report_df.replace("", sqlalchemy.sql.null())
        rows_affected = report_df.to_sql('ManualLoadReport', con=engine, if_exists="append", index=False, method='multi')
        write_to_log(f"ManualLoadReport rows affected: {rows_affected}")
    except Exception as err:
        teams_alert(err, 'ManualLoadReport')
        if attempts >= 1:
            time.sleep(3)
            write_to_log(f"Re-attempting ManualLoadReport sql function execution. {attempts-1} more attempts left.")
            ManualLoadReport(attempts-1)
        else:
            teams_alert(err, "SQL ManualLoadReport function attempts failed")


def ManualLoadReportValues(insert_attempts=5):
        """
        ManualLoadReportValues
            Function that appends to a manual load report value table that 
            contains data or specific values related to the template currently 
            being processed and is not common among all templates.
        """
        global values_df
        try:
            write_to_log(f"Inserting into ManualLoadReportValues tables")
            values_df = values_df.replace("", sqlalchemy.sql.null())
            rows_affected = values_df.to_sql('ManualLoadReportValues', con=engine, if_exists="append", index=False, method='multi')
            write_to_log(f"ManualLoadReportValues rows affected: {rows_affected}")
        except Exception as err:
            teams_alert(err, 'ManualLoadReportValues')
            if insert_attempts >=1:
                time.sleep(3)
                write_to_log(f"Re-attempting ManualLoadReportValues sql function execution. {insert_attempts-1} more attempts left.")
                ManualLoadReportValues(insert_attempts-1)
            else:
                teams_alert(err, "SQL ManualLoadReportValues function attempts failed")
        else:
            MergeManualLoadReportValues()


def MergeManualLoadReportValues(merge_attempts=5):  
    """
    MergeManualLoadReportValues
        Functions that execute a store procedure SQL that emerges data 
        values for certain templates to be included in the final report.
    """
    global debug_log, report_df, values_df
    try:
        write_to_log(f"Merging data from ManualLoadReport to ManualLoadReportValues tables")  
        with engine.begin() as conn:
            conn.execute(f"EXEC MergeManualLoadReportValues @working_timestamp ='{working_timestamp}'") 
    except Exception as err:
        teams_alert(err, 'MergeManualLoadReportValues')
        if merge_attempts >= 1:
            time.sleep(3)
            write_to_log(f"Re-attempting MergeManualLoadReportValues sql function execution. {merge_attempts-1} more attempts left.")
            MergeManualLoadReportValues(merge_attempts-1)
        else:
            teams_alert(err, "SQL MergeManualLoadReportValues function attempts failed")


def ManualLoadLogsAdmin(attempts=5):
    """
    ManualLoadLogsAdmin
        Function of that appends the process logs to the manual load logs table
    """
    global debug_log
    try:
        write_to_log(f"Inserting admin logs into ManualLoadLogs tables")
        admin_logs = debug_log[debug_log['input_filename'] == 'manual_load_main']
        admin_logs = admin_logs.replace("", sqlalchemy.sql.null() )
        rows_affected = admin_logs.to_sql('ManualLoadLogs', con=engine, if_exists="append", index=False, method='multi')
        write_to_log(f"ManualLoadLogs rows affected: {rows_affected}")
    except Exception as err:
        teams_alert(err, 'ManualLoadLogsAdmin')
        if attempts >= 1:
            time.sleep(3)
            write_to_log(f"Re-attempting ManualLoadLogsAdmin sql function execution. {attempts-1} more attempts left.")
            ManualLoadLogsAdmin(attempts-1)
        else:
            teams_alert(err, "SQL ManualLoadLogsAdmin function attempts failed")
    

def ManualLoadLogsValidations():
    """
    ManualLoadLogsValidations
        Function of that appends the process logs to the manual load logs table
    """
    global debug_log
    warnings.filterwarnings("ignore", 'This pattern is interpreted as a regular expression, and has match groups')
    ## Filter the records in the error logs to significant logs
    validation_logs = debug_log[(debug_log['input_filename'] != 'manual_load_main') & (debug_log['log_type'] == 'ERROR')]
    validation_logs = validation_logs[
        ~validation_logs['log_message'].str.contains('|'.join(communications['report']['skipped_log_errors']))
    ]
    validation_logs = validation_logs.replace("", sqlalchemy.sql.null()).replace("N/A", sqlalchemy.sql.null())

    def UploadLogs(template, attempts=5):
        try:
            template_logs = validation_logs[validation_logs['template'] == template]
            if len(template_logs) >= 1:
                write_to_log(f"Appending {template} validation logs into ManualLoadLogs tables")
                rows_affected = template_logs.to_sql('ManualLoadLogs', con=engine, if_exists="append", index=False, method='multi')
                write_to_log(f" {template} ManualLoadLogs rows affected: {rows_affected}")
        except Exception as err:
            teams_alert(err, f'ManualLoadLogsValidations {template}')
            if attempts >= 1:
                time.sleep(3)
                write_to_log(f"Re-attempting ManualLoadLogsValidations sql function execution. {attempts-1} more attempts left.")
                UploadLogs(template, attempts-1)
            else:
                teams_alert(err, f"SQL ManualLoadLogsValidations {template} function attempts failed")

    for current_template in current_templates:
        UploadLogs(current_template)


def send_log_report():
    global debug_log, file_count

    try:
        debug_log = debug_log[debug_log['input_filename'] == 'manual_load_main']
        debug_log = debug_log[["working_timestamp","log_datetime", "log_type", "log_message"]]
        error_log = debug_log[debug_log['log_type'] == 'ERROR']

        data = {
            'timestamp'         : email_timestamp,
            'summary_table'     : '',
            'passed_desc'       : '' if len(debug_log) <= 0 else 'Below are the logs for the manual load automation program.',
            'passed_files'      : '' if len(debug_log) <= 0 else debug_log.to_html(index=False, table_id="aop"),
            'failed_desc'       : '',
            'failed_files'      : '',
            'error_log_desc'    : '' if len(error_log) <= 0 else 'Below are error logs for the manual load automation program.',
            'error_log_table'   : '' if len(error_log) <= 0 else error_log.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else communications['CC'],
                subject=env_subj + communications['report']['logs' if len(error_log) <= 0 else 'errors'] + f'{working_timestamp}{" :: No Files Found" if file_count <= 0 else ""}',
                dataframe=email_report.replace("\n", "")
            )
    except Exception as err:
        teams_alert(err, 'Automation log error')


def end_processing():
    """
    end_processing
        Function that call all functions that updates the SQL Database and email the final loag report.
    """
    ManualLoadReport()
    ManualLoadReportValues()
    ManualLoadLogsValidations()
    ManualLoadLogsAdmin()
    send_log_report()


if __name__ == "__main__":
    start_time = time.time()
    write_to_log("Starting main program")
    try:
        pre_setup_check()
        initial_transfer()
        pre_process_validation()
        ecl_validation()
        ecl_stage_facts()
        update_report() # Update report table with endtime 
        get_report_from_df() # get_reports_from_db()
    except Exception as err:
        teams_alert(err, 'Automation')
    finally:
        end_time = time.time() - start_time
        msg = f"Manual load automation took {str(dt.timedelta(seconds=end_time))}"
        send_to_teams_channel(
            webhook=communications["teams_webhook_url"].format(teams_webhook_path),
            title=env_subj + communications['report']['alert'] + f'Automation completed.',
            message=msg
        )
        write_to_log(msg)
        write_to_log("End of automation program")
        end_processing()