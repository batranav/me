from ftplib import FTP
import os, parseYamlProperty
import AutomationLogging
from vault.secrets import get_ftp_secret

def push_files():
   server = 'transfer.seisint.com'
   logger = AutomationLogging.getLogger('push_dnc_eloqua_extract', True)
   pwd = get_ftp_secret(logger, server + '_marketing', secret='pwd')
   ftp = FTP(server)
   ftp.login('marketing', pwd)
   ftp.cwd('Exclusion Process')
   dncfile = open(os.path.join(parseYamlProperty.get_outbound_dir(),'marketing\\opt_outs.txt'), 'rb')
   ftp.storbinary('STOR opt_outs.txt', dncfile)
   dncfile.close()
   ftp.close()
   print('File uploaded')
if __name__ == '__main__':
   push_files()