#! /usr/bin/python

import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send(_from, _to, _cc, _subject, _msgList):
    
    # Create message container - the correct MIME type is multipart/alternative.
    msg = MIMEMultipart('alternative')
    msg['Subject'] = _subject
    msg['From'] = _from
    msg['To'] = _to
    msg['Cc'] = _cc

    #if _cc == '':
     #   _cc = []
    
    #assert type(_to)==list
    #assert type(_cc)==list

    # Create the body of the message (a plain-text and an HTML version).
    text = "Hi!\nHow..... are you?\nHere is the link you wanted:\nhttp://www.python.org"
    html = """\
    <html>
    <head></head>
    <body>
        <p>Hi!<br>
        How are you?<br>
        Here is the <a href="http://www.python.org">link</a> you wanted.
        </p>
    </body>
    </html>
    """

    # Record the MIME types of both parts - text/plain and text/html.
    part1 = MIMEText(text + _msgList, 'plain')
    part2 = MIMEText(_msgList, 'html')

    # Attach parts into message container.
    # According to RFC 2046, the last part of a multipart message, in this case
    # the HTML message, is best and preferred.
    #msg.attach(part1)
    msg.attach(part2)
    
    #msg.attach(_msgList)

    # Send the message via local SMTP server.
    s = smtplib.SMTP('appmail.risk.regn.net')
    # sendmail function takes 3 arguments: sender's address, recipient's address
    # and message to send - here it is sent as one string.
    #_to = _to + 'raju.nagarajan@lexisnexisrisk.com'
    s.sendmail(msg["From"], msg["To"].split(",") + msg["Cc"].split(","), msg.as_string())
    #s.sendmail(_from, _to, msg.as_string())
    s.quit()