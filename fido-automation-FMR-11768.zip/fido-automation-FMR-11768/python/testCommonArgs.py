import commonArgs

if __name__ == "__main__":
    commonArgs.parse()