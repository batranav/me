import gzip
import time
import zipfile
import shutil
import re
import io
import os
import glob
import subprocess
from subprocess import Popen, PIPE
import shutil
from os.path import isfile, join
from os import listdir
import fido_utils
import parseYamlProperty

def compressFolder(archiveFile, sourcefolder):
    p = Popen([parseYamlProperty.get_winrarpath() , "a", "-m5", "-ed", "-ep1", archiveFile, sourcefolder + "\\*"], shell=True, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate() 
    return p.returncode

def compressFolderwith7z(archiveFile, sourcefolder):
    p = Popen([parseYamlProperty.get_Fido7zpackExecutor(), archiveFile, sourcefolder], shell=True, stderr=PIPE)
    stdout, stderr = p.communicate() 
    return p.returncode

def zipuncompressformultiparts(compressedFileName, folderToUncompress, renameUncompressedFileName):
    try:
        my_zip = zipfile.ZipFile(compressedFileName)
        for file in my_zip.namelist():
            if my_zip.getinfo(file).filename.endswith('.txt'):
                my_zip.extract(file, folderToUncompress)
                # time.sleep(10)
                os.remove(folderToUncompress + '\\' + renameUncompressedFileName.replace('.zip','.txt')) if os.path.exists(folderToUncompress + '\\' + renameUncompressedFileName.replace('.zip','.txt')) else None
                os.rename(folderToUncompress + '\\' + my_zip.getinfo(file).filename,
                    folderToUncompress + '\\' + renameUncompressedFileName.replace('.zip','.txt'))
        my_zip.close()
    except OSError:
        print('Error while uncompress --- ' + compressedFileName)
        pass

    
def zipuncompressparts(commonSourceFiles, source, frequency):
    inbounddir = parseYamlProperty.get_inbound_dir(source) + source + '\\'
    today =  '20190917'#fido_utils.today
    folderToUncompress = inbounddir + '\\' + frequency + '\\working\\' + today
    folderToArchive = inbounddir + '\\' + frequency + '\\archived\\' + today
    folderToArchiveUnused = inbounddir + '\\' + frequency + '\\archived\\' + today
    source_dir = inbounddir + '\\' + frequency + '\\' + '2017' #today[0:4] 
    sourcezipfiles = []
    files = os.listdir(source_dir)
    for file in files:
        if os.path.splitext(file)[-1].lower() == '.zip':
            sourcezipfiles.append(file)
            
        elif os.path.splitext(file)[-1].lower() == '.gz':
            gzuncompress(source_dir + '\\' + file , folderToUncompress + file.replace('.gz', '.txt'))
            continue
        else:
            continue
    for y in range(0, len(sourcezipfiles)):
        for x in range(0, len(commonSourceFiles)):
            if sourcezipfiles[y].lower().find(commonSourceFiles[x].fidoname.lower()) >= 0:
                filename = commonSourceFiles[x].fidoname
        str = sourcezipfiles[y]
        namesplit = str[str.find(filename) + len(filename):len(str)]
        if len( ''.join(ch for ch in namesplit[0:namesplit.find('Full')] if ch.isdigit()) ) == 0:
            Year = namesplit[namesplit.find('Full')+4:namesplit.find('Full')+8]
        else:
            Year = namesplit[0 : namesplit.find('Full')]
        YearMonth = namesplit[namesplit.find('Full')+4:namesplit.find('Full')+10]
        version_num = Year + 'Full' + namesplit[namesplit.find('Full')+4:len(namesplit)]
        # ''.join(ch for ch in sourcezipfiles[y] if ch.isdigit())
        try:
            my_zip = zipfile.ZipFile(source_dir + '\\' + sourcezipfiles[y])
            for file in my_zip.namelist():
                if my_zip.getinfo(file).filename.endswith(".txt"):
                    os.remove(folderToUncompress + '\\' + my_zip.getinfo(file).filename) if os.path.exists(folderToUncompress + '\\' + my_zip.getinfo(file).filename) else None
                    os.remove(folderToUncompress + '\\' + my_zip.getinfo(file).filename.replace('.txt', version_num + '.txt')) if os.path.exists(folderToUncompress + '\\' + my_zip.getinfo(file).filename.replace('.txt', version_num + '.txt')) else None

                    my_zip.extract(file, folderToUncompress)
                    os.rename(folderToUncompress + '\\' + my_zip.getinfo(file).filename,
                    folderToUncompress + '\\' + file.replace('.txt', version_num + '.txt'))
        except Exception as ex:
            print(  ' Issue with zip file is ' + my_zip.filename )                            
        
    txtfileList = []
    basefilenamelist = []
    files = os.listdir(folderToUncompress)
    for file in files:
        if file.endswith('.txt'):
            txtfileList.append(file)
            filenameclean = file.lower().replace('.zip', '').replace('.txt','').replace('full', '')
            basefilenamelist.append(''.join(ch for ch in filenameclean if ch.isalpha()))
    for x in range(0, len(commonSourceFiles)):
        if commonSourceFiles[x].fidoname.lower() in basefilenamelist:
            # with open(folderToUncompress + '\\' + commonSourceFiles[x].fidoname + '_' + today + '.txt', "wb+") as fout:
            if commonSourceFiles[x].fidoname in ['snlDataItem', 'snlStatPCEntity', 'snlAccountingPrinciple','snlCurrency','snlStatLOB']:
                fout = open(folderToUncompress + '\\' + commonSourceFiles[x].fidoname + '_' + today + '.txt', "w+")
            else:
                fout = open(folderToUncompress + '\\' + commonSourceFiles[x].fidoname + '_' + today + '.txt', "wb+")
            for y in range(0, len(txtfileList)):
                filename = commonSourceFiles[x].fidoname
                str = txtfileList[y]
                namesplit = str[str.find(filename) + len(filename):len(str)]
                if len(namesplit[0:namesplit.find('Full')]) == 0:
                    Year = namesplit[namesplit.find('Full')+4:namesplit.find('Full')+8]
                else:
                    Year = namesplit[0 : namesplit.find('Full')]
                YearMonth = namesplit[namesplit.find('Full')+4:namesplit.find('Full')+10]
                if ''.join(ch for ch in txtfileList[y].lower().replace('.zip', '').replace('full', '').replace('.txt','') if ch.isalpha())  == commonSourceFiles[x].fidoname.lower():
                    if commonSourceFiles[x].fidoname in ['snlDataItem', 'snlStatPCEntity', 'snlAccountingPrinciple','snlCurrency', 'snlStatLOB']:
                        for line in open(folderToUncompress + '\\' + txtfileList[y],'r'):
                            newline = line.replace('#@#@#', '\'~\'' + Year[0:4] + '\'~\'' + YearMonth + '\n')
                            # newline = line.replace('#@#@#', '~' + Year + '~' + YearMonth)
                            fout.write(newline)
                    else:
                        for line in open(folderToUncompress + '\\' + txtfileList[y],'rb'):
                            newline = line.decode('utf-8').replace('#@#@#', '\'~\'' + Year[0:4] + '\'~\'' + YearMonth + '\n').encode('utf-8')
                            # newline = line.replace('#@#@#', '~' + Year + '~' + YearMonth)
                            fout.write(newline)
                    os.remove(folderToUncompress + '\\' + txtfileList[y]) if os.path.exists(folderToUncompress + '\\' + txtfileList[y]) else None
            fout.close()

    unusedfiles = [name for name in os.listdir(folderToUncompress) if today not in name]
    if not os.path.exists(folderToArchiveUnused):
        os.mkdir(folderToArchiveUnused)
    for x in range(0, len(unusedfiles)):
        shutil.move( folderToUncompress + '\\' + unusedfiles[x], folderToArchiveUnused + '\\' + unusedfiles[x] )
    compressFolderPattern(folderToArchiveUnused + '\\'+source + '_' + frequency + '_' + today + '.zip', folderToArchiveUnused, '')
    unUsedFiles_archived = folderToArchiveUnused + "\\" + "*.txt"
    for unUsedFile in glob.glob(unUsedFiles_archived):
        os.remove(unUsedFile)
        # logger.debug(unUsedFile)
    # attrs = [o.fidoname for o in commonSourceFiles]
    # try:
    #     for x in range(0, len(set(attrs))): 
    #         with open(folderToUncompress + '\\' + commonSourceFiles[x].fidoname, "w+") as fout:
    #             for y in range(0, len(commonSourceFiles)):
    #                 if commonSourceFiles[y].sourcename == commonSourceFiles[x].sourcename:
    #                     my_zip = zipfile.ZipFile(source_dir + '\\' + commonSourceFiles[y].sourcename)
    #                     for file in my_zip.namelist():
    #                         if my_zip.getinfo(file).filename.endswith(".txt"):
    #                             my_zip.extract(file, folderToUncompress)
    #                             # with open(folderToUncompress + '\\' + my_zip.getinfo(file).filename,'rb') as fin:
    #                             for line in open(folderToUncompress + '\\' + my_zip.getinfo(file).filename,'r'):
    #                                 fout.write(line)
    #                             os.remove(folderToUncompress + '\\' + my_zip.getinfo(file).filename) if os.path.exists(folderToUncompress + '\\' + my_zip.getinfo(file).filename) else None
    #                             # fin.close()
    #                     my_zip.close()
    #         fout.close()
    # except Exception as ex:
    #     print('Control am dying here!' + ex)
    #     pass

#  with open("testlist.txt") as f1, open("testerlist.txt") as f2, \
#             open("accounts.txt", "w") as f3:
#         f1_lines = f1.readlines()
#         f3.write(f1_lines[0].strip())
#         f3.write(f2.read().strip())
#         f3.writelines(f1_lines[1:])

def gzuncompress(compressedFileName, renameUncompressedFileName, logger=None):

    with gzip.open(compressedFileName, 'rb') as f_in:
        with open(renameUncompressedFileName, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out,length=16*1024*1024)

    f_in.close()
    f_out.close()

def unPackWith7z(compressedFileName, renameUncompressedFileName, logger=None):
    # e option extracts file name
    # -aoa	Overwrite All existing files without prompt.
    # -so (write data to stdout) switch
    # -bs p2, e2, o2 mean progress, error and output are written to stdErr since data is written to standard out
    p = subprocess.Popen([parseYamlProperty.get_Fido7zunpackExecutor() , compressedFileName, renameUncompressedFileName], shell=True, stderr=PIPE)

    stdout, stderr = p.communicate()
    if(logger != None):
        logger.debug("In UnpackFiles {0}".format(stderr))
    return p.returncode

def zipuncompress(compressedFileName, renameUncompressedFileName, logger=None):
    zipFile = zipfile.ZipFile(compressedFileName, 'r')

    if logger is not None:
        logger.debug('Compressed File Name in zipuncompress {0}, {1}'.format(compressedFileName, renameUncompressedFileName))

    for zName in zipFile.namelist():
        print(zName)
        fout = open(renameUncompressedFileName, 'wb')
        fout.write(zipFile.read(zName))
        fout.close()

    zipFile.close()

# def decompressToFolder(compressedFileName, folderToUncompress, renameUncompressedFileName, logger=None):

#     ext = os.path.splitext(compressedFileName)[-1].lower()
    
#     if logger is not None:
#         logger.debug('Compressed File Name in DECOMPRESSToFolder {0}, {1}'.format(compressedFileName, renameUncompressedFileName))
    
#     if ext == '.zip':
#         zipuncompress(compressedFileName, renameUncompressedFileName)
#     elif ext == '.gz':
#         unPackWith7z(compressedFileName, renameUncompressedFileName, logger)

def decompressToFolder(compressedFileName, folderToUncompress, renameUncompressedFileName, compressedArchivedFileName, logger=None):

    ext = os.path.splitext(compressedFileName)[-1].lower()
    
    if logger is not None:
        logger.debug('Compressed File Name in DECOMPRESSToFolder {0}, {1}'.format(compressedFileName, renameUncompressedFileName))
    
    if ext == '.zip':
        return unPackWith7z(compressedFileName, renameUncompressedFileName, logger)
    elif ext == '.gz':
        return unPackWith7z(compressedFileName, renameUncompressedFileName, logger)
    
    #shutil.move(compressedFileName, compressedArchivedFileName)
    
    '''with gzip.open(compressedFileName, 'rb') as f_in:
        with open(renameUncompressedFileName, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    '''

'''def decompressToFolder(compressedFileName, folderToUncompress, renameUncompressedFileName):
    print(folderToUncompress)
    p = Popen(["C:\\apps\\winrar\\winrar.exe", "-o+", "x", compressedFileName, folderToUncompress], shell=True, stdout=subprocess.PIPE)
    stdout, stderr = p.communicate()
    compressedFile = os.path.split(compressedFileName)
    uncompressedFolder = os.path.dirname(renameUncompressedFileName)
    uncompressedFileName = uncompressedFolder + "\\" + compressedFile[1].replace(".gz", "") 
    print('Compressed File {0}'.format(compressedFile))
    print('Uncompressed Folder {0}'.format(uncompressedFolder))
    print('CompressedFileName ..{0}'.format(compressedFileName))
    print('UncompressedFileName .. {0}'.format(uncompressedFileName))
    print('Rename UncompressedFileName .. {0}'.format(renameUncompressedFileName))
    if p.returncode == 0:
            os.replace(uncompressedFileName, renameUncompressedFileName)
'''
def safeMoveFiles(folder, filename):

    if not os.access(folder, os.F_OK):
        os.mkdir(folder)  
    
    print ('In safeMovefiles...{0} ... {1}'.format(folder, filename))
    basename = os.path.basename(filename)
    absfilename = folder + '\\' + basename
    try:
        os.remove(absfilename)
    except OSError:
        pass
    shutil.move(filename, folder)

def compressFolderPattern(archiveFile, sourcefolder, pattern):
    fileList = glob.glob(sourcefolder + "\\*" + pattern + "*.*")
    if fileList:
        p = Popen([parseYamlProperty.get_winrarpath(), "a", "-m5", "-ed", "-ep1", archiveFile, sourcefolder + "\\*" + pattern + "*.*"], shell=True, stdout=subprocess.PIPE)
        stdout, stderr = p.communicate()
        return p.returncode
    else:
        return 0

def compressfilewith7z(archiveFile, sourcefile):
    p = Popen([parseYamlProperty.get_Fido7zpackExecutor(), archiveFile, sourcefile], shell=True, stderr=PIPE)
    stdout, stderr = p.communicate()
    return p.returncode
    
def compressFolderPatternwith7z(archiveFile, sourcefolder, pattern="*"):
    
    fileList = glob.glob(sourcefolder + "\\*" + pattern + "*.*")
    sourcefolder_with_pattern = os.path.join(sourcefolder , "*{0}*.*".format(pattern))
    if fileList:
        # p = Popen(["C:\\apps\\winrar\\winrar.exe", "a", "-m5", "-ed", "-ep1", archiveFile, sourcefolder + "\\*" + pattern + "*.*"], shell=True, stdout=subprocess.PIPE)
        p = Popen([parseYamlProperty.get_Fido7zpackExecutor(), archiveFile, sourcefolder_with_pattern], shell=True, stderr=PIPE)
        # p = Popen(["C:\\apps\\7-Zip\\7z.exe", "a", "-mx1", "-sdel", archiveFile, sourcefolder + "\\*" + pattern + "*.*"], shell=True, stderr=PIPE)
        stdout, stderr = p.communicate()
        return p.returncode
    else:
        return 0

def removeFiles(folder):
    shutil.rmtree(folder)

if __name__ == "__main__":

    compressFolderPatternwith7z(os.path.join(parseYamlProperty.get_inbound_dir(), 'mbs\\daily\\archive\\20200523_old\\20200524\\temp'),
                                os.path.join(parseYamlProperty.get_inbound_dir(), 'mbs\\daily\\archive\\20200523_old\\20200524'), '20200524')