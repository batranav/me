import ftplib
import parseYamlProperty
import os
import AutomationLogging
from vault.secrets import get_ftp_secret

def pushfilesToHyperion():
    logger = AutomationLogging.getLogger('preprocess_ftpfiles_forecast')
    server = '192.168.221.29'
    uname, pwd = get_ftp_secret(logger, server)
    ftp_connection = ftplib.FTP(server, uname, pwd)

    try:
        ftp = ftplib.FTP(server)
    except ftplib.all_errors as e:
        print("FTP connection issue:", e)
    else:
        print("Successfully established connection to ", server)
        try:
            ftp.login(uname, pwd)
        except ftplib.all_errors as e:
            print("FTP login issue: ", e)
        else:
            print("Successfully logged in with ", uname)
            remote_path = "/HyperionData/fido"
            ftp_connection.cwd(remote_path)
            #fh = open("D:/rbi/data/extracts/RBI_Revenue_Extract_Forecast.csv", 'rb')
            fh = open(os.path.join(parseYamlProperty.get_app_dir(),"data/extracts/RBI_Revenue_Extract_Forecast.csv"), 'rb')
            ftp_connection.storbinary('STOR RBI_Revenue_Extract_Forecast.csv', fh)
            fh.close()
            ftp.close()
            return True
    raise RuntimeError("Couldn't establish an FTP connection.")

if __name__ == "__main__":
    print(pushfilesToHyperion()) 