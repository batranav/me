import sys, requests, os, time, ssl
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import parseYamlProperty, os
import AutomationLogging
from vault.secrets import get_api_secret
import commonArgs
yesterday = datetime.now() - timedelta(days=1)
sd=yesterday.strftime('%Y/%m/%d')+' 00:00:01'
ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_contourlog_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')

logger = AutomationLogging.getLogger('preprocess_innotas_contour_update')
uname, pwd = get_api_secret(logger, 'innotas')
SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:login>
         <!--Optional:-->
         <ser:username>{uname}</ser:username>
         <!--Optional:-->
         <ser:password>{pwd}</ser:password>
      </ser:login>
   </soapenv:Body>
</soapenv:Envelope>""".encode(encoding = 'utf-8')

print(SoapMessage)
proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
url = "lexisnexis.ppmpro.com"
post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

session = requests.session()
session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}


no_of_attempts = 120
for x in range(0, no_of_attempts):
   response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
   print("status_code:", response.status_code)
   if response.status_code == 429:
      print(response.headers["Retry-After"])
      time.sleep(int(response.headers["Retry-After"]))
      x += 1
   else:
      break

print("status_code:", response.status_code)
print(SoapMessage)
result = response.content
print(result)

with open('temp_contour.xml','wb') as f:
    f.write(result)
	
f.close()
tree = ET.parse('temp_contour.xml')

sessionId = tree.find('.//{http://services}return').text


SoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:getUpdateHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>54</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:showRepeatingPerDay>false</ser:showRepeatingPerDay>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
      </ser:getUpdateHistory>
   </soapenv:Body>
</soapenv:Envelope>""".replace('{!!!!!}', sessionId).replace('{???}', sd).replace('{?????}', ed).encode(encoding = 'utf-8')

print(SoapMessage)
print("here1")

#construct and send the header

proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
url = "lexisnexis.ppmpro.com"
post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

session = requests.session()
session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getUpdateHistory"}

no_of_attempts = 120
for x in range(0, no_of_attempts):
   response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
   print("status_code:", response.status_code)
   if response.status_code == 429:
      print(response.headers["Retry-After"])
      time.sleep(int(response.headers["Retry-After"]))
      x += 1
   else:
      break

print("status_code:", response.status_code)
print(SoapMessage)
result = response.content
print(result)

open('temp_contour.xml','wb').write(result)

tree = ET.ElementTree(file='temp_contour.xml')
entityIds = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]



DefaultSoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
		<ser:selectEntity>
			<ser:sessionId>{sessionID}</ser:sessionId>
			<ser:entityTypeId>54</ser:entityTypeId> 
			<ser:entityId>{entityID}</ser:entityId>		
			<ser:fieldsRequest>5405</ser:fieldsRequest>	
			<ser:fieldsRequest>5411</ser:fieldsRequest>		
		</ser:selectEntity>  
	</soapenv:Body> 
</soapenv:Envelope>"""                                                                                                                                                               

fileOutput = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_contour_' + datetime.now().strftime('%Y%m%d') + '.txt'),'a')

for entityId in entityIds:

   SoapMessage = DefaultSoapMessage.replace('{entityID}',entityId).replace('{sessionID}',sessionId).encode(encoding = 'utf-8') 
   proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
   url = "lexisnexis.ppmpro.com"
   post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

   session = requests.session()
   session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:selectEntity"}
   
   no_of_attempts = 120
   for x in range(0, no_of_attempts):
      response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
      print("status_code:", response.status_code)
      if response.status_code == 429:
         print(response.headers["Retry-After"])
         time.sleep(int(response.headers["Retry-After"]))
         x += 1
      else:
         break  
         
   print("status_code:", response.status_code)
   print(SoapMessage)
   result = response.content
   print(result)


   open('temp_contour.xml','wb').write(result)
   tree = ET.parse('temp_contour.xml')
   
   dates = [x.text for x in tree.findall('.//{http://objects.services/xsd}elementValue')]
   print(entityId)
   print(dates)
   if not dates  : continue
   
   startdatex=datetime.strptime(dates[1], "%m/%d/%Y").strftime("%Y/%m/%d")
   enddatex=datetime.strptime(dates[0], "%m/%d/%Y").strftime("%Y/%m/%d")

   print (entityId)
   print(startdatex)
   print(enddatex)
   
   SoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
         <soapenv:Header/>
         <soapenv:Body>
            <ser:getContour>
               <!--Optional:-->
               <ser:sessionId>{sessionID}</ser:sessionId>
               <!--Optional:-->
               <ser:entityTypeId>54</ser:entityTypeId>
               <!--Optional:-->       
               <ser:entityId>{entityID}</ser:entityId>         
               <!--Optional:-->
               <ser:startDate>{startdatex}</ser:startDate>
               <!--Optional:-->
               <ser:endDate>{enddatex}</ser:endDate>  
            </ser:getContour>
            </soapenv:Body>
         </soapenv:Envelope>""".replace('{sessionID}', sessionId)
      
   entityId = 0 if entityId == '' else entityId
      
   SoapMessage = SoapMessage.replace('{entityID}',entityId).replace('{startdatex}',startdatex).replace('{enddatex}',enddatex).encode(encoding = 'utf-8')
      
      #print (SoapMessage) 
      
   proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
   url = "lexisnexis.ppmpro.com"
   post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

   session = requests.session()
   session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getContour"}

   no_of_attempts = 120
   for x in range(0, no_of_attempts):
      response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
      print("status_code:", response.status_code)
      if response.status_code == 429:
         print(response.headers["Retry-After"])
         time.sleep(int(response.headers["Retry-After"]))
         x += 1
      else:
         break  
         
   print("status_code:", response.status_code)
   print(SoapMessage)
   result = response.content
   print(result)
      
   open('temp_contour.xml','wb').write(result)
   tree = ET.parse('temp_contour.xml')
      
   allocationStartDates = [x.text for x in tree.findall('.//{http://objects.services/xsd}allocationStartDate')]
   allocationEndDates = [x.text for x in tree.findall('.//{http://objects.services/xsd}allocationEndDate')]
   entityId = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
   entityTypeId = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
   entryDates = [x.text for x in tree.findall('.//{http://objects.services/xsd}entryDate')]
   entryHours = [x.text for x in tree.findall('.//{http://objects.services/xsd}entryHours')]

   for i in range(0,len(entryDates)):
      fileOutput.write(allocationEndDates[0] + '\t'+allocationStartDates[0] + '\t'+ entityId[0]+'\t'+ entityTypeId[0]+ '\t'+ entryDates[i] +'\t'+ entryHours[i]  +'\n')

fileOutput.close()
os.remove('temp_contour.xml')
