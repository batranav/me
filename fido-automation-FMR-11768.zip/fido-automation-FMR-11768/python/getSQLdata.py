import json
import sys
from collections import namedtuple
import commonArgs
import traceback
import getProperties
from vault.secrets import get_db_secret

MySQLSource = namedtuple('MySQLSource', ['mysqlsource', 'frequency', 'filename', 'fidoname', 'sql_server', 'dbmapid', 'username', 'password', 'script_name', 'trustedconnection', 'drivername','databasename','port','servertype'])
sql_file_name = getProperties.getSQLJsonFilename()
sqlCred_file_name = getProperties.getSQL_credJsonFilename()

def getSourcePullInfo_RBI(logger, source, frequency, filename):
    with open(sql_file_name, 'r') as jr_file:
        jsonRef = json.load(jr_file)
    with open(sqlCred_file_name, 'r') as scr_file:
        sqlcredRef = json.load(scr_file)

    # get dbname from jsonRef
    json_dict = {k:v for s in jsonRef for k,v in s.items()}  # flatten jsonRef to dict for easy access
    src = json_dict[source]  # list of src data at that index
    fidonames = {s.pop('fidoname'):s for s in src}  # flatten list of src data for easy access
    filesrc = fidonames[filename]  # we want the data where fidoname == filename
    dbname = filesrc['dbmapid']  # dbname for which we need sql creds
    script_name = filesrc['script_name']  # script_name to be returned in MySQLSource

    # get source data from sqlcredRef using dbname as key
    sqlCred_dict = {k:v[0] for s in sqlcredRef for k,v in s.items()}  # flatten sqlcredRef for easy access
    sqlsrc = sqlCred_dict[dbname]
    # find uname and pwd in Vault
    uname, pwd = get_db_secret(logger, dbname)
    return MySQLSource(source, frequency, filename, filename, sqlsrc['sql_server'], dbname, uname, pwd, script_name,
                       sqlsrc['trustedconnection'], sqlsrc['drivername'], '', '', '')


def getSourcePullInfo_NonRbi(logger, source, frequency, filename):
    with open(sql_file_name, 'r') as jr_file:
        jsonRef = json.load(jr_file)
    with open(sqlCred_file_name, 'r') as scr_file:
        sqlcredRef = json.load(scr_file)

    # get dbname from jsonRef
    json_dict = {k:v for s in jsonRef for k,v in s.items()}  # flatten jsonRef to dict for easy access
    src = json_dict[source][0]  # list of src data at that index
    srvName = src['dbmapid']  # srvName for which we need sql creds
    dbname = src['database'] if 'database' in src else ''

    # get source data from sqlcredRef using dbname as key
    sqlCred_dict = {k:v[0] for s in sqlcredRef for k,v in s.items()}  # flatten sqlcredRef for easy access
    sqlsrc = sqlCred_dict[srvName]
    # find uname and pwd in Vault
    uname, pwd = get_db_secret(logger, srvName)
    return MySQLSource(source, frequency, filename, '', sqlsrc['sql_server'], srvName, uname, pwd, '',
                       sqlsrc['trustedconnection'], sqlsrc['drivername'], dbname, sqlsrc['port'], sqlsrc['servertype'])

def getSourcePullInfo(logger, source, frequency, filename):
    # for RBI sources including bulldog
    if commonArgs.getApplication().upper() == 'RBI':
        sqldet = getSourcePullInfo_RBI(logger, source, frequency, filename)
        connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+';DATABASE='+sqldet.dbmapid+';UID='+sqldet.username+';PWD='+sqldet.password+';'
    # for RED sources
    else:
        sqldet = getSourcePullInfo_NonRbi(logger, source, frequency, filename)
        if(sqldet.databasename==''):
            if(sqldet.servertype=='sqlserver'):
                if(sqldet.port!=''):
                    connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+','+sqldet.port+';UID='+sqldet.username+';PWD='+sqldet.password+';'
                else:
                    connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+';UID='+sqldet.username+';PWD='+sqldet.password+';'
            else:
                connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+';PORT='+sqldet.port+';UID='+sqldet.username+';PWD='+sqldet.password+';'
        else:
            if(sqldet.servertype=='sqlserver'):
                if(sqldet.port!=''):
                    connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+','+sqldet.port+';DATABASE='+sqldet.databasename+';UID='+sqldet.username+';PWD='+sqldet.password+';'
                else:
                    connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+';DATABASE='+sqldet.databasename+';UID='+sqldet.username+';PWD='+sqldet.password+';'
            else:
                connstr = 'Trusted Connection='+sqldet.trustedconnection+';DRIVER='+sqldet.drivername+';SERVER='+sqldet.sql_server.replace('\\\\','\\')+';PORT='+sqldet.port+';DATABASE='+sqldet.databasename+';UID='+sqldet.username+';PWD='+sqldet.password+';'
    # return connection string for rbi, bulldog and red sources
    return connstr, sqldet.script_name


if __name__ == "__main__":

    try:
        # print(getSourcePullInfo('accuityiban', 'daily', ''))
        # print(getSourcePullInfo('accuityba', 'daily', 'trial'))
        # SQLJSONData = getSourcePullInfo('accuityiban', 'daily', 'datedconversionrate')
        # print(SQLJSONData[0].username)        
        # print(SQLJSONData[0].fidoname)        
        # print(SQLJSONData[0].dbmapid)
        # print(SQLJSONData[0].username)
        # print(SQLJSONData[0].script_name)
        pass

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print(processerrorMsg)