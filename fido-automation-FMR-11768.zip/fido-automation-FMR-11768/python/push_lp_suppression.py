import ftplib
import os, parseYamlProperty
import AutomationLogging
from vault.secrets import get_ftp_secret

def upload(ftp, file):
    print(os.path.basename(file))
    myfile = open(file, 'rb')
    os.chdir(os.path.join(parseYamlProperty.get_outbound_dir(),"marketing"))
    ftp.storlines('STOR ' + os.path.basename(file), myfile)
    myfile.close()

if __name__ == "__main__":
    server = '138.12.17.31'
    logger = AutomationLogging.getLogger('push_lp_suppression', True)
    uname, pwd = get_ftp_secret(logger, server)
    ftp = ftplib.FTP(server)
    ftp.login(uname, pwd)
    upload(ftp, os.path.join(parseYamlProperty.get_outbound_dir(),"marketing\\lp_suppression.txt"))
    ftp.close()
    print('File uploaded')