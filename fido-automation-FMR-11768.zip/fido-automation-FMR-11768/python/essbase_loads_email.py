import sys
import sendEmail

def send_email(subject,body):  
    emailFrom = 'ERROR-Fido-RBI-Essbase-Cube-Load.automation@lexisnexisrisk.com'
    sendEmail.send(emailFrom, "fido.ops@lexisnexisrisk.com", 'rene.gibson@lexisnexisrisk.com', subject, body)
    return

if __name__ == "__main__":
    send_email(sys.argv[1],sys.argv[2])
             