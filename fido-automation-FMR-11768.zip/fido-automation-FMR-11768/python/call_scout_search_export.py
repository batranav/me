import pyodbc
import datetime
import codecs
import ecl_call_wrapper
from collections import namedtuple
import time
from ScoutExportNotification import ScoutExportNotification
from WorkunitInfo import WorkunitInfo
import re
import sendEmail
import sys
import datetime as dt
import math
import generateSearchExportHTML
from time import gmtime, strftime
import parseWUFullResults
import AutomationLogging
import parseYamlProperty
import os
from vault.secrets import get_db_secret

#print(cursor.description)
#print(len(cursor.description))
'''
_mySQLserver= 'dbdprsql-bct.risk.regn.net'
_mySQLserver= 'dbqprsql-bct.risk.regn.net'
'''
_mySQLserver= 'mbssql.br.seisint.com'
_mySQLUid = ''
_mySQLPwd = ''
_mySQLPort = '3306'

def getSearchExportIds():
    
    try:
        conn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=' + _mySQLserver + ';PORT=' + _mySQLPort + ';DATABASE=scout;UID=' + _mySQLUid + ';PASSWORD=' + _mySQLPwd + ';')

        cursor = conn.cursor()
        
        cpsql = "SELECT export.search_export_id, search.start_date, replace(export.user_added, '@risk',''), requester_email, search.search_name, search.end_date, search.product_id "\
                " FROM scout.mbs_search_export export, scout.mbs_search search "\
                " WHERE search.search_id = export.search_id and export.export_status_id = 0  limit 1"\
                " ; "
        
        sqltoexecute = cpsql
        
        print (sqltoexecute)
        
        cursor.execute(sqltoexecute)
        
        print('# Number of exports to be run : {0}'.format(cursor.rowcount))

        exportSearchList = []

        for (_exportSearchId, _searchInputStartDate, _exportRequestedUser, _exportRequestorEmail, _exportSearchName, _searchInputEndDate, _product_id) in cursor:
            exportSearch = ScoutExportNotification(_exportSearchId, _searchInputStartDate, _exportRequestedUser, _exportRequestorEmail, _exportSearchName, _searchInputEndDate, _product_id) 
            exportSearchList.append(exportSearch)
    
    except ValueError as error:
        print(error)
    except Exception as ex:
        print(ex)
    finally:
        cursor.close()
        conn.close()
        return exportSearchList


def create_export_ecl (source, parameter, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7):
    templateBaseFolder = parseYamlProperty.get_ecl_script_dir()
    if source.lower() == 'searchexport':
        searchExportId = parameter
        eclTemplateFilename = templateBaseFolder + "search_export_template.ecl"
        eclFileName = "search_export_" + str(searchExportId) + ".ecl"
    elif source.lower() == 'summaryreport':
        summaryReportId = parameter
        eclTemplateFilename = templateBaseFolder + "summary_report_template.ecl"
        eclFileName = "summary_report_" + str(summaryReportId) + ".ecl"  
    
    eclFileToExecuteFilename = os.path.join(parseYamlProperty.get_generated_ecl_dir(), eclFileName)
           
    fs = open(eclTemplateFilename, 'r')
    fnew = open(eclFileToExecuteFilename, 'w')
    
    for line in fs:
        if '<inParameter>' in line:
            line = line.replace('<inParameter>', str(parameter))
            print(line)
        if '<inParameter2>' in line:
            line = line.replace('<inParameter2>', str(parameter2))
            print(line)
        if '<inParameter3>' in line:
            line = line.replace('<inParameter3>', str(parameter3))
            print(line)
        if '<inParameter4>' in line:
            line = line.replace('<inParameter4>', str(parameter4))
            print(line)

        if '<inParameter5>' in line and parameter5 != None and parameter5 != '':
            line = line.replace('<inParameter5>', str(parameter5))
            print(line)
        if '<inParameter6>' in line and parameter6 != None and parameter6 != '':
            line = line.replace('<inParameter6>', str(parameter6))
            print(line)
        if '<inParameter7>' in line and parameter7 != None and parameter7 != '':
            line = line.replace('<inParameter7>', str(parameter7))
            print(line)

        if '<inParameter5>' in line and (parameter5 == None or parameter5 == ''):
            continue
        if '<inParameter6>' in line and (parameter6 == None or parameter6 == ''):
            continue
        if '<inParameter7>' in line and (parameter7 == None or parameter7 == ''):
            continue

        fnew.write(line)
    fs.close()
    fnew.close()
    print('ECL FileToExcute {0}'.format(eclFileToExecuteFilename))

    return eclFileToExecuteFilename

def invoke_export_ecl(logger, source, parameter, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7):
    print('inside - invoke_export')
    global _script_to_run

    _script_to_run = create_export_ecl(source, parameter, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7)

    (workunit, errorMsgs) = ecl_call_wrapper.call_ecl_async(logger, _script_to_run)

    print(errorMsgs)
    if errorMsgs:
        print('Processinng ERROR MSG \n\n\n')
        sys.tracebacklimit = None
        sys.stderr.write('\n'.join(errorMsgs))
        return (workunit, errorMsgs)
        # raise RuntimeError('Error creatinng WU')
    
    return (workunit, '')
    
def updateSearchExport(exportSearch, status):

    try:
        conn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=' + _mySQLserver + ';PORT=' + _mySQLPort + ';DATABASE=scout;UID=' + _mySQLUid + ';PASSWORD=' + _mySQLPwd + ';')
        cursor = conn.cursor()
        
        filePathStr  = ''

        data = ()
        if status == 1:
            data = (str(status), exportSearch.folderPath, str(exportSearch.searchId))
            filePathStr = ', report_path = ? '  
        else:
            data = (str(status), str(exportSearch.searchId))

        cpsql = (' UPDATE scout.mbs_search_export SET export_status_id = ? '  
                 + filePathStr + 
                 ' WHERE search_export_id = ? ;')
                  
        sqltoexecute = cpsql
        
        #print (sqltoexecute)
        
        cursor.execute(sqltoexecute, data)

        conn.commit()
    
    except ValueError as error:
        print(error)
 
    finally:
        cursor.close()
        conn.close()

def format_timedelta(value, time_format="{days} days, {hours2}:{minutes2}:{seconds2}"):

    if hasattr(value, 'seconds'):
        seconds = value.seconds + value.days * 24 * 3600
    else:
        seconds = int(value)

    seconds_total = seconds

    minutes = int(math.floor(seconds / 60))
    minutes_total = minutes
    seconds -= minutes * 60

    hours = int(math.floor(minutes / 60))
    hours_total = hours
    minutes -= hours * 60

    days = int(math.floor(hours / 24))
    days_total = days
    hours -= days * 24

    years = int(math.floor(days / 365))
    years_total = years
    days -= years * 365

    return time_format.format(**{
        'seconds': seconds,
        'seconds2': str(seconds).zfill(2),
        'minutes': minutes,
        'minutes2': str(minutes).zfill(2),
        'hours': hours,
        'hours2': str(hours).zfill(2),
        'days': days,
        'years': years,
        'seconds_total': seconds_total,
        'minutes_total': minutes_total,
        'hours_total': hours_total,
        'days_total': days_total,
        'years_total': years_total,
    })

def elapsedTime(newerDt, olderDt):
    #datetime.timedelta(0, 8, 562000)
    date_format = "%Y-%m-%d %H:%M:%S"
    a = datetime.datetime.strptime(str(olderDt), date_format)
    b = datetime.datetime.strptime(str(newerDt), date_format)
    c = b - a
    return format_timedelta(c, '{hours_total}:{minutes2}:{seconds2}')
 
def pull_files():

    logger = AutomationLogging.getLogger('scout_search_export', True)
    app_name='scout'
    global _mySQLUid, _mySQLPwd
    _mySQLUid, _mySQLPwd = get_db_secret(logger, _mySQLserver, app=app_name)

    exportSearchList = []

    try:
        exportSearchList = getSearchExportIds()

        print('--- alert list ---- {0}'.format(exportSearchList))

        if not exportSearchList:
            sys.tracebacklimit = None
            raise ScoutNoExportException
        workunitInfoSet = set()
        for exportSearch in exportSearchList:
            exportSearch.startTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            d1 = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')[0:10], "%Y-%m-%d")
            d2 = datetime.datetime.strptime(exportSearch.searchInputStartDate.strftime('%Y-%m-%d %H:%M:%S')[0:10], "%Y-%m-%d")
            start_yyyymm = datetime.datetime.strptime(exportSearch.searchInputStartDate.strftime('%Y-%m-%d %H:%M:%S')[0:7], "%Y-%m").strftime("%Y%m")
            end_yyyymm = datetime.datetime.strptime(exportSearch.searchInputEndDate.strftime('%Y-%m-%d %H:%M:%S')[0:7], "%Y-%m").strftime("%Y%m")
            product_id = exportSearch.product_id
            expSearchBoundary = "ROXIE"
            if (d1 - d2).days >= 730:
                expSearchBoundary = "THOR"
            else:
                expSearchBoundary = "ROXIE"
            logger.debug('before to update search export  ')
            updateSearchExport(exportSearch, 2)
            logger.debug('Entering into ecl_call_wrapper to submit workunits ')
            (workunit, wuErrorMsg) = invoke_export_ecl(logger,'searchexport', exportSearch.searchId, exportSearch.requestedUser, 'prod', expSearchBoundary, start_yyyymm, end_yyyymm, product_id)
            logger.debug('completed ecl_call_wrapper to submit workunits ')
            exportSearch.workunit = workunit
            workunitinfo = WorkunitInfo(workunit)
            
            if wuErrorMsg != '':
                workunitinfo.message = wuErrorMsg
                workunitinfo.flag = False
                updateSearchExport(exportSearch, -1)
                exportSearch.completionTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                exportSearch.elapsedTime = elapsedTime(exportSearch.completionTime, exportSearch.startTime)
                return workunitinfo

            workunitInfoSet.add(workunitinfo)
            
            workunitCompletedList = []
        
        counter = len(workunitInfoSet)
        removeWUList = []

        print('Counter {0}'.format(counter))
        while counter > 0:
            removeFlag = False
            #removeWUInfo = ''
            for wuInfo in (wuInfo for wuInfo in workunitInfoSet if not wuInfo.workunit in removeWUList):
                (wuState, flag) = ecl_call_wrapper.getWUState(wuInfo.workunit)
                print('##1 Workunit {0}, {1}, {2}'.format(wuInfo.workunit, wuState, flag))
                if flag:
                    for exportSearch in (exportSearch for exportSearch in exportSearchList if not exportSearch.workunit in removeWUList):                    
                        if exportSearch.workunit == wuInfo.workunit:
                            wuInfo.flag = flag
                            wuInfo.state = wuState
                            workunitCompletedList.append(wuInfo)
                            exportSearch.workunitStatus = wuState
                            if wuState in ['failed', 'aborted']:
                                wuInfo.message = ecl_call_wrapper.getWUError(wuInfo.workunit)
                                exportSearch.workUnitMsg = wuInfo.message
                                try:
                                    exportSearch.searchInput = parseWUFullResults.getSearchInput(wuInfo.workunit)                    
                                except Exception as ex:
                                    print("Failed while parsing the workunit 'in parseWUFullResults' - {0} for the wuid {1}".format(str(ex), wuInfo.workunit))
                                # exportSearch.searchInput = parseWUFullResults.getSearchInput(wuInfo.workunit)
                                notifyEmail(exportSearch)
                                #print(wuInfo)
                            else:
                                try:
                                    (absolutePath, absoluteFileNameSet) = ecl_call_wrapper.getWUResults(wuInfo.workunit)                    
                                except Exception as ex:
                                    print("Failed while checking the status - {0} for the wuid {1}".format(str(ex), wuInfo.workunit))
                                print(exportSearch.searchId, exportSearch.requestedUserEmail)
                                x = absolutePath.replace('F:','\\\\alawpsafil200')
                                exportSearch.folderPath = x
                                for absFileName in absoluteFileNameSet:
                                    y = absFileName.replace('F:','\\\\alawpsafil200')
                                    exportSearch.set_of_exportedFiles.add(y)
                                try:
                                    exportSearch.searchInput = parseWUFullResults.getSearchInput(wuInfo.workunit)                    
                                except Exception as ex:
                                    print("Failed while parsing the workunit 'in parseWUFullResults' - {0} for the wuid {1}".format(str(ex), wuInfo.workunit))

                                # exportSearch.searchInput = parseWUFullResults.getSearchInput(wuInfo.workunit)
                                notifyEmail(exportSearch)

                            counter = counter - 1
                            removeFlag = True
                            removeWUList.append(wuInfo.workunit)
                            break
                        
                    print('What is the removeWUList {0}'.format(removeWUList))
                    print('Wat is the counter now {0}'.format(counter))
                else:
                    time.sleep(5)

        notifyAuditEmail(exportSearchList)
        print('Printing Completed WU List : {0}'.format(workunitCompletedList))
    except ScoutNoExportException:
        print('There are no Exports to run at this time!')
    except Exception as ex:
            notifyErrorEmail(str(ex))

def notifyEmail(exportSearch):
    emailFrom = 'fido.automation@lexisnexisrisk.com'
    emailTo = exportSearch.requestedUserEmail #'raju.nagarajan@lexisnexisrisk.com'
    #emailTo = 'raju.nagarajan@lexisnexisrisk.com'
    subject = 'Scout Search Export for ' + str(exportSearch.searchId)
    exportSearch.completionTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    exportSearch.elapsedTime = elapsedTime(exportSearch.completionTime, exportSearch.startTime)
    updateSearchExport(exportSearch, 1)
    msg = generateSearchExportHTML.generate(exportSearch)
    #msgList = msg + '\n' + '\nfile:\\'.join(exportSearch.set_of_exportedFiles)
    print('Printing in NotifyEmail {0}'.format(exportSearch))
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com', subject, msg)     

def notifyAuditEmail(exportSearchList):
    emailFrom = 'fido.automation@lexisnexisrisk.com'
    emailTo = 'raju.nagarajan@lexisnexisrisk.com'
    subject = 'Scout Search Export (Audit) for ' + strftime("%Y-%m-%d %H:%M:%S", gmtime())
    msg = generateSearchExportHTML.generateAudit(exportSearchList)
    sendEmail.send(emailFrom, emailTo, 'Margaret.worob@lexisnexisrisk.com', subject, msg)   

def notifyErrorEmail(msg):
    emailFrom = 'fido.automation@lexisnexisrisk.com'
    emailTo = 'raju.nagarajan@lexisnexisrisk.com'
    subject = 'Error :: Scout Search Export for ' + strftime("%Y-%m-%d %H:%M:%S", gmtime())
    sendEmail.send(emailFrom, emailTo, 'Margaret.worob@lexisnexisrisk.com', subject, msg)   

class ScoutNoExportException(Exception):
    pass

if __name__ == '__main__':
    pull_files()	
    # logger = AutomationLogging.getLogger('scout_search_export')
    # (workunit, wuErrorMsg) = ecl_call_wrapper.invoke_export_ecl(logger,'searchexport', '17299', 'stokje01', 'prod', 'ROXIE')
    # print(workunit)
    # getSearchExportIds()