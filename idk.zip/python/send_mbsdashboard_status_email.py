import send_email
import parseYamlProperty
import platform
import commonArgs
import datetime

emailfrom = "LOGS-Fido."+ "MBSDASHBOARD" + ".automation@lexisnexisrisk.com"
filename = parseYamlProperty.get_build_logs_dir() + '\\mbs_dashboard\\batch\\middaybatchlogs\\MBSdashboard.txt'
servername = platform.node()
myApplication = commonArgs.getSource()
dt = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
dtstr = datetime.datetime.strptime(dt, '%Y%m%d%H%M%S%f').strftime('%m-%d-%Y_%H%M%S')

EmailSubject = servername + '-- ' + myApplication +' MBS Dashboard Update - ' + dtstr 

send_email.send_mail_file(emailfrom, ['Nyruthya.Sanandan@lexisnexisrisk.com'], [], EmailSubject, filename)