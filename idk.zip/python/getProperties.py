import commonArgs
import os

def getPropertyDir():
    application_name = commonArgs.getApplication()
    base_path_override = commonArgs.getBasePathDir()

    base_path_dir = base_path_override if base_path_override != '' else os.environ.get('FIDO_automation_scripts', 'D:\\' + application_name + '\\scripts\\')
    if(commonArgs.getSkipenv()):  
        prop_dir_path = 'D:\\' + application_name + '\\scripts\\' + application_name + '\\properties\\'
    else:
        prop_dir_path = os.path.join(base_path_dir, application_name,'properties')
    return prop_dir_path

def getYamlFilename():
    application_name = commonArgs.getApplication()
    yaml_file_name = os.path.join(getPropertyDir(), application_name + '.yaml')
    return yaml_file_name

def getJsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '.json')
    return json_file_name

def getFTPJsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '_ftp.json')
    return json_file_name

def getSQLJsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '_sql.json')
    return json_file_name

def getSQL_credJsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '_sql_cred.json')
    return json_file_name

def getKeepassJsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '_keepass.json')
    return json_file_name

def getKeepass_credJsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '_keepass_cred.json')
    return json_file_name

def getS3JsonFilename():
    application_name = commonArgs.getApplication()
    json_file_name = os.path.join(getPropertyDir(), application_name + '_s3.json')
    return json_file_name

def getVaultFilename():
    vault_file_name = os.path.join(getPropertyDir(), 'vault_crypt.key')
    return vault_file_name

if __name__ == "__main__":
    print(getPropertyDir())
    print(commonArgs.getBasePathDir())