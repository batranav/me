import pyodbc
from datetime import datetime
import codecs
import parseYamlProperty
import AutomationLogging 
from vault.secrets import get_db_secret

logger = AutomationLogging.getLogger('preprocess_workday_ppm')
uname, pwd = get_db_secret(logger, 'RETDAYSQLP102')


def attempt_strip(x):
    try:
        return x.strip()
    except AttributeError:
        return x

def checkNone(x):
    if x is None:
        return ('')
    else:
        return(x)

def pull_files():
    cnxn = pyodbc.connect('Trusted Connection=yes;DRIVER={ODBC Driver 17 for SQL Server};SERVER=RETDAYSQLP102.lexisnexis.com,1433;DATABASE=emplauth;UID='+uname+';PWD='+pwd)
    cursor = cnxn.cursor()	
    sqltoexecute = "SELECT [EMPLID],[NAME],[EMAIL_ADDR],[DEPTID],[LOCATION_DESCR],[PER_ORG],[BUSINESS_UNIT],[COMPANY_DESCR],[BUSINESS_TITLE],[HIRE_DT],[SUPERVISOR_ID],[SUPERVISOR_NAME],[RE_LVL04_SUPVNAME],[RE_LVL05_SUPVNAME],[RE_LVL06_SUPVNAME],[RE_LVL07_SUPVNAME],[STD_HOURS] FROM [Emplauth].[dbo].[GBL_PPMPRO_VW]"
    cursor.execute(sqltoexecute)    
    f = open(parseYamlProperty.get_inbound_dir()+'\\workday\\daily\\workday_ppm_' + datetime.now().strftime('%Y%m%d') + '.txt','w')
    while 1:
        row = cursor.fetchone()
        iterator = range(0, len(cursor.description)).__iter__()
        col = ''
        outStr = []
        result = ''
        if not row:
            break
        for idx in iterator:
            col = checkNone(attempt_strip(row[idx]))
            if idx > 0:
                outStr.append('|') 
                outStr.append(col)
            else:
                outStr.append(col)
        result = ''.join([str(i) for i in outStr])
        f.write(result.encode("ascii", "ignore").decode() + '\n')
    f.close()

if __name__ == '__main__':
   pull_files()