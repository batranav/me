#import datetime
from datetime import datetime
import shutil
import os, parseYamlProperty

class GracefullyExit(Exception):
    pass

def getToday():
   today = datetime.now()
   return today.strftime("%Y%m%d")

def printwrapper(str, errorFlag=False):
    print(str)
    if errorFlag:
       printList.reverse()
       printList.append(str)
       printList.reverse()
    else:
       printList.append(str)

def createlog(source):
    #print(len(printList))
    if len(printList) > 0:
        logfile = open(os.path.join(parseYamlProperty.get_build_logs_dir(), 'DataPull\\'+source +'_' + datetime.now().strftime('%m-%d-%Y_%H_%M_%S')), 'w')
        for str in printList:
            logfile.write('%s\n' %str)
        logfile.close()

 
def process():
    global printList
    printList = []
    print(getToday())
    
    assignmentfilename      = os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\SALES_ASSIGNMENTS_' + getToday() + '.txt')
    otherfilename           = os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\SALES_ASSIGNMENTS_OTHERS.txt')
    assignmentfinalfilename = os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\SALES_ASSIGNMENTS_FINAL_' + getToday() + '.txt')
    
    archive_dir		    = os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\archive')
    
    archive_assignmentfilename = archive_dir + '\\ORIGINAL_SALES_ASSIGNMENTS_' + getToday() + '.txt'
    try:
       shutil.copy2('\\\\file.br.seisint.com\\backoffice\\RAA\\Nightly_Extract\\sales_org.txt', os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\sales_org_' + getToday() + '.txt'))
       printwrapper("File copy successful for sales_org. Timestamp is {0}".format(datetime.now().strftime('%m-%d-%Y_%H_%M_%S'))) 
    except IOError as e: 
       printwrapper("Unable to copy file sales_org. Error is {0}. Timestamp is {1}".format(e,datetime.now().strftime('%m-%d-%Y_%H_%M_%S')),True)
    try:
       shutil.copy2('\\\\file.br.seisint.com\\backoffice\\RAA\\Nightly_Extract\\SALES_ASSIGNMENTS.txt',assignmentfilename)
       printwrapper("File copy successful for SALES_ASSIGNMENTS. Timestamp is {0}".format(datetime.now().strftime('%m-%d-%Y_%H_%M_%S'))) 
    except IOError as e:
       printwrapper("Unable to copy file SALES_ASSIGNMENTS. Error is {0}. Timestamp is {1}".format(e,datetime.now().strftime('%m-%d-%Y_%H_%M_%S')),True)
    try:
       shutil.copy2('\\\\file.br.seisint.com\\backoffice\\RAA\\Nightly_Extract\\TERTIARY_ASSIGNMENTS.txt', os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\TERTIARY_ASSIGNMENTS_' + getToday() + '.txt'))
       printwrapper("File copy successful for TERTIARY_ASSIGNMENTS. Timestamp is {0}".format(datetime.now().strftime('%m-%d-%Y_%H_%M_%S')))   
    except IOError as e:
       printwrapper("Unable to copy file TERTIARY_ASSIGNMENTS. Error is {0}. Timestamp is {1}".format(e,datetime.now().strftime('%m-%d-%Y_%H_%M_%S')),True)
    try:
       shutil.copy2('\\\\file.br.seisint.com\\backoffice\\RAA\\Nightly_Extract\\HOUSEHOLD_ASSIGNMENTS.txt', os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\HOUSEHOLD_ASSIGNMENTS_' + getToday() + '.txt'))
       printwrapper("File copy successful for HOUSEHOLD_ASSIGNMENTS. Timestamp is {0}".format(datetime.now().strftime('%m-%d-%Y_%H_%M_%S')))   
    except IOError as e:
       printwrapper("Unable to copy file HOUSEHOLD_ASSIGNMENTS. Error is {0}. Timestamp is {1}".format(e,datetime.now().strftime('%m-%d-%Y_%H_%M_%S')),True)

    shutil.copy2(assignmentfilename,assignmentfinalfilename);  
    
    destfile = open(os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\SALES_ASSIGNMENTS_FINAL_' + getToday() + '.txt'), 'wb')
    shutil.copyfileobj(open(assignmentfilename, 'rb'), destfile)
    destfile.close()
    
    lines = []
    
    try:
       otherf = open(otherfilename,'r')
       lines = otherf.readlines()[1:]
       otherf.close()
       print(len(lines))
    except FileNotFoundError:
       return lines
    
    with open(os.path.join(parseYamlProperty.get_inbound_dir(),'accountassign\\daily\\SALES_ASSIGNMENTS_FINAL_' + getToday() + '.txt'), 'a') as newdestfile:
       for str in lines:
          newdestfile.write(str)
    
    newdestfile.close()
    
    assignmentbase_filesize = os.stat(assignmentfilename).st_size
    assignmentfinal_filesize = os.stat(assignmentfinalfilename).st_size
    
    print(assignmentbase_filesize);
    print(assignmentfinal_filesize);
    
    if assignmentfinal_filesize >= assignmentbase_filesize:
    
       try:
          os.stat(archive_dir)
       except:
          os.mkdir(archive_dir)
       
       if os.path.exists(archive_assignmentfilename):
          print('File already exists {0} .. removing'.format(archive_assignmentfilename))
          printwrapper('File already exists {0} .. removing'.format(archive_assignmentfilename))
          os.remove(archive_assignmentfilename)
          
       os.rename(assignmentfilename, archive_assignmentfilename)
       os.rename(assignmentfinalfilename, assignmentfilename)
       
if __name__ == '__main__':
   try:
     process()
   except GracefullyExit as ex:
     printwrapper('\n\n{0}'.format(ex.args[0]))
   finally:
     printwrapper('\n**********\nAll Done!\n**********')
     createlog('accountassign')