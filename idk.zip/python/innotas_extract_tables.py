import sys, requests, os, time, ssl
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret
import commonArgs

yesterday = datetime.now() - timedelta(days=1)
threemonthsprior = datetime.now() - timedelta(days=90)

def frameMessage(entityId, fieldIds):
    firstpart = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">    <soapenv:Header/> <soapenv:Body> <ser:selectEntity> <ser:sessionId>{sessionID}</ser:sessionId> <ser:entityTypeId>' + entityId + '</ser:entityTypeId> <ser:entityId>{entityID}</ser:entityId> '
    strparts = fieldIds.split(',')
    for y in range(0, len(strparts)):
        firstpart += '<ser:fieldsRequest>' + strparts[y] + '</ser:fieldsRequest>'
    firstpart += '</ser:selectEntity>   </soapenv:Body> </soapenv:Envelope>'

    return firstpart

def pullInnotasDataUsingSOAP(table_name, entity_type_id, start_dt, field_list):

    yesterday = datetime.now() - timedelta(days=1)


    sd=start_dt
    ed=yesterday.strftime('%Y/%m/%d')+' 23:59:59'
    sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_'+ table_name +'log_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
    logger = AutomationLogging.getLogger('preprocess_innotas_extract_tables')
    uname, pwd = get_api_secret(logger, 'innotas')
    SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
       <soapenv:Header/>
       <soapenv:Body>
          <ser:login>
             <!--Optional:-->
             <ser:username>{uname}</ser:username>
             <!--Optional:-->
             <ser:password>{pwd}</ser:password>
          </ser:login>
       </soapenv:Body>
    </soapenv:Envelope>""".encode(encoding='utf-8')

    print(SoapMessage)

    #construct and send the header


    proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
    url = "lexisnexis.ppmpro.com"
    post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

    session = requests.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
    
    no_of_attempts = 120
    for x in range(0, no_of_attempts):
        response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
        print("status_code:", response.status_code)
        if response.status_code == 429:
            print(response.headers["Retry-After"])
            time.sleep(int(response.headers["Retry-After"]))
            x += 1
        else:
            break  

    print("status_code:", response.status_code)
    print(SoapMessage)
    result = response.content
    print(result)
    
    with open('temp_' + table_name + '.xml','wb') as f:
        f.write(result)
        
    f.close()
    tree = ET.parse('temp_' + table_name + '.xml')

    sessionId = tree.find('.//{http://services}return').text

    SoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:getUpdateHistory>
            <!--Optional:-->
            <ser:sessionId>""" + sessionId + """</ser:sessionId>
            <!--Optional:-->
            <ser:entityTypeId>""" + entity_type_id + """</ser:entityTypeId>
            <!--Optional:-->
            <ser:startYYYYMMDD>""" + sd + """</ser:startYYYYMMDD>
            <!--Optional:-->
            <ser:endYYYYMMDD>""" + ed + """</ser:endYYYYMMDD>
            <!--Optional:-->
            <ser:showRepeatingPerDay>false</ser:showRepeatingPerDay>
            <!--Optional:-->
            <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
        </ser:getUpdateHistory>
    </soapenv:Body>
    </soapenv:Envelope>"""

    print(SoapMessage)

    #construct and send the header

    proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
    url = "lexisnexis.ppmpro.com"
    post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

    session = requests.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getUpdateHistory"}

    no_of_attempts = 120
    for x in range(0, no_of_attempts):
        response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
        print("status_code:", response.status_code)
        if response.status_code == 429:
            print(response.headers["Retry-After"])
            time.sleep(int(response.headers["Retry-After"]))
            x += 1
        else:
            break

    print("status_code:", response.status_code)
    print(SoapMessage)
    result = response.content
    print(result)

    open('temp_' + table_name + '.xml','wb').write(result)

    tree = ET.ElementTree(file='temp_' + table_name + '.xml')

    if table_name == 'workgroup':
        entityIds1 = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
        entityIds=set(entityIds1)
    else:
        entityIds = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]     

    DefaultSoapMessage = frameMessage(entity_type_id, field_list)                                                                                                                                                                                           

    output_handle = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_' + table_name + '_' + datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding='utf-8')

    for entityId in entityIds:
        SoapMessage = DefaultSoapMessage.replace('{entityID}',entityId).replace('{sessionID}',sessionId)
        proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
        url = "lexisnexis.ppmpro.com"
        post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

        session = requests.session()
        session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:selectEntity"}

        no_of_attempts = 120
        for x in range(0, no_of_attempts):
            response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
            print("status_code:", response.status_code)
            if response.status_code == 429:
                print(response.headers["Retry-After"])
                time.sleep(int(response.headers["Retry-After"]))
                x += 1
            else:
                break  

        print("status_code:", response.status_code)
        print(SoapMessage)
        result = response.content
        print(result)
        open('temp_' + table_name + '.xml','wb').write(result)
        
        tree = ET.ElementTree(file='temp_' + table_name + '.xml')
        output_handle.write(entityId + '||')
        '''for x in tree.findall('.//{http://objects.services/xsd}elementValue'):
            print(x.text)
            y = x.text
            output_handle.write(y)
                '''
        output_handle.write('||'.join([(x.text or '').replace('\r\n','    ').replace('\n','     ').replace('\r','     ') for x in tree.findall('.//{http://objects.services/xsd}elementValue')]))
        output_handle.write('\n')
    
    output_handle.close()
    os.remove('temp_' + table_name + '.xml')

if __name__ == "__main__":
    pullInnotasDataUsingSOAP('project', '4', yesterday.strftime('%Y/%m/%d')+' 00:00:01', '447,739061628,757952169,100495,445,721705330,400006,100451,742241366,470,963344736,920177298,677993818,401,473,448,450,1075875139,910219415,677993278,100442,438,402,1100170653,1100165760,952182805,724196867,403,100492,100493,1056291362,476,481,910254718,495,496,440,742241549,859883436,913284736,400010,400009,744254704,723222210,723220228,100489,846416069,766756866,677992721,474,443,452,795607132,846416785,723224738,723223470,677992120,1252531058,428,475,446,435,742231841,742232046,757949016,410,776645692,942901704,100441,499,498,100469,100468,739056456,400013,742218691,677993424,742242930,100467,846417455,677993944,420,426,427,742242536,742242010,742243212,1194515080,742242242,677991680,777883644,846383393,1052911785,1052893933,742223498,681028850,415,416,407,458,743271836,100470,777882907,779052823,12425015,757960201,860665661,740756215,865270020,913300784,762558036,844901923,723259429,827068949,677992866,910212125,100491,100456,100444,790849473,100466,100476,913283233,739057025,742240213,742240619,742240478,456,677856775,677993575,779121624,790852552,400008,400007,758214167,677991608,411,677992997,855513919,795601338,677992384,961444906,1166770704,1052920189,100471,738963779,1207037806,436,400014,413,998427548,400012,400011,425,741325297,723112473,1514083469,1516240921,1551981991,1583340641,1771263448,1895687406,1934760221,1956893229,1956893636,1956960125,1956894193,1989511697,1989512787,1989511516,2036377901,2517653086,2404447755,1710763323,1710761805,2475723627,1675828905,2403612961,2413602163,2507894399,1771263448,757949016,2630083796,1896970754')
    pullInnotasDataUsingSOAP('allocation', '54', yesterday.strftime('%Y/%m/%d')+' 00:00:01', '5452,5425,5495,5424,5405,5429,5401,5498,5442,5421,5417,5440,5422,5411,5406,5423,5419') 
    pullInnotasDataUsingSOAP('workgroup', '38', '2012/01/01 00:00:01', '3805,3806,3803,3807,3804,3813,3814,3802') 
    pullInnotasDataUsingSOAP('changelog', '6', yesterday.strftime('%Y/%m/%d')+' 00:00:01', '617,615,616,1052098650,643,644,933824161,913308791,695,694,696,757910386,827592482,1052091827,635,697,699,698,605,801950725,801949417,801950137,801948642,606,816015623,1052114862,648,611,679,1052094549,636,612,613,623,625,1518954366')
    pullInnotasDataUsingSOAP('financial_entry', '300', yesterday.strftime('%Y/%m/%d')+' 00:00:01', '30059,30010,30033,2432210706,2432311545,2431705592,30066,2431705517,2434380800,2432207738,30002,30068,30013,30020,30046,30047,30009,30031')
    pullInnotasDataUsingSOAP('hierarchy_unit', '229', yesterday.strftime('%Y/%m/%d')+' 00:00:01', '22901,22909,22902')
    pullInnotasDataUsingSOAP('resource', '11', threemonthsprior.strftime('%Y/%m/%d') +' 23:59:59', '1133,1130,1131,1151446933,1116,1111,1186,101102,886554631,1195,1196,1113,1127,1188,1115,1109,1123,790722906,1168,1169,1103,790723950,1129,1132,1142,1141,676815943,676816072,1164,1107,1121,1117,1199,1198,1104,1135,1136,1119,1128,1150,101103,1137,1139,1138,818328425,1110,1124,1159,721957666,676816274,676815307,1170,1171,1101,1118,1163,1102,1114,1108,1122,1106,1112,1126,676816490,1151')