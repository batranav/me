import pyodbc
import datetime
import codecs
import ecl_call_wrapper
from collections import namedtuple
import time
from ScoutNotification import ScoutNotification
from WorkunitInfo import WorkunitInfo
import re
import sendEmail
import sys
import datetime as dt
import math
import generateAlertHTML
from time import gmtime, strftime
import parseWUFullResults
import argparse
import AutomationLogging
import commonArgs
import parseYamlProperty
import os
from vault.secrets import get_db_secret

#print(cursor.description)
#print(len(cursor.description))
'''
_mySQLserver= 'dbdprsql-bct.risk.regn.net'
_mySQLserver= 'dbqprsql-bct.risk.regn.net'
'''
_mySQLserver= 'mbssql.br.seisint.com'
_mySQLUid = ''
_mySQLPwd = ''
_mySQLPort = '3306'

def insertAlertTrigger(alertId, alertRunPeriod) :

    try :
        conn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=' + _mySQLserver + ';PORT=' + _mySQLPort + ';DATABASE=scout;UID=' + _mySQLUid + ';PASSWORD=' + _mySQLPwd + ';')

        cursor = conn.cursor()

        cpSQL = "INSERT INTO scout.hpcc_alert_trigger_tracking (alert_id, alert_trigger_tracking_status_id, date_added, alert_run_period, baseline_run_period) "\
                " VALUES ({0}, 1, now(), {1}, 0) ".format(alertId, alertRunPeriod)

        print (cpSQL)
        
        cursor.execute(cpSQL)
        
        conn.commit()

    except ValueError as error:
            print(error)
    finally:
        cursor.close()
        conn.close()

def updateAlertTrigger(alertRun, status) :

    try :
        conn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=' + _mySQLserver + ';PORT=' + _mySQLPort + ';DATABASE=scout;UID=' + _mySQLUid + ';PASSWORD=' + _mySQLPwd + ';')

        cursor = conn.cursor()

        alertInfo = alertRun.results

        (key1, prevRunPeriodValue)  = getAlertResultsInfo(alertInfo, 'Baseline --')
        (key2, currRunPeriodValue)  = getAlertResultsInfo(alertInfo, 'Current --')
        (key3, baselineRunPeriodValue)   = getAlertResultsInfo(alertInfo, 'Baseline --')
        (key4, alert_message)       = getAlertResultsInfo(alertInfo, 'Alert')
        alert_flag          = True

        cpSQL = " UPDATE scout.hpcc_alert_trigger_tracking "\
                " set alert_trigger_tracking_status_id = ?, "\
                " baseline_run_period = ?, "\
                " prev_run_period_value = ?, "\
                " curr_run_period_value = ?, "\
                " alert_flag = ?, "\
                " alert_message = ? "\
                " WHERE alert_id = ? AND alert_run_period = ?;"

        print (cpSQL)

        data = ()
         
        baselineRunPeriod = key3.split(' - ',1)[1].split('(',1)[0]

        data = (int(status), int(baselineRunPeriod), float(prevRunPeriodValue), float(currRunPeriodValue), bool(alert_flag), alert_message, int(alertRun.id), int(alertRun.alert_run_period))
        
        sqltoexecute = cpSQL
        cursor.execute(sqltoexecute, data)
        conn.commit()
        
    except ValueError as error:
            print(error)
    finally:
        cursor.close()
        conn.close()


def create_alert_ecl (parameter, parameter1, parameter2, parameter3, parameter4, parameter5, parameter6):

    # parameter = alertId
    # parameter1 = alertRunDate
    # parameter2 = alertTypeId
    # parameter3 = alertInputField
    # parameter4 = score_average_excluding_exceptions
    # parameter5 = score_median_excluding_exceptions

    #// -- alert_type_id  description                                         
    #// -- -------------  ----------------------------------------------------
    #// --             1  transaction volume change                            
    #// --             2  score/score band frequency change                   
    #// --             3  reason code/warning code/risk indicator frequency   
    #// --             4  data input field frequency change                   
    #// --             5  attribute distribution change                       
    #// --             6  response time change                                
    #// --             7  data restriction mask setting change               
    #// --             8  data permission mask setting change    
    
    inputFieldStr = ''
    percentTF = True

    if parameter2 == 1:
        inputFieldStr = 'total_transactions'
        percentTF = False
    elif parameter2 == 2:
        if parameter4 == 1:
            inputFieldStr = 'mean_score'
            percentTF = True
        elif parameter5 == 1:
            inputFieldStr = 'median_score'
            percentTF = True
        else:
            inputFieldStr = 'bin'
            percentTF = True
    elif parameter2 == 3:
        inputFieldStr = 'RC_' + parameter6
        percentTF = True
    elif parameter2 == 4:
        inputFieldStr = parameter3
        percentTF = True
    elif parameter2 == 6:
        inputFieldStr = 'response_time'
        percentTF = True
    
    alertId = parameter
    alert_run_period = parameter1
    templateBaseFolder = parseYamlProperty.get_ecl_script_dir()
    eclTemplateFilename = templateBaseFolder + "alert_template.ecl"
    eclFileName = "alert_" + str(alertId)  + '_' + str(alert_run_period) + ".ecl"
    eclFileToExecuteFilename = os.path.join(parseYamlProperty.get_generated_ecl_dir(), eclFileName)
           
    fs = open(eclTemplateFilename, 'r')
    fnew = open(eclFileToExecuteFilename, 'w')
    
    for line in fs:
        if '<inParameter>' in line:
            line = line.replace('<inParameter>', str(parameter))
            print(line)
        if '<inParameter1>' in line:
            line = line.replace('<inParameter1>', str(parameter1))
            print(line)
        if '<inParameter2>' in line:
            line = line.replace('<inParameter2>', str(parameter2))
            print(line)
        if '<inParameter3>' in line:
            line = line.replace('<inParameter3>', str(inputFieldStr))
        if '<inParameter4>' in line:
            line = line.replace('<inParameter4>',str(percentTF))

            print(line)    
        fnew.write(line)
    fs.close()
    fnew.close()
    print('ECL FileToExcute {0}'.format(eclFileToExecuteFilename))

    return eclFileToExecuteFilename

def invoke_alert_ecl(logger, parameter, parameter1, parameter2, parameter3, parameter4, parameter5, parameter6):
    
    global _script_to_run

    _script_to_run = create_alert_ecl(parameter, parameter1, parameter2, parameter3, parameter4, parameter5, parameter6)
    print('_script_to_run {0}'.format( _script_to_run))
    (workunit, errorMsgs) = ecl_call_wrapper.call_ecl_async(logger, _script_to_run)

    print(errorMsgs)
    if errorMsgs:
        print('Processinng ERROR MSG \n\n\n')
        sys.tracebacklimit = None
        sys.stderr.write('\n'.join(errorMsgs))
        return (workunit, errorMsgs)
        # raise RuntimeError('Error creatinng WU')
    
    return (workunit, '')



def getAlertRunPeriod(frequency) :
    x = 0
    try :
        conn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER=' + _mySQLserver + ';PORT=' + _mySQLPort + ';DATABASE=scout;UID=' + _mySQLUid + ';PASSWORD=' + _mySQLPwd + ';')

        cursor = conn.cursor()

        cpSQLWeek = "SELECT yearweek(curdate())"
        cpSQLMonth = "SELECT concat(year(curdate()), month(curdate()))"


        if frequency.upper() == 'WEEKLY':
            sqltoexecute = cpSQLWeek
        elif frequency.upper() == 'MONTHLY':
            sqltoexecute = cpSQLMonth
        else:
            raise RuntimeError('Frequency can\'t be empty')
        
        print (sqltoexecute)
        
        cursor.execute(sqltoexecute)
        
        data = cursor.fetchall()

        x = 0

        for row in data:
            x = row[0]
        
    except ValueError as error:
            print(error)
    finally:
        cursor.close()
        conn.close()
        print(x)
        return x

def getAlertIds(frequency):
    
    try:

        alert_run_period = getAlertRunPeriod(frequency)

        conn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=' + _mySQLserver + ';PORT=' + _mySQLPort + ';DATABASE=scout;UID=' + _mySQLUid + ';PASSWORD=' + _mySQLPwd + ';')

        cursor = conn.cursor()

        timeFrameFilter = ''

        if frequency.upper() == 'WEEKLY':
            timeFrameFilter = ' (1)'
        elif frequency.upper() == 'MONTHLY':
            timeFrameFilter = ' (2,3,4,5)'
        else:
            timeFrameFilter = ''
        
        cpsql = "SELECT "\
                "alert.alert_id, "\
                "alert.alert_name, "\
                "alert.user_added, "\
                "GROUP_CONCAT(recipient.email_address SEPARATOR ',') AS recipient_email_addresses, "\
                "alert.alert_type_id, "\
                "inputfield.inputfield, "\
                "alert.score_average_excluding_exceptions, "\
                "alert.score_median_excluding_exceptions, "\
                "GROUP_CONCAT(TRIM(reasoncodes.reasoncode) SEPARATOR ',') AS reason_codes "\
                "FROM "\
                "  scout.mbs_alert alert "\
                "  JOIN mbs_alert_type alert_type ON alert.alert_type_id = alert_type.alert_type_id "\
                "  LEFT JOIN mbs_alert_baseline_timeframe_type timeframe_type "\
                "  	ON alert.alert_baseline_timeframe_type_id = timeframe_type.alert_baseline_timeframe_type_id "\
                "  LEFT JOIN mbs_timeframe_date_range_type date_range_type "\
                " 	ON timeframe_type.timeframe_date_range_type_id = date_range_type.timeframe_date_range_type_id "\
                "  LEFT JOIN mbs_alert_reason_code alert_reason_codes "\
                " 	ON alert.alert_id = alert_reason_codes.alert_id AND alert_reason_codes.`status` = 1 "\
                "  LEFT JOIN mbs_recipient_list recipient_list "\
                "	ON alert.recipient_group_id = recipient_list.recipient_group_id AND recipient_list.`status` = 1 "\
                "  LEFT JOIN mbs_recipient recipient "\
                "	ON recipient_list.recipient_id = recipient.recipient_id "\
                "  LEFT JOIN meta_inputfields inputfield "\
                "	ON alert.inputfield_id = inputfield.inputfield_id "\
                "  LEFT JOIN meta_reasoncodes reasoncodes "\
                "	ON alert_reason_codes.reasoncode_id = reasoncodes.reasoncode_id "\
                " WHERE alert.status = 1 and alert.alert_id NOT IN "\
                " (select alert_id from scout.hpcc_alert_trigger_tracking where alert_run_period = " + str(alert_run_period) + " ) "\
                " AND timeframe_type.timeframe_date_range_type_id in  " +  str (timeFrameFilter) + " GROUP BY ALERT.ALERT_ID;"
        
        sqltoexecute = cpsql
        
        print ('Here .. ? {0}'.format(cpsql))
        
        cursor.execute(sqltoexecute)
        
        alertRunList = []
      
        for (_alertId,  _alertSearchName, _alertRequestedUser, _alertRequestorEmail, _alertTypeId, _alertInputField,  _alert_score_avg, _alert_score_median, _alert_reason_codes) in cursor:

            if (_alertId is None):
                sys.tracebacklimit = None
                raise RuntimeError('There are no alerts to run at this time!')
            
            alertRun = ScoutNotification(_alertId, _alertSearchName, _alertRequestedUser, _alertRequestorEmail) 
            alertRun.alert_run_period = str(alert_run_period)
            alertRun.alert_type_id = _alertTypeId
            alertRun.alert_input_field = _alertInputField
            alertRun.score_average_excluding_exceptions = _alert_score_avg
            alertRun.score_median_excluding_exceptions = _alert_score_median
            alertRun.alert_reason_codes = _alert_reason_codes
            alertRunList.append(alertRun)

    except ValueError as error:
        print(error)
 
    finally:
        cursor.close()
        conn.close()
        #print(alertRunList)
        return alertRunList

def format_timedelta(value, time_format="{days} days, {hours2}:{minutes2}:{seconds2}"):

    if hasattr(value, 'seconds'):
        seconds = value.seconds + value.days * 24 * 3600
    else:
        seconds = int(value)

    seconds_total = seconds

    minutes = int(math.floor(seconds / 60))
    minutes_total = minutes
    seconds -= minutes * 60

    hours = int(math.floor(minutes / 60))
    hours_total = hours
    minutes -= hours * 60

    days = int(math.floor(hours / 24))
    days_total = days
    hours -= days * 24

    years = int(math.floor(days / 365))
    years_total = years
    days -= years * 365

    return time_format.format(**{
        'seconds': seconds,
        'seconds2': str(seconds).zfill(2),
        'minutes': minutes,
        'minutes2': str(minutes).zfill(2),
        'hours': hours,
        'hours2': str(hours).zfill(2),
        'days': days,
        'years': years,
        'seconds_total': seconds_total,
        'minutes_total': minutes_total,
        'hours_total': hours_total,
        'days_total': days_total,
        'years_total': years_total,
    })

def elapsedTime(newerDt, olderDt):
    #datetime.timedelta(0, 8, 562000)
    date_format = "%Y-%m-%d %H:%M:%S"
    a = datetime.datetime.strptime(str(olderDt), date_format)
    b = datetime.datetime.strptime(str(newerDt), date_format)
    c = b - a
    return format_timedelta(c, '{hours_total}:{minutes2}:{seconds2}')

def getAlertResultsInfo(dict, srch):
    for key, value in dict.items():
        if key.startswith(srch):
            return (key, value)
    return('N/A', '')

def pull_files(frequency):

    logger = AutomationLogging.getLogger('scout_alerts', True)
    app_name='scout'
    global _mySQLUid, _mySQLPwd
    _mySQLUid, _mySQLPwd = get_db_secret(logger, _mySQLserver, app=app_name)

    alertRunList = []

    try:
        alertRunList = getAlertIds(frequency)

        #print(alertRunList)

        if not alertRunList:
            sys.tracebacklimit = None
            raise RuntimeError('There are no {0} alerts  to run at this time!'.format(frequency))

        workunitInfoSet = set()
        for alertRun in alertRunList:
            # add try/except to catch and bypass the ECL compilation issues we get, which will allow the other alerts to go.
            # without this try/except one alert failure, breaks flow
            try:
                logger.debug('In pull_files -- Try')
                alertRun.startTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                logger.debug('In pull_files -- Try -- alertRun StartTime {0}'.format(alertRun.startTime))
                insertAlertTrigger(alertRun.id, alertRun.alert_run_period)
                logger.debug('In pull_files -- Try -- after insertAlertTrigger')
                (workunit, wuErrorMsg) = invoke_alert_ecl(logger, alertRun.id, alertRun.alert_run_period, alertRun.alert_type_id, alertRun.alert_input_field, alertRun.score_average_excluding_exceptions, alertRun.score_median_excluding_exceptions, alertRun.alert_reason_codes)
                logger.debug('In pull_files -- Try -- workunit {0}, wuErrorMsg {1}'.format(workunit, wuErrorMsg))
                workunitinfo = WorkunitInfo(workunit)    
                alertRun.workunit = workunit
                workunitinfo = WorkunitInfo(workunit)            
                if wuErrorMsg != '':
                    workunitinfo.message = wuErrorMsg
                    workunitinfo.flag = False
                    #updateAlertTrigger(alertRun, -1)
                    alertRun.completionTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    alertRun.elapsedTime = elapsedTime(alertRun.completionTime, alertRun.startTime)
                    logger.debug('In pull_files -- Try -- in Error situation .. going to return')
                    # return workunitinfo
                else:
                    workunitInfoSet.add(workunitinfo)
            except Exception as ex:
                logger.debug('In pull_files -- except - ex {0}'.format(ex))
                print('ECL code failure - Cant raise a worknit for alert Id : ' + alertRun.id + str(ex))
            
            workunitCompletedList = []
        
        logger.debug('In pull_files -- Try -- after For loop')

        counter = len(workunitInfoSet)
        removeWUList = []

        print('Counter {0}'.format(counter))
        print('Alertrunlist {0}'.format(alertRunList))
        print('workunitInfoSet {0}'.format(workunitInfoSet))
        logger.debug('Counter {0}'.format(counter))
        logger.debug('Alertrunlist {0}'.format(alertRunList))
        logger.debug('workunitInfoSet {0}'.format(workunitInfoSet))        
        while counter > 0:
            removeFlag = False
            #removeWUInfo = ''
            for wuInfo in (wuInfo for wuInfo in workunitInfoSet if wuInfo.workunit != '' and not wuInfo.workunit in removeWUList):
                (wuState, flag) = ecl_call_wrapper.getWUState(wuInfo.workunit)
                print('##1 Workunit {0}, {1}, {2}'.format(wuInfo.workunit, wuState, flag))
                logger.debug('##1 Workunit {0}, {1}, {2}'.format(wuInfo.workunit, wuState, flag))
                if flag:
                    for alertRun in (alertRun for alertRun in alertRunList if not alertRun.workunit in removeWUList):                    
                        if alertRun.workunit == wuInfo.workunit:
                            print('on match for both alertRuns and WrokunitInfos -- {0}'.format(alertRun.workunit))                  
                            logger.debug('on match for both alertRuns and WrokunitInfos -- {0}'.format(alertRun.workunit))                  
                            wuInfo.flag = flag
                            wuInfo.state = wuState
                            workunitCompletedList.append(wuInfo)
                            alertRun.workunitStatus = wuState
                            if wuState in ['failed', 'aborted']:
                                wuInfo.message = ecl_call_wrapper.getWUError(wuInfo.workunit)
                                alertRun.workUnitMsg = wuInfo.message
                                alertRun.searchInput = parseWUFullResults.getAlertInput(wuInfo.workunit)
                                print('notifying on workunit failure {0}'.format(alertRun.workunit))
                                logger.debug('notifying on workunit failure {0}'.format(alertRun.workunit))
                                notifyEmail(alertRun)
                                #print(wuInfo)
                            else:
                                alertRun.searchInput = parseWUFullResults.getAlertInput(wuInfo.workunit)
                                alertRun.results = parseWUFullResults.getVarianceInfo(wuInfo.workunit)
                                print('notifying on workunit Success {0}'.format(alertRun.workunit))
                                logger.debug('notifying on workunit Success {0}'.format(alertRun.workunit))
                                notifyEmail(alertRun)

                            counter = counter - 1
                            removeFlag = True
                            print('added to removeWUList -- {0}'.format(wuInfo.workunit))
                            print('added to removeWUList -- {0}'.format(wuInfo.workunit))
                            removeWUList.append(wuInfo.workunit)
                            break
                        
                    print('What is the removeWUList {0}'.format(removeWUList))
                    logger.debug('What is the removeWUList {0}'.format(removeWUList))
                    print('Wat is the counter now {0}'.format(counter))
                    logger.debug('Wat is the counter now {0}'.format(counter))
                else:
                    time.sleep(5)

        notifyAuditEmail(alertRunList)
        print('Printing Completed WU List : {0}'.format(workunitCompletedList))
        logger.debug('Printing Completed WU List : {0}'.format(workunitCompletedList))
    except ScoutNoExportException:
        pass
    except Exception as ex:
        notifyErrorEmail(str(ex))
    
def notifyEmail(alertRun):
    emailFrom = 'fido.automation@lexisnexisrisk.com'
    emailTo = alertRun.requestedUserEmail #'raju.nagarajan@lexisnexisrisk.com'
    #emailTo = 'raju.nagarajan@lexisnexisrisk.com'

    if 'AlertIncrease' in alertRun.results.keys():
        alertRun.IncreaseOrDecrease = 'Increase'
    elif 'AlertDecrease' in alertRun.results.keys():
        alertRun.IncreaseOrDecrease = 'Decrease'
    else:
        alertRun.IncreaseOrDecrease = 'No Threshold change'
    subject = 'Scout Alert (' +  alertRun.IncreaseOrDecrease + ') for ' + str(alertRun.id) + ' (' + alertRun.name  + ') - Run Period : ' + str(alertRun.alert_run_period) 
    alertRun.completionTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    alertRun.elapsedTime = elapsedTime(alertRun.completionTime, alertRun.startTime)
    updateAlertTrigger(alertRun, 2)
    msg = generateAlertHTML.generate(alertRun)
    #msgList = msg + '\n' + '\nfile:\\'.join(alertRun.set_of_exportedFiles)
    print('Printing in NotifyEmail {0}'.format(alertRun))
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com,raja.sundarrajan@lexisnexisrisk.com', subject, msg)     

def notifyAuditEmail(alertRunList):
    emailFrom = 'fido.automation@lexisnexisrisk.com'
    emailTo = 'raju.nagarajan@lexisnexisrisk.com'
    subject = 'Scout Alert Export (Audit) for ' + strftime("%Y-%m-%d %H:%M:%S", gmtime())
    msg = generateAlertHTML.generateAudit(alertRunList)
    sendEmail.send(emailFrom, emailTo, 'Margaret.worob@lexisnexisrisk.com', subject, msg)   

def notifyErrorEmail(msg):
    emailFrom = 'fido.automation@lexisnexisrisk.com'
    emailTo = 'raju.nagarajan@lexisnexisrisk.com'
    subject = 'Error :: Scout Search Alert for ' + strftime("%Y-%m-%d %H:%M:%S", gmtime())
    sendEmail.send(emailFrom, emailTo, 'Margaret.worob@lexisnexisrisk.com', subject, msg)   

class ScoutNoExportException(Exception):
    print('There are no Alerts to run at this time!')
    pass

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='This is a SCOUT Alert run')
    parser.add_argument('-f', '--frequency', help='Frequency (daily / monthly)', required=True)
    args = commonArgs.getArgs()

    if args.frequency.lower() not in ['weekly', 'monthly']:
        parser.print_help()
        sys.exit(1)

    print('Here {0}'.format(args))
    pull_files(args.frequency)