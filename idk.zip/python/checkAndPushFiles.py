import time
import datetime
import getS3data
import boto3
import os
import parseYamlProperty
import AutomationLogging
import sys
import traceback
import commonArgs
import commonSourceInfo
import s3PushEmailAlert
import file_utils
import shutil
import fnmatch
import re
from boto3.s3.transfer import TransferConfig
import checkAndPushFiles_Azure
import checkAndPushFiles_sftp

def getDestinationFiles(source, frequency, date):
    global rbiOutboundFiles
    global rbiOutboundS3Files
    rbiOutboundFiles = commonSourceInfo.getOutboundFiles(source, frequency, date)
    rbiOutboundS3Files = commonSourceInfo.getOutboundS3Files(source, frequency, date)

def getOutboundRequiredS3Files(source, frequency, found):
    return [x for x in commonSourceInfo.getOutboundS3Files(source, frequency) if x.destination == source and x.frequency == frequency]

def getOutboundRequiredFiles(source, frequency, found):
    return [x for x in commonSourceInfo.getOutboundFiles(source, frequency) if x.destination == source and x.frequency == frequency]

def outbound_files(logger, source, frequency, date, env, requiredFilesFlag = False):

    global rbiInboundFiles
    global SFTPCallList
    global optionalFiles
    global requiredFiles
    global requiredS3Files
    global MissingRequiredFiles
    global ThreadPoolsize
    try:
        S3details = getS3data.getSourcePushInfo(source, env)
        bucketname = S3details[0].bucket
        session = boto3.Session(profile_name = S3details[0].profile)
        S3_client = session.client('s3')
 
        ThreadPoolsize = parseYamlProperty.get_threadpool_size(source, frequency)
        abort_after = 14400 #seconds
        sleep_time = 60

        timer_start = datetime.datetime.now().strftime('%Y%m%d%H%M%S')

        outboundFilesList = []
                
        requiredFiles = getOutboundRequiredFiles(source, frequency, False)
        requiredS3Files = getOutboundRequiredS3Files(source, frequency, False)

        for S3fileobject in requiredS3Files:
            s3_outgoing_folder = S3fileobject.relativedestinationFolder
            s3_working_folder = s3_outgoing_folder + 'working/'  

        path = os.path.join(parseYamlProperty.get_outbound_dir(), 's3', source)
        os_file_list = os.listdir(path)
        txt_only_list_all = fnmatch.filter(os_file_list, '*.txt')
        lookup_string = 'Aggregate'
        txt_only_list = []
        if requiredFilesFlag == True :
            for file_name in  txt_only_list_all :
                if file_name.find(lookup_string) == -1:
                    txt_only_list.append(file_name)
        else :
            for file_name in  txt_only_list_all :
                if file_name.find(lookup_string) > 0:
                    txt_only_list.append(file_name)

        yaml_files_list = []
        yaml_stg_files_list = []
        MissingRequiredFiles = []
        s3_working_folder_file_list = []
        
        if requiredFilesFlag == True :
            for f in requiredFiles :
                if f.absFidoFileName.find("Aggregate") == -1 :
                    yaml_files_list.append(f.absFidoFileName)             
        else :
            for f in requiredFiles :
                if f.absFidoFileName.find("Aggregate") > 0 :
                    yaml_files_list.append(f.absFidoFileName)
                else :
                    yaml_stg_files_list.append(f.absFidoFileName) 
                   
        if requiredFilesFlag == False :
            s3_working_file_list = S3_client.list_objects_v2(Bucket=bucketname, Prefix=s3_working_folder).get('Contents')
            for file_details in s3_working_file_list :
                # s3_file_keys.append(file_details["Key"])
                file_details["Key"] = re.sub(r'[^>]*?\/', '', file_details["Key"])
                s3_working_folder_file_list.append(file_details["Key"])            

            MissingRequiredFiles = getDeltas(yaml_stg_files_list, s3_working_folder_file_list)

        if len(MissingRequiredFiles) == 0 :
            MissingRequiredFiles = getDeltas(yaml_files_list, txt_only_list)
        
        requiredFilesCount = len(yaml_files_list)
        missingRequiredFilesCount = len(MissingRequiredFiles)
             
        return(requiredFilesCount, missingRequiredFilesCount)
        
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        print('\nException raised s3 push : {0}\n'.format(str(e)))
        flag = 0

def getDeltas(x, y):
    return (list(set(x) - set(y)))

def move_s3_files(logger, s3_bucket, s3_profile, source_key, target_key):     
    s3_move_flag = True
    func = 'move_s3_files'
    try:
        session = boto3.Session(profile_name = s3_profile)
        S3_client = session.resource('s3')        
        
        copy_source = {'Bucket': s3_bucket, 'Key': source_key}
        S3_client.meta.client.copy(copy_source, s3_bucket , target_key, ExtraArgs ={'ServerSideEncryption':'AES256'})
        S3_client.Object(s3_bucket,source_key).delete()
        logger.debug('{0} -> File moved from {1} to {2}'.format(func, source_key, target_key))
        print("File moved from working to outgoing bucket")
        
    except Exception as e:
        print("File was not moved from working to outgoing bucket")
        logger.debug('{0} -> File not moved from {1} to {2}'.format(func, source_key, target_key))
        s3_move_flag = False
    
    return s3_move_flag

def push_S3_files(logger, market, frequency, env, requiredFilesFlag = False):
    
    try:
        
        S3details = getS3data.getSourcePushInfo(market, env)
        print("s3details", S3details)
        bucketname = S3details[0].bucket

        session = boto3.Session(profile_name = S3details[0].profile)
        S3_client = session.client('s3')
        logger.debug('Received S3 details')

        s3_working_folder_file_list = []
        s3_file_keys = []

        path = os.path.join(parseYamlProperty.get_outbound_dir(), 's3', market)        
        path_working = os.path.join(path, 'working')
        path_archive = os.path.join(path, 'archive')

        os_file_list = os.listdir(path)
        txt_only_list = fnmatch.filter(os_file_list, '*.txt')

        requiredFiles = getOutboundRequiredFiles(market, frequency, False)
        yaml_files_list = []
        yaml_full_files_list = []
        MissingRequiredFiles = []
        if requiredFilesFlag == True :
            for f in requiredFiles :
                if f.absFidoFileName.find("Aggregate") == -1 :
                    yaml_files_list.append(f.absFidoFileName)             
        else :
            for f in requiredFiles :
                if f.absFidoFileName.find("Aggregate") > 0 :
                    yaml_files_list.append(f.absFidoFileName)
                # else :
                yaml_full_files_list.append(f.absFidoFileName) 

        if len(MissingRequiredFiles) == 0 :
            MissingRequiredFiles = getDeltas(yaml_files_list, txt_only_list)
        
        requiredS3Files = commonSourceInfo.getOutboundRequiredS3Files(market, 'daily')
        print("requiredS3Files",  requiredS3Files)
        timing_list = [['FileName', 'Start_Time', 'End_Time', 'Compression_Time', 'Upload_Time', 'Total_Time_Taken']]
        time_format = '%Y-%m-%d %H:%M:%S'
        starttime = datetime.datetime.now().strftime(time_format)
        logger.debug('\n \nUploading ' + market + ' data into ' + bucketname + '/' +  ' started \n')
        totalcompressionfiletdelta = datetime.timedelta(0)
        totaluploadfiletdelta = datetime.timedelta(0)
        config = TransferConfig(multipart_threshold=1024*1024, max_concurrency=100,
                        multipart_chunksize=1024*1024, use_threads=True)
        for S3fileobject in requiredS3Files:
            s3_outgoing_folder = S3fileobject.relativedestinationFolder
            s3_working_folder = s3_outgoing_folder + 'working/'
            if ((requiredFilesFlag and S3fileobject.absDestinationFileName.find('Aggregate') >= 0) or  (not requiredFilesFlag and S3fileobject.absDestinationFileName.find('Aggregate') == -1)):
                continue
            # print("Pushing ",S3fileobject.absDestinationFileName)            
            # continue
            logger.debug(S3fileobject)
            # logger.debug('Compression initiated .....')
            # compressionfilestarttime = datetime.datetime.now().strftime(time_format)
            # logger.debug('start time : ' + compressionfilestarttime)
            file_path = os.path.join(path, S3fileobject.absFidoFileName)            
            path_working_file = os.path.join(path_working, S3fileobject.fileDate, S3fileobject.absDestinationFileName)
            path_archive_file = os.path.join(path_archive, S3fileobject.absDestinationFileName)
                        
            s3_working_folder_path = s3_working_folder + S3fileobject.absDestinationFileName
            
            logger.debug('S3 upload initiated .....')
            Uploadfilestarttime = datetime.datetime.now().strftime(time_format)
            logger.debug('start time : ' + Uploadfilestarttime)
            
            S3_client.upload_file(file_path, bucketname, s3_working_folder_path, ExtraArgs = {'ServerSideEncryption': 'AES256'}, Config=config)
            
            Uploadfileendtime = datetime.datetime.now().strftime(time_format)
            logger.debug('end time : ' + Uploadfileendtime)
            Uploadfiletdelta = datetime.datetime.strptime(Uploadfileendtime, time_format) - datetime.datetime.strptime(Uploadfilestarttime, time_format)
            totaluploadfiletdelta = totaluploadfiletdelta + Uploadfiletdelta
            logger.debug('Upload completed in : {0}'.format(Uploadfiletdelta))
            
            logger.debug('archive initiated....')
            logger.debug('Compression initiated .....')
            compressionfilestarttime = datetime.datetime.now().strftime(time_format)
            logger.debug('start time : ' + compressionfilestarttime)
            file_utils.compressfilewith7z(path_archive_file.replace('.txt', '.7z'), file_path)
            compressionfileendtime = datetime.datetime.now().strftime(time_format)
            logger.debug('end time : ' + compressionfileendtime)
            compressionfiletdelta = datetime.datetime.strptime(compressionfileendtime, time_format) - datetime.datetime.strptime(compressionfilestarttime, time_format)
            logger.debug('Compression completed in : {0}'.format(compressionfiletdelta))
            totalcompressionfiletdelta = totalcompressionfiletdelta + compressionfiletdelta
            totalfiletdelta = datetime.datetime.strptime(compressionfileendtime, time_format) - datetime.datetime.strptime(Uploadfilestarttime, time_format)
            logger.debug('Compress + Upload completed in : {0}'.format(totalfiletdelta))

            timing_list.append([S3fileobject.absDestinationFileName, '{0}'.format(compressionfilestarttime) , '{0}'.format(Uploadfileendtime) , '{0}'.format(compressionfiletdelta) , '{0}'.format(Uploadfiletdelta) , '{0}'.format(totalfiletdelta)])
                        
            logger.debug('archive completed')
        # shutil.rmtree(path_working)
        endtime = datetime.datetime.now().strftime(time_format)
        tdelta = datetime.datetime.strptime(endtime, time_format) - datetime.datetime.strptime(starttime, time_format)
        timing_list.append(['Total Time', '{0}'.format(starttime) , '{0}'.format(endtime) , '{0}'.format(totalcompressionfiletdelta), '{0}'.format(totaluploadfiletdelta) , '{0}'.format(tdelta)])
        logger.debug('\n*************************************************************')        
    
        if requiredFilesFlag == False :
            s3_working_file_list = S3_client.list_objects_v2(Bucket=bucketname, Prefix=s3_working_folder).get('Contents')
            for file_details in s3_working_file_list :
                if re.sub(r'[^>]*?\/', '', file_details["Key"]) in yaml_full_files_list :
                    s3_file_keys.append(file_details["Key"])
                    file_details["Key"] = re.sub(r'[^>]*?\/', '', file_details["Key"])
                    s3_working_folder_file_list.append(file_details["Key"])                

            MissingRequiredFiles = getDeltas(yaml_full_files_list, s3_working_folder_file_list)

        if len(MissingRequiredFiles) == 0 and requiredFilesFlag == False:
            for source_key in s3_file_keys:
                file_path = source_key
                file_name_only = re.sub(r'[^>]*?\/', '', file_path)
                target_key = s3_outgoing_folder + file_name_only
                
                flag = move_s3_files(logger, bucketname, S3details[0].profile, source_key, target_key)
                if not flag:
                    logger.debug('\n\nFile {} not moved'.format(source_key))

        for f in timing_list:
            logger.debug(f)

        return timing_list   

    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        print('\nException raised s3 push : {0}\n'.format(str(e)))
        flag = 0

def process(args, logger):
    source = args.source
    frequency = args.frequency
    debug = args.debug
    date = args.date
    env = args.env   
    requiredFilesFlag = args.skipFindAllrequired
    skips3push = args.skips3push
    skipazurepush = args.skipazurepush
    global requiredFiles   

    if not commonSourceInfo.hasOutboundFiles(source, frequency):
        logger.debug('No push files defined for {0} - {1}'.format(source, frequency))
        return

    logger.debug('Inside PushFiles Process')
    if date == '':
        date = datetime.datetime.now().strftime("%Y%m%d")

    logger.debug('Processing for {0}'.format(date))

    requiredFilesCount = 0
    missingRequiredFilesCount = 0
    if skips3push == False and len(commonSourceInfo.getOutboundS3Files(source, frequency, date)) > 0:
        [requiredFilesCount, missingRequiredFilesCount] = outbound_files(logger, source, frequency, date, env, requiredFilesFlag) 
    if skipazurepush == False and len(commonSourceInfo.getOutboundAzureFiles(source, frequency, date)) > 0:
        checkAndPushFiles_Azure.process()
    if len(commonSourceInfo.getOutboundFilesSftp(source, frequency, date)) > 0:
        (missingRequiredFilesCount, requiredFilesCount) = checkAndPushFiles_sftp.process()
    
    # if missingRequiredFilesCount > 0:
    #     raise Exception('S3 push required file(s) are missing')
    countDict = {}
    countDict['RequiredFilesCount'] = requiredFilesCount
    countDict['OptionalFilesCount'] = 0
    countDict['Missing-RequiredFilesCount'] = missingRequiredFilesCount
    countDict['Missing-OptionalFilesCount'] = 0

    push_timings = []
    
    if skips3push == False and len(commonSourceInfo.getOutboundS3Files(source, frequency, date)) > 0 and missingRequiredFilesCount == 0:
        push_timings = push_S3_files(logger, source, frequency, env, requiredFilesFlag)
        requiredfiles_missing = []
        for f in requiredFiles:
            if f.absFidoFileName in MissingRequiredFiles:
                requiredfiles_missing.append(f)
        if missingRequiredFilesCount  > 0 :
            s3PushEmailAlert.notifyEmail(debug, countDict, requiredfiles_missing, push_timings, len(MissingRequiredFiles) > 0 , ['destination','fileDate','frequency'], 's3')
        else :
            s3PushEmailAlert.notifyEmail(debug, countDict, requiredFiles, push_timings, len(MissingRequiredFiles) > 0 , ['destination','fileDate','frequency'], 's3')
if __name__ == "__main__":
    # logger = AutomationLogging.getLogger('checkAndPushFiles')
    # push_S3_files('icissd', logger)
    # print(outbound_files(logger, 'icissd','daily', '20200101'))
    # print(getOutboundRequiredFiles('icissd','daily', False))
    try:
        args = commonArgs.parse()
        logger = AutomationLogging.getLogger('checkAndPushFiles')
        print("Chack and push")
        process(args, logger)

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print("Error : ", processerrorMsg)   
        logger.debug(processerrorMsg) 