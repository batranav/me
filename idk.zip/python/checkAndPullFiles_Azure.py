import time
import datetime
import os
import parseYamlProperty
import AutomationLogging
import sys
import traceback
import commonArgs
import commonSourceInfo
import s3PushEmailAlert
import file_utils
import shutil
import fido_utils
import fnmatch
import re
import subprocess
import getkeepassdata

compressedExtensions = ['gz', 'zip', 'rar', '7z']
# revisit
def getSourceFiles(source, frequency, date):
    global commonAzureInboundFiles
    commonAzureInboundFiles = commonSourceInfo.getPullAzureFiles(source, frequency, date)

def getInboundRequiredAzureFiles(source, frequency, found):
    return [x for x in commonSourceInfo.getPullAzureFiles(source, frequency)]

def getInboundAzureRequiredFiles(source, frequency, found):
    return [x for x in commonSourceInfo.getPullAzureFiles(source, frequency)]

def getPullAzureRequiredFiles(source, frequency, found):
    return [x for x in commonAzureInboundFiles if x.source == source and x.frequency == frequency and x.required == True and x.pullOrPush.lower() == 'pull' and x.found == found]

def getPullAzureOptionalFiles(source, frequency, found):
    return [x for x in commonAzureInboundFiles if x.source == source and x.frequency == frequency and x.required == False and x.pullOrPush.lower() == 'pull' and x.found == found]

def isCompressedExtension(extension):
    for extn in map(str.lower, compressedExtensions):
        if extension.lower().endswith(extn):
            return True
    return False
    
def uncompressfiles(absFidoCompressedFileName, absFidoFileName):
    start_time = time.time()
    file_utils.unPackWith7z(absFidoCompressedFileName, absFidoFileName)
    # fido_utils.unpack(absFidoCompressedFileName, absFidoFileName)
    end_time = time.time() - start_time    
    print('Unpacking took {0}-{1}'.format(absFidoFileName, end_time))
    return True


def get_commonsourceinfo__diff_byfidoname(x, y):
    x_names = {record.fidoname for record in x}
    y_names = {record.fidoname for record in y}
    diff_list = list(x_names - y_names)
    missing_object = []
    if diff_list:
        for file_object in x:
            if file_object.fidoname in diff_list:
                missing_object.append(file_object)
    
    return missing_object


def pull_Azure_files(logger, source, frequency, env, filedate):
    
    try:
        azure_folder_file_list = []
        azure_file_keys = []
        path = os.path.join(parseYamlProperty.get_inbound_dir(), source, frequency)
        path_working = os.path.join(path, 'working')
        azcopy_path = parseYamlProperty.get_azcopypath(commonArgs.getSource())
        if not os.path.exists(path):
            os.makedirs(path)
        os_file_list = os.listdir(path)
        txt_only_list = fnmatch.filter(os_file_list, '*.txt')

        requiredFiles = getInboundAzureRequiredFiles(source, frequency, False)
        optionalAzureFiles = commonSourceInfo.getPullOptionalAzureFiles(source, frequency, filedate)
        requiredAzureFiles = commonSourceInfo.getPullRequiredAzureFiles(source, frequency, filedate)
        
        logger.debug(requiredFiles)
        azure_pulledfileslist = []
                
        yaml_files_list = []
        yaml_full_files_list = []
        MissingRequiredFiles = []
        AzurepullFiles = commonSourceInfo.getPullAzureFiles(source, 'daily', filedate)
        timing_list = [['FileName', 'Start_Time', 'End_Time', 'Compression_Time', 'Download_Time', 'Total_Time_Taken']]
        time_format = '%Y-%m-%d %H:%M:%S'
        starttime = datetime.datetime.now().strftime(time_format)
        logger.debug('\n \nDownloading ' + source + ' started \n')
        totalcompressionfiletdelta = datetime.timedelta(0)
        totaldownloadfiletdelta = datetime.timedelta(0)
        for Azurefileobject in AzurepullFiles:
            azure_folder = Azurefileobject.relativeSourceFolder
            logger.debug(Azurefileobject)
            file_path = os.path.join(path, Azurefileobject.absFidoFileName)
            # azure_path_file = os.path.join(path_working, Azurefileobject.fileDate, Azurefileobject.absFidoFileName)
            azure_path_file = azure_folder
            azure_base_file_name = "{0}{1}".format(Azurefileobject.sourcename, Azurefileobject.sourceExtension)
            logger.debug('Azure download initiated .....')
            downloadfilestarttime = datetime.datetime.now().strftime(time_format)
            logger.debug('start time : ' + downloadfilestarttime)
            
            azure_working_filename_account_url = "{0}{1}{2}{3}".format(azure_account_url_container, azure_path_file, azure_base_file_name, azure_sas_token)
            if os.path.exists(file_path) :
                azure_pulledfileslist.append(Azurefileobject)
            else:
                stdout = subprocess.run([azcopy_path, "copy", azure_working_filename_account_url, file_path], capture_output=True, text=True).stdout            
                logger.debug('Azure download details : ' + stdout)
                if os.path.exists(file_path) :
                    azure_pulledfileslist.append(Azurefileobject)
            
            downloadfileendtime = datetime.datetime.now().strftime(time_format)
            logger.debug('end time : ' + downloadfileendtime)
            downloadfiletdelta = datetime.datetime.strptime(downloadfileendtime, time_format) - datetime.datetime.strptime(downloadfilestarttime, time_format)
            totaldownloadfiletdelta = totaldownloadfiletdelta + downloadfiletdelta
            logger.debug('download completed in : {0}'.format(downloadfiletdelta))
            logger.debug('UnCompression initiated .....')
            compressionfilestarttime = datetime.datetime.now().strftime(time_format)
            logger.debug('start time : ' + compressionfilestarttime)
            if isCompressedExtension(Azurefileobject.sourceExtension.lower()):                    
                uncompressfiles(Azurefileobject.absFidoCompressedFileName, Azurefileobject.absFidoFileName)   
            elif os.path.exists(Azurefileobject.absFidoCompressedFileName):
                os.rename(Azurefileobject.absFidoCompressedFileName, Azurefileobject.absFidoFileName)
            
            compressionfileendtime = datetime.datetime.now().strftime(time_format)
            logger.debug('end time : ' + compressionfileendtime)
            compressionfiletdelta = datetime.datetime.strptime(compressionfileendtime, time_format) - datetime.datetime.strptime(compressionfilestarttime, time_format)
            logger.debug('Compression completed in : {0}'.format(compressionfiletdelta))
            totalcompressionfiletdelta = totalcompressionfiletdelta + compressionfiletdelta
            totalfiletdelta = datetime.datetime.strptime(compressionfileendtime, time_format) - datetime.datetime.strptime(downloadfilestarttime, time_format)
            logger.debug('Compress + download completed in : {0}'.format(totalfiletdelta))

            timing_list.append([Azurefileobject.absFidoFileName, '{0}'.format(compressionfilestarttime) , '{0}'.format(downloadfileendtime) , '{0}'.format(compressionfiletdelta) , '{0}'.format(downloadfiletdelta) , '{0}'.format(totalfiletdelta)])
                        
            logger.debug('archive completed')
        # shutil.rmtree(path_working)
        endtime = datetime.datetime.now().strftime(time_format)
        tdelta = datetime.datetime.strptime(endtime, time_format) - datetime.datetime.strptime(starttime, time_format)
        timing_list.append(['Total Time', '{0}'.format(starttime) , '{0}'.format(endtime) , '{0}'.format(totalcompressionfiletdelta), '{0}'.format(totaldownloadfiletdelta) , '{0}'.format(tdelta)])
        logger.debug('\n*************************************************************')        
        
        MissingAzureRequiredFiles = get_commonsourceinfo__diff_byfidoname(requiredAzureFiles, azure_pulledfileslist)
        MissingAzureOptionalFiles = get_commonsourceinfo__diff_byfidoname(optionalAzureFiles, azure_pulledfileslist)

        MissingRequiredFiles = MissingAzureRequiredFiles + MissingRequiredFiles
        
        for f in timing_list:
            logger.debug(f)

        return (len(optionalAzureFiles), len(requiredAzureFiles), len(MissingAzureOptionalFiles), len(MissingAzureRequiredFiles), optionalAzureFiles, requiredAzureFiles, MissingRequiredFiles)   

    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        print('\nException raised Azure push : {0}\n'.format(str(e)))
        flag = 0
        MissingRequiredFiles = []
        optionalAzureFiles = []
        requiredAzureFiles = []
        return(0, 0, 0, 0, optionalAzureFiles, requiredAzureFiles, MissingRequiredFiles)

def process(date):
    args = commonArgs.parse()
    logger = AutomationLogging.getLogger('checkAndPullFiles_Azure')
    global azure_account_url_container
    global azure_sas_token
    azure_sas_token_path = parseYamlProperty.get_bdapkeepasspath(args.source)
    azure_keepass_list = getkeepassdata.getSourcekeepassinfo(logger, args.source, args.frequency)
    azure_sas_token_path_file_name = os.path.join(azure_sas_token_path, azure_keepass_list.keepassfilename)
    sas_url = fido_utils.get_sas_token(azure_sas_token_path_file_name, azure_keepass_list.password, azure_keepass_list.title)
    azure_sas_token = "".join(re.findall('\?[\w\W]+?$', sas_url))
    azure_account_url_container = "".join(re.findall('[\w\W]+?\?', sas_url)).replace('?', '/')
    source = commonArgs.getSource()
    frequency = commonArgs.getFrequency()
    debug = commonArgs.getDebugFlag()
    if date == '':
        date = commonArgs.getFiledate()
    env = commonArgs.getEnv()
    
    if(commonArgs.getFiledate() == '') and date == '':
        date = datetime.datetime.now().strftime('%Y%m%d')
        
    if len(commonSourceInfo.getPullAzureFiles(source, frequency, date)) == 0:
        logger.debug('No pull files defined for {0} - {1}'.format(source, frequency))
        return
    
    logger.debug('Inside Pull Azure Files Process')
    if date == '':
        date = datetime.datetime.now().strftime("%Y%m%d")

    logger.debug('Processing for {0}'.format(date))

    requiredFilesCount = 0
    missingRequiredFilesCount = 0

    
    push_timings = []
    print("File count===>", len(commonSourceInfo.getPullAzureFiles(source, frequency, date)))
    if len(commonSourceInfo.getPullAzureFiles(source, frequency, date)) > 0:
        [optionalfilecount, requiredfilecount, optionalmissingfilecount, requiredmissingfilecount, optionalAzureFiles, requiredAzureFiles, MissingRequiredFiles] = pull_Azure_files(logger, source, frequency, env, date)
        return(optionalfilecount, requiredfilecount, optionalmissingfilecount, requiredmissingfilecount, optionalAzureFiles, requiredAzureFiles, MissingRequiredFiles)
    # [optionalFilesCount, requiredFilesCount, missingOptionalFilesCount, missingRequiredFilesCount] = pull_Azure_files(logger, source, frequency, date)
    # countDict = {}
    # countDict['RequiredFilesCount'] = requiredFilesCount
    # countDict['OptionalFilesCount'] = optionalFilesCount
    # countDict['Missing-RequiredFilesCount'] = missingRequiredFilesCount
    # countDict['Missing-OptionalFilesCount'] = missingOptionalFilesCount
    # alertEmailMsgTemplateBuilder.notifyEmail(debug, countDict, optionalFiles + requiredFiles, MissingRequiredFiles , ['source','fileDate','frequency'], ['absFidoFileName','absSourceFileName','found','foundServer'])
if __name__ == "__main__":
    try:
        
        process(datetime.datetime.now().strftime('%Y%m%d'))

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print("Error : ", processerrorMsg)   
        