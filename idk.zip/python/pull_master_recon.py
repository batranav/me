#!/usr/bin/env python

import datetime, pyodbc, re, zlib
from sendEmail import *
import parseYamlProperty
import getSQLdata
import os
import AutomationLogging
# Timestamps.
import commonArgs

source = 'master_recon'
freq = 'daily'

filedate = commonArgs.getFiledate()
filedate = filedate if filedate else datetime.datetime.today().strftime('%Y%m%d')
today     = datetime.datetime.strptime(filedate, '%Y%m%d')
yesterday = datetime.datetime.strptime(filedate, '%Y%m%d') - datetime.timedelta(days=1)
conn = None
#yesterday = datetime.datetime.now() - datetime.timedelta(hours=10)

today_timestamp     = today.strftime("%Y-%m-%d") + ' 00:00:00'
yesterday_timestamp = yesterday.strftime("%Y-%m-%d") + ' 00:00:00'

## All of our SQL.

sql_mantis_totalvsam = '''\
select bill_cycle,ACCOUNT,cps_co_no,ebill_producer,sales_point,industry_code,service_type,
statement_type,location_Addr_foreign_ind, sales_person,date_open,date_drop,drop_reason,grandparent_account_number,
grandparent_account_suffix,short_name,special_mailing_instruction,ar_credit_card_ptr,invoice_type,ytd_billing,
summary_bill_code,send_with_account_number,send_with_account_suffix,control_number,date_last_billed,prior_yr_billing,
tax_exempt,custom_line,purchase_order,tax_zip1,tax_zip2,date_last_address_change,date_stop_bill,stop_bill_code,
print_option,main_account_number,main_account_suffix,scan_remit_flag,collect_at_ln,trading_partner,joint_vendor,
foreign_address_billing,company_number, location_attention_line, location_department_line, location_name,
location_street_address,location_city,location_state,location_zip1,location_zip2,billing_attention_line,
billing_department_line,billing_account_name,billing_street_address,billing_city,billing_state,billing_zip1,
billing_zip2,sc_agent_node,sc_agent_id,sc_agent_state,sc_agent_region,sc_agent_region,sc_agent_email, user_comment1,
user_comment2, agent_number, mbsi_gc_id, mbsi_mvr_rebate, mvr_flag, mvr_dfsno,ytd_quantity, prior_yr_quantity,
mstrfl_customer_no,mstrfl_clue_auto,mstrfl_clue_prop,mstrfl_ncf,add_chg_ind,test_ind,date_last_Address_changed,
message,date_record_updated,lock_name,tax_payer_id
from mbs_billing_snapshot.mantis_totalvsam
'''

sql_billing_calendar = '''\
select id,calendar_year,calendar_day,calendar_month,billing_cycle_1,billing_cycle_2,billing_cycle_3,billing_cycle_4,billing_cycle_5,billing_cycle_6,billing_cycle_7,billing_cycle_8,date_record_updated,lock_name
from mbs_billing.billing_calendar
'''

sql_to_execute = [
    sql_billing_calendar,
    sql_mantis_totalvsam
    
    ]

table_list = [
    
    'billing_calendar',
    'mantis_totalvsam'
    ]


def clean_field_names(field_names):
    replacements = [('[',  ''),
                    (',',  '|#?'),
                    (']',  ''),
                    ('\'', ''),
                    (' ',  '')]
    result = field_names
    for (before, after) in replacements:
        result = result.replace(before, after)
    return result


def get_normal_data(data):
    try:
        data = data.strip()
    except AttributeError:
        data = str(data)
    if data == 'None':
        data = ''
    return data


printList = []
def printwrapper(str):
    print(str)
    printList.append(str)

def get_database_connection():
    global conn
    if conn == None:
        logger = AutomationLogging.getLogger('pull_master_recon', True)
        (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger,source,freq,'')
        conn = pyodbc.connect(connstr)
    return conn

def pull_all_files():
    success_flag=False
    thrownthing = None
    try:
        printwrapper('Calling mbs_billing_snapshot and mbs_billing DB extract process')
        start_time = datetime.datetime.now()
        printwrapper('Connection to mbs_billing_snapshot and mbs_billing DB extablished')
        conn   = get_database_connection()
        for index, sql in enumerate(sql_to_execute):
            table_name = table_list[index]
            pull_one_file(table_name, sql, conn)
        endtime = datetime.datetime.now()
        tdelta = endtime - start_time
        tdelta_min = tdelta.total_seconds() / 60
        printwrapper('*************************************************************')
        printwrapper('Total Duration in minutes: {0}'.format(tdelta_min))
        printwrapper('mbs_billing_snapshot and mbs_billing Data extract completed...')
        success_flag = True
        thrownthing = None
    except Exception as ex:
        printwrapper('Exception raised : {0}'.format(ex))
        success_flag = False
        thrownthing = ex
    finally:
        printwrapper('**********')
        printwrapper('All Done!')
        printwrapper('**********')
        email_subject = 'data pull from mbs_billing_snapshot and mbs_billing DBs for master_recon for ' + today.strftime('%Y%m%d')
        email_from    =  'arjun.mudunuru@lexisnexis.com'
        email_to      = 'arjun.mudunuru@lexisnexis.com' 
        if success_flag:
            subject = 'Success: ' + email_subject
        else:
            subject = 'ERROR / WARNING: ' + email_subject
        #send_mail(email_from, email_to, '', subject, '' + '\n'.join(printList))
        send(email_from, email_to, '', subject, '' + '\n'.join(printList))
        if thrownthing:
            raise thrownthing


def pull_one_file(table_name, sqlquery, conn):
    printwrapper('\n****************************{0}*********************************'.format(table_name))
    printwrapper('\nTable being extracted : {0}'.format(table_name))
    file_name   = os.path.join(parseYamlProperty.get_outbound_dir(),'azure', source+'\\' + table_name + '_' + today.strftime('%Y%m%d') + '.tsv')
    # conn   = get_database_connection()
    cursor = conn.cursor()
    #cursor.execute("SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")
    cursor.execute(sqlquery)
    #print (cursor.description)
    columns     = [t[0] for t in cursor.description]
    field_names = str([i[0] for i in cursor.description])
    header      = clean_field_names(field_names)
    with open(file_name, 'w',encoding="utf8") as f:
        printwrapper('\nFile location : {0}'.format(file_name))
        f.write(header + '\n')
        printwrapper('\nFetching records from table : {0}'.format(table_name))
        row_count = 0
        while True:
            row = cursor.fetchone()
            if not row:
                break
            row_count += 1
            out_str = []
            for idx in range(len(cursor.description)):
                field = get_normal_data(row[idx])
                out_str.append(field)
            result = '|#?'.join(out_str)
            f.write(result + '\n')
        printwrapper('\nFile count of file {0} : {1} '.format(file_name, row_count))
        printwrapper('\nData extract completed for table : {0}'.format(table_name))


if __name__ == '__main__':
    pull_all_files()