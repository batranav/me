import pyodbc
import pandas as pd
import re
import os 
import json 
from datetime import datetime
import sys
import numpy as np
import AutomationLogging
import commonArgs
import weekly_release_utils
import generate_weekly_email
import shutil
import glob

def getLogger():
    return AutomationLogging.getLogger('Weekly_release_despray_release_copy')

def weekly_release_copy_file(logger,base_path, release_date, db, file_loc, write_loc):
    logger.debug('weekly_release_copy_file function initiated')
    file_path = '{0}\\SQL Changes - ALL.xlsx'.format(base_path)
    df = weekly_release_utils.read_excel(file_path, release_date, 3)
    logger.debug('pandas frame work {0}'.format(df))
    
    sheet_table_view_name = weekly_release_utils.constant_table_view_name
    sheet_change = weekly_release_utils.constant_change
    sheet_change_type = weekly_release_utils.constant_change_type
    sheet_sql_ecl_type = weekly_release_utils.constant_sql_ecl_type
    sheet_modify_keep = weekly_release_utils.constant_modify_keep
    sheet_application = weekly_release_utils.constant_application    
    sheet_despray_start_month = weekly_release_utils.constant_despray_start_month
    
    downloaded = df[df[sheet_sql_ecl_type] != 'ECL']
    downloaded = downloaded.fillna('')
    logger.debug('After cleaning pandas data frame {0}'.format(downloaded))
    (db_server_name, username, passwd) = weekly_release_utils.read_cred_for_server(logger, 'PROD_SQl_DB_CRED')
    for index, row in downloaded.iterrows():
        try:
            row[sheet_table_view_name] = re.sub("\[|\]", '', row[sheet_table_view_name])
            despray_path = weekly_release_utils.get_despray_path()
            partition_column = ''
            tbl_name = ''
            schema = ''
            obj_name = ''
            
            if row[sheet_change].lower()[:3] != 'new' and row[sheet_change_type].lower().strip() == 'table':
                sheet_value = "{0}".format(row[sheet_change])
                sheet_value2 = "{0}".format(row[sheet_change_type])
                print(row[sheet_table_view_name])
                obj_name = row[sheet_table_view_name]
                
                if '.' not in obj_name:
                    obj_name = "dbo." + obj_name
                schema = obj_name.split('.')[0]
                tbl_name = obj_name.split('.')[1]
                try:
                    partition_by_column = weekly_release_utils.check_partition_table(logger, tbl_name, db)
                    tsv_file_name = "{0}.tsv".format(tbl_name)
                    if partition_by_column != '' and commonArgs.getSource() == 'weekly_release_adhoc_despray':
                        tsv_file_name = "{0}_[0-9]*.tsv".format(tbl_name)
                    despray_path_file_name = os.path.join(despray_path, tsv_file_name)                    
                    for file in glob.glob(despray_path_file_name):
                        basename = os.path.basename(file)
                        despray_release_file_name = "release_{0}".format(basename)  
                        despray_release_file_name_full_path = os.path.join(despray_path, despray_release_file_name)                  
                        if os.path.exists(despray_release_file_name_full_path):
                            os.remove(despray_release_file_name_full_path)
                        shutil.copyfile(file, despray_release_file_name_full_path)
                        
                except Exception  as e:
                    logger.debug('Exception error while copy despray file {0}'.format(e)) 
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    print(exc_tb.tb_lineno)
                    print('*****************************************************************************')
                    print('\n'+'------------'+ row[sheet_table_view_name] + " had copy issue issue. Pease advise ------------"+'\n')
                    print(e)
                    print('\n')
                    print('*****************************************************************************')

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_tb.tb_lineno)
            print('*****************************************************************************')
            print('\n'+'------------'+ row[sheet_table_view_name] + " had copy issue issue. Pease advise ------------"+'\n')
            print(e)
            print('\n')
            print('*****************************************************************************')
            continue
            logger.debug('weekly_release_copy_file function Completed')

    
    try:
        sql_adhoc_path = weekly_release_utils.get_sql_adhoc_path()
        despray_path = weekly_release_utils.get_despray_path()
        partition_column = ''
        tbl_name = ''
        schema = ''
        obj_name = ''               
        
        tsv_file_name = "*.tsv"
        despray_path_file_name = os.path.join(despray_path, tsv_file_name)                    
        for file in glob.glob(despray_path_file_name):
            basename = os.path.basename(file)
            sql_adhoc_file_name_full_path = os.path.join(sql_adhoc_path, basename)                 
            if os.path.exists(sql_adhoc_file_name_full_path):
                os.remove(sql_adhoc_file_name_full_path)
            shutil.copyfile(file, sql_adhoc_file_name_full_path)  
            os.remove(file)                          
        
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(exc_tb.tb_lineno)
        print('*****************************************************************************')
        print('\n'+ "-----------move file had issue. Pease advise ------------"+'\n')
        print(e)
        print('\n')
        print('*****************************************************************************')
        logger.debug('weekly_release_copy_file function Completed')
    
def weekly_release_copy_procedure():
    logger = getLogger()
    if(commonArgs.getFiledate() == ''):
        sheet_name = datetime.today().strftime('%Y-%m-%d')
    else:
        sheet_name = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
    
    base_path = weekly_release_utils.get_base_path()
    weekly_release_copy_file(logger, base_path, sheet_name, commonArgs.getApplication(), weekly_release_utils.get_script_path(), weekly_release_utils.get_script_path())

if __name__ == "__main__":
    weekly_release_copy_procedure()