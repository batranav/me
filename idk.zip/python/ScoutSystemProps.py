class ScoutSystemProps(object):
    inbound_dir	= ""
    base_script_dir	= ""
    ecl_script_dir	= ""
    build_logs_dir	= ""
    src_dir		= ""
    generated_ecl_dir= ""
    success_email	= ""
    error_cc_email	= ""
    HPCCProd	= ""
    HPCCProdCluster	= ""
    HPCCDev		= ""
    HPCCDevCluster	= ""
    csspath		= ""

    def __init__(self, _inbound_dir, _base_script_dir, _ecl_script_dir, _build_logs_dir, _src_dir, _generated_ecl_dir, _success_email, _error_cc_email, _HPCCProd, _HPCCProdCluster, _HPCCDev, _HPCCDevCluster	, _csspath):
        self.inbound_dir = _inbound_dir
        self.base_script_dir = _base_script_dir
        self.ecl_script_dir = _ecl_script_dir
        self.build_logs_dir = _build_logs_dir
        self.src_dir = _src_dir
        self.generated_ecl_dir = _generated_ecl_dir
        self.success_email = _success_email
        self.error_cc_email = _error_cc_email
        self.HPCCProd = _HPCCProd
        self.HPCCProdCluster = _HPCCProdCluster
        self.HPCCDev = _HPCCDev
        self.HPCCDevCluster = _HPCCDevCluster
        self.csspath = _csspath


    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 
