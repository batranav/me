import pyodbc
from datetime import datetime
import codecs
import parseYamlProperty
import getSQLdata
import os
import AutomationLogging

#print(cursor.description)
#print(len(cursor.description))

def attempt_strip(x):
    try:
        #print(x)
        return x.strip()
    except AttributeError:
        return x

def checkNone(x):
    if x is None:
        #print('None condition')
        return ('')
    else:
        return(x)

def pull_files():
    logger = AutomationLogging.getLogger('preprocess_workday_employee_pull')
    (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, 'workday','daily','')
    cnxn = pyodbc.connect(connstr)
    cursor = cnxn.cursor()
	
    #cpsql =     "SELECT [Empl_Legal_ID],[OPRID],[EMPLID],[NAME],[FIRST_NAME],[MIDDLE_NAME],[LAST_NAME],[EMPL_STATUS],CONVERT(VARCHAR(10),[EFFDT], 111)as [EFFDT],[ACTION],[ACTION_REASON],CONVERT(VARCHAR(10),HIRE_DT, 111) as HIRE_DT,CONVERT(VARCHAR(10),[TERMINATION_DT], 111) as [TERMINATION_DT],[EMAIL_ADDR],[COST_CENTER],[COST_CENTER_DESC],[LOCATION],[COMPANY],[COMPANY_DESCR],[JOBCODE],[JOBTITLE],[FULL_PART_TIME],[SUPER_Legal_ID],[super_oprid],[SUPERVISOR_ID] ,[SUPERVISOR_NAME],[WORK_PHONE],[CELL_PHONE], 'LOCAL' AS [SOURCE] FROM [EmplAuth].[dbo].[PS_CP_DSHBRD_VW] where emplid  not in (select emplid from  [Emplauth].[dbo].[LN_RSK_DATA_WAREHOUSE_VW] )"
    globalsql = "SELECT [LEGAL_ID] as [Empl_Legal_ID], '' as OPRID,[EMPLID], preferred_NAME as[NAME],[FIRST_NAME],[MIDDLE_NAME],[LAST_NAME],[EMPL_STATUS],CONVERT(VARCHAR(10),[EFFDT], 111)as [EFFDT],'' as ACTION,'' as ACTION_REASON,CONVERT(VARCHAR(10),HIRE_DT, 111) as HIRE_DT,CONVERT(VARCHAR(10),[TERMINATION_DT], 111) as [TERMINATION_DT],[EMAIL_ADDR],[COST_CENTER],[COST_CENTER_DESCR],[LOCATION],[COMPANY],[COMPANY_DESCR],[JOBCODE],[JOBTITLE],'' as FULL_PART_TIME,'' as SUPER_Legal_ID,'' as super_oprid,[SUPERVISOR_ID],[SUPERVISOR_NAME],[BUSINESS_PHONE],[CELL_PHONE],[PER_ORG],[UPN],[business_unit] FROM [EmplAuth].[dbo].[LN_RSK_DATA_WAREHOUSE_VW]"
    #rtnsql =   "SELECT [AD_USER_ID] as [Empl_Legal_ID] ,'' as OPRID,[EMPLID],[NAME],[FIRST_NAME],replace(replace([preferred_NAME],([last_NAME]+','),'') ,first_name,'')AS middle_name,[LAST_NAME],[EMPL_STATUS],CONVERT(VARCHAR(10),1901/12/12, 111)AS [EFFDT],''AS [ACTION],''AS [ACTION_REASON],CONVERT(varchar(10),hire_dt, 111) AS hire_dt,CONVERT(varchar(10),[TERMINATION_DT], 111) AS [TERMINATION_DT],[INTERNET_ADDRESS] AS [EMAIL_ADDR],[COST_CENTER], '' AS [COST_CENTER_DESC],[LOCATION],[COMPANY], '' AS [COMPANY_DESCR],[JOBCODE],'' AS [JOBTITLE] ,'' AS [FULL_PART_TIME],'' AS super_legal_id,'' AS [super_oprid],[SUPERVISOR_ID] ,[mgr_preferred_NAME]as[SUPERVISOR_NAME],[BUSN_PHONE] as  [WORK_PHONE],[CELL_PHONE], 'RET' AS [SOURCE] FROM  dbo.rets_employee_info_vw  WHERE COST_CENTER = 'PH403' "
    sqltoexecute =globalsql ;
	#sqltoexecute = cpsql ;
    
    print (sqltoexecute);
    
    cursor.execute(sqltoexecute);
    
    f = open(os.path.join(parseYamlProperty.get_inbound_dir(),'workday\\daily\\workday_ln_dashboard_' + datetime.now().strftime('%Y%m%d') + '.txt'),'w')
    while 1:
        row = cursor.fetchone()
        iterator = range(0, len(cursor.description)).__iter__()
        col = ''
        outStr = []
        result = ''
        #print(row)
        if not row:
            break
        for idx in iterator:
            col = checkNone(attempt_strip(row[idx]))
            if idx > 0:
                outStr.append('|') 
                outStr.append(col)
            else:
                outStr.append(col)

        result = ''.join(outStr)
        f.write(result.encode("ascii", "ignore").decode() + '\n')
    #print(result)

    f.close()

if __name__ == '__main__':
   pull_files()