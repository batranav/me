import time
import datetime
import os
import parseYamlProperty
import AutomationLogging
import sys
import traceback
import commonArgs
import commonSourceInfo
import s3PushEmailAlert
import file_utils
import shutil
import fido_utils
import fnmatch
import re
import subprocess
import getkeepassdata
import checkAndPullFiles
import paramiko

class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)

def getDestinationFiles(source, frequency, date):
    global rbiOutboundFiles
    global rbiOutboundAzureFiles
    rbiOutboundFiles = commonSourceInfo.getOutboundFilesAzure(source, frequency, date)
    rbiOutboundAzureFiles = commonSourceInfo.getOutboundAzureFiles(source, frequency, date)

def getOutboundRequiredSftpFiles(source, frequency, found):
    return [x for x in commonSourceInfo.getOutboundFilesSftp(source, frequency) if x.destination == source and x.frequency == frequency]


def getDeltas(x, y):
    return (list(set(x) - set(y)))

def check_and_create(dir_name):
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)


def push_sftp_files(logger, source, frequency, env):
    global MissingRequiredFiles
    try:
        sftp_client_list = checkAndPullFiles.getSourcePullInfo(logger, source)
        filedate = commonArgs.getFiledate()
        sftp = [o for o in sftp_client_list if o.host == 'supportftp.lexisnexis.com'][0]    

        ssh_conn = FastTransport((sftp.host, 22))
        ssh_conn.connect(username=sftp.uname,password=sftp.pwd)
        sftp_client = paramiko.SFTPClient.from_transport(ssh_conn)

        azure_folder_file_list = []
        azure_file_keys = []
        path = os.path.join(parseYamlProperty.get_outbound_dir(), 'sftp', source)
        path_archive = os.path.join(path, 'archive',filedate)
        check_and_create(path_archive)
        azcopy_path = parseYamlProperty.get_azcopypath(commonArgs.getSource())

        requiredFiles = getOutboundRequiredSftpFiles(source, frequency, False)
        MissingRequiredFiles = []
                
        requiredSftpFiles = commonSourceInfo.getOutboundFilesSftp(source, 'daily')
        required_azure_files_list = []
        no_file_found = []
        for sftpfileobject in requiredSftpFiles:
            if(os.path.exists(path + '\\' + sftpfileobject.absFidoFileName) != True):
                no_file_found.append(sftpfileobject.absFidoFileName)
        if len(no_file_found) == 0:
            for sftpfileobject in requiredSftpFiles:
                sftp_client.put(path + '\\' + sftpfileobject.absFidoFileName, '/' + sftpfileobject.relativedestinationFolder + '/' + sftpfileobject.absDestinationFileName)
                shutil.move(path + '\\' + sftpfileobject.absFidoFileName, path_archive + '\\' + sftpfileobject.absFidoFileName)
                logger.debug('archive completed')
        else:
            logger.debug("Files are not found to be pushed ..... {0}".format(no_file_found))

        logger.debug('\n*************************************************************')        
        return (len(no_file_found), len(requiredFiles))

    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        print('\nException raised Azure push : {0}\n'.format(str(e)))
        flag = 0

def process():
    args = commonArgs.parse()
    logger = AutomationLogging.getLogger('checkAndPushFiles_Sftp')
    source = args.source
    frequency = args.frequency
    start_time = time.time()
    my_source = commonArgs.getSource()
    my_frequency = commonArgs.getFrequency()
    logger.debug('preprocess started for the source ' + my_source)
    
  
    debug = args.debug
    date = args.date
    env = args.env   
    global requiredFiles   

    if not commonSourceInfo.hasOutboundFiles(source, frequency):
        logger.debug('No push files defined for {0} - {1}'.format(source, frequency))
        return

    logger.debug('Inside PushFiles Process')
    if date == '':
        date = datetime.datetime.now().strftime("%Y%m%d")

    logger.debug('Processing for {0}'.format(date))

    requiredFilesCount = 0
    missingRequiredFilesCount = 0

    push_timings = []
    if len(commonSourceInfo.getOutboundFilesSftp(source, frequency, date)) > 0 and missingRequiredFilesCount == 0:
        (missingRequiredFilesCount, requiredFilesCount) = push_sftp_files(logger, source, frequency, env)
    return (missingRequiredFilesCount, requiredFilesCount)
    
    # for f in requiredFiles:
    #     if f.absFidoFileName in MissingRequiredFiles:
    #         requiredfiles_missing.append(f)

    # if missingRequiredFilesCount == 0:
    #     missingRequiredFilesCount = len(requiredfiles_missing)
    
    # countDict = {}
    # countDict['RequiredFilesCount'] = requiredFilesCount
    # countDict['OptionalFilesCount'] = 0
    # countDict['Missing-RequiredFilesCount'] = missingRequiredFilesCount
    # countDict['Missing-OptionalFilesCount'] = 0

    # if missingRequiredFilesCount  > 0 :
    #     s3PushEmailAlert.notifyEmail(debug, countDict, requiredfiles_missing, push_timings, len(MissingRequiredFiles) > 0 , ['destination','fileDate','frequency'], 'azure')
    # else :
    #     s3PushEmailAlert.notifyEmail(debug, countDict, requiredFiles, push_timings, len(MissingRequiredFiles) > 0 , ['destination','fileDate','frequency'], 'azure')
if __name__ == "__main__":
    try:
        
        process()

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print("Error : ", processerrorMsg)   
        