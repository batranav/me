class commonOutbound(object):
    # source = ""
    destination = ""  
    frequency = ""
    destinationname = ""
    fidoname = ""
    required = ""
    destinationExtension   = ""
    fidoExtension   = ""
    found = False
    foundServer = ""
    relativedestinationFolder = ""
    absDestinationFileName = ""
    absFidoFileName = ""
    fileDate = ""
    autodestinationFolderPrefix = False
    completedFlagFileName = ""
    actualFileNameAtdestination = "" 

    def __init__(self, _destination, _frequency, _filedate, _destinationname , _fidoname, _required, _destinationExtension, _fidoExtension, _absDestinationFileName, _absFidoFileName, _relativedestinationFolder, _moveUnusedFiles = True):
        # self.source = _destination 
        self.destination = _destination
        self.frequency = _frequency
        self.destinationname = _destinationname
        self.fidoname = _fidoname
        self.required = _required
        self.destinationExtension  = _destinationExtension
        self.fidoExtension  = _fidoExtension
        self.found = False
        self.foundServer = ''
        self.fileDate = _filedate
        # self.completedFlagFileName = _completedFlagFileName
        self.absDestinationFileName = _absDestinationFileName
        self.absFidoFileName = _absFidoFileName
        self.relativedestinationFolder = _relativedestinationFolder

        # self.autodestinationFolderPrefix = _autodestinationFolderPrefix

    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 
