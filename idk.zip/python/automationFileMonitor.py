# from ECL_Python import getWUID, parseResult, checkStatus
import os
import shutil
from datetime import datetime
import time
from send_email import send_mail

class AutomationFileMonitor:
	
	def __init__(self, sendFrom, sendTo, sendCC, landingZoneRootPath, targetFolderPath, fileType):
		self.sendFrom = sendFrom
		self.sendTo = sendTo
		self.sendCC = sendCC
		self.landingZoneRootPath = landingZoneRootPath
		self.targetFolderPath = targetFolderPath
		self.fileType = fileType
		
	def sendEmail(self, send_from, send_to, send_cc, **options):
		if options.get('err'):
			content ='Errors have been found:' + "\n"
			subject = options.get('subject')
			f = open(options.get('fileName'),'r')
			for line in f:
				content = content + line
			f.close()
			send_mail(send_from, send_to, send_cc, subject, content)
			
	def readTab(self, inputFile, tabName, outputFileName, outputFilePath):

		#First check if the tab contains more than one line data (header only)
		#If No, ignore this tab
		
		try:
			tab = inputFile[tabName]
		except:
			print('Tab '+ tabName +' does not exist. Skip')
			return False
		if tab.max_row < 2:
			return False
		
		rows = tab.rows
		tableContents = []
		
		for row in rows:
			rowContent = []
			for cell in row:
				if cell.value is None:
					continue
				rowContent.append(str(cell.value))
			allNone = all(ele is None for ele in rowContent)
			if not allNone:
				tableContents.append(rowContent)

		if len(tableContents) > 1:		
			outputFilePath = outputFilePath if outputFilePath.endswith("/") else outputFilePath+'/'
			outputFile =  open(outputFilePath + outputFileName+'.txt','w')
			for x in tableContents:
				for y in x:
					outputFile.write(y)
					outputFile.write("\t")
				outputFile.write("\n")
			outputFile.close()
			return True
				
		return False
	
	def missingInputTabName(self, sheetsName):
		if 'input' not in sheetsName and 'Input' not in sheetsName:
			errorMessage = 'Input Tab Is Not Found in File! Program Terminated!'
			print(errorMessage)
			return errorMessage
		return False		
		
	
	def txtFileName(self, processName):
		return {'revenue adjustment': 'revenue_adjustment_','CY_Vertical':'cy_vertical_', 'Sub_Mkt': 'sub_market_cd_', 'ABA':'bs_aba_ind_','CRD':'bussrv_crd_customer_', 'Reseller':'direct_reseller_', 'Acq_Tracking':'acquisition_tracking_customer_', 'Govt_Tier':'govt_cy_tier_', 'Segment_Lead':'segment_lead_', 'PMC':'primary_market_code_','SubAcct_Country':'subaccount_country_mapping_', 'Use_Case':'customer_use_case_', 'Revenue_Segment':'customer_revenue_segment_', 'PMK_vertical':'pmk_vertical_allocation_', 'PMK_product':'customer_PMK_product_assignment_', 'fact forecast details':'forecast_fact_details_', 'insurance override':'ins_growth_metric_realtime_override_' }.get(processName, False)

	def copyFile(self, copyFromPath, copyToPath, processName, destiny):
		todayDate = datetime.now().strftime("%Y%m%d")
		
		if not os.path.exists(copyToPath):
			os.makedirs(copyToPath)
		else:
			os.chmod(copyToPath, 0o777)
		
		if destiny == 'landing zone':
			# try:
				# fileName = self.txtFileName(processName)
				# if fileName == False:
					# print('Process Name is not recognized. Program Terminated!')
					# return
				# absolutePath = copyFromPath + fileName + todayDate + '.txt'
				# shutil.copy2(absolutePath, copyToPath)
			# except:
				# print("Error in copy txt file to landing zone folder!")

			fileName = self.txtFileName(processName)

			absolutePath = copyFromPath + todayDate + '/' + fileName + todayDate +'.txt'
			#for forecast fact details there are two different files
			#hc and ins_forecast_fact_details
			files = os.listdir(copyFromPath)
			for f in files:
				if 'forecast_fact_details' in f:
					fileName = f
					absolutePath = copyFromPath + fileName
					break
					
			if fileName == False:
				print('Process Name is not recognized. Program Terminated!')
				return

			shutil.copy2(absolutePath, copyToPath)

		else:
			# try:
				# files = os.listdir(copyFromPath)
				# for f in files:
					# shutil.move(copyFromPath + f, copyToPath + f)
			# except:
				# print("Error in move files to archive folder")
			files = os.listdir(copyFromPath)
			for f in files:
				if os.path.isfile(os.path.join(copyFromPath, f)):
					shutil.move(copyFromPath + f, copyToPath + f)
				
	def run(self):
		todayDate = datetime.now().strftime("%Y%m%d")
		loadingPaths = [self.targetFolderPath , 'D:/red/data/inbound/forecast/working/'+ todayDate + '/']
		
		for loadingPath in loadingPaths:		
			if not os.path.exists(loadingPath):
				os.makedirs(loadingPath)
				
			allFiles = os.listdir(loadingPath)
			for f in allFiles:
				if (f.endswith('xlsx') or f.endswith('XLSX')) and self.fileType in f:# or f.endswith('txt'):
					print('New File Detected!')
					# self.fileSizeStable(loadingPath+f)				
					return f
		return ''
		
if __name__ =="__main__":
	automationFileMonitor = AutomationFileMonitor('yang.xu@lexisnexisrisk.com', ['yang.xu@lexisnexisrisk.com'], ['yang.xu@lexisnexisrisk.com'], 'D:/red/data/inbound/manual/adhoc/working/', 'D:/red/data/inbound/manual_adjustment/', 'override')
	print(automationFileMonitor.landingZoneRootPath)

