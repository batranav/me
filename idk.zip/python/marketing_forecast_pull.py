import datetime
from Marketing_Forecast_model.model_code import LexisNexisDeployment
from Marketing_Forecast_model.model_code import ln_model


def process():
    thismonday = datetime.datetime.today()  - datetime.timedelta(days=datetime.datetime.today().weekday() % 7)
    thismonday_inYMD = thismonday.strftime('%Y%m%d')
    filedate = thismonday_inYMD
    inboundFolder = 'D:\\red\\data\\inbound\\marketing_forecast\\weekly\\'
    input_file = inboundFolder + 'lead_fcst_'+ filedate +'.tsv'
    output_file = inboundFolder + 'lead_fcst_model_results_'+ filedate +'.txt'
    LexisNexisDeployment.main(input_file, output_file, 'info','',28)

if __name__ == '__main__':
    process()