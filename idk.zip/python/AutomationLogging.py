import logging
import commonArgs
import os
import parseYamlProperty
import datetime
import fido_utils
_logger = None
loggerList = dict()
def makeFolder(source, frequency, filedate):
    path = ''
    try:
        dynamic_folder_path = '{0}\\{1}\\{2}\\{3}'.format(source, 'build', frequency, filedate)
        path = os.path.join(parseYamlProperty.get_build_logs_dir() + (dynamic_folder_path))
        os.makedirs(path, exist_ok = True)
        print(path)
    except OSError as error: 
        print(error) 
    return path

def getLogger(modulename, checkArgs=True):

    global _logger, loggerList

    args = commonArgs.parse()
    
    filedate = args.date

    if filedate == '':
        filedate = fido_utils.getToday()

    if modulename in loggerList.keys():
        return loggerList.get(modulename)

    if _logger is None or _logger.name != modulename:
    
        if checkArgs:
            _logger =  setup_logger(modulename, args.source, args.frequency, filedate, args.timestamp)
        else:
            _logger = setup_logger(modulename)
    
    loggerList.update({modulename: _logger})

    return _logger

def setup_logger(name, source = '', frequency = '', filedate = '', timestamp='defaultTS'):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    path = makeFolder(source, frequency, filedate)
    # create file handler which logs even debug messages
    fh = logging.FileHandler(path + '\\' + name + '-' + source + '-' +  frequency + '-' + filedate + '-' + timestamp + '.debug')
    fh.setLevel(logging.DEBUG)
    # create console handler with a higher log level
    ch = logging.FileHandler(path + '\\'  + name + '-' + source + '-' +  frequency + '-' + filedate + '-' + timestamp +  '.err')
    ch.setLevel(logging.ERROR)
    # create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    fh.setFormatter(formatter)
    # add the handlers to logger
    logger.addHandler(ch)
    logger.addHandler(fh)
    return logger

if __name__ == '__main__':
    getLogger('mvr', True)