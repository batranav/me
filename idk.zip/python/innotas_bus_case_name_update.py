import sys, requests, os, time, ssl
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret
import commonArgs
sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_buscase_namelog_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
logger = AutomationLogging.getLogger('preprocess_innotas_bus_case_name_update')

uname, pwd = get_api_secret(logger, 'innotas')
SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:login>
         <!--Optional:-->
         <ser:username>{uname}</ser:username>
         <!--Optional:-->
         <ser:password>{pwd}</ser:password>
      </ser:login>
   </soapenv:Body>
</soapenv:Envelope>""".encode(encoding = 'utf-8')

#print(SoapMessage)

#construct and send the header
proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
url = "lexisnexis.ppmpro.com"
post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"

session = requests.session()
session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}

no_of_attempts = 120
for x in range(0, no_of_attempts):
   response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
   print("status_code:", response.status_code)
   if response.status_code == 429:
      print(response.headers["Retry-After"])
      time.sleep(int(response.headers["Retry-After"]))
      x += 1
   else:
      break

print("status_code:", response.status_code)
print(SoapMessage)
result = response.content
print(result)

with open('temp_bus_casename.xml','wb') as f:
    f.write(result)
	
f.close()
tree = ET.parse('temp_bus_casename.xml')

sessionId = tree.find('.//{http://services}return').text


DefaultSoapMessage = """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services" xmlns:xsd="http://objects.services/xsd">
   <soap:Header/>
   <soap:Body>
      <ser:findEntity>
         <!--Optional:-->
         <ser:sessionId>{sessionID}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>129</ser:entityTypeId>
         <!--Zero or more repetitions:-->
         <ser:searchValuePairs>
            <!--Optional:-->
            <xsd:elementValue>677490115</xsd:elementValue>
            <!--Optional:-->
            <xsd:id>12902</xsd:id>
         </ser:searchValuePairs>
         <!--Zero or more repetitions:-->
         <ser:fieldsRequest>12904</ser:fieldsRequest>
 
      </ser:findEntity>
   </soap:Body>
</soap:Envelope>"""

output_handle = open(os.path.join(parseYamlProperty.get_inbound_dir(), commonArgs.getSource(), 'Daily\\innotas_bus_case_name_' + datetime.now().strftime('%Y%m%d') + '.txt'),'w',encoding="utf8")


proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
url = "lexisnexis.ppmpro.com"
post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap12Endpoint/)"

SoapMessage = DefaultSoapMessage.replace('{sessionID}',sessionId).encode(encoding = 'utf-8')
session = requests.session()
session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "application/soap+xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:findEntity"}

no_of_attempts = 120
for x in range(0, no_of_attempts):
   response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
   print("status_code:", response.status_code)
   if response.status_code == 429:
      print(response.headers["Retry-After"])
      time.sleep(int(response.headers["Retry-After"]))
      x += 1
   else:
      break

print("status_code:", response.status_code)
print(SoapMessage)
result = response.content
print(result)

open('temp_bus_casename.xml','wb').write(result)
tree = ET.ElementTree(file='temp_bus_casename.xml')

col1 = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityId')]
col2 = [x.text for x in tree.findall('.//{http://objects.services/xsd}entityTypeId')]
col3= [x.text for x in tree.findall('.//{http://objects.services/xsd}elementValue')]

for i in range(0,len(col1)):
	output_handle.write(col1[i] + '\t'+col2[i] + '\t'+col3[i]   +'\n')

output_handle.close()
os.remove('temp_bus_casename.xml')