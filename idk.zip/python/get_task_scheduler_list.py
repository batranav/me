import subprocess, sys
import pyodbc
import csv
import datetime
import parseYamlProperty
import os
import AutomationLogging
from vault.secrets import get_db_secret

today = datetime.datetime.today().strftime('%Y%m%d')
logger = AutomationLogging.getLogger('preprocess_get_task_scheduler')
uname, pwd = get_db_secret(logger, 'ALAWPREDSQLCL1')

connection = pyodbc.connect(DRIVER="{ODBC Driver 17 for SQL Server}",SERVER="ALAWPREDSQLCL1\SQLPRD01",DATABASE="red",UID=uname,PWD=pwd)
fname = os.path.join(parseYamlProperty.get_inbound_dir(), 'task_scheduler\\'+today+'_task_list.csv')
insert_sql = """begin tran
                    INSERT INTO [RED].[dbo].[task_scheduler_list](
                                    run_date,
									job_name,
									Status,
                                    NextRunDateTime,
                                    LastRunDateTime,
									LastRunResult,
                                    Author,
                                    Created
									)
                                VALUES (
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?
                                    )
                
                commit tran
                    """

def cleantext(txt):
    
    if txt.strip() == "":
        ret = "UA"
    else:
        ret = txt.strip()
    return ret


def get_task_scheduler_list():
    p = subprocess.Popen(["powershell.exe", 
                os.path.join(parseYamlProperty.get_powershell_script_dir(), 'get_task_scheduler_list.ps1')], 
                stdout=sys.stdout)
    p.communicate()


def process():
    get_task_scheduler_list()
    del_query = 'delete from [RED].[dbo].[task_scheduler_list] where run_date = ' + today
    cursor = connection.cursor()
    cursor.execute(del_query)
    with open (fname, 'r') as f:
        reader = csv.reader(f,quoting=csv.QUOTE_ALL,quotechar='"',delimiter=',')
        columns = next(reader)
        query = 'insert into [RED].[dbo].[task_scheduler_list]({0}) values ({1})'
        query = query.format(','.join(columns), ','.join('?' * len(columns)))
        for data in reader:
            print(data)
            cursor.execute(query, data)
        cursor.commit()

if __name__ == "__main__":
    try:
        print('In Process')
        process()   
        print('\n\nSuccessful')
    except BaseException as ex:
        print('\n\nFailed!!!!')
        print('\n\nUnknown error : {0}'.format(ex))
