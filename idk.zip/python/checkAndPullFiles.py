import pysftp
from collections import namedtuple
import json
import paramiko
import fido_utils
import file_utils
import commonSourceInfo
import os
from pathlib import Path
import time
import datetime
from multiprocessing.dummy import Pool as ThreadPool
import sys
import commonArgs
import traceback
import alertEmailMsgTemplateBuilder
import parseYamlProperty
import AutomationLogging
import io
import pyodbc
import getSQLdata
import prepSourceFiles
import getS3data
import boto3
import checkEnvironmentVariables
import getProperties
from datetime import datetime as sub_dt
import checkAndPullFiles_Azure
from vault.secrets import get_ftp_secret
# import datetime as dt

MySQLSource = namedtuple('MySQLSource', ['mysqlsource', 'host', 'uname', 'pwd', 'port'])
MyS3Source = namedtuple('MyS3Source', ['myS3source', 'profile', 'bucket'])
rbiInboundFiles = [] # Global Definition
commonDBInboundFiles = [] # Global Definition

commonInboundFiles = [] # Global Definition
SFTPCall = namedtuple('SFTPCall', ['sftp', 'sourcefilename', 'fidofilename', 'required'])
SFTPCallList = [] #Global Definition
optionalFiles = []
printList = []
requiredFiles = []
pulloptionalFiles = []
pullrequiredFiles = []
    
MissingRequiredFiles = []
alreadyPulledRequiredFilesList = []
alreadyPulledOptionalFilesList = []
ftp_file_name = getProperties.getFTPJsonFilename()
# os.path.join(parseYamlProperty.get_base_script_dir(),'properties','red_ftp.json') 
S3_file_name = getProperties.getS3JsonFilename()
# os.path.join(parseYamlProperty.get_base_script_dir(),'properties','rbi_S3.json')
transport = ''
compressedExtensions = ['gz', 'zip', 'rar', '7z'] # standard Compressed files extensions.
today     = datetime.datetime.now()
cntmismtachList = []

def attempt_strip(x):
    try:
        return x.strip()
    except AttributeError:
        return x
   
def checkNone(x):
    if x == 'None':
        #print('None condition')
        return ('')
    else:
        return(x)

def getLogger():
    return AutomationLogging.getLogger('checkAndPull')

def getSize(filename):
    
    fileobject = open(filename, 'rb')
    #print getSize(file)

    fileobject.seek(0,2) # move the cursor to the end of the file
    size = fileobject.tell()
    return size

def getsourceFolderName(filenamewithpath):
    head, tail = os.path.split(filenamewithpath)
    return head

def getsourceFileName(filenamewithpath):
    return os.path.splitext(filenamewithpath)[0]

# revisit
def getSourceFiles(source, frequency, date):
    global commonInboundFiles
    global commonDBInboundFiles
    global commonS3InboundFiles
    
    commonInboundFiles = commonSourceInfo.getPullFeedFiles(source, frequency, date)
    commonDBInboundFiles = commonSourceInfo.getPullDBFiles(source, frequency, date)
    commonS3InboundFiles = commonSourceInfo.getPullS3Files(source, frequency, date)
    
def getSourcePullInfo(logger, mySQLSource):
    with open(ftp_file_name) as f:
        jsonRef = json.load(f)
    MySQLSourceList = []  # array of MySQLSource namedtuples to be returned
    json_dict = {k:v for source in jsonRef for k,v in source.items()}  # flatten jsonRef to dict for easy access
    src = json_dict[mySQLSource]  # list of host data for our source
    for host in src:  # iterate over list of host data
        # get uname and pwd from Vault
        uname, pwd = get_ftp_secret(logger, host['host'])
        # append new MySQLSource using json host and port along with data from the Vault
        MySQLSourceList.append(MySQLSource(mySQLSource, host['host'], uname, pwd, host['port']))
    return MySQLSourceList

def getSourceS3Info(MyS3Source):

    print('GetSourceInfo {0}'.format(MyS3Source))
    jsonRef = json.load(open(S3_file_name))

    MyS3SourceList = []

    for index in range(len(jsonRef)):
        print('IDX {0}'.format(index))
        for key in jsonRef[index]:
            if (key == MyS3Source):
                src = jsonRef[index][key]
                print(src)
                for index2 in range(len(src)):
                    src2 = src[index2]
                    MyS3SourceList.append(MyS3Source(MyS3Source, src2['profile'], src2['bucket']))
    #print(MyS3SourceList)

    return MyS3SourceList
def isCompressedExtension(extension):
    for extn in map(str.lower, compressedExtensions):
        if extension.lower().endswith(extn):
            return True
    return False

class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)


# revisit
def pull(mySQLsource, commonInboundFiles):

    time.sleep(5)
    start_time = time.time()
    
    sftpFileSize = ''
    destFileSize = ''

    print('Here {0}-{1}-{2}'.format(mySQLsource.uname, mySQLsource.pwd, commonInboundFiles.absSourceFileName))

    if isCompressedExtension(commonInboundFiles.sourceExtension.lower()):
        sftp_file = commonInboundFiles.relativeSourceFolder + commonInboundFiles.actualFileNameAtSource
        dest_file = commonInboundFiles.absFidoCompressedFileName
    else:
        sftp_file = commonInboundFiles.relativeSourceFolder + commonInboundFiles.actualFileNameAtSource
        dest_file = commonInboundFiles.absFidoFileName

    ssh_conn = FastTransport((mySQLsource.host, 22))
    ssh_conn.connect(username=mySQLsource.uname,password=mySQLsource.pwd)
    sftp_client = paramiko.SFTPClient.from_transport(ssh_conn)
    sftpFileSize = sftp_client.lstat(sftp_file).st_size
    sftp_client.get(sftp_file, dest_file)
    elapsedtime = time.time() - start_time
    destFileSize = getSize(dest_file)
    return (sftp_file, dest_file, elapsedtime, sftpFileSize, destFileSize)

def sftpGetFile(mySQLsource, commonInboundFiles):

    if isCompressedExtension(commonInboundFiles.sourceExtension.lower()):
        (sftp_file, dest_file, elapsedTime, srcFileSize, destFileSize) =  pull(mySQLsource, commonInboundFiles)

        # if srcFileSize != destFileSize:
        #     raise Exception('SourceFile and DestFile sizes are not matching {0} - {1}'.format(srcFileSize, destFileSize)) 

        if srcFileSize == destFileSize:
            uncompressfiles(commonInboundFiles.absFidoCompressedFileName, commonInboundFiles.absFidoFileName)
        else:
            raise Exception('SourceFile and DestFile sizes are not matching {0} - {1}'.format(srcFileSize, destFileSize)) 
    else:
        (sftp_file, dest_file, elapsedTime, srcFileSize, destFileSize) =  pull(mySQLsource, commonInboundFiles)

        if srcFileSize != destFileSize:
            raise Exception('SourceFile and DestFile sizes are not matching {0} - {1}'.format(srcFileSize, destFileSize)) 

    print('Source Filename {3}, Destination Filename {4}, Elapsed Time {0}, SrcFileSize {1}, DestFileSize {2}'.format(elapsedTime, srcFileSize, destFileSize, sftp_file, dest_file))

    time.sleep(2) #Sleep for 2 seconds
    
    return True

def uncompressfiles(absFidoCompressedFileName, absFidoFileName):
    start_time = time.time()
    file_utils.unPackWith7z(absFidoCompressedFileName, absFidoFileName)
    # fido_utils.unpack(absFidoCompressedFileName, absFidoFileName)
    end_time = time.time() - start_time    
    print('Unpacking took {0}-{1}'.format(absFidoFileName, end_time))
    return True

# revisit
def sftpGetFiles(mySQLsource, commonInboundFiles):
    start_time = time.time()
#    pool = ThreadPool(1)
    pool = ThreadPool(ThreadPoolsize)
    mysqlsourcelist = []

    print('RedIB {0} size'.format(len(commonInboundFiles)))

    for f in commonInboundFiles:
        mysqlsourcelist.append(mySQLsource)

    print('RedIB SQL {0} size'.format(len(mysqlsourcelist)))

    #print(mysqlsourcelist)
    print('In sftpGetFiles {0}'.format(commonInboundFiles))
    pool.starmap(sftpGetFile, zip(mysqlsourcelist, commonInboundFiles))
    pool.close()
    pool.join()
    end_time = time.time() - start_time
    print('Processing {0} took {1} time using multiproecssing'.format(len(commonInboundFiles), end_time))

    return end_time

def getPullRequiredFiles(source, frequency, found):
    return [x for x in commonInboundFiles if x.source == source and x.frequency == frequency and x.required == True and x.pullOrPush.lower() == 'pull' and x.found == found]

def getPullOptionalFiles(source, frequency, found):
    return [x for x in commonInboundFiles if x.source == source and x.frequency == frequency and x.required == False and x.pullOrPush.lower() == 'pull' and x.found == found]
def getPullDBRequiredFiles(source, frequency, found):
    return [x for x in commonDBInboundFiles if x.source == source and x.frequency == frequency and x.required == True and x.pullOrPush.lower() == 'pull' and x.found == found]

def getPullDBOptionalFiles(source, frequency, found):
    return [x for x in commonDBInboundFiles if x.source == source and x.frequency == frequency and x.required == False and x.pullOrPush.lower() == 'pull' and x.found == found]

def getPullS3RequiredFiles(source, frequency, found):
    return [x for x in commonS3InboundFiles if x.source == source and x.frequency == frequency and x.required == True and x.pullOrPush.lower() == 'pull' and x.found == found]

def getPullS3OptionalFiles(source, frequency, found):
    return [x for x in commonS3InboundFiles if x.source == source and x.frequency == frequency and x.required == False and x.pullOrPush.lower() == 'pull' and x.found == found]


def getFileInfoForPull(file, sftp, date):
    try:
        sourceFolderName = file.relativeSourceFolder
        sourceFileName = file.sourcename
        #print('Base FolderName {0} ... sourceFileName {1}'.format(sourceFolderName, sourceFileName))
        try:
            sftp.chdir(sourceFolderName)
        except Exception as ex:
            return
        #print('sourceFolderName {0}'.format(sourceFolderName))
        filesInFTP = sftp.listdir(sourceFolderName)
        
        tempFilesInFTP = [item.lower() for item in filesInFTP]
        #print(tempFilesInFTP)

        # completedFlagFileName = sourceFileName + '.completed.flag'
        file_found = False
        sourceDataFileName = sourceFileName + file.sourceExtension
        if sourceDataFileName.lower() not in tempFilesInFTP :
            return
        files_array = sftp.listdir_attr(os.path.join(sourceFolderName))

        if(commonArgs.getFiledate() != None):
            file_date = sub_dt.today()
        else:
            file_date = datetime.datetime.strptime(commonArgs.getFiledate(), '%Y%m%d')

        month_from_yesterday = (file_date - datetime.timedelta(days=1)).month

        month_from_today = sub_dt.today().month
        # check sourcedatafile is one of the files in the sftp folder location and it is modified date falls in month of its previous day
        # Reason for checking month of prev day :some sources might add date to the file matching with data date, on 1st of month, data date will be last day of prev of month
        for index in range(0, len(files_array)):
            if(file.match_latest_file):
                sorted_matching_files = [x.filename for x in sorted([x for x in files_array if x.filename.lower().startswith(Path(sourceDataFileName).stem) == True] , key = lambda f: f.st_mtime)]
                if(len(sorted_matching_files) > 0):
                    actualFileNameAtSource = sorted_matching_files[len(sorted_matching_files) - 1]
                    file_found = True
                    break
            if(files_array[index].filename == sourceDataFileName):
                if(sub_dt.fromtimestamp(files_array[index].st_mtime).month in [month_from_today, month_from_yesterday]):
                    actualFileNameAtSource = files_array[index].filename
                    file_found = True
                    break
        
        # if sourceDataFileName.lower() not in tempFilesInFTP:
        if file_found == False:
            return
        fileIndex = tempFilesInFTP.index(sourceDataFileName.lower()) # Get the File Name in SFTP, This is for case Insensitive Search
        print(fileIndex)

        # actualFileNameAtSource = filesInFTP[fileIndex]

        print('Filename at source {0}'.format(actualFileNameAtSource))

        #print('CompletionFlag File, Data Filename {0}, {1}'.format(file.completedFlagFileName, sourceDataFileName))
        
        file.actualFileNameAtSource = actualFileNameAtSource

        if (file.completedFlagFileName == '' or file.completedFlagFileName.upper() in map(str.upper, filesInFTP)) and sourceDataFileName.upper() in map(str.upper, filesInFTP):
            #print('File Found {0}'.format(sourceDataFileName))
            file.found = True
            file.foundServer = MySQLSource.host
            #print('Absolute Source Name Fido Filename {0} {1}'.format(file.absSourceFileName, file.absFidoFileName))
            if Path(file.absFidoCompressedFileName).is_file() or Path(file.absFidoFileName).is_file():
                #print('File Exists {0}'.format(file.absFidoFileName))
                if file in requiredFiles:
                    alreadyPulledRequiredFilesList.append(file)
                elif file in optionalFiles:
                    alreadyPulledOptionalFilesList.append(file)
                return None
            else:
                #return(absSourceFileName, absFidoFileName)
                print('getFileInfoForPull ... {0}--{1}'.format(file.absSourceFileName, file.absFidoCompressedFileName))
                return file
    except FileNotFoundError:
        print('Ignoring file not found {0}'.format(file.sourcename))   

# revisit
def pull_files(logger, source, frequency, date):
    
    global commonInboundFiles
    global SFTPCallList
    global optionalFiles
    global requiredFiles
    global MissingRequiredFiles
    global ThreadPoolsize
    
    ThreadPoolsize = parseYamlProperty.get_threadpool_size(source, frequency)
    sql_server_list = getSourcePullInfo(logger, source)
    # increase pull wait time to 6hrs
    abort_after = 21600 #seconds
    sleep_time = 60

    timer_start = time.time()
    
    filesFoundFlag = False

    if not sql_server_list:
        sys.tracebacklimit = -1
        raise Exception('Don\'t see any definition for FTP pull, please check for {0} in {1}'.format(source, ftp_file_name))

    pullFilesList = []

    while not filesFoundFlag:

        optionalFiles = getPullOptionalFiles(source, frequency, False)
        requiredFiles = getPullRequiredFiles(source, frequency, False)
        global pulloptionalFiles
        global pullrequiredFiles
        
        pulloptionalFiles = pulloptionalFiles + optionalFiles
        pullrequiredFiles = pullrequiredFiles + requiredFiles
        if not requiredFiles and not optionalFiles:
            raise Exception('Both Required and Optional files can\'t be empty')


        for f in optionalFiles:
            logger.debug(f.absSourceFileName)
        for f in requiredFiles:
            logger.debug(f.absSourceFileName)

        for MySQLSource in sql_server_list:
            
            SFTPCallList = []
            logger.debug('MySQLSource {0}'.format(MySQLSource))
            try:
                transport = paramiko.Transport(MySQLSource.host, 22)
            except paramiko.SSHException as sshException:
                logger.debug('Sftp Server {0} is unreachable, skipping to next server'.format(MySQLSource.host))
                continue
            transport.connect(username=MySQLSource.uname,password=MySQLSource.pwd)
            sftp = paramiko.SFTPClient.from_transport(transport)

            logger.debug(pullFilesList)

            for file in optionalFiles:
                try:
                    logger.debug('optionalFile {0}'.format(file.absSourceFileName))
                    if file not in pullFilesList:
                        x = getFileInfoForPull(file, sftp, date)
                        logger.debug('Optional File Info {0}'.format(x))
                        if x is not None:
                            pullFilesList.append(x)
                            SFTPCallList.append(x)
                            file.foundServer = MySQLSource.host
                except TypeError:
                    pass

            for file in requiredFiles:
                try:
                    logger.debug('RequiredFile {0}'.format(file.absSourceFileName))
                    if file not in pullFilesList:
                        x = getFileInfoForPull(file, sftp, date)
                        logger.debug('Required File Info {0}'.format(x))
                        if x is not None:
                            pullFilesList.append(x)
                            SFTPCallList.append(x)
                            file.foundServer = MySQLSource.host
                except TypeError:
                    pass

            sftp.close()
            transport.close()
            
            #print('Pull Files List {0}'.format(pullFilesList))
            
            if SFTPCallList:
                logger.debug(len(SFTPCallList))
                sftpGetFiles(MySQLSource, SFTPCallList)

            if len(pullFilesList) == len(optionalFiles + requiredFiles):
                logger.debug('Found all {0} files in {1}, {2}'.format(len(pullFilesList), len(optionalFiles), len(requiredFiles)))
                break

        #print(commonInboundFiles)
        optionalFilesNotFound = getPullOptionalFiles(source, frequency, False)
        requiredFilesNotFound = getPullRequiredFiles(source, frequency, False)

        #print('optionalFilesNotFound {0}'.format(optionalFilesNotFound))
        #print('requiredFilesNotFound {0}'.format(requiredFilesNotFound))

        if len(requiredFilesNotFound) == 0:
            filesFoundFlag = True
            logger.debug('Found all required files ... Yay! {0}'.format(time.time()))
        else:
            logger.debug('Going into Wait mode...')
            time.sleep(sleep_time)
            delta = time.time() - timer_start
            logger.debug('What is delta {0}'.format(delta))
            if delta >= abort_after:
                logger.debug('How long should I wait {0}'.format(str(datetime.timedelta(seconds=delta))))
                break
    
    MissingFTPRequiredFiles = get_commonsourceinfo__diff_byfidoname(requiredFiles, pullFilesList + alreadyPulledRequiredFilesList)
    MissingFTPOptionalFiles = get_commonsourceinfo__diff_byfidoname(optionalFiles, pullFilesList + alreadyPulledOptionalFilesList)

    MissingRequiredFiles = MissingRequiredFiles + MissingFTPRequiredFiles
    
    missingRequiredFilesCount = len(MissingFTPRequiredFiles)
    missingOptionalFilesCount = len(MissingFTPOptionalFiles)

    return(len(optionalFiles), len(requiredFiles), missingOptionalFilesCount, missingRequiredFilesCount)

def get_commonsourceinfo__diff_byfidoname(x, y):
    x_names = {record.fidoname for record in x}
    y_names = {record.fidoname for record in y}
    diff_list = list(x_names - y_names)
    missing_object = []
    if diff_list:
        for file_object in x:
            if file_object.fidoname in diff_list:
                missing_object.append(file_object)
    
    return missing_object

def pull_db_files(logger, market, frequency):
    try:
        source = market
        flag = 1
        nbrofmismatchfiles = 0
        maxcntmismtachList = 0 
        logger.debug('Calling ' + market + ' DB extract process')
        strttime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')

        files_list = commonSourceInfo.getPullRequiredDBFiles(market,frequency)
        optionalDBFiles = getPullDBOptionalFiles(source, frequency, False)
        requiredDBFiles = getPullDBRequiredFiles(source, frequency, False)
        global pulloptionalFiles
        global pullrequiredFiles
        global MissingRequiredFiles
        pulloptionalFiles = pulloptionalFiles + optionalDBFiles
        pullrequiredFiles = pullrequiredFiles + requiredDBFiles
        
        logger.debug(files_list)
        db_pulledfileslist = []
                    
        for filename in files_list:
            (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, market,frequency,filename.sourcename)
            logger.debug('Received SQL details')
            cnxn = pyodbc.connect(connstr,timeout=-12000000)
            cnxn.timeout = 150000
            cursor = cnxn.cursor()
            print(market)
            script_path = parseYamlProperty.get_sql_script_dir(market)  + '\\' + scriptname
            with open(script_path, 'r') as open_sql_script:
                data = open_sql_script.read()
                print(data)
            logger.debug('\nConnection to ' + market + ' DB extablished')
            
            tblname = filename.fidoname
            sqlquery_temp = data
            tbname2 = tblname

            logger.debug('\nTable being extracted : {0}'.format(tbname2))
            cursor.execute(sqlquery_temp)
            prepSourceFiles.check_and_create(parseYamlProperty.get_inbound_dir() + '\\' + market + '\\' + frequency)
            base_write_file_name = "{0}_{1}.txt".format(tbname2.strip(), today.strftime('%Y%m%d'))
            write_file_name = os.path.join(parseYamlProperty.get_inbound_dir(), market, frequency, base_write_file_name)
            f = open(write_file_name, 'w', encoding='utf-8')
            logger.debug('\nFile location : {0}'.format(write_file_name))
            field_names = str([i[0] for i in cursor.description])
            head = str.replace(str.replace(str.replace(str.replace(str.replace(field_names,'[',''),',','"~"'),']',''),'\'',''),' ','')
            f.write('"' + head + '"\n')
            logger.debug('\nFetching records from table : {0}'.format(tbname2))
            rowcnt = 0
            while 1:
                row = cursor.fetchone()
                rowcnt = rowcnt + 1
                if cursor.description == None:
                    iterator = range(0, 0).__iter__()
                else:
                    iterator = range(0, len(cursor.description)).__iter__()
                col = ''
                outStr = []
                result = ''
                if not row:
                    break
                for idx in iterator:
                    
                    col = checkNone(attempt_strip((str(row[idx]))))
                    if idx > 0:
                        outStr.append('"~"')
                        outStr.append(str.replace(str.replace(str.replace(str(col),'\n',''),'\\','\\\\'),'"','\\"'))

                    else:
                        outStr.append(str.replace(str.replace(str.replace(str(col),'\n',''),'\\','\\\\'),'"','\\"'))
                result = ''.join(outStr)
                f.write('"' + result + '"')
                f.write("\n")
            f.close()  
            count = rowcnt
            flength = count #file_len(parseYamlProperty.get_inbound_dir() + '\\accuityba\\daily\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt')
            #printwrapper('\nFile count of file {0} : {1} '.format(parseYamlProperty.get_inbound_dir() + '\\' + market + '\\' + frequency + '\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt',flength-1))
            logger.debug('\nFile count of file {0} : {1} '.format(parseYamlProperty.get_inbound_dir() + '\\' + market + '\\' + frequency + '\\'+ tbname2.strip() + '_' +today.strftime('%Y%m%d') + '.txt',flength-1))
            #printwrapper('\nCount of records in DB for table {0} is : {1}'.format(tbname2,int(count)))
            logger.debug('\nCount of records in DB for table {0} is : {1}'.format(tbname2,int(count)))
            if flength - count > 1:
                    cntmismtachList.append(1)
            else:
                    cntmismtachList.append(0)
            #printwrapper('\nData extract completed for table : {0}'.format(tbname2))
            logger.debug('\nData extract completed for table : {0}'.format(tbname2))
            #endtime = today.strftime('%Y%m%d%H%M%S')
            if os.path.exists(write_file_name) :
                db_pulledfileslist.append(filename)
                
        endtime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        print(strttime)
        print(endtime)
        tdelta = int(endtime) - int(strttime)
        tdelta_min = tdelta/60

        MissingDBRequiredFiles = get_commonsourceinfo__diff_byfidoname(requiredDBFiles, db_pulledfileslist)
        MissingDBOptionalFiles = get_commonsourceinfo__diff_byfidoname(optionalDBFiles, db_pulledfileslist)
        MissingRequiredFiles = MissingRequiredFiles + MissingDBRequiredFiles

        #printwrapper('\n*************************************************************')
        #printwrapper('\nStart Time : {0}'.format(strttime))
        #printwrapper('\nEnd Time : {0}'.format(endtime))
        #printwrapper('\nTotal Duration in minutes : {0}'.format(tdelta_min))
        #printwrapper('\n' + market +' Data extract completed...')
        logger.debug('\n' + market +' Data extract completed in {0} minutes'.format(tdelta_min))
        nbrofmismatchfiles = sum(1 for i in cntmismtachList if i == 1)
        maxcntmismtachList = max(cntmismtachList)
        return(len(optionalDBFiles), len(requiredDBFiles), len(MissingDBOptionalFiles), len(MissingDBRequiredFiles))
    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        # printwrapper('\nException raised : {0}\n'.format(str(e)))
        flag = 0
        return(0, 0, 0, 0)


def pull_S3_files(logger, market, frequency, env):
    try:
        source = market
        env = 'prod'
        flag = 1
        nbrofmismatchfiles = 0
        maxcntmismtachList = 0 
        logger.debug('Calling ' + market + ' S3 extract process')
        strttime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        S3Bucketdetails = getS3data.getSourcePullInfo(market, env)
        files_list = commonS3InboundFiles

        optionalS3Files = getPullS3OptionalFiles(source, frequency, False)
        requiredS3Files = getPullS3RequiredFiles(source, frequency, False)

        global pulloptionalFiles
        global pullrequiredFiles
        global MissingRequiredFiles
        
        pulloptionalFiles = pulloptionalFiles + optionalS3Files
        pullrequiredFiles = pullrequiredFiles + requiredS3Files
        
        s3_pulledfileslist = []
        
        # print(files_list)
        logger.debug(files_list)
        s3filespulled = []

        for s3Bucket in S3Bucketdetails:
            for S3fileobject in files_list:
                print(s3Bucket)
                print(S3fileobject.absFidoFileName)
                if S3fileobject.absFidoFileName not in s3filespulled:
                    S3JSONData =  getS3data.getSourcePullInfo(market,env)
                    SourceArchiveFolder = S3fileobject.relativeSourceFolder + 'Archive/' + S3fileobject.sourcename + S3fileobject.sourceExtension
                    session = boto3.Session(profile_name = s3Bucket.profile)
                    lz_path = parseYamlProperty.get_inbound_dir() + market + '\\' + frequency + '\\'
                    logger.debug('Received S3 details')
                    S3_client = session.client('s3')
                    file_exists = S3_client.list_objects_v2(Bucket=s3Bucket.bucket, Prefix=S3fileobject.absSourceFileName).get('Contents')
                    file_exists_in_archived = S3_client.list_objects_v2(Bucket=s3Bucket.bucket, Prefix=SourceArchiveFolder).get('Contents')
                    if file_exists:
                        if os.path.exists(S3fileobject.absFidoCompressedFileName) and file_exists[0]['Size'] == os.path.getsize(S3fileobject.absFidoCompressedFileName):
                            s3_pulledfileslist.append(S3fileobject)
                        else:
                            S3_client.download_file(s3Bucket.bucket, S3fileobject.absSourceFileName, S3fileobject.absFidoCompressedFileName)
                            s3filespulled.append(S3fileobject.absFidoFileName)
                            logger.debug('\nConnection to ' + market + ' S3 established')
                            if os.path.exists(S3fileobject.absFidoCompressedFileName) and file_exists[0]['Size'] == os.path.getsize(S3fileobject.absFidoCompressedFileName):
                                s3_pulledfileslist.append(S3fileobject)
                    elif file_exists_in_archived:
                        if os.path.exists(S3fileobject.absFidoCompressedFileName) and file_exists_in_archived[0]['Size'] == os.path.getsize(S3fileobject.absFidoCompressedFileName):
                            s3_pulledfileslist.append(S3fileobject)
                        else:
                            S3_client.download_file(s3Bucket.bucket, SourceArchiveFolder, S3fileobject.absFidoCompressedFileName)
                            s3filespulled.append(S3fileobject.absFidoFileName)
                            logger.debug('\nConnection to ' + market + ' S3/ARCHIVE established')
                            if os.path.exists(S3fileobject.absFidoCompressedFileName) and file_exists_in_archived[0]['Size'] == os.path.getsize(S3fileobject.absFidoCompressedFileName):
                                s3_pulledfileslist.append(S3fileobject)
                            else:
                                continue
                    print(market)
                    logger.debug('\nConnection to ' + market + ' S3 extablished')
                    tblname = S3fileobject.sourcename
                    logger.debug('\nTable being extracted : {0}'.format(tblname))
                    if isCompressedExtension(S3fileobject.sourceExtension.lower()):
                    # if srcFileSize == destFileSize:
                        uncompressfiles(S3fileobject.absFidoCompressedFileName, S3fileobject.absFidoFileName)   
                    elif os.path.exists(S3fileobject.absFidoCompressedFileName):
                        os.rename(S3fileobject.absFidoCompressedFileName, S3fileobject.absFidoFileName)
                        # raise Exception('SourceFile and DestFile sizes are not matching {0} - {1}'.format(srcFileSize, destFileSize)) 
            # if len(s3filespulled) == len(files_list):
            #     break
        endtime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        print(strttime)
        logger.debug('Start time when S3 pulling started -- {0}'.format(strttime))
        print(endtime)
        logger.debug('end time when S3 pulling started -- {0}'.format(endtime))
        # if len(s3filespulled) != len(files_list):
        #     print('Can\'t find all the files to be pulled from S3 - files_list difference s3filespulled')
        #     logger.debug('Can\'t find all the files to be pulled from S3 - files_list difference s3filespulled')

        MissingS3RequiredFiles = get_commonsourceinfo__diff_byfidoname(requiredS3Files, s3_pulledfileslist)
        MissingS3OptionalFiles = get_commonsourceinfo__diff_byfidoname(optionalS3Files, s3_pulledfileslist)

        MissingRequiredFiles = MissingRequiredFiles + MissingS3RequiredFiles
    
        tdelta = int(endtime) - int(strttime)
        tdelta_min = tdelta/60
        logger.debug('\n' + market +' Data extract completed in {0} minutes'.format(tdelta_min))
        nbrofmismatchfiles = sum(1 for i in cntmismtachList if i == 1)
        # maxcntmismtachList = max(cntmismtachList)

        return(len(optionalS3Files), len(requiredS3Files), len(MissingS3OptionalFiles), len(MissingS3RequiredFiles))

    except Exception as e:
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        print(lineno)
        flag = 0
        return(0, 0, 0, 0)

def process():
    logger = getLogger()
    checkEnvironmentVariables.validate_variables()
    source = commonArgs.getSource()
    frequency = commonArgs.getFrequency()
    debug = commonArgs.getDebugFlag()
    date = commonArgs.getFiledate()
    env = commonArgs.getEnv()
    startdate = commonArgs.getFilestartdate()
    enddate = commonArgs.getFileenddate()

    global pulloptionalFiles
    global pullrequiredFiles
    global MissingRequiredFiles
    
    if not commonSourceInfo.isPullFiles(source, frequency):
        logger.debug('No pull files defined for {0} - {1}'.format(source, frequency))
        return
    logger.debug('Inside CheckandPullFiles Process')
    if date == '':
        date = fido_utils.getToday()

    if startdate == '':
        startdate = date

    if enddate == '':
        enddate = date
    
    logger.debug('Processing for {0}'.format(date))
    # getSourceFiles(source, frequency, date)
    # checkAndPullFiles_Azure.getSourceFiles(source, frequency, date)

    missingOptionalFilesCount = 0
    missingRequiredFilesCount = 0
    optionalFilesCount = 0
    requiredFilesCount = 0

    delta_date_list = fido_utils.get_start_end_date_list(startdate, enddate)
    # print(delta_date_list)
    # input()
    if len(commonSourceInfo.getPullFeedFiles(source, frequency, date)) > 0:
        for in_date in delta_date_list:
            getSourceFiles(source, frequency, in_date)
            [ftp_OptionalFilesCount, ftp_RequiredFilesCount, ftp_missingOptionalFilesCount, ftp_missingRequiredFilesCount] = pull_files(logger, source, frequency, in_date)
            missingOptionalFilesCount = missingOptionalFilesCount + ftp_missingOptionalFilesCount
            missingRequiredFilesCount = missingRequiredFilesCount + ftp_missingRequiredFilesCount

    if len(commonSourceInfo.getPullDBFiles(source, frequency, date)) > 0:
        [db_OptioanlFilesCount, db_RequiredFilesCount, db_missingOptioanlFilesCount, db_missingRequiredFilesCount] = pull_db_files(logger, source, frequency)
        missingOptionalFilesCount = missingOptionalFilesCount + db_missingOptioanlFilesCount
        missingRequiredFilesCount = missingRequiredFilesCount + db_missingRequiredFilesCount

    if len(commonSourceInfo.getPullS3Files(source, frequency, date)) > 0:
        for in_date in delta_date_list:
            getSourceFiles(source, frequency, in_date)
            [s3_OptioanlFilesCount, s3_RequiredFilesCount, s3_missingOptionalFilesCount, s3_missingRequiredFilesCount] = pull_S3_files(logger, source, frequency, env)
            missingOptionalFilesCount = missingOptionalFilesCount + s3_missingOptionalFilesCount
            missingRequiredFilesCount = missingRequiredFilesCount + s3_missingRequiredFilesCount

    if len(commonSourceInfo.getPullAzureFiles(source, frequency, delta_date_list[0])) > 0:
        for in_date in delta_date_list:
            checkAndPullFiles_Azure.getSourceFiles(source, frequency, in_date)
            [azure_OptionalFilesCount, azure_RequiredFilesCount, azure_missingOptionalFilesCount, azure_missingRequiredFilesCount, optionalAzureFiles, requiredAzureFiles, MissingRequiredFiles_Azure] = checkAndPullFiles_Azure.process(in_date)
            pulloptionalFiles = pulloptionalFiles + optionalAzureFiles
            pullrequiredFiles = pullrequiredFiles + requiredAzureFiles

            MissingRequiredFiles = MissingRequiredFiles + MissingRequiredFiles_Azure
            
            missingOptionalFilesCount = missingOptionalFilesCount + azure_missingOptionalFilesCount
            missingRequiredFilesCount = missingRequiredFilesCount + azure_missingRequiredFilesCount
    
    countDict = {}
    countDict['RequiredFilesCount'] = len(pullrequiredFiles)
    countDict['OptionalFilesCount'] = len(pulloptionalFiles)
    countDict['Missing-RequiredFilesCount'] = missingRequiredFilesCount
    countDict['Missing-OptionalFilesCount'] = missingOptionalFilesCount
    print("MissingRequiredFiles===>", MissingRequiredFiles)
    print(len(pulloptionalFiles), len(pullrequiredFiles), missingOptionalFilesCount, missingRequiredFilesCount)
    alertEmailMsgTemplateBuilder.notifyEmail(debug, countDict, pulloptionalFiles + pullrequiredFiles, MissingRequiredFiles , ['source','fileDate','frequency'], ['absFidoFileName','absSourceFileName','found','foundServer'])

if __name__ == "__main__":

    try:
        args = commonArgs.parse()
        logger = AutomationLogging.getLogger('checkAndPullFiles')
        process()

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print(processerrorMsg)