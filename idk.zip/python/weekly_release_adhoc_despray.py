import pandas as pd
from datetime import datetime
import sys
import traceback
import weekly_release_utils
import commonArgs
import parseYamlProperty
import os
import glob
# pylint: disable=E1101
def getDeltas(x, y):
    return (list(set(x) - set(y)))

def collect_files(df, file_type, type_change_column, despray_column, start_month, end_month, application, file_name, object_type, despray_by_developer):
    list_files = []
    app_name = commonArgs.getApplication().upper()
    file_type = file_type.upper()
    try:
        df = df.astype(str)
        base_path = weekly_release_utils.get_script_path()
        table_path = '{0}table'.format(base_path)
        for index, row in df.iterrows():
            if row[despray_by_developer].strip().lower() == 'y':
                continue
            row[type_change_column] = row[type_change_column].upper()
            row[file_name] = row[file_name].replace('.sql', '')
            script_path = ''
            if row[object_type].upper().strip() == 'TABLE':
                script_path = '{0}\\*{1}.*sql'.format(table_path, row[file_name])
            
            if row[application].upper() == app_name and len(glob.glob(script_path)) > 0 and script_path:
                if row[despray_column] != 'nan' and row[despray_column].strip() != '':
                    if row[start_month] != 'nan' and row[start_month].strip() != '':
                        df = pd.date_range(start= row[start_month][4:6] +'/'+ row[start_month][0:4], end=row[end_month][4:6] +'/'+ row[end_month][0:4], freq='MS').strftime('%Y%m')
                        for date in df.values:
                            if row[despray_column].find('.') >= 0:
                                list_files.append(row[despray_column] + '(\'' + date + '\')')                                
                            else:
                                list_files.append(app_name + '.dm.' + row[despray_column] + '.despray(\'' + date + '\')')
                    else :
                        if row[despray_column].find('.') >= 0:
                            list_files.append(row[despray_column])
                            
                        else:
                            list_files.append(app_name + '.dm.' + row[despray_column] + '.despray' )
                    
        list_files = list(dict.fromkeys(list_files))
        return list_files
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = ''.join(line for line in lines)
        print(processerrorMsg)

def collect_files_auto_generate(df, file_type, type_change_column, despray_column, start_month, end_month, application, file_name, object_type, despray_by_developer):
    list_files = []
    app_name = commonArgs.getApplication().upper()
    file_type = file_type.upper()
    try:
        df = df.astype(str)
        base_path = weekly_release_utils.get_script_path()
        table_path = '{0}table'.format(base_path)
        for index, row in df.iterrows():
            if row[despray_column] != 'nan' and row[despray_column].strip() != '':
                if row[start_month] != 'nan' and row[start_month].strip() != '':
                    df = pd.date_range(start= row[start_month][4:6] +'/'+ row[start_month][0:4], end=row[end_month][4:6] +'/'+ row[end_month][0:4], freq='MS').strftime('%Y%m')
                    for date in df.values:
                        list_files.append('sequential('  + app_name + '.dm.' + row[despray_column] + '.despray(\'' + date + '\'),'+ app_name +'.common.util.fn_extract_dim_stats('+ app_name + '.dm.' + row[despray_column] + '.file(\'' + date + '\'),\'' + row[despray_column] + '_' + date + '\'))')
                else :
                    list_files.append('sequential(' + app_name + '.dm.' + row[despray_column] + '.despray,' + app_name + '.common.util.fn_extract_dim_stats(' + app_name + '.dm.' + row[despray_column] + '.file,\'' +  row[despray_column] + '\'))' )
                    
        list_files = list(dict.fromkeys(list_files))
        return list_files
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = ''.join(line for line in lines)
        print(processerrorMsg)

def collect_files_headers_only(df, file_type, type_change_column, despray_column, start_month, end_month, application, file_name, object_type):
    list_files = []
    app_name = commonArgs.getApplication().upper()
    file_type = file_type.upper()
    try:
        df = df.astype(str)
        base_path = weekly_release_utils.get_script_path()
        table_path = '{0}table'.format(base_path)
        for index, row in df.iterrows():
            row[type_change_column] = row[type_change_column].upper()
            row[file_name] = row[file_name].replace('.sql', '')
            script_path = ''
            if row[object_type].upper().strip() == 'TABLE':
                script_path = '{0}\\*{1}.*sql'.format(table_path, row[file_name])
            
            if row[application].upper() == app_name and len(glob.glob(script_path)) > 0 and script_path != '':
                if row[despray_column] != 'nan' and row[despray_column].strip() != '':
                    ecl_path = ''
                    if row[despray_column].find('.') >= 0:
                        despray_list = row[despray_column].split('.')
                        despray_list = despray_list.reverse()
                        ecl_path = "{0}.dm.fn_despray_headersonly({0}.dm.{1}, '{1}')".format(commonArgs.getApplication().lower(), despray_list[1])
                    else:
                        ecl_path = "{0}.dm.fn_despray_headersonly({0}.dm.{1}, '{1}')".format(commonArgs.getApplication().lower(), row[despray_column])

                    list_files.append(ecl_path)
                    
        list_files = list(dict.fromkeys(list_files))
        return list_files
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = ''.join(line for line in lines)
        print(processerrorMsg)


def get_adhoc_despray_script():
        if(commonArgs.getFiledate() == ''):
            run_date = datetime.today().strftime('%Y-%m-%d')
        else:
            run_date = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
        
        despray_folder_name = os.path.join(parseYamlProperty.get_outbound_dir(), 'sql\\dm\\weekly_release_' + run_date.replace('-',''))
        weekly_release_utils.check_and_create(despray_folder_name)
        weekly_release_utils.check_and_create(os.path.join(despray_folder_name, 'working'))
        weekly_release_utils.check_and_create(os.path.join(despray_folder_name, 'archive'))
        weekly_release_utils.check_and_create(os.path.join(despray_folder_name, 'error'))
        base_path = weekly_release_utils.get_base_path()
        file_path = '{0}\\SQL Changes - ALL.xlsx'.format(base_path)
        
        df = weekly_release_utils.read_excel(file_path, run_date, 3)
        
        sheet_table_view_name = weekly_release_utils.constant_table_view_name
        sheet_change_type = weekly_release_utils.constant_change_type
        sheet_sql_ecl_type = weekly_release_utils.constant_sql_ecl_type
        sheet_application = weekly_release_utils.constant_application
        sheet_dim_fact = weekly_release_utils.constant_dim_fact
        sheet_despray_start_month = weekly_release_utils.constant_despray_start_month
        sheet_despray_end_month = weekly_release_utils.constant_despray_end_month
        sheet_despray_by_developer = weekly_release_utils.constant_despray_by_developer

        str_file_list = ''
        file_list = collect_files(df, 'ECL', sheet_sql_ecl_type, sheet_dim_fact, sheet_despray_start_month, sheet_despray_end_month, sheet_application, sheet_table_view_name, sheet_change_type, sheet_despray_by_developer)
        if file_list:
            str_file_list = ', '.join(file_list)
        else:
            str_file_list = 'output(\'nothing to despray for this week\')'
        
        return str(str_file_list)

def get_adhoc_despray_script_auto_generate():
        if(commonArgs.getFiledate() == ''):
            run_date = datetime.today().strftime('%Y-%m-%d')
        else:
            run_date = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
        
        base_path = weekly_release_utils.get_base_path()
        # file_path = '{0}\\SQL Changes - ALL.xlsx'.format(base_path)
        args_sheet_file_path = commonArgs.getSheetPath()
        # if  args_sheet_file_path is not None and args_sheet_file_path != '':
        file_path = args_sheet_file_path
        if(args_sheet_file_path is None or args_sheet_file_path == ''):
            str_file_list = 'output(\'nothing to despray for this week\')'
            return str_file_list
        
        df = weekly_release_utils.read_despray_excel(file_path)
        
        sheet_table_view_name = weekly_release_utils.constant_table_view_name
        sheet_change_type = weekly_release_utils.constant_change_type
        sheet_sql_ecl_type = weekly_release_utils.constant_sql_ecl_type
        sheet_application = weekly_release_utils.constant_application
        sheet_dim_fact = weekly_release_utils.constant_dim_fact
        sheet_despray_start_month = weekly_release_utils.constant_despray_start_month
        sheet_despray_end_month = weekly_release_utils.constant_despray_end_month
        sheet_despray_by_developer = weekly_release_utils.constant_despray_by_developer

        str_file_list = ''
        file_list = collect_files_auto_generate(df, 'ECL', sheet_sql_ecl_type, sheet_dim_fact, sheet_despray_start_month, sheet_despray_end_month, sheet_application, sheet_table_view_name, sheet_change_type, sheet_despray_by_developer)
        if file_list:
            str_file_list = ', '.join(file_list)
        else:
            str_file_list = 'output(\'nothing to despray for auto generate despray feature \')'
        
        return str(str_file_list)

def get_adhoc_despray_script_headers_only():
        if(commonArgs.getFiledate() == ''):
            run_date = datetime.today().strftime('%Y-%m-%d')
        else:
            run_date = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
        
        despray_folder_name = os.path.join(parseYamlProperty.get_outbound_dir(), 'sql\\dm\\weekly_release_' + run_date.replace('-',''))
        weekly_release_utils.check_and_create(despray_folder_name)
        weekly_release_utils.check_and_create(os.path.join(despray_folder_name, 'working'))
        weekly_release_utils.check_and_create(os.path.join(despray_folder_name, 'archive'))
        weekly_release_utils.check_and_create(os.path.join(despray_folder_name, 'error'))
        base_path = weekly_release_utils.get_base_path()
        file_path = '{0}\\SQL Changes - ALL.xlsx'.format(base_path)
        
        df = weekly_release_utils.read_excel(file_path, run_date, 3)
        # file_columns = df.columns.values

        sheet_table_view_name = weekly_release_utils.constant_table_view_name
        sheet_change_type = weekly_release_utils.constant_change_type
        sheet_sql_ecl_type = weekly_release_utils.constant_sql_ecl_type
        sheet_application = weekly_release_utils.constant_application
        sheet_dim_fact = weekly_release_utils.constant_dim_fact
        sheet_despray_start_month = weekly_release_utils.constant_despray_start_month
        sheet_despray_end_month = weekly_release_utils.constant_despray_end_month
        
        str_file_list = ''
        
        file_list = collect_files_headers_only(df, 'ECL', sheet_sql_ecl_type, sheet_dim_fact, sheet_despray_start_month, sheet_despray_end_month, sheet_application, sheet_table_view_name, sheet_change_type)
        if file_list:
            str_file_list = ', '.join(file_list)
        else:
            str_file_list = 'output(\'nothing to despray for this week\')'
                
        return str(str_file_list)

if __name__ == "__main__":
    try:
        # print("result =>",get_adhoc_despray_script())
        print("result =>",get_adhoc_despray_script_headers_only())
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = ''.join(line for line in lines)
        print(processerrorMsg)