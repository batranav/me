from tempfile import mkstemp
from shutil import move
from os import remove, close, path
import parseYamlProperty
def replace(file, pattern, subst):
    #Create temp file
    fh, abs_path = mkstemp()
    print (fh, abs_path)
    new_file = open(abs_path,'w')
    old_file = open(file)
    for line in old_file:
        new_file.write(line.replace(pattern, subst))
    #close temp file
    new_file.close()
    close(fh)
    old_file.close()
    #Move new file
    newfilename = file.replace(".txt", "_" + subst + ".ecl").replace("_template", "")
    move(abs_path, newfilename)

if __name__ == "__main__":
    yrMonthList = list(range(200801, 200813)) + list(range(200901, 200913)) + list(range(201001, 201013)) + list(range(201101, 201113)) + list(range(201201, 201213)) + list(range(201301, 201313)) + list(range(201401, 201413)) + list(range(201501, 201506))
    print(yrMonthList)
    callfile = open(path.join(parseYamlProperty.get_base_script_dir(),'python\\history\\update_fact_revenue_international_bwr_call.bat'), 'w')
    for yrMonth in yrMonthList:
        newfilename = path.join(parseYamlProperty.get_base_script_dir(),'python\\history\\update_fact_revenue_international_template.txt').replace('buildx', str(yrMonth))
        callfile.write('start /b ' + path.join(parseYamlProperty.get_base_script_dir(),'python\\call_history_ecl.bat update_fact_revenue_international_' + str(yrMonth)) + '\n')
