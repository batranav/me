import psutil
import socket
from collections import namedtuple
import datetime
from send_email import *

ProcessInfo = namedtuple('ProcessInfo', 'hostname Drive UsedSpace AvailableSpace PercentAvailable')

dt = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')  # datetime now (all in UTC)
dtstr = datetime.datetime.strptime(dt, '%Y%m%d%H%M%S%f').strftime('%m-%d-%Y %H:%M:%S')
_warningThreshold=15
_errorThreshold=10

def set_process_name(self):
        klass = self.__class__.__name__
        properties = []
        for prop in getattr(self, "_named_mixin_properties", []):
            properties.append("{}={}".format(prop, getattr(self, prop)))
        name = "{}({})".format(klass, ", ".join(properties))


def format_bytes(B):
    """Return the given bytes as a human friendly KB, MB, GB, or TB string."""
    B = float(B)
    KB = float(1024)
    MB = float(KB ** 2) # 1,048,576
    GB = float(KB ** 3) # 1,073,741,824
    TB = float(KB ** 4) # 1,099,511,627,776

    if B < KB:
        return '{0} {1}'.format(B,'Bytes' if 0 == B > 1 else 'Byte')
    elif KB <= B < MB:
        return '{0:.2f} KB'.format(B / KB)
    elif MB <= B < GB:
        return '{0:.2f} MB'.format(B / MB)
    elif GB <= B < TB:
        return '{0:.2f} GB'.format(B / GB)
    elif TB <= B:
        return '{0:.2f} TB'.format(B / TB)

def sendMail(drives, flag) :
    print(flag)
    if (flag=='error'):
        EmailSubject = "SEV 1 Error : Disk Space Alert" + str(drives[0].hostname) + '-- Drive Info ' + '--' + dtstr
        emailTo = ['fido.ops@lexisnexisrisk.com']
    elif(flag=='warning'):
        EmailSubject =  "Warning : Disk Space Alert" + str(drives[0].hostname) + '-- Drive Info ' + '--' + dtstr
        emailTo = ['fido.ops@lexisnexisrisk.com']
    
    emailFrom = 'Fidoautomation@lexisnexisrisk.com'
    
    result = ""

    for drive in drives:
        result += drive.Drive + " -- Used Space: " + str(drive.UsedSpace) + ", Available Space: " + str(drive.AvailableSpace) + ", Percent Available: " + str(drive.PercentAvailable) + "%" + "\n\n"
    
    result += 'Thresholds are :\n Warning  - ' + str(_warningThreshold) + '%\n Critical - ' + str(_errorThreshold) + '%'

    send_mail(emailFrom,emailTo,[],EmailSubject,'' + result)

def getDriveSpace():
    global ProcessInfo,_cDriveThresold,_dDriveThresold
    cDrive = {}
    dDrive = {}

    cDrive = psutil.disk_usage('C:/')
    dDrive = psutil.disk_usage('D:/')

    cDriveSpacePercentLeft = abs(100 - cDrive.percent)
    dDriveSpacePercentLeft = abs(100 - dDrive.percent)

    drives = []
    drives.append(ProcessInfo(socket.gethostname(), 'C-Drive', format_bytes(cDrive.used), format_bytes(cDrive.free), round(abs(100 - cDrive.percent),2)))
    drives.append(ProcessInfo(socket.gethostname(), 'D-Drive', format_bytes(dDrive.used), format_bytes(dDrive.free), round(abs(100 - dDrive.percent),2)))

    if cDriveSpacePercentLeft < _errorThreshold or dDriveSpacePercentLeft < _errorThreshold:
        sendMail(drives, 'error')
    elif cDriveSpacePercentLeft < _warningThreshold or dDriveSpacePercentLeft < _warningThreshold:
        sendMail(drives, 'warning')
    else:
        print("No disk space issues noted")
    

if __name__ == '__main__':
    getDriveSpace()