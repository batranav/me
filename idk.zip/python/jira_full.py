from jira import JIRA
import sys, http.client, os
import json
import csv
import os
from collections import defaultdict
from datetime import datetime, timedelta
import yaml
import io
import base64
import platform
from redsourceinbounddtls import redsourceinbounddtls
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret

sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir() ,'jira//fields_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
#sys.stdout = open('D:\\red\\applogs\\field_'+ datetime.now().strftime('%Y%m%d') + '.txt','w')
def main():

	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_full', True)
	uname, pwd = get_api_secret(logger, 'jira')
	jira = JIRA(options, basic_auth=(uname, pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		print('working')
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   updated >= -4d and updated <= 1d  ' , startidx, blocksize)
		#newissues=jira.search_issues('project !=EMPTY and  created >= "2019/01/01" AND created <= "2019/03/31" ' , startidx, blocksize)
		
		numissues=len(newissues)
		if  numissues==0 or  blocknum==400:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0	
	
	# fieldsfile=open('D:\\red\\data\\inbound\\jira\\daily\\fields_' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	fieldsfile=open(os.path.join(parseYamlProperty.get_inbound_dir() ,'jira//daily//fields_'+ datetime.now().strftime('%Y%m%d') + '.csv'),"w+", encoding='utf-8',newline="")
	fieldswriter=csv.writer(fieldsfile)
	
	fieldname = ['customfield_10500'	,
				'created'	,
				'issuelinks'	,
				'subtasks'	,
				'customfield_20512'	,
				'customfield_21601'	,
				'customfield_11305'	,
				'customfield_10337'	,
				'customfield_12745'	,
				'aggregatetimeestimate'	,
				'customfield_20000'	,
				'customfield_10319'	,
				'customfield_19002'	,
				'customfield_21200'	,
				'customfield_19000'	,
                'timespent'	,
                'customfield_19001'	,
                'aggregatetimespent'	,
                'components'	,
                'timeoriginalestimate'	,               
                'priority'	,
                'customfield_17769'	,
                'customfield_11601'	,
                'updated'	,
                'created'	,
				'summary'.strip('\n')	,
                'customfield_10902'	,
                'customfield_10909'	,
                'customfield_20304'	,
                'customfield_15728'	,
                'customfield_12415'	,
                'customfield_10000'	,
                'customfield_11238'	,
                'customfield_13902'	,
                'customfield_10916'	,
                'customfield_11000'	,
                'customfield_10917'	,
                'customfield_10925'	,
                'customfield_10920'	,
                'customfield_10928'	,
                'resolutiondate'	,
                'customfield_10315'	,
                'customfield_19223'	,
                'customfield_10001'	,
                'customfield_11204'	,
                'customfield_10505'	,
                'customfield_10101'	,
                'customfield_21104'	,
				'assignee'	,
				'creator'	,
				'reporter'	,
				'status'	,
				'issuetype'	,
				'project'	,
				'customfield_11210'		,
				'customfield_11243'		,
				'customfield_12410'	,				
				'customfield_13800'	,
				'customfield_14524'	,
				'customfield_19214'		,
				'customfield_21410'		,
				'customfield_21700'		,
				'customfield_22102'		,
				'customfield_25000'		,
				'customfield_25001'		,
				'customfield_25002'		,
				'customfield_25003'		,
				'customfield_25004'		,
				'customfield_25005'		,
				'customfield_25006'		,
				'customfield_25007'		,
				'customfield_25008'		,
				'customfield_25009'		,
				'customfield_25011'		,
				'customfield_25012'		,
				'customfield_25200'		,
				'customfield_10008'		,
				'customfield_10813'		,
				'customfield_10814'		,
				'customfield_11215'		,
				'customfield_11248'		,
				'customfield_11805'		,
				'customfield_18501'		,
				'customfield_20700'		,
				'customfield_20800'		,
				'customfield_23804'		,
				'customfield_25014'		,
				'customfield_25015'		,
				'customfield_25016'		,
				'customfield_25013'		,
				'customfield_25301'		,
				'customfield_11601'		,
				'customfield_13808'		,
				'customfield_14432'		,
				'customfield_20805'		,
				'customfield_13811'		,
				'customfield_13812'		,
				'customfield_13810'		,
				'customfield_11309'		,
				'customfield_19246'		,
				'customfield_22116'		,
				'fixVersions',
				'customfield_20510',
				'customfield_20511',
				'issue','customfield_25017','customfield_12919']
	
	
	#Customer,DVI Operator,SPOT Operator,QA Analyst,Deployment Analyst,Data Arrival Date (ETA),Data Arrival Date
	
	for resultlist in issues:	
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
				
			fields=dict['fields']
			del dict['fields']
			fields['issue']=issueId
			#if issue is not None:
			#	del fields['issue']
			fieldsDict=fields
			writer = csv.DictWriter(fieldsfile, fieldnames=fieldname, extrasaction='ignore')
			if issues  is None:
				del fields['issue']
			if issuecount==0:
			
				writer.writeheader()
			writer.writerow(fieldsDict)

	
			
				
			issuecount=issuecount+1
				
	fieldsfile.close()
	
if __name__== "__main__" :
     main()





