import os, datetime, argparse, shutil, sys
from pathlib import Path

def checkIfFileExists(filename):
    fileexist = Path(filename)
    if not fileexist.is_file():
        return False
    else:
        return True

def getNewFileName(filePath, givenDate):
    splitfilePath = filePath.rsplit(sep='/', maxsplit=1)
    filename = splitfilePath[1].rpartition('.')
    newFileName = filename[0] + '_' + givenDate + filename[1] + filename[2]
    newFileName = splitfilePath[0] + '/' + newFileName
    return newFileName

def checkIfFolderExists(folderPath):
    folderExist = Path(folderPath)
    if not folderExist.exists():
        return False
    else:
        return True

def createNewFolder(folderPath):
    try:
        os.makedirs(folderPath)
    except OSError:
        print ("Could not create the directory %s" % folderPath)
        return False
    else:
        return True

def copyFileToFolder(filepath, folderpath, date):
    folderexists = checkIfFolderExists(folderpath)
    if(folderexists):
        try:
            shutil.copy(filepath, folderpath)
            splitfilePath = filepath.rsplit(sep='/', maxsplit=1)
            newfolderfilepath = folderpath + '/' + splitfilePath[1]
            newfilename = getNewFileName(newfolderfilepath, date)
            os.rename(newfolderfilepath, newfilename)
        except IOError as e:
            print("Unable to copy file. %s" % e)
        except:
            print("Unexpected error:", sys.exc_info())
    else:
        folderCreated = createNewFolder(folderpath)
        if(folderCreated):
            try:                
                shutil.copy(filepath, folderpath)
                splitfilePath = filepath.rsplit(sep='/', maxsplit=1)
                newfolderfilepath = folderpath + '/' + splitfilePath[1]
                newfilename = getNewFileName(newfolderfilepath, date)
                os.rename(newfolderfilepath, newfilename)
            except IOError as e:
                print("Unable to copy file. %s" % e)
            except:
                print("Unexpected error:", sys.exc_info())
        else:
            print("Unable to create new folder. %s" % e)

def moveFileToFolder(filepath, folderpath, newfilename):
    folderexists = checkIfFolderExists(folderpath)
    if(folderexists):
        try:
            os.rename(filepath, newfilename)
            shutil.move(newfilename, folderpath)
        except IOError as e:
            print("Unable to move file. %s" % e)
        except:
            print("Unexpected error:", sys.exc_info())
    else:
        folderCreated = createNewFolder(folderpath)
        if(folderCreated):
            try:
                os.rename(filepath, newfilename)
                shutil.move(newfilename, folderpath)
            except IOError as e:
                print("Unable to move file. %s" % e)
            except:
                print("Unexpected error:", sys.exc_info())
        else:
            print("Unable to create new folder. %s" % e)

if __name__== "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-fn","--filename", help="File name", required=True)
    parser.add_argument("-dt","--date", help="Date", required=False)
    parser.add_argument("-fl","--folder", help="Folder name", required=True)
    parser.add_argument("-a","--action", help="Copy/Move", choices=['c','m'], required=True)
    args = parser.parse_args()

    result = checkIfFileExists(args.filename)
    if(not result):
        print("Given file: ", args.filename, " does not exist")
    else:
        if(args.action == 'c'):
            if(not args.date is None):
                copyFileToFolder(args.filename, args.folder, args.date)
                print("Copied file to folder with given date.")
            else:
                todayDate = datetime.datetime.today().strftime('%Y%m%d')
                copyFileToFolder(args.filename, args.folder, todayDate)
                print("Copied file to folder with today's date.")
        
        elif(args.action == 'm'):
            if(not args.date is None):
                newfilename = getNewFileName(args.filename, args.date)
                moveFileToFolder(args.filename, args.folder, newfilename)
                print("Moved file to folder with given date.")
            else:
                todayDate = datetime.datetime.today().strftime('%Y%m%d')
                newfilename = getNewFileName(args.filename, todayDate)
                moveFileToFolder(args.filename, args.folder, newfilename)
                print("Moved file to folder with today's date.")
        else:
            print("Please check your syntax.\nUse <filename> <date> <foldername> <c/m>")