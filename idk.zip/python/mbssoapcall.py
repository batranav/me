from send_email import *
from datetime import datetime
import json
import sys
from xml.dom.minidom import parseString
import http.client
import re
import parseYamlProperty
import prepSourceFiles
import fido_utils
import commonArgs
import platform
import os, shutil, sys
import AutomationLogging
from vault.secrets import get_api_secret

dt = datetime.now().strftime('%Y%m%d%H%M%S%f')  # datetime now (all in UTC)
dtstr = datetime.strptime(dt, '%Y%m%d%H%M%S%f').strftime('%m-%d-%Y_%H%M%S')
fldate = datetime.strptime(dt, '%Y%m%d%H%M%S%f').strftime('%Y%m%d')

print(dtstr)

def getLogger():
    return AutomationLogging.getLogger('mbsSoapCall')
    #return 1

def getplatforminfo(env):
    logger = getLogger()
    logger.debug('Getting platform information.')
    if env == 'prod':
        # for sessionid
        baseurl = 'bmbsws.risk.regn.net'
        # for dashboard
        dashurl = 'mbs-ms-production.risk.regn.net'
    else:
        # for sessionid
        baseurl = 'mbswsdev.risk.regn.net'
        # for dashboard
        dashurl = 'mbs-ms-dev.risk.regn.net'
    uname, pwd = get_api_secret(logger, 'mbssoap')
    logger.debug('env: {0}'.format(env))
    logger.debug('baseurl: {0}'.format(baseurl))
    logger.debug('dashurl: {0}'.format(dashurl))
    return baseurl,uname,pwd,dashurl

def createjson(mapcodes, statusid, status_message):
    logger = getLogger()
    logger.debug('Creating json object with mapcodes.')
    textdata = []
    fileDateFromArgs = commonArgs.getFiledate() #datetime.now().strftime('%m-%d-%Y %H:%M:%S')
    if fileDateFromArgs=='':
        fileDate = datetime.now().strftime('%m-%d-%Y %H:%M:%S')
    else:
        fileDateFromArgs = datetime.strptime(fileDateFromArgs, '%Y%m%d').strftime('%m-%d-%Y')
        addtime = datetime.now().strftime('%H:%M:%S')
        fileDate = fileDateFromArgs + ' ' + addtime
    print(fileDate)
    # fileDate = '2021-01-05 17:02:11'
    for mapcode in mapcodes:
        rowdata = {
            "DashboardCode": "BDD",
            "ColumnCode": "FDL",
            "MapCode": mapcode,
            "ProcessDate": fileDate,
            "StatusId": statusid,
            "Message": status_message
        }
        textdata.append(rowdata)
    logger.debug('json:\n {0}'.format(textdata))
    result = json.dumps(textdata)
    return result

def create_mbs_session(baseurl,login,passw):
    logger = getLogger()
    logger.debug('Creating MBS session.')
    # tagname = 'bil:OpenSession'
    #baseurl = 'mbswsdev.risk.regn.net'
    SoapMessage1 = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:bil="http://billingsystems.lexisnexis.com/"><soap:Header/><soap:Body><bil:OpenSession><!--Optional:--><bil:domain>risk</bil:domain><!--Optional:-->'
    SoapMessage2 = '<bil:login>'+ login +'</bil:login><!--Optional:-->'
    SoapMessage3 = '<bil:password>' + passw +'</bil:password></bil:OpenSession></soap:Body></soap:Envelope>'
    SoapMessage = SoapMessage1 + SoapMessage2 + SoapMessage3
    sodurl = 'https://' + baseurl
    headers = {"Host": baseurl,
    "Content-Type": "application/soap+xml; charset=UTF-8",
    "Content-Length": str(len(SoapMessage))}
    # "SOAPAction" : _soapAction}
    try:
        conn = http.client.HTTPSConnection(baseurl)
        conn.request('POST', sodurl + '/BillingSystemsMBS/ws_mbsauth.asmx?op=OpenSession', SoapMessage, headers)
        response = conn.getresponse()
        print("Response: ", response.status, response.reason)
        print("headers: ", headers)
        temp = response.read()
        res = temp.decode('UTF-8')
        # print(res)
        session_ss = '<session_id>[0-9]+</session_id>'
        session_ss_re = re.search(session_ss,res)
        tmp = session_ss_re.group(0)
        tmp_ss = '[0-9]+'
        tmp_ss_re = re.search(tmp_ss,tmp)
        # print(session_ss_re.group(0))
        # print(tmp_ss_re.group(0))
        logger.debug('MBS session ID: {0}'.format(tmp_ss_re.group(0)))
        return (0, tmp_ss_re.group(0))
    except Exception as ex:
        text = 'Error creating session id because: {0}'.format(ex)
        logger.debug('Error creating session id because: {0}'.format(ex))
        return (1,text)

def close_mbs_session(sessionid, baseurl):
    logger = getLogger()
    logger.debug('Closing MBS session: {0}'.format(sessionid))
    #<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:bil="http://billingsystems.lexisnexis.com/"><soap:Header/><soap:Body><bil:CloseSession><!--Optional:--><bil:session_id>?</bil:session_id></bil:CloseSession></soap:Body></soap:Envelope>
    SoapMessage = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:bil="http://billingsystems.lexisnexis.com/"><soap:Header/><soap:Body><bil:CloseSession><!--Optional:--><bil:session_id>' + str(sessionid) + '</bil:session_id></bil:CloseSession></soap:Body></soap:Envelope>'
    #baseurl = 'mbswsdev.risk.regn.net'
    sodurl = 'https://' + baseurl
    headers = {"Host": baseurl,
    "Content-Type": "application/soap+xml; charset=UTF-8",
    "Content-Length": str(len(SoapMessage))}
    try:
        conn = http.client.HTTPSConnection(baseurl)
        conn.request('POST', sodurl + '/BillingSystemsMBS/ws_mbsauth.asmx?op=CloseSession', SoapMessage, headers)
        response = conn.getresponse()
        print("Response: ", response.status, response.reason)
        print("headers: ", headers)
        temp = response.read()
        res = temp.decode('UTF-8')
        code_ss = '<Code>\d+</Code>'
        code_ss_re = re.search(code_ss,res)
        tmp = code_ss_re.group(0)
        tmp_ss = '\d+'
        tmp_ss_re = re.search(tmp_ss,tmp)
        rescode = tmp_ss_re.group(0)
        print(rescode)
        if rescode == '0' or rescode == '23':
            text = 'Session id {0} is closed.'.format(sessionid)
            logger.debug('Session id {0} is closed.'.format(sessionid))
            return (0, text)
        else:
            text = 'Check session id {0} status on https://mbswsdev.risk.regn.net/BillingSystemsMBS/ws_mbsauth.asmx.'.format(sessionid)
            logger.debug('Check session id {0} status on https://mbswsdev.risk.regn.net/BillingSystemsMBS/ws_mbsauth.asmx.'.format(sessionid))
            return (2, text)
    except Exception as ex:
        text = 'Error closing session because: {0}'.format(ex)
        logger.debug('Error closing session because: {0}'.format(ex))
        return (2,text)

# def getstatuses(sessionid):
#     #https://mbs-ms-dev.risk.regn.net/ws_dashboard/GetStatuses
#     body = ''
#     baseurl = 'mbs-ms-dev.risk.regn.net'
#     sodurl = 'https://' + baseurl
#     auth = 'LNAA ' + str(sessionid)
#     headers = {"Host": baseurl,
#     "Content-Type": "application/json; charset=UTF-8",
#     "Content-Length": str(len(body)),
#     "Authorization": auth}
#     try:
#         conn = http.client.HTTPSConnection(baseurl)
#         conn.request('POST', sodurl + '/ws_dashboard/GetStatuses', None, headers)
#         response = conn.getresponse()
#         print("Response: ", response.status, response.reason)
#         print("headers: ", headers)
#         temp = response.read()
#         res = temp.decode('UTF-8')
#         return res
#     except ex:
#         print(ex)

# def getcells(sessionid):
#     #https://mbs-ms-dev.risk.regn.net/ws_dashboard/GetCells
#     baseurl = 'mbs-ms-dev.risk.regn.net'
#     sodurl = 'https://' + baseurl
#     auth = 'LNAA ' + str(sessionid)
#     body = {"DashboardId": 10,"DateRange": {"StartDate": "2020-10-19T23:59:59.000","EndDate": "2020-10-20T13:00:00.000"}}
#     jsonObj = json.dumps(body)
#     headers = {"Host": baseurl,
#     "Content-Type": "application/json; charset=UTF-8",
#     "Content-Length": str(len(str(jsonObj))),
#     "Authorization": auth}
#     try:
#         conn = http.client.HTTPSConnection(baseurl)
#         conn.request('POST', sodurl + '/ws_dashboard/GetCells', jsonObj, headers)
#         response = conn.getresponse()
#         print("Response: ", response.status, response.reason)
#         print("headers: ", headers)
#         temp = response.read()
#         res = temp.decode('UTF-8')
#         return res
#     except ex:
#         print(ex)

def updatestatus(sessionid, jsonObj, dashurl):
    logger = getLogger()
    logger.debug('Updating dashboard using MBS session: {0} on {1}'.format(sessionid,dashurl))
    logger.debug('jsonObject:\n {0}'.format(jsonObj))
    # print(jsonObj)
    sodurl = 'https://' + dashurl
    auth = 'LNAA ' + str(sessionid)
    # print(auth)
    headers = {"Host": dashurl,
    "Content-Type": "application/json; charset=UTF-8",
    "Content-Length": str(len(str(jsonObj))),
    "Authorization": auth}
    try:
        conn = http.client.HTTPSConnection(dashurl)
        conn.request('POST', sodurl + '/ws_dashboard/InsertCell', jsonObj, headers)
        response = conn.getresponse()
        # print("Response: ", response.status, response.reason)
        # print("headers: ", headers)
        temp = response.read()
        res = temp.decode('UTF-8')
        resultCount_ss = '"ResultCount":[\d]+,"'
        resultCount_ss_re = re.search(resultCount_ss,res)
        tmp = resultCount_ss_re.group(0)
        tmp_ss = '\d+'
        tmp_ss_re = re.search(tmp_ss,tmp)
        resultCount = tmp_ss_re.group(0)
        if int(resultCount) > 0:
            text = '{0} records updated.'.format(resultCount)
            logger.debug('{0} records updated.'.format(resultCount))
            return(0, text)
        else:
            text = '{0} records updated.'.format(resultCount)
            logger.debug('{0} records updated.'.format(resultCount))
            return(1, text)
    except Exception as ex:
        text = 'Error updating records because: {0}'.format(ex)
        logger.debug('Error updating records because: {0}'.format(ex))
        return (1, text)

def getmapcodesfromdesprayfile():
    logger = getLogger()
    logger.debug('Getting mapcodes from the despray file:')
    mapcodes = []
    filepath = parseYamlProperty.get_outbound_dir() + '\\sql\\dm\\mbs_dashboard\\working\\mbs_dashboard_update.tsv'
    logger.debug('{0}'.format(filepath))
    desprayfile = open(filepath,'r')
    if desprayfile.mode == 'r':
        filecontent = desprayfile.read()
        # print(filecontent)
        lines = filecontent.split('\n')
        # print(lines[0])
        for eachline in lines:
            if len(eachline) > 0:
                item = eachline.split('\t')
                if item[3] != '60':
                    if item[0] != '':
                        mapcodes.append(item[0])
    logger.debug('Mapcodes:\n{0}'.format(mapcodes))
    return mapcodes

def sendMail(code,msg):
    logger = getLogger()
    logger.debug('Preparing to send email')
    servername = platform.node()
    
    EmailSubject = servername + '-- ' + myApplication +' MBS Dashboard Update - ' + dtstr 

    successEmailFrom = "SUCESS-Fido."+ commonArgs.getApplication() + ".automation@lexisnexisrisk.com"
    errorEmailFrom  = "ERROR-Fido."+ commonArgs.getApplication() + ".automation@lexisnexisrisk.com"

    emailTo = ['Nyruthya.Sanandan@lexisnexisrisk.com']

    if(code==0):
        logger.debug('Sending success email')
        send_mail(successEmailFrom,emailTo,[],EmailSubject,msg)
    else:
        logger.debug('Sending error email')
        send_mail(errorEmailFrom,emailTo,[],EmailSubject,msg)

def createhtmlbody(updatedval):
    logger = getLogger()
    logger.debug('Creating email body in html')
    body = "\n"
    for eachitem in updatedval:
        body = body + str(eachitem) + "\n\n"
    return body

def process():
    logger = getLogger()
    
    global myApplication
    myApplication = commonArgs.getSource()
    updatedval = []
    fromFilr = parseYamlProperty.get_outbound_dir() + '\\sql\\dm\\mbs_dashboard\\'
    fileName = 'mbs_dashboard_update.tsv'
    workingfilepath = parseYamlProperty.get_outbound_dir() + '\\sql\\dm\\mbs_dashboard\\working\\'
    prepSourceFiles.check_and_create(workingfilepath)
    shutil.move(os.path.join(fromFilr, fileName), os.path.join(workingfilepath, fileName))
    updatedval.append('File moved to working')
    logger.debug('File moved to working directory')

    mapcodesfromdesprayfile = getmapcodesfromdesprayfile()
    updatedval.append('mapcodes from despray file:')
    updatedval.append(mapcodesfromdesprayfile)
    print(mapcodesfromdesprayfile)

    statusid = 30
    status_message = 'Data loaded into fido'
    result = createjson(mapcodesfromdesprayfile, statusid, status_message)
    jsonobj = json.loads(result)
    updatedval.append('json created')
    updatedval.append(jsonobj)
    print(jsonobj)

    env = commonArgs.getEnv()
    baseurl,login,passw,dashurl = getplatforminfo(env)

    res, sessionid = create_mbs_session(baseurl,login,passw)
    updatedval.append('\nmbs session:')
    updatedval.append(sessionid)
    print(sessionid)


    if(res == 0):
        for eachjson in jsonobj:
            stat,text = updatestatus(sessionid, str(eachjson), dashurl)
            updatedval.append('\nupdate status for object: {0}'.format(eachjson))
            updatedval.append(text)
            print(text)

        closestat,closetext = close_mbs_session(sessionid, baseurl)
        updatedval.append('\nmbs close session:')
        updatedval.append(closetext)
        archivefilepath = parseYamlProperty.get_outbound_dir() + '\\sql\\dm\\mbs_dashboard\\archive\\' + fldate
        prepSourceFiles.check_and_create(archivefilepath)


        shutil.move(os.path.join(workingfilepath, fileName), os.path.join(archivefilepath, fileName))
        updatedval.append('\nFile moved to archive')
        logger.debug('File moved to archive directory')
        msg = createhtmlbody(updatedval)
        sendMail(res,msg)
        return closetext
    else:
        msg = createhtmlbody(updatedval)
        sendMail(res,msg)
        return sessionid

if __name__ == "__main__":
    logger = getLogger()
    try:
        process()
    except Exception as ex:
        msg = 'Exception at main with message: {0}'.format(ex)
        logger.debug('Exception at main with message: {0}'.format(ex))
        sendMail(1,msg)