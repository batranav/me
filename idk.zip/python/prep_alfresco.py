import datetime
import shutil
import os.path
import os, parseYamlProperty

def getToday():
   today=datetime.date.today()
   return today.strftime("%Y%m%d")

def process(source_dir):
   input_filename = source_dir + '\\alfresco_data.txt'
   if os.path.exists(input_filename):
      today = getToday()
      output_filename = source_dir + '\\alfresco_data_' + today + '.txt'
      shutil.move(input_filename, output_filename)
   
if __name__ == '__main__':
   process(os.path.join(parseYamlProperty.get_inbound_dir(),'alfresco\\daily'))