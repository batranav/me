import pyodbc
from contextlib import suppress
import pandas as pd
from datetime import datetime
import sys
import traceback
import parseYamlProperty as parse_props
import generate_weekly_email
import commonArgs
from collections import namedtuple
import AutomationLogging
import weekly_release_utils
import parseYamlProperty as parse_props
import re
import glob
import codecs
import fido_utils

def getLogger():
    return AutomationLogging.getLogger('Weeklyrelease')
def xstr(s):
    return '' if s is None else str(s)

def getDeltas(x, y):
    return (list(set(x) - set(y)))
def get_sql_script(logger, execution_type):
    logger.debug('get_sql_script function initiated')
    base_path = weekly_release_utils.get_base_path()
    file_path = '{0}\\SQL Changes - ALL.xlsx'.format(base_path)
    if(commonArgs.getFiledate() == ''):
        sheet_name = datetime.today().strftime('%Y-%m-%d')
    else:
        sheet_name = datetime.strptime(commonArgs.getFiledate(), '%Y%m%d').strftime('%Y-%m-%d')
    logger.debug('Release excel file path {0} sheet name {1}'.format(file_path, sheet_name))
    df = weekly_release_utils.read_excel(file_path, sheet_name, 3)

    sheet_table_view_name = weekly_release_utils.constant_table_view_name
    sheet_change = weekly_release_utils.constant_change
    sheet_change_type = weekly_release_utils.constant_change_type
    sheet_sql_ecl_type = weekly_release_utils.constant_sql_ecl_type
    sheet_application = weekly_release_utils.constant_application
    sheet_jira_ticket = weekly_release_utils.constant_jira_ticket
        
    logger.debug('pandas frame work {0}'.format(df))
    status_dict = {}
    status_dict = execute_sql_files(logger, df, 'SQL', sheet_sql_ecl_type, sheet_change_type, sheet_table_view_name, sheet_application, sheet_change, execution_type, sheet_jira_ticket)
    logger.debug('sql files dict values {0}'.format(status_dict))
    logger.debug('get_sql_script function completed')
    return(status_dict)
    
def execute_sql_files(logger, df, file_type, type_change_column, object_type, file_name, application_name, change_type, execution_type, sheet_jira_ticket):
    jira_script_dict = {}
    try:
        logger.debug('execute_sql_files function initiated')
        app_name = commonArgs.getApplication().upper()
        base_path = weekly_release_utils.get_script_path()
        table_path = '{0}table'.format(base_path)
        view_path = '{0}view'.format(base_path)
        custom_path = '{0}custom'.format(base_path)
        db_server_name_key = "{0}_SQl_DB_CRED".format(commonArgs.getEnv().upper())
        (db_server_name, username, passwd) = weekly_release_utils.read_cred_for_server(logger, db_server_name_key)
        cnxn = pyodbc.connect('Trusted Connection=yes;DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + db_server_name + ';UID='+ username + ';PWD=' + passwd, timeout=-12000000)
        status_dict = {}               
        table_list_files = []
        view_list_files = []
        custom_list_files = []        
        df = df.astype(str)
        
        for index, row in df.iterrows():
            jira_task = row[sheet_jira_ticket]
            if row[type_change_column].upper().find(file_type) >= 0 and row[file_name] != 'nan' and row[application_name].upper() == app_name:
                script_path = ''
                row[file_name] = row[file_name].replace('.sql', '')
                # row[file_name] = re.sub('[^<]*\.', '', row[file_name])
                if row[change_type].upper().strip() in ['INSERT RECORD', 'UPDATE RECORD']:
                    script_path = '{0}\\*{1}.*sql'.format(custom_path, row[file_name])
                    custom_list_files.append(script_path)
                    jira_script_dict[script_path] = jira_task
                elif row[object_type].upper().strip() == 'TABLE':
                    script_path = '{0}\\*{1}.*sql'.format(table_path, row[file_name])
                    table_list_files.append(script_path)
                    jira_script_dict[script_path] = jira_task
                elif row[object_type].upper().strip() == 'VIEW':
                    script_path = '{0}\\*{1}.*sql'.format(view_path, row[file_name])
                    view_list_files.append(script_path)
                    jira_script_dict[script_path] = jira_task
                
        
        script_path = '{0}\\*{1}.*sql'.format(table_path, 'insert_loads_tables_filegroup')
        view_list_files = list(dict.fromkeys(view_list_files))
        table_list_files = list(dict.fromkeys(table_list_files))
        table_list_files.append(script_path)
        jira_script_dict[script_path] = 'No jira ticket'        
        logger.debug('table sql files list {0}'.format(table_list_files))
        logger.debug('View sql files list {0}'.format(view_list_files))


        if execution_type.lower().strip() == 'table':
            if table_list_files:
                listsstatus = []
                db_connection = "use {0}".format(app_name)       
                date_withtime = fido_utils.getTodayTS()         
                copy_load_table_filegroup = "SELECT * INTO load_tables_filegroup_{0} FROM load_tables_filegroup".format(date_withtime)
                sql_list = [db_connection, copy_load_table_filegroup]
                sql_file_name = "Copy load_tables_filegroup to load_tables_filegroup_{0}".format(date_withtime)
                try:
                    with cnxn.cursor() as cur:
                        if sql_list:
                            for i in sql_list:
                                if i:
                                    cur.execute(i)
                            listsstatus.append('True')
                            listsstatus.append('No Jira ticket')
                            listsstatus.append('')
                            status_dict[sql_file_name] = listsstatus
                except Exception  as e:
                    logger.debug('Exception error while execution Table sql file {0}'.format(e.args[1])) 
                    listsstatus.append('False')
                    listsstatus.append('No Jira ticket')
                    listsstatus.append(format(e.args[1]))
                    status_dict[sql_file_name] = listsstatus 
            for script_path in table_list_files:
                listsstatus = []    
                logger.debug('Executing following sql file {0}'.format(script_path))  
                if len(glob.glob(script_path)) > 0:
                    sql_file_name = glob.glob(script_path)[0]
                    with codecs.open(sql_file_name, encoding='utf-8-sig') as open_sql_script:
                        data = re.sub("SET\s+[^\n]+]?\s+ON*", "", re.sub("\s*GO\s*\n", ";\n",open_sql_script.read()))
                    data = re.sub("\n\s*\;*\s*\n", "\n", data)
                    data = re.sub("\n\s*\;*\s*\n", "\n", data)
                    sql_list = data.split(";")
                    try:
                        with cnxn.cursor() as cur:
                            if sql_list:
                                for i in sql_list:
                                    if i:
                                        cur.execute(i)
                                listsstatus.append('True')
                                listsstatus.append(jira_script_dict[script_path].lower())
                                listsstatus.append('')                                
                                status_dict[sql_file_name] = listsstatus
                    except Exception  as e:
                        logger.debug('Exception error while execution Table sql file {0}'.format(e.args[1])) 
                        listsstatus.append('False')
                        listsstatus.append(jira_script_dict[script_path].lower())
                        listsstatus.append(format(e.args[1]))
                        status_dict[sql_file_name] = listsstatus 

            for script_path in custom_list_files:
                listsstatus = []    
                logger.debug('Executing following sql file {0}'.format(script_path))  
                db_str = "use {0}".format(commonArgs.getApplication())
                if len(glob.glob(script_path)) > 0:
                    sql_file_name = glob.glob(script_path)[0]
                    with codecs.open(sql_file_name, encoding='utf-8-sig') as open_sql_script:
                        data = re.sub("SET\s+[^\n]+]?\s+ON*", "", re.sub("\s*GO\s*\n", ";\n",open_sql_script.read()))
                    data = re.sub("\n\s*\;*\s*\n", "\n", data)
                    data = re.sub("\n\s*\;*\s*\n", "\n", data)
                    sql_list = [db_str] + data.split(";")
                    try:
                        with cnxn.cursor() as cur:
                            if sql_list:
                                for i in sql_list:
                                    if i:
                                        cur.execute(i)
                                listsstatus.append('True')
                                listsstatus.append(jira_script_dict[script_path].lower())
                                listsstatus.append('')
                                status_dict[sql_file_name] = listsstatus
                    except Exception  as e:
                        logger.debug('Exception error while execution custom sql file {0}'.format(e.args[1])) 
                        listsstatus.append('False')
                        listsstatus.append(jira_script_dict[script_path].lower())
                        listsstatus.append(format(e.args[1]))
                        status_dict[sql_file_name] = listsstatus 
        
        if execution_type.lower().strip() == 'view':
            for script_path in view_list_files:
                listsstatus = []
                logger.debug('Executing following view sql file {0}'.format(script_path))
                if len(glob.glob(script_path)) > 0:
                    sql_file_name = glob.glob(script_path)[0]
                    with codecs.open(sql_file_name, encoding='utf-8-sig') as open_sql_script:     
                        data = re.sub("SET\s+[^\n]+]?\s+ON*", "", re.sub("\s*GO\s*\n", ";\n",open_sql_script.read()))
                    data = re.sub("\n\s*\;*\s*\n", "\n", data)
                    data = re.sub("\n\s*\;*\s*\n", "\n", data)
                    sql_list = data.split(";")
                    try:
                        with cnxn.cursor() as cur:
                            if sql_list:
                                for i in sql_list:
                                    if i:
                                        cur.execute(i)
                                    
                                listsstatus.append('True')
                                listsstatus.append(jira_script_dict[script_path].lower())
                                listsstatus.append('')
                                status_dict[sql_file_name] = listsstatus
                    except Exception  as e:                    
                        listsstatus.append('False')
                        listsstatus.append(jira_script_dict[script_path].lower())
                        listsstatus.append(format(e.args[1]))
                        status_dict[sql_file_name] = listsstatus
                        logger.debug('Exception error while execution view sql file {0}'.format(e.args[1]))            

    except pyodbc.Error as e:
        logger.debug('Exception pyodbc error while execution sql file {0}'.format(e.args[1])) 
        listsstatus.append('False')
        listsstatus.append(jira_script_dict[script_path].lower())
        listsstatus.append(format(e.args[1]))
        status_dict[script_path] = listsstatus
        pass
        
    except Exception as e :
        exc_type, exc_obj, tb = sys.exc_info()
        logger.debug('Exception error while execution sql file {0}'.format(e.args[0])) 
        f = tb.tb_frame
        lineno = tb.tb_lineno
        flag = 0
        pass
    finally:
        cnxn.close()
    logger.debug('execute_sql_files function completed')
    return(status_dict)

def process(execution_type):
    args = commonArgs.parse()
    logger = getLogger()
    script_status = get_sql_script(logger, execution_type)
    logger.debug('generate_weekly_email.notifyEmail going to initiated')
    print(script_status)
    generate_weekly_email.notifyEmail(script_status)
    logger.debug('generate_weekly_email.notifyEmail going to Completed')
    return

if __name__ == '__main__':    
    # process('view')
    process('table')