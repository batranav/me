from requests.auth import HTTPBasicAuth
import requests
import json
import sys
from datetime import datetime, timedelta, date
import os
import sys, http.client, os, os.path
import AutomationLogging
from vault.secrets import get_api_secret
import commonArgs
import parseYamlProperty
from send_email import *

today = date.today()
yr_mnth = today.strftime('%Y%m%d')

sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_analytics_audit_history_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')

output_path = parseYamlProperty.get_inbound_dir('common') + '\\' + commonArgs.getSource() + '\\daily\\'
#output_path = 'C:\\Users\\RosserSL\\OneDrive - Reed Elsevier Group ICO Reed Elsevier Inc\\Desktop\\ppm_analytics\\'
audit_history_output_file = output_path + 'innotas_analytics_project_audit_history_' + yr_mnth + '.txt'
project_logs_output_file = output_path + 'innotas_analytics_project_log_audit_history_' + yr_mnth + '.txt'

audit_history_project_logs_url = r'https://odata.ppmpro.com/InnotasOdataService/Entities(%27Project%20Log__2711157325@lninsurancebusinesspmo%27)/Fields?'
audit_history_url = r'https://odata.ppmpro.com/InnotasOdataService/Entities(%27Project__2670208048@lninsurancebusinesspmo%27)/Fields?'

logger = AutomationLogging.getLogger('innotas_analytics_audit_history', True)
uname, pwd = get_api_secret(logger, 'innotas_analytics')

project_logs_fields = [['Row', 'Entity_Description', 'Project_Log_Audit_Project_Title', 'Project_Log_Audit_Action', 'Project_Log_Audit_Field', 'Project_Log_Audit_Modified_By', 'Project_Log_Audit_Modified_Date', 'Project_Log_Audit_New_Value', 'Project_Log_Audit_Old_Value', 'Project_Log_Audit_Project_Log_Title', 'Project_Log_ID']]
audit_history_fields = [['Row', 'EntityDescription', 'Innotas_ID', 'Action', 'Project_Title', 'Status', 'Modified_By', 'Modified_Date', 'Field', 'New_Value', 'Old_Value']]

def get_audit_history():
    audit_history_request = requests.get(audit_history_url, auth=(uname, pwd))

    audit_history_parsed = json.loads(audit_history_request.text.replace('\t', ''))
    audit_history_values = audit_history_parsed['value']
    
    complete_content = ""
    for audit_history_data_list in audit_history_values:
        temp_audit_history_array = [audit_history_data_list['Row'], audit_history_data_list['EntityDescription'], audit_history_data_list['Innotas\nID'], audit_history_data_list['Action'], audit_history_data_list['Project\nTitle'], audit_history_data_list['Status'], audit_history_data_list['Modified\nBy'], audit_history_data_list['Modified\nDate'], audit_history_data_list['Field'], audit_history_data_list['New\nValue'], audit_history_data_list['Old\nValue']]
        audit_history_fields.append(temp_audit_history_array)
    
    with open(audit_history_output_file, 'w') as f_audit_history:
        for audit_history_item in audit_history_fields:
            audit_history_line = "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format(audit_history_item[0], audit_history_item[1].encode('ascii', 'ignore').decode().replace('\n', ''), audit_history_item[2], audit_history_item[3], audit_history_item[4].encode('ascii', 'ignore').decode().replace('\n', ''), audit_history_item[5], audit_history_item[6], audit_history_item[7], audit_history_item[8].encode('ascii', 'ignore').decode().replace('\n', ''), audit_history_item[9].encode('ascii', 'ignore').decode().replace('\n', ''), audit_history_item[10].encode('ascii', 'ignore').decode().replace('\n', ''))
            f_audit_history.write(audit_history_line)

def get_audit_history_project_logs():
    project_logs_request = requests.get(audit_history_project_logs_url, auth=(uname, pwd))
    project_logs_parsed = json.loads(project_logs_request.text.replace(r'\n', '').replace(r'\t', ''))
    project_logs_values = project_logs_parsed['value']
    
    for project_logs_data_list in project_logs_values:
        temp_project_logs_array = [project_logs_data_list['Row'], project_logs_data_list['EntityDescription'], project_logs_data_list['ProjectLogAuditProjectTitle'], project_logs_data_list['ProjectLogAuditAction'], project_logs_data_list['ProjectLogAuditField'], project_logs_data_list['ProjectLogAuditModifiedBy'], project_logs_data_list['ProjectLogAuditModifiedDate'], project_logs_data_list['ProjectLogAuditNewValue'], project_logs_data_list['ProjectLogAuditOldValue'], project_logs_data_list['ProjectLogAuditProjectLogTitle'], project_logs_data_list['ProjectLogID']]
        project_logs_fields.append(temp_project_logs_array)
    
    with open(project_logs_output_file, 'w') as f_project_logs:
        for project_logs_item in project_logs_fields:
            line = "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format(project_logs_item[0].encode('ascii', 'ignore').decode(), project_logs_item[1].encode('ascii', 'ignore').decode(), project_logs_item[2].encode('ascii', 'ignore').decode(), project_logs_item[3].encode('ascii', 'ignore').decode(), project_logs_item[4].encode('ascii', 'ignore').decode(), project_logs_item[5].encode('ascii', 'ignore').decode(), project_logs_item[6].encode('ascii', 'ignore').decode(), project_logs_item[7].encode('ascii', 'ignore').decode(), project_logs_item[8].encode('ascii', 'ignore').decode(), project_logs_item[9].encode('ascii', 'ignore').decode(), project_logs_item[10].encode('ascii', 'ignore').decode())
            f_project_logs.write(line)

error_email_list = ['stephen.rosser@lexisnexisrisk.com']

try:
    get_audit_history()
except:
    send_mail('stephen.rosser@lexisnexisrisk.com', error_email_list, '', 'ERROR: PPM Pro (Business) pull script failed for Audit History on ' + yr_mnth,'')
    print("Audit History Failed")
    sys.exit(1)

try:
    get_audit_history_project_logs()
except:
    send_mail('stephen.rosser@lexisnexisrisk.com', error_email_list, '', 'ERROR: PPM Pro (Business) pull script failed for Audit History Project Logs on ' + yr_mnth,'')
    print("Audit History Project Logs Failed")
    sys.exit(1)
