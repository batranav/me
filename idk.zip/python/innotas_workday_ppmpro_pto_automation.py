import requests as req
import xml.etree.ElementTree as ET
import csv, json, sys, os, ssl, time
from datetime import datetime, timedelta, date
from dateutil.parser import parse
from collections import namedtuple
import AutomationLogging
from vault.secrets import get_api_secret

start_month =  0

if date.today().month - 2 <= 0:
    start_month = 1
else:
    start_month = date.today().month - 2

start_dt = str(date(date.today().year, start_month, 1))
end_dt   = str(date(date.today().year, 12, 31))

logger_ppm = AutomationLogging.getLogger('preprocess_workday_ppm_update')
uname_ppm, pwd_ppm = get_api_secret(logger_ppm, 'innotas')

logger_workday= AutomationLogging.getLogger('preprocess_workday')
uname_workday, pwd_workday = get_api_secret(logger_workday, 'workday_to_innotas')


# PPM SOAP Server Details --------------
proxy = {'http' : 'http://admzproxyout.risk.regn.net:80'}
url = "lexisnexis.ppmpro.com"
#sandbox url
#url = "lexisnexis-sb.ppmpro.com"
post = "https://lexisnexis.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"
#sandbox post url
#post = "https://lexisnexis-sb.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"
ppm_data_url = r'https://odata.ppmpro.com/InnotasOdataService/Entities%28%27Resource__2525843924@lexisnexis%27%29/Fields?'
# ---------------------------------------------

# Workday webservice credentials --------------
wrkday_url = f"https://wd3-services1.myworkday.com/ccx/service/customreport2/relx/{uname_workday}/RPT_INTHROB064_PPM_PRO_Time_Off_Data_Outbound?End_Date=" + end_dt + "&Start_Date=" + start_dt

# Sandbox URL
#wrkday_url = f"https://wd3-impl-services1.workday.com/ccx/service/customreport2/relx/{uname_workday}/RPT_INTHROB064_PPM_PRO_Time_Off_Data_Outbound?End_Date=" + end_dt + "&Start_Date=" + start_dt

user = uname_workday
passwd = pwd_workday
# ---------------------------------------------

def getSessionId():

    SoapMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:login>
            <!--Optional:-->
            <ser:username>{uname_ppm}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd_ppm}</ser:password>
        </ser:login>
    </soapenv:Body>
    </soapenv:Envelope>"""

    session = req.session()
    session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:login"}
    response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
    root = ET.fromstring(response.content)
    sessionId = root.find('.//{http://services}return').text
    return sessionId

def is_date(string, fuzzy=False):
    input_data = str(string)
    """
    Return whether the string can be interpreted as a date.
    :param string: str, string to check for date
    :param fuzzy: bool, ignore unknown tokens in string if True
    """
    try: 
        parse(input_data, fuzzy=fuzzy)
        return True

    except ValueError:
        return False

#NEED TO CALCULATE DATES EACH MONTH

workday_file_status = False

workdayPTO = namedtuple('workdayPTO', ['emp_id', 'time_off_date', 'time_off_hours', 'resource_id'])

def pullWorkdayPTO():

    resp = req.get(wrkday_url, auth=(user, passwd))
    root = ET.fromstring(resp.content)
    resourceID_dict = {}
    tupleArray = []


    r = req.get(ppm_data_url, auth=(uname_ppm, pwd_ppm))
    data_parsed = json.loads(r.text)
    values_parsed = data_parsed['value']

    for data in values_parsed:
        resourceID_dict[int(data['Emp\nID'])] = data['PPM\nPro\nID']

    ns = {'prefix': 'urn:com.workday.report/RPT_INTHROB064_PPM_PRO_Time_Off_Data_Outbound'}
    
    for data in root.findall('prefix:Report_Entry', ns):
        row = []
        time_off_date = data.find('prefix:Time_Off_Date', ns).text
        time_off_hours = data.find('prefix:Time_Off_Hours', ns).text
        for group in data.findall('prefix:employee_group', ns):
            emp_id = int(group.find('prefix:Employee_ID', ns).text)
            if(emp_id != None and emp_id != '' and resourceID_dict.get(emp_id) != None and float(time_off_hours) >= 6.0):
                tupleArray.append(workdayPTO(emp_id,time_off_date,time_off_hours,resourceID_dict.get(emp_id)))

    global workday_file_status
    workday_file_status = True
    return tupleArray

ppm_file_status = False

outfile_status = False

def getDistinctResources():
    distinct_resource = set()
    #distinct_resource = ['1971404491']
    resource_array = pullWorkdayPTO()

    for row in range(0,len(resource_array)):
            distinct_resource.add(resource_array[row].resource_id)
    return distinct_resource
# At this point we need to take the distinct list of resources from the output file and
# call the getCalenderEvents method to return all the calendar events in the specified
# date range. We will then pass the retuned results into the removeCalendarEvents method
# to purge all of the calendar events from the system.

output_handle_status = False

def pullInnotasDataUsingSOAP():
    distinct_resource = set()
    #distinct_resource = ['1971404491']
    resource_array = pullWorkdayPTO()

    for row in range(0,len(resource_array)):
        distinct_resource.add(resource_array[row].resource_id)

    yesterday = datetime.now() - timedelta(days=1)

    sd=start_dt
    ed=end_dt

    DefaultSoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
       <ser:getCalendarEvents>
          <ser:sessionId>{sessionId}</ser:sessionId>
          <ser:parentTypeId>11</ser:parentTypeId>
          <ser:parentId>{resourceid}</ser:parentId>
          <ser:startDate>{sd}</ser:startDate>
          <ser:endDate>{ed}</ser:endDate>
       </ser:getCalendarEvents>
    </soapenv:Body>
    </soapenv:Envelope>""".replace('{sessionId}', getSessionId())

    #construct and send the heade                                                                                                                                                                                      
    innotasRemove = namedtuple('innotasRemove', ['resource_id','time_off_date'])
    removeTuple = []
    for entityId in distinct_resource:
        SoapMessage = DefaultSoapMessage.replace('{resourceid}', str(entityId)).replace('{sd}',start_dt).replace('{ed}',end_dt).encode(encoding = 'utf-8')
        print(SoapMessage)
        row= []
        session = req.session()
        session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:getCalendarEvents"}

        no_of_attempts = 25
        for x in range(0, no_of_attempts):
            response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
            print("status_code:", response.status_code)
            if response.status_code == 429:
                print(response.headers["Retry-After"])
                time.sleep(int(response.headers["Retry-After"]))
                x += 1
            else:
                break    
        
        result = response.content
        
        tree = ET.ElementTree(ET.fromstring(result))

        for x in tree.findall('.//{http://objects.services/xsd}elementValue'):
            if is_date(x.text) == True and len(x.text) == 10:                
                removeTuple.append(innotasRemove(entityId, x.text))

    return removeTuple

# At this point we have the list of PTO records that need to be removed from Innotas
# We now need to call the removeCalendarEvents method to remove all the existing PTO
# records before uploading the updated data.

remove_file_status = False

def removePPMEvents():

    removeTupleData = pullInnotasDataUsingSOAP()

    # The middle line is a generator expression which
    # iterates over each line in the check file. emp_id and resource_id
    # are extracted from each line
    # This is then converted into a dictionary. This dictionary has the emp_id as its keys and
    # their result code as its values.

    DefaultSoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
    <ser:removeCalendarEvents>
        <ser:sessionId>{sessionId}</ser:sessionId>
        <ser:parentTypeId>11</ser:parentTypeId>
        <ser:parentId>{resourceid}</ser:parentId>
        <ser:date>{date}</ser:date>
    </ser:removeCalendarEvents>
    </soapenv:Body>
    </soapenv:Envelope>""".replace('{sessionId}', getSessionId())


    for row in range(0,len(removeTupleData)):
        
        data = removeTupleData[row]

        format_date = datetime.strptime(data['time_off_date'], '%m/%d/%Y').date()
        SoapMessage = DefaultSoapMessage.replace('{resourceid}', data['resource_id']).replace('{date}', str(format_date)).encode(encoding = 'utf-8')
        row= []
        session = req.session()
        session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:removeCalendarEvents"}

        no_of_attempts = 25
        for x in range(0, no_of_attempts):
            response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
            print("status_code:", response.status_code)
            if response.status_code == 429:
                print(response.headers["Retry-After"])
                time.sleep(int(response.headers["Retry-After"]))
                x += 1
            else:
                break    
        
        result = response.content
        print(result)          

def addPPMEvents():

    addTupleData = pullWorkdayPTO()
    removePPMEvents()


    # The middle line is a generator expression which
    # iterates over each line in the check file. emp_id and resource_id
    # are extracted from each line
    # This is then converted into a dictionary. This dictionary has the emp_id as its keys and
    # their result code as its values.

    DefaultSoapMessage = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
    <ser:createOrReplaceCalendarEvent>
        <ser:sessionId>{sessionId}</ser:sessionId>
        <ser:parentTypeId>11</ser:parentTypeId>
        <ser:parentId>{resourceid}</ser:parentId>
        <ser:eventTitle>'PTO'</ser:eventTitle>
        <ser:eventTypeId>100</ser:eventTypeId>
        <ser:date>{date}</ser:date>
    </ser:createOrReplaceCalendarEvent>
    </soapenv:Body>
    </soapenv:Envelope>""".replace('{sessionId}', getSessionId())

    for row in range(0,len(addTupleData)):
        data = addTupleData[row]
        if len(data['resource_id']) > 3:
            format_date = datetime.strptime(data['time_off_date'], '%Y-%m-%d-%H:%M').date()
            SoapMessage = DefaultSoapMessage.replace('{resourceid}', data['resource_id']).replace('{date}', str(format_date)).encode(encoding = 'utf-8')
            row= []
            session = req.session()
            session.headers = {"Host": url, "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)", "Content-type": "text/xml; charset=\"UTF-8\"", "Content-length": str(len(SoapMessage)), "SOAPAction": "urn:createOrReplaceCalendarEvent"}

            no_of_attempts = 25
            for x in range(0, no_of_attempts):
                response = session.post(url=post, proxies = proxy, data=SoapMessage, verify=False)
                print("status_code:", response.status_code)
                if response.status_code == 429:
                    print(response.headers["Retry-After"])
                    time.sleep(int(response.headers["Retry-After"]))
                    x += 1
                else:
                    break    
        
            result = response.content
            print(result)
            
addPPMEvents()

 
