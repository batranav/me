import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import requests
import parseYamlProperty
from vault.secrets import get_api_secret
import commonArgs
import AutomationLogging


url = "lninsurancebusinesspmo.ppmpro.com"
post = "https://lninsurancebusinesspmo.ppmpro.com/services/MainService.MainServiceHttpsSoap11Endpoint/)"
proxy = {"http": "http://admzproxyout.risk.regn.net:80"}

session = requests.session()

outputFolder = parseYamlProperty.get_inbound_dir('common') + '\\' + commonArgs.getSource() + '\\daily\\'
logger = AutomationLogging.getLogger('preprocess_innotas_analytics_daily_pull')
uname, pwd = get_api_secret(logger, 'innotas_analytics')

loginMessage = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:login>
            <!--Optional:-->
            <ser:username>{uname}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd}</ser:password>
        </ser:login>
    </soapenv:Body>
    </soapenv:Envelope>""".encode(encoding='utf-8')


def frameMessage(entityId, fieldIds):
    firstpart = (
        '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">    <soapenv:Header/> <soapenv:Body> <ser:selectEntity> <ser:sessionId>{sessionID}</ser:sessionId> <ser:entityTypeId>'
        + entityId
        + "</ser:entityTypeId> <ser:entityId>{entityID}</ser:entityId> "
    )
    strparts = fieldIds.split(",")
    for y in range(0, len(strparts)):
        firstpart += "<ser:fieldsRequest>" + strparts[y] + "</ser:fieldsRequest>"
    firstpart += "</ser:selectEntity>   </soapenv:Body> </soapenv:Envelope>"

    return firstpart


def pullInnotasDataUsingSOAP(table_name, entity_type_id, start_dt, end_dt, field_list):

    sd = start_dt
    ed = end_dt

    # construct and send the header

    session.headers = {
        "Host": url,
        "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
        "Content-type": 'text/xml; charset="UTF-8"',
        "Content-length": str(len(loginMessage)),
        "SOAPAction": "urn:login",
    }
    response = session.post(url=post, proxies=proxy, data=loginMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    sessionId = tree.find(".//{http://services}return").text

    SoapMessage = (
        """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:getUpdateHistory>
            <!--Optional:-->
            <ser:sessionId>"""
        + sessionId
        + """</ser:sessionId>
            <!--Optional:-->
            <ser:entityTypeId>"""
        + entity_type_id
        + """</ser:entityTypeId>
            <!--Optional:-->
            <ser:startYYYYMMDD>"""
        + sd
        + """</ser:startYYYYMMDD>
            <!--Optional:-->
            <ser:endYYYYMMDD>"""
        + ed
        + """</ser:endYYYYMMDD>
            <!--Optional:-->
            <ser:showRepeatingPerDay>false</ser:showRepeatingPerDay>
            <!--Optional:-->
            <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
        </ser:getUpdateHistory>
    </soapenv:Body>
    </soapenv:Envelope>"""
    )

    # construct and send the header
    session.headers = {
        "Host": url,
        "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
        "Content-type": 'text/xml; charset="UTF-8"',
        "Content-length": str(len(SoapMessage)),
        "SOAPAction": "urn:getUpdateHistory",
    }
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    if table_name == "workgroup":
        entityIds1 = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")
        ]
        entityIds = set(entityIds1)
    else:
        entityIds = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")
        ]

    DefaultSoapMessage = frameMessage(entity_type_id, field_list)

    output_handle = open(
        outputFolder
        + "innotas_analytics_"
        + table_name
        + "_"
        + datetime.now().strftime("%Y%m%d")
        + ".txt",
        "w",
        encoding="utf-8",
    )

    for entityId in entityIds:
        SoapMessage = DefaultSoapMessage.replace("{entityID}", entityId).replace(
            "{sessionID}", sessionId
        )

        session.headers = {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'text/xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:selectEntity",
        }
        response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)

        result = response.content

        tree = ET.fromstring(result)

        output_handle.write(entityId + "||")
        output_handle.write(
            "||".join(
                [
                    (x.text or "")
                    .replace("\r\n", "    ")
                    .replace("\n", "     ")
                    .replace("\r", "     ")
                    for x in tree.findall(
                        ".//{http://objects.services/xsd}elementValue"
                    )
                ]
            )
        )
        output_handle.write("\n")

    output_handle.close()


def contourUpdate(start_date, end_date):
    sd = start_date
    ed = end_date

    session.headers = {
        "Host": url,
        "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
        "Content-type": 'text/xml; charset="UTF-8"',
        "Content-length": str(len(loginMessage)),
        "SOAPAction": "urn:login",
    }

    response = session.post(url=post, proxies=proxy, data=loginMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    sessionId = tree.find(".//{http://services}return").text

    SoapMessage = (
        """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
    <soapenv:Header/>
    <soapenv:Body>
        <ser:getUpdateHistory>
            <!--Optional:-->
            <ser:sessionId>"""
        + sessionId
        + """</ser:sessionId>
            <!--Optional:-->
            <ser:entityTypeId>54</ser:entityTypeId>
            <!--Optional:-->
            <ser:startYYYYMMDD>"""
        + sd
        + """</ser:startYYYYMMDD>
            <!--Optional:-->
            <ser:endYYYYMMDD>"""
        + ed
        + """</ser:endYYYYMMDD>
            <!--Optional:-->
            <ser:showRepeatingPerDay>false</ser:showRepeatingPerDay>
            <!--Optional:-->
            <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
        </ser:getUpdateHistory>
    </soapenv:Body>
    </soapenv:Envelope>"""
    )

    # update and send the header

    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'text/xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:getUpdateHistory",
        }
    )
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    entityIds = [
        x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")
    ]

    fileOutput = open(
        outputFolder
        + "innotas_analytics_contour_"
        + datetime.now().strftime("%Y%m%d")
        + ".txt",
        "wb",
    )

    for entityId in entityIds:

        SoapMessage = (
            """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
        <soapenv:Header/>
        <soapenv:Body>
            <ser:selectEntity>
                <ser:sessionId>"""
            + sessionId
            + """</ser:sessionId>
                <ser:entityTypeId>54</ser:entityTypeId> 
                <ser:entityId>"""
            + entityId
            + """</ser:entityId>		
                <ser:fieldsRequest>5405</ser:fieldsRequest>	
                <ser:fieldsRequest>5411</ser:fieldsRequest>		
            </ser:selectEntity>  
        </soapenv:Body> 
        </soapenv:Envelope>"""
        )

        session.headers.update(
            {
                "Host": url,
                "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
                "Content-type": 'text/xml; charset="UTF-8"',
                "Content-length": str(len(SoapMessage)),
                "SOAPAction": "urn:selectEntity",
            }
        )
        response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
        result = response.content

        tree = ET.fromstring(result)

        dates = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}elementValue")
        ]
        if not dates:
            continue

        startdatex = datetime.strptime(dates[1], "%m/%d/%Y").strftime("%Y/%m/%d")
        enddatex = datetime.strptime(dates[0], "%m/%d/%Y").strftime("%Y/%m/%d")

        SoapMessage = (
            """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://services">
        <soapenv:Header/>
        <soapenv:Body>
            <ser:getContour>
                <!--Optional:-->
                <ser:sessionId>"""
            + sessionId
            + """</ser:sessionId>
                <!--Optional:-->
                <ser:entityTypeId>54</ser:entityTypeId>
                <!--Optional:-->       
                <ser:entityId>"""
            + entityId
            + """</ser:entityId>         
                <!--Optional:-->
                <ser:startDate>"""
            + startdatex
            + """</ser:startDate>
                <!--Optional:-->
                <ser:endDate>"""
            + enddatex
            + """</ser:endDate>  
            </ser:getContour>
            </soapenv:Body>
        </soapenv:Envelope>"""
        )

        entityId = 0 if entityId == "" else entityId

        session.headers.update(
            {
                "Host": url,
                "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
                "Content-type": 'text/xml; charset="UTF-8"',
                "Content-length": str(len(SoapMessage)),
                "SOAPAction": "urn:getContour",
            }
        )
        response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
        result = response.content

        tree = ET.fromstring(result)

        allocationStartDates = [
            x.text
            for x in tree.findall(".//{http://objects.services/xsd}allocationStartDate")
        ]
        allocationEndDates = [
            x.text
            for x in tree.findall(".//{http://objects.services/xsd}allocationEndDate")
        ]
        entityId = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")
        ]
        entityTypeId = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}entityTypeId")
        ]
        entryDates = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}entryDate")
        ]
        entryHours = [
            x.text for x in tree.findall(".//{http://objects.services/xsd}entryHours")
        ]

        for i in range(0, len(entryDates)):
            fileOutput.write(
                (
                    allocationEndDates[0]
                    + "||"
                    + allocationStartDates[0]
                    + "||"
                    + entityId[0]
                    + "||"
                    + entityTypeId[0]
                    + "||"
                    + entryDates[i]
                    + "||"
                    + entryHours[i]
                    + "\r\n"
                ).encode()
            )

    fileOutput.close()



# START DELETED FILES *************************************************************************



def delete_allcation_update(start_date, end_date):
    sd = start_date
    ed = end_date

    SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
            <ser:username>{uname}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>"""

    # construct and send the header
    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'application/soap+xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:login",
        }
    )

    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    sessionId = tree.find(".//{http://services}return").text

    SoapMessage = (
        """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>54</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace(
            "{!!!!!}", sessionId
        )
        .replace("{???}", sd)
        .replace("{?????}", ed)
        .encode(encoding="utf-8")
    )

    # construct and send the header
    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'application/soap+xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:getDeleteHistory",
        }
    )
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    datemodifieds = [x.text for x in tree.findall(".//{http://objects.services/xsd}dateModified")]
    entityids = [x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")]
    entitytypeids = [x.text for x in tree.findall(".//{http://objects.services/xsd}entityTypeId")]
    modified = [x.text for x in tree.findall(".//{http://objects.services/xsd}modifiedBy")]

    fileoutput = open(
        outputFolder
        + "innotas_analytics_allocation_deleted_"
        + datetime.now().strftime("%Y%m%d")
        + ".txt",
        "w",
        encoding="utf8",
    )

    for i in range(0, len(entityids)):
        fileoutput.write(
            datemodifieds[i]
            + "||"
            + entityids[i]
            + "||"
            + entitytypeids[0]
            + "||"
            + modified[i]
            + "\n"
        )

    fileoutput.close()


def delete_resource_update(start_date, end_date):
    sd = start_date
    ed = end_date

    SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
            <ser:username>{uname}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>"""

    # construct and send the header
    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'application/soap+xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:login",
        }
    )
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    sessionId = tree.find(".//{http://services}return").text

    SoapMessage = (
        """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>11</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace(
            "{!!!!!}", sessionId
        )
        .replace("{???}", sd)
        .replace("{?????}", ed)
    )

    # construct and send the header
    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'application/soap+xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:getDeleteHistory",
        }
    )
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    datemodifieds = [x.text for x in tree.findall(".//{http://objects.services/xsd}dateModified")]
    entityids = [x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")]
    entitytypeids = [x.text for x in tree.findall(".//{http://objects.services/xsd}entityTypeId")]
    modified = [x.text for x in tree.findall(".//{http://objects.services/xsd}modifiedBy")]

    fileoutput = open(
        outputFolder
        + "innotas_analytics_resource_deleted_"
        + datetime.now().strftime("%Y%m%d")
        + ".txt",
        "w",
        encoding="utf8",
    )

    for i in range(0, len(entityids)):
        fileoutput.write(
            datemodifieds[i]
            + "||"
            + entityids[i]
            + "||"
            + entitytypeids[0]
            + "||"
            + modified[i]
            + "\n"
        )

    fileoutput.close()


def delete_project_update(start_date, end_date):
    sd = start_date
    ed = end_date

    SoapMessage = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
			xmlns:ser="http://services">
			<soap:Header/>
			<soap:Body>
			<ser:login>
			<!--Optional:-->
            <ser:username>{uname}</ser:username>
            <!--Optional:-->
            <ser:password>{pwd}</ser:password>
			</ser:login>
			</soap:Body>
			</soap:Envelope>"""

    # construct and send the header
    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'application/soap+xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:login",
        }
    )
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    sessionId = tree.find(".//{http://services}return").text

    SoapMessage = (
        """<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://services">
	<soap:Header/>
	<soap:Body>
    <ser:getDeleteHistory>
         <!--Optional:-->
         <ser:sessionId>{!!!!!}</ser:sessionId>
         <!--Optional:-->
         <ser:entityTypeId>4</ser:entityTypeId>
         <!--Optional:-->
         <ser:startYYYYMMDD>{???}</ser:startYYYYMMDD>
         <!--Optional:-->
         <ser:endYYYYMMDD>{?????}</ser:endYYYYMMDD>
         <!--Optional:-->
         <ser:simpleDateFormat>yyyy/MM/dd HH:mm:ss</ser:simpleDateFormat>
		</ser:getDeleteHistory>
		</soap:Body>
		</soap:Envelope>""".replace(
            "{!!!!!}", sessionId
        )
        .replace("{???}", sd)
        .replace("{?????}", ed)
    )

    # construct and send the header
    session.headers.update(
        {
            "Host": url,
            "User-Agent": "Apache-HttpClient/4.1.1 (java 1.5)",
            "Content-type": 'application/soap+xml; charset="UTF-8"',
            "Content-length": str(len(SoapMessage)),
            "SOAPAction": "urn:getDeleteHistory",
        }
    )
    response = session.post(url=post, proxies=proxy, data=SoapMessage, verify=True)
    result = response.content

    tree = ET.fromstring(result)

    datemodifieds = [x.text for x in tree.findall(".//{http://objects.services/xsd}dateModified")]
    entityids = [x.text for x in tree.findall(".//{http://objects.services/xsd}entityId")]
    entitytypeids = [x.text for x in tree.findall(".//{http://objects.services/xsd}entityTypeId")]
    modified = [x.text for x in tree.findall(".//{http://objects.services/xsd}modifiedBy")]

    fileoutput = open(
        outputFolder
        + "innotas_analytics_project_deleted_"
        + datetime.now().strftime("%Y%m%d")
        + ".txt",
        "w",
        encoding="utf8",
    )

    for i in range(0, len(entityids)):
        fileoutput.write(
            datemodifieds[i]
            + "||"
            + entityids[i]
            + "||"
            + entitytypeids[0]
            + "||"
            + modified[i]
            + "\n"
        )

    fileoutput.close()


def main():
    prior = datetime.now() - timedelta(days=2)
    yesterday = datetime.now() - timedelta(days=1)
    start_date = prior.strftime("%Y/%m/%d") + " 00:00:01"
    end_date = yesterday.strftime("%Y/%m/%d") + " 00:00:01"

    pullInnotasDataUsingSOAP(
        "project",
        "4",
        start_date,
        end_date,
        "962689914,962698323,962697562,436,411,498,1002652070,2607757697,400027,2597603791,445",
    )
    pullInnotasDataUsingSOAP(
        "resource",
        "11",
        start_date,
        end_date,
        "1117,1102,1110,1124,1151,1198",
    )
    pullInnotasDataUsingSOAP(
        "allocation",
        "54",
        start_date,
        end_date,
        "5452,5425,5495,5424,5405,5429,5401,5498,5421,5417,5440,5422,5411,5406,5423,5419",
    )

    contourUpdate(start_date, end_date)

    delete_allcation_update(start_date, end_date)
    delete_resource_update(start_date, end_date)
    delete_project_update(start_date, end_date)

    session.close()

def printsource():
    print(commonArgs.getSource())

if __name__ == "__main__":
    main()
