import sendEmail
import parseYamlProperty
import fido_utils

def xstr(s):
    return "" if s is None else str(s)

def generateemailmsg(countDict, exportSearchList, timing_list, headerfields, actionFailed):

    cssdata = open(parseYamlProperty.getCSSPath(), "r").read()

    htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>""" + cssdata + "</style>"""

    maindetails = """ <TABLE id="pull"> """ 

    lines = ""
    lines += """<table id="buildsuccess">
                        <tr>
                        <th># of Expected Files</th>
                        <th># of Optional Files</th>
                        <th># of Missing Files</th>
                        <th># of Missing(Expected) Files</th>
                        <th># of Missing(Optional) Files</th>
                        </tr>"""
    lines += "<td>" +  xstr(countDict["RequiredFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["OptionalFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["Missing-OptionalFilesCount"] + countDict["Missing-RequiredFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["Missing-RequiredFilesCount"]) + "</td>"
    lines += "<td>" +  xstr(countDict["Missing-OptionalFilesCount"]) + "</td>"
    lines += "</tr></TABLE>"

    for x in  headerfields:
        maindetails += "<tr><th>"+ x + "</th><td>" + xstr(getattr(exportSearchList[0], x)) + "</td></tr>"
    maindetails += """ </TABLE> """ + lines

    searchDataRow = ""

    searchTable = maindetails + """ <TABLE id="pull"> """  + """
                            <tr> """
    if timing_list == [] or timing_list == None:
        timing_list_header = []
    else :
        timing_list_header = timing_list.pop(0)

    for y in  timing_list_header:                        
        searchTable += "<th>" + y + "</th>"

    searchTable += """</tr> """
    if timing_list != []  or timing_list != None:
        for x in timing_list:
            searchDataRow += " <tr> " 
            for y in  x: 
                searchDataRow +=  " <td> " + xstr(y) + " </td> " 
            searchDataRow += " </tr> "
    if actionFailed:
        for exportSearch in exportSearchList:
            searchDataRow += " <tr> " 
            #print(xstr(getattr(exportSearch, y)))
            #print(getattr(exportSearch, y))
            searchDataRow +=  " <td> " + xstr(getattr(exportSearch, 'absFidoFileName')) + " </td> " 
            searchDataRow += " </tr> "
    
    if exportSearchList:
        searchDataRow += "</TABLE>"
        return (htmlHeader + searchTable + searchDataRow)
    else: 
        return htmlHeader + "<table><tr><td>No Data exported</td></tr></table>"

def notifyEmail(debug, countDict, ssFiles, timing_list, actionFailed, headerfieldsList="", cloud_type = "",app = "RBI"):
    if len(ssFiles) == 0 :
        return None

    successEmailFrom = "SUCESS-Fido." + app + ".automation@lexisnexisrisk.com"
    errorEmailFrom  = "ERROR-Fido." + app + ".automation@lexisnexisrisk.com"

    source = ssFiles[0].destination
    pull_or_outbound = app +  "Outbound {0} loads with compressed files for ".format(cloud_type)

    PlatformPrefix = parseYamlProperty.getPlatform() + " :: " 

    if actionFailed:
        subjectPrefix =  "Error ::" 
        emailFrom = errorEmailFrom
        emailTo = ",".join(parseYamlProperty.get_error_cc_email(source))
    else:
        subjectPrefix = "Success :: "
        emailFrom = successEmailFrom
        emailTo = ",".join(parseYamlProperty.get_success_email(source))
        
    if debug:
        # emailTo = "gopala.rudraraju@lexisnexisrisk.com"
        emailTo = "gopala.rudraraju@lexisnexisrisk.com, saravana.pandi@reedbusiness.com,sathishkumar.seenivasan@reedbusiness.com,arjun.mudunuru@lexisnexisrisk.com,raja.sundarrajan@lexisnexisrisk.com"
        emailFrom = "debug-" + app + "-fido@lexisnexisrisk.com"
    
    subject = subjectPrefix + PlatformPrefix + pull_or_outbound + source + "-" + ssFiles[0].frequency + "-" + ssFiles[0].fileDate
    msg = generateemailmsg(countDict, ssFiles, timing_list, headerfieldsList, actionFailed)
    sendEmail.send(emailFrom, emailTo, emailTo, subject, msg)  
    print("Printing in NotifyEmail {0}".format(ssFiles))