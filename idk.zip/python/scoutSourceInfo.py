import yaml
import io
import base64
from ScoutInbound import ScoutInbound
import parseYamlProperty
import fido_utils
import os

_today = fido_utils.getToday()
config = ''

def getPreviousDay(filedate):
	return fido_utils.getYesterday(fido_utils.mkDateTime(filedate, strFormat="%Y%m%d"))

def getYamlStream():
    global stream
    with open("D:\\scout\\scripts\\properties\\scout.yaml", 'r') as x:
        stream = x.read()
    return stream

def getConfig():
    stream = getYamlStream()
    config = yaml.load(stream)	
    return config

def getFidoFolder(source, frequency):
	data_loaded = getConfig()	
	frequencyData = data_loaded.get(source).get(frequency).get('pullrequiredfiles')
	fidoFolderName = parseYamlProperty.get_inbound_dir() + '\\' + data_loaded.get(source).get(frequency).get('fidofolder').get('name')
	return fidoFolderName

def getMoveUnusedFilesFlag(frequencyData):
	if frequencyData.get('moveUnusedFiles') == None:
		return True
	else:
		frequencyData.get('moveUnusedFiles')

def getSourceExtension(frequencyData):
	
	sourceExtension = ''

	if frequencyData.get('sourceExtension') != None: 
			sourceExtension = '.' + frequencyData.get('sourceExtension') 
	
	return sourceExtension

def getFidoExtension(frequencyData):
	
	data_loaded = getConfig()
	
	FidoExtension = ''

	if frequencyData.get('fidoExtension') != None: 
		fidoExtension = '.' + frequencyData.get('fidoExtension') 
	else : 
		fidoExtension = '.' + data_loaded.get('common').get('Fido_Extn')
	
	return fidoExtension


def isPushFiles(source, frequency):
    
    data_loaded = getConfig()	
    
    x = data_loaded.get(source).get(frequency).get('pushrequiredfiles')
    y = data_loaded.get(source).get(frequency).get('pushoptionalfiles')
    
    data = []

    if x is not None:
        data.append(x.get('files'))

    if y is not None:
        data.append(y.get('files'))

    if data != []:
        print(data)
        return True
    
    return False

def isPullFiles(source, frequency):
    
    data_loaded = getConfig()	
    
    x = data_loaded.get(source).get(frequency).get('pullrequiredfiles')
    y = data_loaded.get(source).get(frequency).get('pulloptionalfiles')
    
    data = []

    if x is not None:
        data.append(x.get('files'))

    if y is not None:
        data.append(y.get('files'))

    if data != []:
        print(data)
        return True
    
    return False

def getPushRequiredFeedFiles(source, frequency, filedate=_today):
	data_loaded = getConfig()	
	arr = []
	frequencyData = data_loaded.get(source).get(frequency).get('pushrequiredfiles')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))

	if frequencyData is None:
		return arr

	files = frequencyData.get('files')
	for y in range(0, len(files)):
		
		fidoName   = files[y]
		pullOrPush = "push"
		required   = False
		sourceExtension  = getSourceExtension(frequencyData) 
		fidoExtension  = getFidoExtension(frequencyData)
		sourceName = ""
		relativeSourceFolder = ""
		arr.append(ScoutInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, "","","", moveUnusedFiles))

	return arr

def getPushOptionalFeedFiles(source, frequency, filedate=_today):
	data_loaded = getConfig()	
	arr = []
	frequencyData = data_loaded.get(source).get(frequency).get('pushoptionalfiles')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
	if frequencyData is None:
		return arr

	files = frequencyData.get('files')
	for y in range(0, len(files)):
		
		fidoName   = files[y]
		pullOrPush = "push"
		required   = False
		sourceExtension  = getSourceExtension(frequencyData) 
		fidoExtension  = getFidoExtension(frequencyData)
		sourceName = ""
		relativeSourceFolder = ""
		arr.append(ScoutInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, "","","", moveUnusedFiles))

	return arr

def getPullRequiredFeedFiles(source, frequency, filedate=_today):
	data_loaded = getConfig()	
	
	arr = []

	frequencyData = data_loaded.get(source).get(frequency).get('pullrequiredfiles')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))
	
	if frequencyData is None:
		return arr

	fidofolder = getFidoFolder(source, frequency)
	
	for x in range(0, len(frequencyData.get('sourcefolders'))):
		sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
		files = sf.get('files')
		for y in range(0, len(files)):
			fidoName   = files[y].get('file').get('fidoname')

			pullOrPush = "pull"
			required   = True
			if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
				sourceExtension = ''
			else:
				sourceExtension  = getSourceExtension(frequencyData) 

			if sf.get('autoSourceFolderPrefix') != None:
				autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
			else:
				autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix') 

			fidoExtension  = getFidoExtension(frequencyData) 

			if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == False:
				sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() + '_' + filedate
			else:
				sourceName = files[y].get('file').get('sourcename') 

			if frequencyData.get('completedFlagPrefix') == None:
				cmpflagprefix = ''
			else :
				cmpflagprefix = frequencyData.get('completedFlagPrefix')
			
			if frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False:
				completedFlagFileName =  ''
			else :
				completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'

			if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
				completedFlagFileName =  ''
			if autoSourceFolderPrefix == False:
			# if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
				autoSourceFolderPrefix = False
				relativeSourceFolder = sf.get('name') + "/" 
			else :
				autoSourceFolderPrefix = True
				relativeSourceFolder = sf.get('name')  + "/" + filedate + "/"

			absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
			absFidoFileName = fidofolder + '\\' + fidoName + '_' + filedate + fidoExtension  
			absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

			arr.append(ScoutInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, absSourceFileName, absFidoFileName,  absFidoCompressedFileName, completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))

	return arr

def getPullOptionalFeedFiles(source, frequency, filedate=_today):
	data_loaded = getConfig()	
	
	arr = []
	frequencyData = data_loaded.get(source).get(frequency).get('pulloptionalfiles')
	moveUnusedFiles = getMoveUnusedFilesFlag(data_loaded.get(source).get(frequency))

	if frequencyData is None:
		return arr

	fidofolder = getFidoFolder(source, frequency)

	for x in range(0, len(frequencyData.get('sourcefolders'))):
		sf = frequencyData.get('sourcefolders')[x].get('sourcefolder')
		files = sf.get('files')
		for y in range(0, len(files)):
			fidoName   = files[y].get('file').get('fidoname')

			pullOrPush = "pull"
			required   = False

			if sf.get('sourceExtensionMissing') != None and sf.get('sourceExtensionMissing') == True:
				sourceExtension = ''
			else:
				sourceExtension  = getSourceExtension(frequencyData) 

			if sf.get('autoSourceFolderPrefix') != None:
				autoSourceFolderPrefix  = sf.get('autoSourceFolderPrefix')
			else:
				autoSourceFolderPrefix  = frequencyData.get('autoSourceFolderPrefix')

			fidoExtension  = getFidoExtension(frequencyData) 

			if sf.get('filedateInNameSuffix') != None and sf.get('filedateInNameSuffix') == True:
				sourceName = files[y].get('file').get('sourcename') + '_' + frequency.upper() + '_' + filedate
			else:
				sourceName = files[y].get('file').get('sourcename') 

			if frequencyData.get('completedFlagPrefix') == None:
				cmpflagprefix = ''
			else :
				cmpflagprefix = frequencyData.get('completedFlagPrefix')

			if frequencyData.get('completedFlagRequired') != None and frequencyData.get('completedFlagRequired') == False:
				completedFlagFileName =  ''
			else:
				completedFlagFileName = cmpflagprefix + sourceName + '.completed.flag'		

			if sf.get('completedFlagRequired') != None and sf.get('completedFlagRequired') == False:
				completedFlagFileName =  ''
			if autoSourceFolderPrefix == False:
			# if frequencyData.get('autoSourceFolderPrefix') != None or frequencyData.get('autoSourceFolderPrefix') == False or autoSourceFolderPrefix == False:
				autoSourceFolderPrefix = False
				relativeSourceFolder = sf.get('name')  + "/"  
			else :
				autoSourceFolderPrefix = True
				relativeSourceFolder = sf.get('name')  + "/" + filedate + "/"

			absSourceFileName = relativeSourceFolder + sourceName + sourceExtension
			absFidoFileName = fidofolder + '\\' + fidoName + '_' + filedate + fidoExtension  
			absFidoCompressedFileName = fidofolder + '\\' + fidoName + '_' + filedate + sourceExtension  

			arr.append(ScoutInbound(source, frequency, filedate, relativeSourceFolder, sourceName, fidoName, required, pullOrPush, sourceExtension, fidoExtension, absSourceFileName, absFidoFileName, absFidoCompressedFileName,  completedFlagFileName, autoSourceFolderPrefix, moveUnusedFiles))
	return arr

def getRequiredFiles(source, frequency, filedate=_today):
	pullRequired = getPullRequiredFeedFiles(source, frequency, filedate=_today)
	pushRequired = getPushRequiredFeedFiles(source, frequency, filedate=_today)

	files = [o.fidoname for o in pullRequired] + [o.fidoname for o in pushRequired]

	return files 

def getOptionalFiles(source, frequency, filedate=_today):
	pullOptional = getPullOptionalFeedFiles(source, frequency, filedate=_today)
	pushOptional = getPushOptionalFeedFiles(source, frequency, filedate=_today)

	files = [o.fidoname for o in pullOptional] + [o.fidoname for o in pushOptional]

	return files

def getPullFiles(source, frequency, filedate = ''):
	return getPullRequiredFeedFiles(source, frequency, filedate) + getPullOptionalFeedFiles(source, frequency, filedate)

def getPushFiles(source, frequency, filedate = ''):
	return getPushRequiredFeedFiles(source, frequency, filedate) + getPushOptionalFeedFiles(source, frequency, filedate)

def getFeedFiles(source, frequency, filedate=''):
	return getRequiredFiles(source, frequency, filedate) + getOptionalFiles(source, frequency, filedate)

def getFidoExtns(source, frequency):
	line = ''
	data_loaded = getConfig()
	try:
		for k, v in data_loaded.get(source).get(frequency).items():
			if line != '':
				line += ','
			if data_loaded.get(source).get(frequency)[k].get('fidoExtension') is None:
				line += data_loaded.get('common').get('Fido_Extn')
			else:
				line += data_loaded.get(source).get(frequency)[k].get('fidoExtension')
		
		return [item.strip() for item in line.strip().split(",")]
	except:
		raise Exception('Can\'t find details for {0} {1} in Yaml'.format(str(source), str(frequency)))

if __name__ == '__main__':
	# x = getPushRequiredFeedFiles('eloqua', 'daily')
	# print(x)
	x1 = getPullRequiredFeedFiles('logs', 'daily')
	# x1 = getPullFiles('logs', 'daily', '20190508')
	# x1 = getFiledateInNameSuffix(sf)
	# x1 = getFidoExtns('logs', 'daily')
	# print(x1) 
	print(getPullRequiredFeedFiles('logs', 'daily'))