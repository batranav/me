import json
import json.decoder
import sys
import os
import traceback
from collections import namedtuple
import pandas
from pandas.io.json import json_normalize
import requests
import re
import datetime
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret

def getLogger():
    return AutomationLogging.getLogger('runSourceBuilds')

today_date = datetime.datetime.today().strftime('%Y%m%d')
yesterday = datetime.datetime.today() - datetime.timedelta(days=1)
yesterday_date = yesterday.strftime('%Y%m%d')
currentyearmonth = datetime.datetime.strptime(yesterday_date,'%Y%m%d').strftime('%Y-%m')
currentyearmonth_last_date = datetime.datetime.strptime(yesterday_date,'%Y%m%d').strftime('%d')


# proj_cols = ["id", "ActualCostManuallySet", "ActualEffortUpdatedFromTimesheets", "ActualEndDate", "ActualRevenueManuallySet", "ActualStartDate", "AdditionalComments", "Alignment", "AllowReportingOnSubItems", "BenefitManuallySet", "Billable", "BillingTypeManuallySet", "BudgetSummary", "BusinessAlignment", "BusinessImpact", "C_50ProgressNotificationSent", "C_75ProgressNotificationSent", "C_billing_id", "C_BillingDeferredID", "C_BusinessUnitLN", "C_Category", "C_CLZ_ProjectMethodology", "C_CLZ_TeamBoardScrumMaster_CLZ", "C_CLZ_TeamBoardState_CLZ", "C_CLZ_TeamBoardStatusData_CLZ", "C_CLZ_TeamBoardStatusIcon_CLZ", "C_CLZ_TeamBoardType_CLZ", "C_CLZ_TeamTaskColor_CLZ", "C_Code", "C_ContractEffectiveDate2", "C_CurrentMonth", "C_CustSatStatus", "C_DeferredCOA", "C_DurationMultiplier", "C_EffectiveDateofService", "C_ExpirationDateofService", "C_FCCPSBillingType", "C_FCCPSRegion", "C_FinanceNotes", "C_HoursUnits", "C_ILTDeliveryDate", "C_ILTDeliveryDate2", "C_ILTDeliveryDate3", "C_ILTSeats", "C_ILTSurveySent", "C_Invoice", "C_InvoiceGJEDate", "C_InvoiceSubmissionDate", "C_InvoiceTotalAmount", "C_IsParentProject", "C_IsSubProject", "C_Live", "C_LocationLanguage", "C_LossRate", "C_MyCRMProject", "C_ODTEnabled", "C_ODTSeats", "C_OnsiteRemote", "C_OriginatedOpportunity", "C_PeerReviewer", "C_PhaseRDP", "C_PhaseTMX", "C_POVFollowonRevenueYear1", "C_POVScheduledGoLiveDate", "C_POVStage", "C_PPR_ActualEndDateWithinRange", "C_PPR_DueDateWithinRange", "C_PPR_ResourcesDisplay", "C_PPR_RoadmapURL", "C_PPRDescription", "C_PPREmailBody", "C_PPREmailRecipients", "C_PPREmailSubject", "C_PPRFileName", "C_PPRReportEndDate", "C_PPRReportStartDate", "C_Product", "C_ProductionAPIDate", "C_Products", "C_ProjectAssignmentLastUpdatedOn", "C_ProjectContinuingFrom", "C_ProjectContinuingTo", "C_ProjectCustomerSatNotes", "C_ProjectManagerName", "C_ProjectNotes", "C_RecognitionMethodUsed", "C_ResellerSubClient", "C_RevSymLineID", "C_SpecializedRate", "C_SupportHandoverDate", "C_TargetEndDate", "C_TargetStartDate", "C_TCSSurveyScore", "C_ThreatmetrixSubsidiary", "C_TodaysDate", "C_TrainingDelivered", "C_TrainingNotes", "C_TravelExpenses", "C_updateresourcerates", "C_UseCasesScopeNotes", "C_UseCasesTMX", "CalculateCompletenessBasedOnEfforts", "CalculateFinancials", "ChargedAmountManuallySet", "ChargedTypeManuallySet", "ClarizenGoWorkspaceCreator", "ClosingNotes", "CommittedDate", "Country", "CurrencyExchangeDate", "CurrencyExchangeDateManuallySet", "DefaultIntegrationPath", "Deliverable", "DeliverableType", "Description", "DueDate", "DurationManuallySet", "ExpectedBusinessValue", "ExpectedROI", "ExternalID", "FinancialEnd", "FinancialStart", "FixedCost", "FixedPrice", "GoalsAchieved", "HoldingNotes", "IgnoreResourceCalendars", "IgnoreResourceCalendarsManuallySet", "InternalId", "InternalStatus", "InvestmentType", "IsPortfolio", "Justification", "LastSyncedWithClarizenGo", "LinkToClarizenGo", "Mitigation", "Name", "NLRExchangeRateDateOptionSet", "ObjectAlias", "OrderID", "OverallSummary", "PercentCompleted", "PermissionInheritanceForExternalUsers", "PlannedBudgetManuallySet", "PlannedRevenueManuallySet", "PlannedSavings", "Priority", "ProgressUpdateFrequencyManuallySet", "ProjectGoals", "ProjectSponsor", "ProjectTagging", "RateCard", "Reportable", "ReportableManuallySet", "ReportingStartDate", "Required", "ResourceRateDate", "Risks", "RisksImpact", "RisksRate", "RollupFinancialAndEffortDataFromShortcut", "RollupProgressAndDatesFromShortcut", "ScheduleSummary", "SfExternalId", "SfExternalName", "SKU", "StartDate", "StateProvince", "SyncWithClarizenGo", "TimeApproval", "TotalEstimatedCost", "TrackStatusManuallySet", "WorkManuallySet", "C_BillingProductCode", "C_BillingDescription", "C_BillingChargeCode", "SYSID", "C_SubProjectCount", "ActualCost.currency", "ActualCost.value", "ActualEffort.unit", "ActualEffort.value", "ActualRevenue.currency", "ActualRevenue.value", "Benefit.currency", "Benefit.value", "BillingType.id", "BudgetedHours.unit", "BudgetedHours.value", "BudgetStatus.id", "C_GeographicalRegionSubDivision.id", "C_HourlyRateUnitRate.currency", "C_HourlyRateUnitRate.value", "C_InvoiceGJEAmount.currency", "C_InvoiceGJEAmount.value", "C_ProductStatus.id", "C_ProjectTypeL1.id", "C_ProjectTypeL2.id", "C_ProjectTypeL4.id", "C_RevSymAdjustedRate.currency", "C_RevSymAdjustedRate.value", "C_ScopeStatus.id", "C_TimeTrackingLevel.id", "C_TypeofConsulting.id", "Charged.id", "ChargedAmount.currency", "ChargedAmount.value", "CommitLevel.id", "CostCurrencyType.id", "DirectPlannedBilledExpenses.currency", "DirectPlannedBilledExpenses.value", "DirectPlannedExpenses.currency", "DirectPlannedExpenses.value", "Duration.unit", "Duration.value", "Duration.durationType", "EntityOwner.id", "ExpenseType.id", "GeographicalRegion.id", "Importance.id", "ImportedFrom.id", "LaborBudget.id", "Manager.id", "Parent.id", "Pending.id", "Phase.id", "PlannedAmount.currency", "PlannedAmount.value", "PlannedBudget.currency", "PlannedBudget.value", "PlannedRevenue.currency", "PlannedRevenue.value", "ProgressUpdateFrequency.id", "ProjectManager.id", "ProjectSize.id", "ProjectType.id", "RemainingEffort.unit", "RemainingEffort.value", "ResourceUtilizationCategory.id", "RevenueCurrencyType.id", "SchedulingType.id", "TaskReportingPolicy.id", "TrackStatus.id", "Work.unit", "Work.value", "WorkPolicy.id", "C_RateTMX.currency", "C_RateTMX.value", "C_InvoiceGJEAmount", "C_RevSymAdjustedRate", "C_TimeTrackingLevel", "C_CLZ_ProjectMethodology.id", "C_CLZ_TeamBoardState_CLZ.id", "C_CLZ_TeamBoardType_CLZ.id", "C_CLZ_TeamTaskColor_CLZ.id", "C_PhaseTMX.id", "C_GeographicalRegionSubDivision", "C_ProjectTypeL4", "C_BusinessUnitLN.id", "C_LossRate.currency", "C_LossRate.value", "C_ODTSeats.id", "C_PeerReviewer.id", "PermissionInheritanceForExternalUsers.id", "C_OnsiteRemote.id", "BudgetedHours", "C_BillingMBSTMXProjectFilter", "C_ExtensionInProgress", "C_BillingFIDOTMXProjectFilter"]
# ts_cols = ["id", "AssignedApprover", "C_BilledonInvoice", "C_CSMActivity", "C_CSMActivityType", "C_CSMCategory", "C_DeliverableBP", "C_DeliverableTCS", "C_DeliverableTMX", "C_InternalMeeting", "C_OnsiteMeeting", "C_PPR_Project", "C_SpecializedRate", "C_SubDeliverableBP", "C_SubmittedOn", "Charged", "Comment", "DisableReportingTimeLimit", "ExternalID", "LastSubmittedDate", "Overtime", "RegularHours", "RejectedBy", "RejectionDate", "RejectionNote", "ReportedDate", "C_DurationMultiplierEnabledHours", "C_TimesheetofCustomer.id", "CreatorType.id", "Duration.unit", "Duration.value", "HumanResource.id", "ReportedBy.id", "WorkItem.id", "Project.id", "C_TimesheetofCustomer", "C_CSMCategory.id", "C_DeliverableTMX.id", "C_DeliverableTCS.id", "C_DeliverableBP.id", "C_CSMActivityType.id", "Project", "Duration.duration_type"]
user_cols = ["id", "AllowEmails", "Availability", "BusinessAddress", "C_AnnualLeaveEntitlementBalance", "C_Billable", "C_CalculateDICapBookings", "C_CollaboratingGroup", "C_CostCenter", "C_CurrentQuarterDICap", "C_CurrentQuarterEndDate", "C_CurrentQuarterStartDate", "C_DeletionDate", "C_DepartmentalInitiativeLimit", "C_DepartmentName", "C_DIDuration", "C_DpmtNumber", "C_EmployeeNumber", "C_EntityNumber", "C_FCCPSRegionemployee", "C_HoursReported_LastWeek", "C_HoursReportedCurrentMonth", "C_HoursReportedCurrentMonthLastUpdated", "C_HoursReportedLastWeekUpdated", "C_JobFamily", "C_LatestTimesheetComplianceDate", "C_NextQuarterDICap", "C_NextQuarterEndDate", "C_NextQuarterStartDate", "C_QuarterofWorkRequest", "C_Ramping", "C_ReferencedCustomer", "C_RevenueTypeL2", "C_SalesTeam", "C_StartDate", "C_SubscribeToResourceNotifications", "C_UserQuarter", "CurrencyExchangeDate", "CurrencyExchangeDateManuallySet", "DirectManager", "DisplayName", "Email", "ExpirationDate", "ExternalID", "ExternalUser", "Financial", "FirstName", "HomeAddress", "IntegrationUser", "InternalId", "Language", "LastName", "LiteAdmin", "Location", "MobilePhone", "MobileProfile", "OfficeFax", "OfficePhone", "Position", "Profile", "Region", "ScimSyncId", "ScimSyncJobTitle", "SendInvitationMail", "ShowLocalCurrencyCode", "Signature", "SubscribeToProjectNotifications", "SuperUser", "TargetUtilization", "TimesheetsExpectedFrom", "TimeZone", "UserName", "UserSyncId", "UserSyncNotes", "UserSyncUpdated", "C_ContractHours.unit", "C_ContractHours.value", "C_EmployeeRegionEmployee.id", "CostOvertimeRate.currency", "CostOvertimeRate.value", "CostRegularRate.currency", "CostRegularRate.value", "EmailNotifications.id", "ExpectedTimesheets.id", "JobTitle.id", "LicenseType.id", "LocalCurrency.id", "NumericFormat.id", "Phase.id", "RevenueOvertimeRate.currency", "RevenueOvertimeRate.value", "RevenueRegularRate.currency", "RevenueRegularRate.value", "C_HoursReportedCurrentMonth.unit", "C_HoursReportedCurrentMonth.value", "C_RevenueTypeL2.id", "DirectManager.id", "Profile.id", "TimeZone.id", "JobTitle", "C_DepartmentName.id", "C_DpmtNumber.id", "C_EntityNumber.id", "C_HoursReported_LastWeek.unit", "C_HoursReported_LastWeek.value", "C_EmployeeRegionEmployee", "C_CostCenter.id", "C_FCCPSRegionemployee.id", "C_ContractHours", "C_SalesTeam.id", "Language.id"]
cust_cols = ["id", "BillingAddress", "BusinessAddress", "C_AccountManager", "C_AccountMarker", "C_AccountOwner2", "C_ActionItems", "C_APIType", "C_BehaviorBiometricIdentification", "C_BridgerPremierTAM", "C_BridgerPremierTAM2", "C_BridgerType", "C_CaseManagement", "C_CollaboratingGroup", "C_ContractSize", "C_CRM", "C_CSChallenges", "C_CustomerNotes", "C_CustomerRenewalDate", "C_CustomerSubName", "C_DowJonesBP", "C_EngagementIssues", "C_EnhancedProfiling", "C_FCCPSRegion", "C_FraudData", "C_HouseholdNumberGCID", "C_IssueUpdate", "C_LastHealthCheckDate", "C_LastInteractionDate", "C_LastPolicyUpdate", "C_LastQBRDate", "C_LinktoAccountPage", "C_LiveSince", "C_LocationLanguage", "C_Login", "C_MobileSDK", "C_NAO", "C_NumberofTouchPoints", "C_OngoingInitiatives", "C_OtherProducts2BP", "C_OtherProducts3BP", "C_OtherProductsBP", "C_ParentCustomer", "C_Payment", "C_PersonaRecognitionRate", "C_PII", "C_PolicyName", "C_PortalNameOrgID", "C_POV", "C_ProfessionalServicesAccountManager", "C_ProfessionalServicesEngagementManagerTAM", "C_ProfessionalServicesEngagementManagerTAM2", "C_ProfessionalServicesFraudDataAnalystDataScientis", "C_ProfessionalServicesProjectManager", "C_ProfessionalServicesTechnicalConsultant", "C_PS_FDA_DS_2", "C_SDK", "C_SmartLearning", "C_SmartRules", "C_StartingUnknownSession", "C_StatusIssueLastUpdatedBy", "C_StatusIssueLastUpdatedOn", "C_StoringAPIResponses", "C_StrongCustomerAuthentication", "C_SupportTier", "C_TagObfuscation", "C_TargetedMalware", "C_TrainingDelivered", "C_TruthData", "C_UseCase", "C_Version", "C_WorldCheckBP", "C_WorldComplianceBP", "Country", "CurrencyExchangeDate", "CurrencyExchangeDateManuallySet", "CustomerValue", "DefaultIntegrationPath", "Description", "EntityOwner", "ExternalID", "Industry", "InternalId", "LastDateContacted", "MarketingSource", "Name", "OfficePhone", "Owner", "Region", "SfExternalId", "SfExternalName", "StateProvince", "TechnicalAccountManager", "URL", "AccountStatus.id", "C_CommercialBudgetStatus.id", "C_CSATStatus.id", "C_CSMEngagementTask.id", "C_CustomerSubType.id", "C_CustomerType.id", "C_EngagementStatus.id", "C_GeographicalRegionSubDivision.id", "CompanySize.id", "CustomerSuccessStatus.id", "GeographicalRegion.id", "Tier.id", "C_CSMEngagementTask", "C_GeographicalRegionSubDivision", "GeographicalRegion", "C_CustomerType", "C_FCCPSRegion.id", "C_AccountOwner2.id", "C_MobileSDK.id", "C_ProfessionalServicesAccountManager.id", "C_ProfessionalServicesEngagementManagerTAM.id", "C_ProfessionalServicesProjectManager.id", "C_StatusIssueLastUpdatedBy.id", "EntityOwner.id", "Industry.id", "Owner.id", "C_BridgerPremierTAM.id", "C_BridgerPremierTAM2.id", "C_BridgerType.id", "Country.id", "C_CRM.id", "C_ProfessionalServicesFraudDataAnalystDataScientis.id", "C_SupportTier.id", "C_ProfessionalServicesTechnicalConsultant.id", "C_ParentCustomer.id", "C_ProfessionalServicesEngagementManagerTAM2.id", "C_TruthData.id", "AccountStatus", "C_PS_FDA_DS_2.id", "C_EngagementStatus", "C_TrainingDelivered.id", "TechnicalAccountManager.id", "CustomerSuccessStatus"]



def process(foldername):
    # proj_jsonfilename = os.path.join(foldername,'projectsQuery_'+today_date+'.json')
    # timesheet_jsonfilename = os.path.join(foldername,'timesheetQuery_'+today_date+'.json')
    customer_jsonfilename = os.path.join(foldername,'customerQuery_'+today_date+'.json')
    user_jsonfilename = os.path.join(foldername,'userQuery_'+today_date+'.json')
    # with open(timesheet_jsonfilename, encoding='utf-8') as tsf:
    #     ts_df = json.load(tsf)
    #     ts_entities = json_normalize(ts_df['entities'])
    #     corrected_ts_df = ts_entities.reindex(columns=ts_cols)
    #     corrected_ts_df.to_csv(os.path.join(foldername,'apitimesheets_'+today_date+'.csv'),encoding='utf-8')
    # with open(proj_jsonfilename, encoding='utf-8') as projf:
    #     proj_df = json.load(projf)
    #     p_entities = json_normalize(proj_df['entities'])
    #     corrected_proj_df = p_entities.reindex(columns=proj_cols)
    #     corrected_proj_df.to_csv(os.path.join(foldername,'apiprojects_'+today_date+'.csv'),encoding='utf-8')
    with open(customer_jsonfilename, encoding='utf-8') as custf:
        cust_df = json.load(custf)
        cust_entities = json_normalize(cust_df['entities'])
        corrected_cust_df = cust_entities.reindex(columns=cust_cols)
        corrected_cust_df.to_csv(os.path.join(foldername,'apicustomers_'+today_date+'.csv'),encoding='utf-8')
    with open(user_jsonfilename, encoding='utf-8') as userf:
        user_df = json.load(userf)
        user_entities = json_normalize(user_df['entities'])
        corrected_user_df = user_entities.reindex(columns=user_cols)
        corrected_user_df.to_csv(os.path.join(foldername,'apiusers_'+today_date+'.csv'),encoding='utf-8')


def prepAPIcall(jsonfilepath,fromdate,todate, logger):
    url = "https://api.clarizen.com/V2.0/services/data/query"
    headers = {
    'Authorization': get_api_secret(logger, 'clarizen', secret='pwd'),
    'Content-Type': 'text/plain'
    }
    # createTSJsonFile(url,headers,os.path.join(jsonfilepath,'timesheetQuery_'+today_date+'.json'),fromdate,todate)
    # createProjectJsonFile(url,headers,os.path.join(jsonfilepath,'projectsQuery_'+today_date+'.json'))
    createCustomerJsonFile(url,headers,os.path.join(jsonfilepath,'customerQuery_'+today_date+'.json'))
    createUserJsonFile(url,headers,os.path.join(jsonfilepath,'userQuery_'+today_date+'.json'))

def createUserJsonFile(url,headers,jsonfilename):
    pagingfrom = 0
    hasmore = True
    user_entities = []
    while(hasmore == True):
        cust_resp = getuserresponse(url, headers, pagingfrom)
        hasmore,pagingfrom = checkmoreAPIcallsRequired(cust_resp["paging"])
        if hasmore == True:
            # save entities object into a variable
            user_entities.append(cust_resp['entities'])
            print('has more true')
        else:
            # save last entities object into a variable
            user_entities.append(cust_resp['entities'])
            print('has more false')
    createjsonFile(user_entities,jsonfilename)

def createCustomerJsonFile(url,headers,jsonfilename):
    pagingfrom = 0
    hasmore = True
    cust_entities = []
    while(hasmore == True):
        cust_resp = getcustomerresponse(url, headers, pagingfrom)
        hasmore,pagingfrom = checkmoreAPIcallsRequired(cust_resp["paging"])
        if hasmore == True:
            # save entities object into a variable
            cust_entities.append(cust_resp['entities'])
            print('has more true')
        else:
            # save last entities object into a variable
            cust_entities.append(cust_resp['entities'])
            print('has more false')
    createjsonFile(cust_entities,jsonfilename)


# def createProjectJsonFile(url,headers,jsonfilename):
#     pagingfrom = 0
#     hasmore = True
#     proj_entities = []
#     while(hasmore == True):
#         proj_resp = getprojectresponse(url, headers, pagingfrom)
#         hasmore,pagingfrom = checkmoreAPIcallsRequired(proj_resp["paging"])
#         if hasmore == True:
#             # save entities object into a variable
#             proj_entities.append(proj_resp['entities'])
#             print('has more true')
#         else:
#             # save last entities object into a variable
#             proj_entities.append(proj_resp['entities'])
#             print('has more false')
#     createjsonFile(proj_entities,jsonfilename)

# def createTSJsonFile(url,headers,jsonfilename,fromdate,todate):
#     pagingfrom = 0
#     hasmore = True
#     ts_entities = []
#     while(hasmore == True):
#         ts_resp = getTSresponse(url, headers, fromdate, todate, pagingfrom)
#         hasmore,pagingfrom = checkmoreAPIcallsRequired(ts_resp["paging"])
#         if hasmore == True:
#             # save entities object into a variable
#             ts_entities.append(ts_resp['entities'])
#             print('has more true')
#         else:
#             # save last entities object into a variable
#             ts_entities.append(ts_resp['entities'])
#             print('has more false')
#     createjsonFile(ts_entities,jsonfilename)

def createjsonFile(jsonentries, jsonfilename):
    ret_str = '{"entities":['
    comma_cnt_json_objs = len(jsonentries)
    for eachobj in jsonentries:
        comma_cnt_ts_entry = len(eachobj)
        print(comma_cnt_ts_entry)
        for eachentry in eachobj:
            comma_cnt = len(eachentry)
            ret_str += '\n{'
            for key,value in eachentry.items():
                if(isinstance(value, dict)):
                    comma_cnt1 = len(value)
                    parsedstr = '"'+key+'" : {'
                    for key2,value2 in value.items():
                        if(isinstance(value2, str)):
                            value2 = value2.replace("\"", "'")
                            value2 = value2.replace("\t", " ")
                            value2 = value2.replace("\n", " ")
                            value2 = value2.replace("\r", " ")
                            value2 = value2.replace("\\", "/")
                            sub_ret_str = '"'+key2+'" : "'+value2+'"'
                        elif(value2 is None or isinstance(value2, bool)):
                            sub_ret_str = '"'+key2+'" : "'+str(value2)+'"'
                        else:
                            sub_ret_str = '"'+key2+'" : '+str(value2)
                        if(comma_cnt1 > 1):
                            sub_ret_str += ','
                        parsedstr += sub_ret_str
                        comma_cnt1-=1
                    parsedstr +='}'
                elif(isinstance(value, str)):
                    value = value.replace("\"", "'")
                    value = value.replace("\t", " ")
                    value = value.replace("\n", " ")
                    value = value.replace("\r", " ")
                    value = value.replace("\\", "/")
                    parsedstr = '"'+key+'" : "'+value+'"'
                elif(value is None or isinstance(value, bool)):
                    parsedstr = '"'+key+'" : "'+str(value)+'"'
                elif(isinstance(value, int) or isinstance(value, float)):
                    parsedstr = '"'+key+'" : '+str(value)
                else:
                    value = value.replace("\"", "'")
                    value = value.replace("\t", " ")
                    value = value.replace("\n", " ")
                    value = value.replace("\r", " ")
                    value = value.replace("\\", "/")
                    parsedstr = '"'+key+'" : "'+str(value)+'"'
                if(comma_cnt > 1):
                    parsedstr += ',\n'
                ret_str += parsedstr
                comma_cnt-=1
            ret_str += '}'
            if(comma_cnt_ts_entry > 1):
                ret_str += ',\n'
                comma_cnt_ts_entry-=1
        if(comma_cnt_json_objs > 1):
            ret_str += ',\n'
            comma_cnt_json_objs-=1
    ret_str += ']}'
    a_file = open(jsonfilename, "w", encoding='utf-8')
    a_file.write(ret_str)

def checkmoreAPIcallsRequired(APIresp):
    if('hasMore' in APIresp):
        pagingFrom = APIresp["from"]
        pagingHasMore = APIresp["hasMore"]
        return pagingHasMore,pagingFrom
    return False,0

def getuserresponse(url, headers, pagingfrom=0):
    payload = "{\"q\":\"Select AllowEmails, Availability, BusinessAddress, C_AnnualLeaveEntitlementBalance, C_Billable, C_CalculateDICapBookings, C_CollaboratingGroup, C_ContractHours, C_CostCenter, C_CurrentQuarterDICap, C_CurrentQuarterEndDate, C_CurrentQuarterStartDate, C_DepartmentalInitiativeLimit, C_DepartmentName, C_DIDuration, C_DpmtNumber, C_EmployeeNumber, C_EntityNumber, C_FCCPSRegionemployee, C_HoursReported_LastWeek, C_HoursReportedCurrentMonth, C_HoursReportedCurrentMonthLastUpdated, C_HoursReportedLastWeekUpdated, C_JobFamily, C_LatestTimesheetComplianceDate, C_NextQuarterDICap, C_NextQuarterEndDate, C_NextQuarterStartDate, C_QuarterofWorkRequest, C_Ramping, C_ReferencedCustomer, C_RevenueTypeL2, C_SalesTeam, C_StartDate, C_SubscribeToResourceNotifications, C_UserQuarter, CostOvertimeRate, CostRegularRate, CurrencyExchangeDate, CurrencyExchangeDateManuallySet, DirectManager, DisplayName, Email, EmailNotifications, ExpectedTimesheets, ExpirationDate, ExternalID, ExternalUser, Financial, FirstName, HomeAddress, IntegrationUser, InternalId, JobTitle, Language, LastName, LicenseType, LiteAdmin, LocalCurrency, Location, MobilePhone, MobileProfile, NumericFormat, OfficeFax, OfficePhone, Phase, Position, Profile, Region, RevenueOvertimeRate, RevenueRegularRate, ScimSyncId, ScimSyncJobTitle, SendInvitationMail, ShowLocalCurrencyCode, Signature, SubscribeToProjectNotifications, SuperUser, TargetUtilization, TimesheetsExpectedFrom, TimeZone, UserName, UserSyncId, UserSyncNotes, UserSyncUpdated from User\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
    # payload = "{\"q\":\"Select AllowEmails, Availability, BusinessAddress, C_AnnualLeaveEntitlementBalance, C_Billable, C_CalculateDICapBookings, C_CollaboratingGroup, C_ContractHours, C_CostCenter, C_CurrentQuarterDICap, C_CurrentQuarterEndDate, C_CurrentQuarterStartDate, C_DepartmentalInitiativeLimit, C_DepartmentName, C_DIDuration, C_DpmtNumber, C_EmployeeNumber, C_EmployeeRegionEmployee, C_EntityNumber, C_FCCPSRegionemployee, C_HoursReported_LastWeek, C_HoursReportedCurrentMonth, C_HoursReportedCurrentMonthLastUpdated, C_HoursReportedLastWeekUpdated, C_JobFamily, C_LatestTimesheetComplianceDate, C_NextQuarterDICap, C_NextQuarterEndDate, C_NextQuarterStartDate, C_QuarterofWorkRequest, C_Ramping, C_ReferencedCustomer, C_RevenueTypeL2, C_SalesTeam, C_StartDate, C_SubscribeToResourceNotifications, C_UserQuarter, CostOvertimeRate, CostRegularRate, CurrencyExchangeDate, CurrencyExchangeDateManuallySet, DirectManager, DisplayName, Email, EmailNotifications, ExpectedTimesheets, ExpirationDate, ExternalID, ExternalUser, Financial, FirstName, HomeAddress, IntegrationUser, InternalId, JobTitle, Language, LastName, LicenseType, LiteAdmin, LocalCurrency, Location, MobilePhone, MobileProfile, NumericFormat, OfficeFax, OfficePhone, Phase, Position, Profile, Region, RevenueOvertimeRate, RevenueRegularRate, ScimSyncId, ScimSyncJobTitle, SendInvitationMail, ShowLocalCurrencyCode, Signature, SubscribeToProjectNotifications, SuperUser, TargetUtilization, TimesheetsExpectedFrom, TimeZone, UserName, UserSyncId, UserSyncNotes, UserSyncUpdated from User\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json()

def getcustomerresponse(url, headers, pagingfrom=0):
    payload = "{\"q\":\"Select AccountStatus, BillingAddress, BusinessAddress, C_AccountManager, C_AccountMarker, C_AccountOwner2, C_ActionItems, C_APIType, C_BehaviorBiometricIdentification, C_BridgerPremierTAM, C_BridgerPremierTAM2, C_BridgerType, C_CaseManagement, C_CollaboratingGroup, C_CommercialBudgetStatus, C_ContractSize, C_CRM, C_CSATStatus, C_CSChallenges, C_CSMEngagementTask, C_CustomerNotes, C_CustomerRenewalDate, C_CustomerSubName, C_CustomerSubType, C_CustomerType, C_DowJonesBP, C_EngagementIssues, C_EngagementStatus, C_EnhancedProfiling, C_FCCPSRegion, C_FraudData, C_IssueUpdate, C_LastHealthCheckDate, C_LastInteractionDate, C_LastPolicyUpdate, C_LastQBRDate, C_LinktoAccountPage, C_LiveSince, C_LocationLanguage, C_Login, C_MobileSDK, C_NAO, C_NumberofTouchPoints, C_OngoingInitiatives, C_OtherProducts2BP, C_OtherProducts3BP, C_OtherProductsBP, C_ParentCustomer, C_Payment, C_PersonaRecognitionRate, C_PII, C_PolicyName, C_PortalNameOrgID, C_POV, C_ProfessionalServicesAccountManager, C_ProfessionalServicesEngagementManagerTAM, C_ProfessionalServicesEngagementManagerTAM2, C_ProfessionalServicesFraudDataAnalystDataScientis, C_ProfessionalServicesProjectManager, C_ProfessionalServicesTechnicalConsultant, C_PS_FDA_DS_2, C_SDK, C_SmartLearning, C_SmartRules, C_StartingUnknownSession, C_StatusIssueLastUpdatedBy, C_StatusIssueLastUpdatedOn, C_StoringAPIResponses, C_StrongCustomerAuthentication, C_SupportTier, C_TagObfuscation, C_TargetedMalware, C_TrainingDelivered, C_TruthData, C_UseCase, C_Version, C_WorldCheckBP, C_WorldComplianceBP, CompanySize, Country, CurrencyExchangeDate, CurrencyExchangeDateManuallySet, CustomerSuccessStatus, CustomerValue, DefaultIntegrationPath, Description, EntityOwner, ExternalID, GeographicalRegion, Industry, InternalId, LastDateContacted, MarketingSource, Name, OfficePhone, Owner, Region, SfExternalId, SfExternalName, StateProvince, TechnicalAccountManager, Tier, URL from Customer\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
    # payload = "{\"q\":\"Select AccountStatus, BillingAddress, BusinessAddress, C_AccountManager, C_AccountMarker, C_AccountOwner2, C_ActionItems, C_APIType, C_BehaviorBiometricIdentification, C_BridgerPremierTAM, C_BridgerPremierTAM2, C_BridgerType, C_CaseManagement, C_CollaboratingGroup, C_CommercialBudgetStatus, C_ContractSize, C_CRM, C_CSATStatus, C_CSChallenges, C_CSMEngagementTask, C_CustomerNotes, C_CustomerRenewalDate, C_CustomerSubName, C_CustomerSubType, C_CustomerType, C_DowJonesBP, C_EngagementIssues, C_EngagementStatus, C_EnhancedProfiling, C_FCCPSRegion, C_FraudData, C_GeographicalRegionSubDivision, C_HouseholdNumberGCID, C_IssueUpdate, C_LastHealthCheckDate, C_LastInteractionDate, C_LastPolicyUpdate, C_LastQBRDate, C_LinktoAccountPage, C_LiveSince, C_LocationLanguage, C_Login, C_MobileSDK, C_NAO, C_NumberofTouchPoints, C_OngoingInitiatives, C_OtherProducts2BP, C_OtherProducts3BP, C_OtherProductsBP, C_ParentCustomer, C_Payment, C_PersonaRecognitionRate, C_PII, C_PolicyName, C_PortalNameOrgID, C_POV, C_ProfessionalServicesAccountManager, C_ProfessionalServicesEngagementManagerTAM, C_ProfessionalServicesEngagementManagerTAM2, C_ProfessionalServicesFraudDataAnalystDataScientis, C_ProfessionalServicesProjectManager, C_ProfessionalServicesTechnicalConsultant, C_PS_FDA_DS_2, C_SDK, C_SmartLearning, C_SmartRules, C_StartingUnknownSession, C_StatusIssueLastUpdatedBy, C_StatusIssueLastUpdatedOn, C_StoringAPIResponses, C_StrongCustomerAuthentication, C_SupportTier, C_TagObfuscation, C_TargetedMalware, C_TrainingDelivered, C_TruthData, C_UseCase, C_Version, C_WorldCheckBP, C_WorldComplianceBP, CompanySize, Country, CurrencyExchangeDate, CurrencyExchangeDateManuallySet, CustomerSuccessStatus, CustomerValue, DefaultIntegrationPath, Description, EntityOwner, ExternalID, GeographicalRegion, Industry, InternalId, LastDateContacted, MarketingSource, Name, OfficePhone, Owner, Region, SfExternalId, SfExternalName, StateProvince, TechnicalAccountManager, Tier, URL from Customer\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json()

# def getprojectresponse(url, headers, pagingfrom=0):
#     payload = "{\"q\":\"Select ActualCost, ActualCostManuallySet, ActualEffort, ActualEffortUpdatedFromTimesheets, ActualEndDate, ActualRevenue, ActualRevenueManuallySet, ActualStartDate, AdditionalComments, Alignment, AllowReportingOnSubItems, Benefit, BenefitManuallySet, Billable, BillingType, BillingTypeManuallySet, BudgetedHours, BudgetStatus, BudgetSummary, BusinessAlignment, BusinessImpact, C_50ProgressNotificationSent, C_75ProgressNotificationSent, C_billing_id, C_BillingDeferredID, C_BusinessUnitLN, C_Category, C_CLZ_ProjectMethodology, C_CLZ_TeamBoardScrumMaster_CLZ, C_CLZ_TeamBoardState_CLZ, C_CLZ_TeamBoardStatusData_CLZ, C_CLZ_TeamBoardStatusIcon_CLZ, C_CLZ_TeamBoardType_CLZ, C_CLZ_TeamTaskColor_CLZ, C_Code, C_ContractEffectiveDate2, C_CurrentMonth, C_CustSatStatus, C_DeferredCOA, C_DurationMultiplier, C_EffectiveDateofService, C_ExpirationDateofService, C_FCCPSBillingType, C_FCCPSRegion, C_FinanceNotes, C_HourlyRateUnitRate, C_HoursUnits, C_ILTDeliveryDate, C_ILTDeliveryDate2, C_ILTDeliveryDate3, C_ILTSeats, C_ILTSurveySent, C_Invoice, C_InvoiceGJEAmount, C_InvoiceGJEDate, C_InvoiceSubmissionDate, C_InvoiceTotalAmount, C_IsParentProject, C_IsSubProject, C_Live, C_LocationLanguage, C_LossRate, C_MyCRMProject, C_ODTEnabled, C_ODTSeats, C_OnsiteRemote, C_OriginatedOpportunity, C_PeerReviewer, C_PhaseRDP, C_PhaseTMX, C_POVFollowonRevenueYear1, C_POVStage, C_PPR_ActualEndDateWithinRange, C_PPR_DueDateWithinRange, C_PPR_ResourcesDisplay, C_PPR_RoadmapURL, C_PPRDescription, C_PPREmailBody, C_PPREmailRecipients, C_PPREmailSubject, C_PPRFileName, C_PPRReportEndDate, C_PPRReportStartDate, C_Product, C_ProductionAPIDate, C_Products, C_ProductStatus, C_ProjectAssignmentLastUpdatedOn, C_ProjectContinuingFrom, C_ProjectContinuingTo, C_ProjectCustomerSatNotes, C_ProjectManagerName, C_ProjectNotes, C_ProjectTypeL1, C_ProjectTypeL2, C_ProjectTypeL4, C_RecognitionMethodUsed, C_ResellerSubClient, C_RevSymAdjustedRate, C_RevSymLineID, C_ScopeStatus, C_SpecializedRate, C_SupportHandoverDate, C_TargetEndDate, C_TargetStartDate, C_TCSSurveyScore, C_ThreatmetrixSubsidiary, C_TimeTrackingLevel, C_TodaysDate, C_TrainingDelivered, C_TrainingNotes, C_TravelExpenses, C_TypeofConsulting, C_updateresourcerates, C_UseCasesScopeNotes, C_UseCasesTMX, CalculateCompletenessBasedOnEfforts, CalculateFinancials, Charged, ChargedAmount, ChargedAmountManuallySet, ChargedTypeManuallySet, ClarizenGoWorkspaceCreator, ClosingNotes, CommitLevel, CommittedDate, CostCurrencyType, Country, CurrencyExchangeDate, CurrencyExchangeDateManuallySet, DefaultIntegrationPath, Deliverable, DeliverableType, Description, DirectPlannedBilledExpenses, DirectPlannedExpenses, DueDate, Duration, DurationManuallySet, EntityOwner, ExpectedBusinessValue, ExpectedROI, ExpenseType, ExternalID, FinancialEnd, FinancialStart, FixedCost, FixedPrice, GeographicalRegion, GoalsAchieved, HoldingNotes, IgnoreResourceCalendars, IgnoreResourceCalendarsManuallySet, Importance, ImportedFrom, InternalId, InternalStatus, InvestmentType, IsPortfolio, Justification, LaborBudget, LastSyncedWithClarizenGo, LinkToClarizenGo, Manager, Mitigation, Name, NLRExchangeRateDateOptionSet, ObjectAlias, OrderID, OverallSummary, Parent, Pending, PercentCompleted, PermissionInheritanceForExternalUsers, Phase, PlannedAmount, PlannedBudget, PlannedBudgetManuallySet, PlannedRevenue, PlannedRevenueManuallySet, PlannedSavings, Priority, ProgressUpdateFrequency, ProgressUpdateFrequencyManuallySet, ProjectGoals, ProjectManager, ProjectSize, ProjectSponsor, ProjectTagging, ProjectType, RateCard, RemainingEffort, Reportable, ReportableManuallySet, ReportingStartDate, Required, ResourceRateDate, ResourceUtilizationCategory, RevenueCurrencyType, Risks, RisksImpact, RisksRate, RollupFinancialAndEffortDataFromShortcut, RollupProgressAndDatesFromShortcut, ScheduleSummary, SchedulingType, SfExternalId, SfExternalName, SKU, StartDate, StateProvince, SyncWithClarizenGo, TaskReportingPolicy, TimeApproval, TotalEstimatedCost, TrackStatus, TrackStatusManuallySet, Work, WorkManuallySet, WorkPolicy, C_BillingProductCode, C_BillingDescription, C_BillingChargeCode, SYSID, C_SubProjectCount, C_RateTMX, C_BillingMBSTMXProjectFilter, C_ExtensionInProgress, C_BillingFIDOTMXProjectFilter from Project\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
#     # payload = "{\"q\":\"Select ActualCost, ActualCostManuallySet, ActualEffort, ActualEffortUpdatedFromTimesheets, ActualEndDate, ActualRevenue, ActualRevenueManuallySet, ActualStartDate, AdditionalComments, Alignment, AllowReportingOnSubItems, Benefit, BenefitManuallySet, Billable, BillingType, BillingTypeManuallySet, BudgetedHours, BudgetStatus, BudgetSummary, BusinessAlignment, BusinessImpact, C_50ProgressNotificationSent, C_75ProgressNotificationSent, C_billing_id, C_BillingDeferredID, C_BusinessUnitLN, C_Category, C_CLZ_ProjectMethodology, C_CLZ_TeamBoardScrumMaster_CLZ, C_CLZ_TeamBoardState_CLZ, C_CLZ_TeamBoardStatusData_CLZ, C_CLZ_TeamBoardStatusIcon_CLZ, C_CLZ_TeamBoardType_CLZ, C_CLZ_TeamTaskColor_CLZ, C_Code, C_ContractEffectiveDate2, C_CurrentMonth, C_CustSatStatus, C_DeferredCOA, C_DurationMultiplier, C_EffectiveDateofService, C_ExpirationDateofService, C_FCCPSBillingType, C_FCCPSRegion, C_FinanceNotes, C_GeographicalRegionSubDivision, C_HourlyRateUnitRate, C_HoursUnits, C_ILTDeliveryDate, C_ILTDeliveryDate2, C_ILTDeliveryDate3, C_ILTSeats, C_ILTSurveySent, C_Invoice, C_InvoiceGJEAmount, C_InvoiceGJEDate, C_InvoiceSubmissionDate, C_InvoiceTotalAmount, C_IsParentProject, C_IsSubProject, C_Live, C_LocationLanguage, C_LossRate, C_MyCRMProject, C_ODTEnabled, C_ODTSeats, C_OnsiteRemote, C_OriginatedOpportunity, C_PeerReviewer, C_PhaseRDP, C_PhaseTMX, C_POVFollowonRevenueYear1, C_POVScheduledGoLiveDate, C_POVStage, C_PPR_ActualEndDateWithinRange, C_PPR_DueDateWithinRange, C_PPR_ResourcesDisplay, C_PPR_RoadmapURL, C_PPRDescription, C_PPREmailBody, C_PPREmailRecipients, C_PPREmailSubject, C_PPRFileName, C_PPRReportEndDate, C_PPRReportStartDate, C_Product, C_ProductionAPIDate, C_Products, C_ProductStatus, C_ProjectAssignmentLastUpdatedOn, C_ProjectContinuingFrom, C_ProjectContinuingTo, C_ProjectCustomerSatNotes, C_ProjectManagerName, C_ProjectNotes, C_ProjectTypeL1, C_ProjectTypeL2, C_ProjectTypeL4, C_RecognitionMethodUsed, C_ResellerSubClient, C_RevSymAdjustedRate, C_RevSymLineID, C_ScopeStatus, C_SpecializedRate, C_SupportHandoverDate, C_TargetEndDate, C_TargetStartDate, C_TCSSurveyScore, C_ThreatmetrixSubsidiary, C_TimeTrackingLevel, C_TodaysDate, C_TrainingDelivered, C_TrainingNotes, C_TravelExpenses, C_TypeofConsulting, C_updateresourcerates, C_UseCasesScopeNotes, C_UseCasesTMX, CalculateCompletenessBasedOnEfforts, CalculateFinancials, Charged, ChargedAmount, ChargedAmountManuallySet, ChargedTypeManuallySet, ClarizenGoWorkspaceCreator, ClosingNotes, CommitLevel, CommittedDate, CostCurrencyType, Country, CurrencyExchangeDate, CurrencyExchangeDateManuallySet, DefaultIntegrationPath, Deliverable, DeliverableType, Description, DirectPlannedBilledExpenses, DirectPlannedExpenses, DueDate, Duration, DurationManuallySet, EntityOwner, ExpectedBusinessValue, ExpectedROI, ExpenseType, ExternalID, FinancialEnd, FinancialStart, FixedCost, FixedPrice, GeographicalRegion, GoalsAchieved, HoldingNotes, IgnoreResourceCalendars, IgnoreResourceCalendarsManuallySet, Importance, ImportedFrom, InternalId, InternalStatus, InvestmentType, IsPortfolio, Justification, LaborBudget, LastSyncedWithClarizenGo, LinkToClarizenGo, Manager, Mitigation, Name, NLRExchangeRateDateOptionSet, ObjectAlias, OrderID, OverallSummary, Parent, Pending, PercentCompleted, PermissionInheritanceForExternalUsers, Phase, PlannedAmount, PlannedBudget, PlannedBudgetManuallySet, PlannedRevenue, PlannedRevenueManuallySet, PlannedSavings, Priority, ProgressUpdateFrequency, ProgressUpdateFrequencyManuallySet, ProjectGoals, ProjectManager, ProjectSize, ProjectSponsor, ProjectTagging, ProjectType, RateCard, RemainingEffort, Reportable, ReportableManuallySet, ReportingStartDate, Required, ResourceRateDate, ResourceUtilizationCategory, RevenueCurrencyType, Risks, RisksImpact, RisksRate, RollupFinancialAndEffortDataFromShortcut, RollupProgressAndDatesFromShortcut, ScheduleSummary, SchedulingType, SfExternalId, SfExternalName, SKU, StartDate, StateProvince, SyncWithClarizenGo, TaskReportingPolicy, TimeApproval, TotalEstimatedCost, TrackStatus, TrackStatusManuallySet, Work, WorkManuallySet, WorkPolicy, C_BillingProductCode, C_BillingDescription, C_BillingChargeCode, SYSID, C_SubProjectCount, C_RateTMX, C_BillingMBSTMXProjectFilter from Project\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
#     response = requests.request("POST", url, headers=headers, data=payload)
#     return response.json()

# def getTSresponse(url, headers, fromdate, todate, pagingfrom=0):
#     payload = "{\"q\":\"SELECT AssignedApprover, C_BilledonInvoice, C_CSMActivity, C_CSMActivityType, C_CSMCategory, C_DeliverableBP, C_DeliverableTCS, C_DeliverableTMX, C_InternalMeeting, C_OnsiteMeeting, C_PPR_Project, C_SpecializedRate, C_SubDeliverableBP, C_SubmittedOn, C_TimesheetofCustomer, Charged, Comment, CreatorType, DisableReportingTimeLimit, Duration, ExternalID, HumanResource, LastSubmittedDate, Overtime, RegularHours, RejectedBy, RejectionDate, RejectionNote, ReportedBy, ReportedDate, WorkItem, Project, C_DurationMultiplierEnabledHours from Timesheet where ReportedDate>='"+fromdate+"' and ReportedDate<='"+todate+"'\",\"paging\":{\"from\": "+ str(pagingfrom) +",\"limit\":5000}}"
#     response = requests.request("POST", url, headers=headers, data=payload)
#     return response.json()

def pull_all_files():
    logger = getLogger()
    try:
        foldername = parseYamlProperty.get_inbound_dir()+'\\mbs_tmx_clarizen\\daily\\'
        if not os.path.isdir(foldername):
            os.mkdir(foldername)
        fromdate = currentyearmonth + '-01'
        todate = currentyearmonth + '-' + currentyearmonth_last_date
        prepAPIcall(foldername,fromdate,todate,logger)
        process(foldername)
    except Exception as ex:
        logger.error("Pull from API error", exc_info=True)
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print(processerrorMsg)

if __name__ == "__main__":
    pull_all_files()