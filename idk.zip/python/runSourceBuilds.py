from commonSourceFiles import commonSourceFiles
import prepSourceFiles
import ecl_call_wrapper
import AutomationLogging
import logging_into_db
import generateBuildNotification
import datetime
import generateBuildLog
import commonArgs
import parseJSONProperty
import fido_utils
import sys
import traceback
import checkAndPullFiles
import parseYamlProperty as parse_props
import checkEnvironmentVariables
run_date_time = datetime.datetime.now()

def getLogger():
    return AutomationLogging.getLogger('runSourceBuilds')

def eclCall(sourceRun):

    logger = getLogger()

    (workunit, status, wuMsg) = ecl_call_wrapper.invoke_ecl_and_wait_for_completion(logger, sourceRun)
    logger.info('Workunit {0}'.format(workunit))
    logger.info('Status {0}'.format(status))
    logger.info('WUMsg {0}'.format(wuMsg))
    
    return (workunit, status, wuMsg)
#  this pull process is not  in use now
# def pullprocess(source, frequency, filedate):
#     checkAndPullFiles.process(source, frequency, filedate)

def process():

    logger = getLogger()
    checkEnvironmentVariables.validate_variables()
   
    sourceInfo = parseJSONProperty.getSourceInfo(commonArgs.getSource(), commonArgs.getFrequency(), commonArgs.getFiledate())
    logger.debug('In Process - SourceInfo {0}'.format(sourceInfo))
    if commonArgs.getskipPreProcess() == True:
                print("Skipping Pre Processing")    
    elif sourceInfo.preProcess != '':
            exec(sourceInfo.preProcess)
    #This new processType is for NO ECL and Just Push feeds to Servers, hence returning with NO action
    if sourceInfo.processtype == 'pushfeeds':
        return 

    if sourceInfo.processtype == 'extracts' or sourceInfo.processtype == 'fromHPCC':
        processRun = processNoInboundFiles(sourceInfo)
        
    elif sourceInfo.processtype == 'inboundloads':
        if not commonArgs.getSkipPullFlag():
            checkAndPullFiles.process()
        processRun = processInbound(sourceInfo)

    if not processRun.status:
        raise GracefullyExit(Exception('process status is: {0}'.format(processRun.status)))

def processInbound(sourceInfo):

    logger = getLogger()

    logger.info('Are we here or wat?')
    logger.debug("Inside processInbound") 
    sortedcommonSourceFilesList = prepSourceFiles.process(sourceInfo)

    resultcommonSourceFilesList = sorted(sortedcommonSourceFilesList)

    print(resultcommonSourceFilesList)
    for sourceRun in resultcommonSourceFilesList:
        
        sourceRun.successEmailTo = sourceInfo.successemailto
        sourceRun.errorEmailTo = sourceInfo.erroremailto
        sourceRun.hostname = parse_props.getHostName()
        iterationFlag = True

        logger.debug('Processing files for {0}'.format(sourceRun.file_date))
        logger.debug('Source Run Status {0}'.format(sourceRun.status))

        #if sourceRun.status and (sourceRun.file_date == filedate if filedate != '' else True):
        if sourceRun.status:
            sourceRun.HPCCStartTime = datetime.datetime.now()
            #logger.info('DB logging start time for HPCC start time {0}'.format(datetime.datetime.now()))
            logging_into_db.process(sourceRun,run_date_time)
            #logger.info('DB logging end time for HPCC start time {0}'.format(datetime.datetime.now()))
            #(workunit, status, wuMsg) = eclCall(sourceRun.source, sourceRun.frequency, sourceRun.file_date, env )
            (workunit, status, wuMsg) = eclCall(sourceRun)
            logger.info('Workunit {0}'.format(workunit))
            logger.info('Status {0}'.format(status))
            logger.info('WUMsg {0}'.format(wuMsg))
            sourceRun.workunit = workunit
            sourceRun.workunitMsg = wuMsg
            sourceRun.workunitstatus = status
            logging_into_db.process(sourceRun,run_date_time)
            if status.lower() == 'completed':
                sourceRun.status = True
            else:
                sourceRun.status = False
                sys.tracebacklimit = None
                sourceRun.msg = 'Status is showing False'
                logger.info('Error in Processing Status ...Going to Post Process {0}'.format(sourceRun))
                logger.info(sourceRun)
                iterationFlag = False
                
            if iterationFlag and sourceRun.workunitstatus in ['failed', 'aborted']:
                sys.tracebacklimit = None
                sourceRun.status = False
                sourceRun.msg = 'Workunit status is {0}'.format(sourceRun.workunitstatus)
                logger.info('Error in Workunit Status ...Going to Post Process {0}'.format(sourceRun))
                logger.info(sourceRun)        
                iterationFlag = False
            
            sourceRun.HPCCEndTime = datetime.datetime.now()
            logging_into_db.process(sourceRun,run_date_time)
            if sourceRun.postProcessFlag and commonArgs.getskipPostProcess() != True:
                logger.info('Going to Post Process {0}'.format(sourceRun))
                prepSourceFiles.postProcess(logger, sourceRun,run_date_time)
            
            logger.info(sourceRun)
        
        log_filename = sourceRun.source + '_' + sourceRun.frequency + '_' + (sourceRun.requestorId + "_" if sourceRun.requestorId else '') + sourceRun.file_date + '_build.html'

        sourceRun.log_filename = log_filename
        generateBuildLog.generate(sourceRun)
        sourceRun.processEndTime = datetime.datetime.now()
        logging_into_db.process(sourceRun,run_date_time)
        generateBuildNotification.notifyEmail(sourceRun)

        if iterationFlag == False:
            break
    
    ##   archive older date files from sourcefolder when skipOldDates is true
    if commonArgs.getSkipOldDates() == True:
        for processEachFrequency in sorted(sortedcommonSourceFilesList, reverse = True)[1:]:
            prepSourceFiles.postProcess(logger, processEachFrequency, run_date_time) 
    
    return sourceRun

def processNoInboundFiles(sourceInfo):
    
    logger = getLogger()

    logger.debug('Inside ProcessExtracts')
    extractRun = commonSourceFiles(sourceInfo.source, sourceInfo.frequency,sourceInfo.processtype)
    #DBextractRun = DBlogging(extractRun)
    #debugEmailTo = parse_props.get_debug_email()
    extractRun.errorEmailTo = sourceInfo.erroremailto
    extractRun.successEmailTo = sourceInfo.successemailto    
    extractRun.processStartTime = datetime.datetime.now()
    # extractRun.file_date = commonArgs.getFiledate()
    # defaulting today as file_date for fromHPCC jobs, as fromHPCC processtype jobs are expected to run for this date
    extractRun.file_date = sourceInfo.filedate
    extractRun.HPCCStartTime = datetime.datetime.now()
    logging_into_db.process(extractRun,run_date_time)
    (workunit, status, wuMsg) = eclCall(extractRun)

    extractRun.workunit = workunit
    extractRun.workunitMsg = wuMsg
    extractRun.workunitstatus = status
    logging_into_db.process(extractRun,run_date_time)
            
    if status.lower() == 'completed':
        extractRun.status = True
    else:
        extractRun.status = False
        sys.tracebacklimit = None
        extractRun.msg = 'Status is showing False'
        logger.info('Error in Processing Status ...Going to Post Process {0}'.format(extractRun))
        logger.info(extractRun)
                
    if extractRun.workunitstatus in ['failed', 'aborted']:
        sys.tracebacklimit = None
        extractRun.status = False
        extractRun.msg = 'Workunit status is {0}'.format(extractRun.workunitstatus)
        logger.info('Error in Workunit Status ...{0}'.format(extractRun))
        logger.info(extractRun)        

    extractRun.HPCCEndTime = datetime.datetime.now()
    logging_into_db.process(extractRun,run_date_time)
    log_filename = extractRun.source + '_' + extractRun.frequency + '_' + extractRun.file_date + '_build.html'
    extractRun.log_filename = log_filename
    generateBuildLog.generate(extractRun)
    extractRun.processEndTime = datetime.datetime.now()
    logging_into_db.process(extractRun,run_date_time)
    generateBuildNotification.notifyEmail(extractRun)
    return extractRun

def processerror(source, frequency, processtype, filedate, processerrorMsg, successemailto, erroremailto):
    
    logger = getLogger()

    logger.info('Inside Error Process')
    ErrorRun = commonSourceFiles(source, frequency, processtype)
    ErrorRun.source = source
    ErrorRun.successEmailTo = successemailto
    ErrorRun.errorEmailTo = erroremailto
    ErrorRun.processtype = processtype
    ErrorRun.file_date = filedate
    ErrorRun.frequency = frequency
    #ErrorRun.preProcessStartTime = datetime.datetime.now()
    #ErrorRun.preProcessEndTime = datetime.datetime.now()
    ErrorRun.processStartTime = datetime.datetime.now()
    ErrorRun.processEndTime = datetime.datetime.now()
    #ErrorRun.HPCCStartTime = datetime.datetime.now()      
    #ErrorRun.HPCCEndTime = datetime.datetime.now()
    #ErrorRun.postProcessEndTime = datetime.datetime.now()
    #ErrorRun.postProcessStartTime = datetime.datetime.now()
    ErrorRun.processerrorMsg = processerrorMsg
    ErrorRun.status = False
    logging_into_db.process(ErrorRun,run_date_time)
    log_filename = ErrorRun.source + '_' + ErrorRun.frequency + '_' + ErrorRun.file_date + '_build.html'
    ErrorRun.log_filename = log_filename
    generateBuildLog.generate(ErrorRun)
    logging_into_db.process(ErrorRun,run_date_time)
    generateBuildNotification.notifyEmail(ErrorRun)

class GracefullyExit(Exception):
    pass

if __name__ == "__main__":
    
    logger = getLogger()

    debug = False
    if commonArgs.getDebugFlag():
        debug = True
    try:
        process()
        exit(0)
    
    except GracefullyExit as gex:
        logger.error("Process error", exc_info=True)
        exit(-99)

    except Exception as ex:
        logger.error("Fatal error in main loop", exc_info=True)
        exc_type, exc_value, exc_traceback = sys.exc_info()
        sourceInfo = parseJSONProperty.getSourceInfo(commonArgs.getSource(), commonArgs.getFrequency(), commonArgs.getFiledate())
        successEmailTo = sourceInfo.successemailto
        errorEmailTo = sourceInfo.erroremailto
        
        if debug:
            successEmailTo = parse_props.get_debug_email()
            errorEmailTo = parse_props.get_debug_email()
        
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        if commonArgs.getFiledate() != '':
            file_date = commonArgs.getFiledate()
        else:
            file_date = fido_utils.today

        processerror(commonArgs.getSource(), commonArgs.getFrequency(), sourceInfo.processtype, file_date, processerrorMsg, successEmailTo, errorEmailTo)
        exit(-99)