
import subprocess
def pull_files():
	subprocess.run("python jira_full.py & python jira_issue.py & python jira_resolution.py & python jira_worklog.py", shell=True)



pull_files()