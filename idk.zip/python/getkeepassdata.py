import json
import sys
from collections import namedtuple
import commonArgs
import traceback
import getProperties
from vault.secrets import get_api_secret

MyKeepassSource = namedtuple('MyKeepassSource', ['mykeepasssource', 'frequency','keepassfilename', 'password', 'title'])
keepass_file_name = getProperties.getKeepassJsonFilename()
keepass_cred_file_name = getProperties.getKeepass_credJsonFilename()

def getSourcekeepassinfo(logger, source, frequency):
    with open(keepass_file_name, 'r') as jr_file:
        jsonRef = json.load(jr_file)
    with open(keepass_cred_file_name, 'r') as kcr_file:
        keepasscredRef = json.load(kcr_file)
    json_dict = {k:v for item in jsonRef for k,v in item.items()}  # flatten jsonRef for easy access
    src = json_dict[source]  # isolate source we're looking for
    env = commonArgs.getEnv().lower()
    for item in src:
        if item['environment'].lower() == env:
            title = item['title']
            keepassmapid = item['keepassmapid']
            keepasscred_dict = {k:v for item in keepasscredRef for k,v in item.items()}  # flatten keepasscredRef for easy access
            target_keepasscred = keepasscred_dict[keepassmapid][0]
            filename = target_keepasscred['filename']
            pwd = get_api_secret(logger, target_keepasscred['source'], secret='pwd')
            return MyKeepassSource(source, frequency, filename, pwd, title)

if __name__ == "__main__":

    try:
        #print(getSourcekeepassinfo('salesforceunity', 'daily'))
        pass

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print(processerrorMsg)
