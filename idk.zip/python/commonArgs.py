import argparse
import time
import datetime
import os

def valiDate(dt, fmt='%Y%m%d'):
    try:
        date_obj = datetime.datetime.strptime(dt, fmt)
        #print('Am I here? .. {0}'.format(date_obj))
    except ValueError as e:
        raise Exception("Incorrect data format, should be YYYYMMdd {0}".format(e))
    
def getTodayTS():
    return datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

def formatDate(dtDateTime, strFormat="%Y%m%d"):
    # format a datetime object as YYYY-MM-DD string and return
    return dtDateTime.strftime(strFormat)

def getYesterday(dtDatetime = datetime.date.today()):
    one_day = datetime.timedelta(days=1)
    newDate = formatDate(dtDatetime - one_day)
    return newDate

def getTomorrow(dtDatetime = datetime.date.today()):
    one_day = datetime.timedelta(days=1)
    newDate = formatDate(dtDatetime + one_day)
    return newDate

args = None

# revisit
def parse():

    parser = argparse.ArgumentParser(description='This is a RED Source Spray Automation Common Argument Parser, not all options are relevant to the calling module')
    parser.add_argument('-a', '--application', help='application name', required=True)
    parser.add_argument('-s', '--source', help='Source name', required=True)
    parser.add_argument('-f', '--frequency', help='Frequency (daily / monthly)', required=True)        
    parser.add_argument('-e', '--env', help='Environment (dev/prod)', default='', required=True)
    parser.add_argument('-dhost', '--dhost', help='Hostname to despray', default='', required=False)
    parser.add_argument('-dt', '--date', help='filedate', default='', required=False)
    parser.add_argument('-d', '--debug', help='enabling this option would not send email to all', action='store_true', default=False)
    parser.add_argument('-de', '--debugEmail', help='this option would send email for debug', default='', required = False)
    parser.add_argument('-path', '--basePathDir', help='this option would set base path', default='', required = False)
    parser.add_argument('-m', '--buildmonth', help='Build Month', default='', required=False)
    parser.add_argument('-fr', '--skipFindAllrequired', help='Find all required files (true/false)', action='store_true', default=False, required=False)
    parser.add_argument('-skipOldDates', '--skipOldDates', help='Skip old dates files (true/false)', action='store_true', default=False, required=False)
    parser.add_argument('-skippull', '--skippull',      help='Skip the Check And Pull process', action='store_true', default=False, required=False)
    parser.add_argument('-skipenv', '--skipenv',      help='Skip to read directory paths using env variables', action='store_true', default=False, required=False)
    parser.add_argument('-skipwhen', '--skipwhen',      help='Skip to add when parameter in ECL', action='store_true', default=False, required=False)
    parser.add_argument('-skips3push', '--skips3push',      help='Skip the Check And push process for s3', action='store_true', default=False, required=False)
    parser.add_argument('-skipazurepush', '--skipazurepush',      help='Skip the Check And push process for Azure', action='store_true', default=False, required=False)
    parser.add_argument('-hhost', '--hhost', help='Hostname to HPCCCluster', default='', required=False)
    parser.add_argument('-startdt', '--startdate', help='filestartdate', default='', required=False)
    parser.add_argument('-enddt', '--enddate', help='fileenddate', default='', required=False)
    parser.add_argument('-IgnoreWhenparamHistoryDate', '--IgnoreWhenparamHistoryDate', help='Ignore Whenparam in ecl for history file date', action='store_true', default=False, required=False)
    parser.add_argument('-validateflag', '--validateflag', help='Validate weekly release flag', action='store_true', default=False, required=False)
    _ts = getTodayTS()
    parser.add_argument('--timestamp', default=_ts, required=False)
    parser.add_argument('-skipPostProcess', '--skipPostProcess', help='Skips Post Processing', action='store_true', default=False, required=False)
    parser.add_argument('-skipPreProcess', '--skipPreProcess', help='Skips Pre Processing', action='store_true', default=False, required=False)
    parser.add_argument('-cubeList', '--cubeList', help='List of cubes', nargs='+', default=False, required=False)
    parser.add_argument('-sh', '--sheetPath', help='overrider the spreadsheet path', default='', required=False)

    args = parser.parse_args()
    # print('Here {0}'.format(args))
    # args.date = fido_utils.getToday() if args.date == '' else args.date
        
    if args.date.lower() == 'yesterday':
        args.date = getYesterday()
    elif args.date.lower() == 'tomorrow':
        #print('here?')
        args.date = getTomorrow()

    if args.date != '':
        valiDate(args.date)

    return args

def getArgs():
    global args
    if(args==None):
        args = parse()
    return args

def getApplication():
    return getArgs().application

def getSheetPath():
    return getArgs().sheetPath


def getSource():
    return getArgs().source

def getFrequency():
    return getArgs().frequency

def getEnv():
    if getArgs().env == '':
        return 'prod'
    return getArgs().env

def get_despray_hostname():
    return getArgs().dhost

def getFiledate():
    return getArgs().date

def getDebugFlag():
    return getArgs().debug

def getDebugEmail():
    return getArgs().debugEmail

def getBasePathDir():
    return getArgs().basePathDir

def getBuildMonth():
    return getArgs().buildmonth

def getSkipFindAllRequiredFlag():
    return getArgs().skipFindAllrequired

def getSkipenv():
    return getArgs().skipenv

def getSkipOldDates():
    return getArgs().skipOldDates

def getSkipPullFlag():
    return getArgs().skippull

def getSkipS3PushFlag():
    return getArgs().skips3push

def getSkipAzurePushFlag():
    return getArgs().skipazurepush

def getHpccHost():
    return getArgs().hhost

def getFilestartdate():
    return getArgs().startdate

def getFileenddate():
    return getArgs().enddate

def getIgnoreWhenparamHistoryDate():
    return getArgs().IgnoreWhenparamHistoryDate

def getvalidateflag():
    return getArgs().validateflag

def getTimestamp():
    return getArgs().timestamp

def getskipPostProcess():
    return getArgs().skipPostProcess
    
def getskipPreProcess():
    return getArgs().skipPreProcess

def getSkipWhen():
    return getArgs().skipwhen

def getCubeList():
    return getArgs().cubeList
    
if __name__ == '__main__':
    #parse()
    # print(getArgs().hhost)
    print(getSheetPath())