#touch ./python/__init__.py
if pylint -E python
then
    echo "success $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
else
    echo "fail $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
    exit 1
fi

