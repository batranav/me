#! /bin/bash 
timestamp=$(date +%Y%m%d_%H%M%S)
logfilename=/d/red/scripts/logs/gitlab_pull_fido_$timestamp.log
echo $logfilename
eval `ssh-agent -s`
ssh-add /d/red/scripts/git/gitlab_id_rsa
basefolder=/c/development/gitlab
cd $basefolder
find . -type d -name 'fido_*' |xargs rm -r
if [ -d $basefolder/fido ]; then
   timestamp=$(date +%Y%m%d%H%M%S)
   mkdir $timestamp
   cd $timestamp
   git clone git@gitlab.ins.risk.regn.net:fido/red.git 
   mv $basefolder/fido/red $basefolder/fido_$timestamp
   mv $basefolder/$timestamp/red $basefolder/fido
   cd $basefolder
   rm -rf $timestamp
else
   mkdir fido
   cd $basefolder/fido
   git clone git@gitlab.ins.risk.regn.net:fido/red.git
fi