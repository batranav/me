$application = "rbi"
$source = "hyperion"
$frequency = "daily"
$environment = "prod"
$get_uname_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_uname.py"
$get_pwd_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_pwd.py"
$uname = python $get_uname_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
$uname_full = 'alawpfido101\' + $uname
$pass = python $get_pwd_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
PSExec.exe /accepteula -s \\alawpfido101 -u $uname_full -p $pass f:\scripts\RBI_FCST\RBI_FCST_Data_Export_for_HPCC.bat