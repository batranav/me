
import os
import parseYamlProperty

def generatedBatchFile(source, frequency, action):
    data = ""
    data = data + 'set source=' + source + '\n'
    if frequency != '':
        data = data + 'set frequency='+ frequency  + '\n'
        data = data + 'set action=' + action  + '\n'
        data = data + 'call set_env_values.bat %source% %frequency% %action%'  + '\n'
    else:
        data = data + 'call set_env_values.bat %source%'  + '\n'
    if action == 'pull':
        data = data + 'python %scripts_dir%\\\\python\\\\checkAndPullFiles.py -s %source% -f %frequency% -e prod 1> %logfile% 2> %errfile%'  + '\n'
    elif action == 'build':
        data = data + 'python %scripts_dir%\\\\python\\\\runSourceBuilds.py -s %source% -f %frequency% -e prod 1> %logfile% 2> %errfile%'  + '\n'
    data = data + 'exit'

    filename = os.path.join(parseYamlProperty.get_base_script_dir(), 'batch', source + '_' + frequency + '_' + action +'.bat')
    fileobj = open(filename, "w")
    fileobj.write(data)
    fileobj.close()
    return
if __name__ == __name__:
    print('Iam in batch generator')
    generatedBatchFile('dummy','daily','pull')