from jira import JIRA
import sys, http.client, os
import json
import csv
from collections import defaultdict
from datetime import datetime, timedelta
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret

sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir() ,'jira//resolution_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
def main():

	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_resolution', True)
	uname, pwd = get_api_secret(logger, 'jira')
	jira = JIRA(options, basic_auth=(uname, pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		print('working')
		startidx=blocknum*blocksize
		#newissues=jira.search_issues('project !=EMPTY and   updated >= -5d and updated <= 1d order by updated' , startidx, blocksize)
		newissues=jira.search_issues('project !=EMPTY and  created >= "2019/01/01" AND created <= "2019/03/31" ' , startidx, blocksize)
		#'project !=EMPTY and updatedDate >  startOfDay()'
		numissues=len(newissues)
		if  numissues==0 or  blocknum==1000:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0	
	resolutionfile=open(os.path.join(parseYamlProperty.get_inbound_dir() ,'jira//daily//resolution_'+ datetime.now().strftime('%Y%m%d') + '.csv'),"w+", encoding='utf-8',newline="")
	#resolutionfile=open('D:\\red\\data\\inbound\\jira\\daily\\resolution_'+ datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	resolutionwriter=csv.writer(resolutionfile)
		
	for resultlist in issues:
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
				
			fields=dict['fields']
			del dict['fields']
			fields['issue']=issueId
		
			resolution=fields['resolution']
			if resolution is not None:
				del fields['resolution']
		
				resolution['resolution']=issueId
				if issuecount==0:
						resolutionwriter.writerow(resolution.keys())
				
				resolutionwriter.writerow(resolution.values())	
				
			issuecount=issuecount+1
				
	resolutionfile.close()
	#f.close()
if __name__== "__main__" :
     main()





