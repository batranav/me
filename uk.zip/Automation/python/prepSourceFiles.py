import os.path, re, glob, shutil, os, subprocess
#import parseYamlProperty as parse_props
# revisit
from os import listdir
from os.path import isfile, join
from commonSourceFiles import commonSourceFiles
from subprocess import Popen, PIPE
import file_utils
import AutomationLogging
import sys
import time
import datetime
import logging_into_db
import commonSourceInfo
import fido_utils
import parseYamlProperty,parseJSONProperty
import commonArgs
from pathlib import Path

all_regexes = [
    re.compile(r'(?P<filename>)_(?P<requestorId>\d{8})_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})', re.X),
    re.compile(r'(?P<filename>)_(?P<requestorId>\d{8})_(?P<month>\d{2}) \. (?P<day>\d{2}) \. (?P<year>\d{4})', re.X),
    re.compile(r'(?P<filename>)_(?P<requestorId>\d{8})_(?P<month>\d{2}) - (?P<day>\d{2}) - (?P<year>\d{4})', re.X),
    re.compile(r'(?P<filename>)_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})', re.X),
    re.compile(r'(?P<filename>)_(?P<month>\d{2}) \. (?P<day>\d{2}) \. (?P<year>\d{4})', re.X),
    re.compile(r'(?P<filename>)_(?P<month>\d{2}) - (?P<day>\d{2}) - (?P<year>\d{4})', re.X)
]


def getLogger():
    return AutomationLogging.getLogger('prepSourceFiles')
    #return 1

file_dates = set()
source_dest_file_date_dict = dict()

def parse_file_name_date(file_name):

    logger = getLogger()

    logger.debug('prepSourceFiles -- parse_file_name_date {0}'.format(file_name))
    '''Try regexes until we get one that returns the date.'''
    idx = 0
    requestorId = ''
    base_name = os.path.splitext(os.path.basename(file_name))[0]
    # print(base_name)
    # abs_base_name = '.'.join(base_name.split('.')[:-1]) if '.' in base_name else base_name
    try:    
        for regex in all_regexes:
            match = regex.search(file_name)
            if(match):
                diction = match.groupdict()
                if 'requestorId' in diction.keys():
                    requestorId = diction['requestorId']
                    source_file_date = match.group()[10:]
                else:
                    source_file_date = match.group()[1:]

                day = match.group('day')
                month = match.group('month')
                year = match.group('year')

                file_date = '{0:04d}{1:02d}{2:02d}'.format(int(year), int(month), int(day))
                if idx == 0:
                    dateStr = requestorId if requestorId != '' else '{0}{1}{2}'.format(year, month, day)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, requestorId, file_date)
                if idx == 1:
                    dateStr = requestorId if requestorId != '' else '{0}.{1}.{2}'.format(month, day, year)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, requestorId, file_date)
                if idx == 2:
                    dateStr = requestorId if requestorId != '' else '{0}-{1}-{2}'.format(month, day, year)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, requestorId, file_date)
                if idx == 3:
                    dateStr = requestorId if requestorId != '' else '{0}{1}{2}'.format(year, month, day)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, requestorId, file_date)
                if idx == 4:
                    dateStr = requestorId if requestorId != '' else '{0}.{1}.{2}'.format(month, day, year)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, requestorId, file_date)
                if idx == 5:
                    dateStr = requestorId if requestorId != '' else '{0}-{1}-{2}'.format(month, day, year)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, requestorId, file_date)
                '''if idx == 0:
                    dateStr = '{0}.{1}.{2}'.format(month, day, year)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, file_date)
                if idx == 1:
                    dateStr = '{0}-{1}-{2}'.format(month, day, year)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, file_date)
                if idx == 2:
                    timestamp = match.group('timestamp')
                    dateStr = '{0}_{1}{2}{3}'.format(timestamp, year, month, day)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, file_date)
                if idx == 3:
                    dateStr = '{0}{1}{2}'.format(year, month, day)
                    return(base_name[0:base_name.index(dateStr) - 1], source_file_date, file_date)'''

            idx += 1
    except Exception:  
        return ('', 0, '', 0)
    # Nothing matched.
    return ('', 0, '', 0)
    
def get_filesListByExtn(source_dir, prefix, extnList):
    print("get_filesListByExtn")

    logger = getLogger()
    global file_dates, source_dest_file_date_dict
    requestorId = ''
    print('get_filesListByExtn : source_dir::{0}'.format(source_dir))
    file_set_dict = dict()
    logger.debug('Source Dir {0}'.format(source_dir))
    for extn in extnList:
        glob_pattern = os.path.join(source_dir, prefix + "*." + extn)
        print('get_filesListByExtn : glob_pattern::{0}'.format(glob_pattern))
        logger.debug('Glob Pattern {0}'.format(glob_pattern))
        
        for file_name in glob.glob(glob_pattern):
            # print(file_name)
            (abs_base_name, source_file_date, requestorId, file_date) = parse_file_name_date(file_name)
            if(file_date == 0):
                continue
            print('get_filesListByExtn : file_date::{0}'.format(file_date))
            print('get_filesListByExtn : file_name::{0}'.format(glob_pattern))
            logger.debug('names are {0}, {1}, {2}'.format(abs_base_name, file_date,requestorId))
            # Not working in latest code
            #if buildYearMonthFlag == True:
            #    file_date = file_date[0:6]
            source_dest_file_date_dict[file_date] = source_file_date
            file_dates.add(file_date)
            if file_date in file_set_dict:
                file_set_dict[file_date].append(abs_base_name)
            else:
                file_set_dict[file_date] = []
                file_set_dict[file_date].append(abs_base_name)
    return file_set_dict, requestorId

def check_and_create(dir_name):
    logger = getLogger()
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)

def postProcess(logger, commonSourceFiles,run_date_time):
    logger.debug(' Inside PostProcess')
    
    commonSourceFiles.postProcessStartTime = datetime.datetime.now()
    logging_into_db.process(commonSourceFiles,run_date_time)
    working_date_folder = commonSourceFiles.working_dir + "\\" + commonSourceFiles.file_date
    logger.debug('In PostProcess working Date folder : {0}'.format(working_date_folder))

    inbound_dir = parseYamlProperty.get_inbound_dir(commonSourceFiles.source)
    processing_dir = parseYamlProperty.get_processing_dir(commonSourceFiles.source)
    archive_date_dir = commonSourceFiles.archive_dir + "\\" + commonSourceFiles.file_date

    check_and_create(archive_date_dir)
    if commonSourceFiles.status == False:
        files = os.listdir(working_date_folder)
        logger.debug('Going to move files back to {0}'.format(commonSourceFiles.source_dir))
        for file in files:
            #shutil.move(working_date_folder + "\\" + file, commonSourceFiles.source_dir)
            shutil.move(os.path.join(working_date_folder, file), os.path.join(commonSourceFiles.source_dir, file))
    else:
        if compressFiles(logger, commonSourceFiles) == 0:
            logger.debug('All compress files action is success')
            logger.debug(commonSourceFiles.base_dir)
            logger.debug(commonSourceFiles.working_dir)
            
            for files in os.listdir(working_date_folder):
                fileNameWithoutExtension = os.path.splitext(files)[0]
                fileInSourceFolder = working_date_folder + "\\" + fileNameWithoutExtension + ".*"
                for f in glob.glob(fileInSourceFolder):
                    os.remove(f)
                    logger.debug (f)

        if commonSourceFiles.move_unused_files:
            logger.debug('Switch source and destination folders for unsued archival from processing to inbound when they are not same')
            if(inbound_dir != processing_dir) :
                source_dir_to_clean_unused = commonSourceInfo.getInboundFolder(commonSourceFiles.source, commonSourceFiles.frequency)
                archive_date_dir = commonSourceFiles.archive_dir + '\\' + commonSourceFiles.file_date
            else:
                source_dir_to_clean_unused = commonSourceFiles.source_dir
            logger.debug('archive unsued files')
            if file_utils.compressFolderPatternwith7z(archive_date_dir + "\\" + commonSourceFiles.source + "_" + commonSourceFiles.frequency + "_" + commonSourceFiles.file_date + "_unused", source_dir_to_clean_unused, commonSourceFiles.file_date) == 0:
                unUsedFiles = source_dir_to_clean_unused + "\\" + "*" + commonSourceFiles.file_date + "*"
                for unUsedFile in glob.glob(unUsedFiles):
                    os.remove(unUsedFile)
                    logger.debug(unUsedFile)
        file_utils.removeFiles(working_date_folder)

    commonSourceFiles.postProcessEndTime = datetime.datetime.now()
    logger.debug(' Exiting PostProcess')
    logging_into_db.process(commonSourceFiles,run_date_time)
'''
    compressFolder functions is to compress the whole folder
    from automation we compress the files from working_date_directory to archived file
    all files from <source>/<frequency>/working/<date> will be compressed into <source>/<frequency>/archived/<source_frequency_date.gz>
    ''' 
def compressFiles(logger, commonSourceFiles):
    logger.debug("compressFiles")
    working_date_folder = commonSourceFiles.working_dir  + '\\' + commonSourceFiles.file_date
    processing_dir = commonSourceInfo.getProcessingFolder(commonSourceFiles.source, commonSourceFiles.frequency)
    archive_inbound_date_dir = commonSourceFiles.archive_dir + '\\' + commonSourceFiles.file_date
    inbound_dir = commonSourceInfo.getInboundFolder(commonSourceFiles.source, commonSourceFiles.frequency)
    check_and_create(archive_inbound_date_dir)
    compressValue = 0
    try:

        compressedFormats = parseYamlProperty.get_list_of_gz_file_extn(commonSourceFiles.source)
        for work_file in os.listdir(working_date_folder):
            compressed_workfile = [ele for ele in glob.glob(os.path.join(inbound_dir, work_file + '*')) if ele.split('.')[-1] in compressedFormats]
            if len(compressed_workfile) > 0:
                logger.debug('move compressed file if source directory has compressed file {0}'.format(work_file))
                sourceGzfile = os.path.join(inbound_dir, os.path.basename(compressed_workfile[0]))
                destGzfile = os.path.join(archive_inbound_date_dir, os.path.basename(compressed_workfile[0]))
                shutil.move(sourceGzfile, destGzfile )
            else:
                if(os.path.exists(os.path.join(inbound_dir, os.path.basename(work_file)))):
                    shutil.move(os.path.join(inbound_dir, os.path.basename(work_file)), os.path.join(archive_inbound_date_dir, os.path.basename(work_file)))
                else:
                    shutil.move(os.path.join(working_date_folder, os.path.basename(work_file)), os.path.join(archive_inbound_date_dir, os.path.basename(work_file)))



        for work_file in os.listdir(working_date_folder):
            compressed_workfile = [ele for ele in glob.glob(os.path.join(archive_inbound_date_dir, work_file + '*')) if ele.split('.')[-1] in compressedFormats]
            if len(compressed_workfile) > 0:
                logger.debug('delete working text if source directory has compressed file {0}'.format(work_file))
                os.remove(os.path.join(working_date_folder, os.path.basename(work_file)))
                if os.path.exists(os.path.join(inbound_dir, os.path.basename(work_file))) == True:
                    os.remove(os.path.join(inbound_dir, os.path.basename(work_file)))

        logger.debug('completed cleaning working directory and moved matching (used) compressed feeds to archive_date directory ')

        logger.debug('Going to call Utils Compress Folder')
        archivedAbsoulteFileName = archive_inbound_date_dir + "\\" + commonSourceFiles.source + "_" + commonSourceFiles.frequency + "_" + (commonSourceFiles.requestorId + "_" if commonSourceFiles.requestorId else '') + commonSourceFiles.file_date #+ ".gz"
        commonSourceFiles.archivedFileName = archivedAbsoulteFileName

        
        logger.debug('Going to pack used files for -- {0}'.format(archivedAbsoulteFileName))
        compressValue = file_utils.compressFolderPatternwith7z(archivedAbsoulteFileName , archive_inbound_date_dir)
        logger.debug('Completed - packing of used files for -- {0}'.format(archivedAbsoulteFileName))

        logger.debug('delete all files from working')
        if(inbound_dir != processing_dir):
            logger.debug('Clear the processing working date directory -- {0}'.format(processing_dir))
            for work_file in os.listdir(working_date_folder):
                os.remove(os.path.join(working_date_folder, work_file))
            logger.debug('Clear the Processing source directory')
            for processing_source_file in  glob.glob(processing_dir + '\\' + '*' +  commonSourceFiles.file_date + '*'):
                file_to_delete = os.path.join(processing_dir, processing_source_file)
                logger.debug('Removing processing source directory files - postprocess {0}'.format(file_to_delete))
                os.remove(file_to_delete)

            logger.debug('all processing directories are cleared')
    except Exception as ex:
        logger.debug('Error at postprocess pack -- {0}'.format(ex))

    logger.debug("Exiting compressFiles")
    return compressValue

'''
Group files by extension under three categories
'''
def fileListByExtension(logger, extn_list, source_dir):
    logger.debug('Inside function:: fileListByExtension')
    print("fileListByExtension")
    print('extn_list: {0}'.format(extn_list))
    
    logger.debug('Inside function:: fileListByExtension')
    logger.debug('What is the extension here {0}'.format(extn_list))
    dict_of_gz_files = {}
    dict_of_done_files = {}
    dict_of_txt_files = {}
    text_file_extn = {}
    list_of_text_file_extn = parseYamlProperty.get_list_of_text_file_extn()
    list_of_gz_file_extn = parseYamlProperty.get_list_of_gz_file_extn()
    list_of_done_file = parseYamlProperty.get_list_of_done_file()
    # for extn in extn_list:
    #     print(extn)
    #     print('fileListByExtension : source_dir::{0}'.format(source_dir))
    #     #print(sourceInfo)
    #     if extn.lower() in list_of_text_file_extn:

                # text_file_extn = extn.lower()
    # if extn.lower() in list_of_gz_file_extn :
    (dict_of_gz_files, requestorId) = get_filesListByExtn(source_dir, '', list_of_gz_file_extn)
            # dict_of_gz_files.update(dict_of_gz_files)
        # if extn.lower() == list_of_done_file:
    (dict_of_done_files, requestorId) = get_filesListByExtn(source_dir, '', list_of_done_file)
    
    fileList, requestorId = get_filesListByExtn(source_dir, '', list_of_text_file_extn)
    dict_of_txt_files.update(fileList)    
    logger.debug('fileListByExtension :dict_of_gz_files {0}'.format(dict_of_gz_files))
    logger.debug('fileListByExtension :dict_of_done_files {0}'.format(dict_of_done_files))
    logger.debug('fileListByExtension :dict_of_txt_files {0}'.format(dict_of_txt_files))
    logger.debug('Exit function:: sortFiles')
    return dict_of_gz_files, dict_of_done_files, dict_of_txt_files, text_file_extn, requestorId

# def matchDates(sorted_file_date, g_in_filedate):
#     g_in_filedate_str = g_in_filedate.strftime("%Y%m%d")
#     return [ele for ele in sorted_file_date if(ele in g_in_filedate_str)]

def sortFiles(logger, sourceInfo, g_in_filedate, extn_list):
    logger.debug('Inside function:: sortFiles')
    source_dir = commonSourceInfo.getProcessingFolder(sourceInfo.source, sourceInfo.frequency)
    print('source_dir {0}'.format(source_dir))
    (dict_of_gz_files, dict_of_done_files, dict_of_txt_files, text_file_extn, requestorId) = fileListByExtension(logger, extn_list, source_dir)
    commonSourceFilesListAppend =[]
    print('File Dates {0}'.format(file_dates))
    # if g_in_filedate != '':
    #     sorted_file_dates = [g_in_filedate]
    # else:
    #     
    sorted_file_dates = sorted(file_dates, key=int)
    if g_in_filedate != '':
        #working_sorted_file_dates = sorted_file_dates # filter to have only in_file_date if there is a match
        working_sorted_file_dates = [ele for ele in sorted_file_dates if(ele == g_in_filedate)]
    else:
        working_sorted_file_dates = sorted_file_dates
    
    logger.debug('Sorted File Dates {0}'.format(working_sorted_file_dates))
    if g_in_filedate != '' and len(working_sorted_file_dates) == 0:
        if g_in_filedate not in working_sorted_file_dates:
            sys.tracebacklimit = -1
            raise Exception('Passed parameter -dt {0} files are not present in the file location'.format(g_in_filedate))
            logger.debug('Passed parameter -dt {0} files are not present in the file location'.format(g_in_filedate))

    print('Sorted File Dates before for{0}'.format(working_sorted_file_dates))
     ##Review  
    for file_date in working_sorted_file_dates:
        logger.debug('What is the filedate {0}'.format(file_date))
        print("This is commonSourceFiles{0}".format(commonSourceFiles))
        #ps = commonSourceFiles(source, frequency, processtype)
        ps = commonSourceFiles(sourceInfo.source, sourceInfo.frequency, sourceInfo.processtype)
        ps.file_date = file_date
        #ps.build_month = g_build_month
        '''**Year month implementation: Not being used'''
        #if buildYearMonthFlag == True:
        #    ps.file_date = fido_utils.today
        #else:
        ps.file_date = file_date
        ps.source_file_date = source_dest_file_date_dict[file_date]
        ps.working_dir = working_dir
        ps.archive_dir = archive_dir
        ps.source_dir = source_dir
        ps.requestorId = requestorId
        ps.list_of_gz_files = dict_of_gz_files.get(file_date)
        ps.list_of_text_files = dict_of_txt_files.get(file_date)
        ps.list_of_done_files = dict_of_done_files.get(file_date)
        ps.list_of_expected_files = list_of_expected_files
        ps.list_of_optional_files = list_of_optional_files
        ps.text_file_extn = text_file_extn
        ps.move_unused_files = parseYamlProperty.get_move_used_files_flag(sourceInfo.source, sourceInfo.frequency)
        commonSourceFilesListAppend.append(ps)

    logger.debug('sortFiles :commonSourceFilesListAppend {0}'.format(commonSourceFilesListAppend))
    # if g_in_filedate != '':
    #     commonSourceFilesListFiltered = list(filter(lambda x: (x.source_file_date == g_in_filedate), commonSourceFilesListAppend)) 
    #     #[x in commonSourceFilesListAppend.tolist() if x.source_file_date == g_in_filedate]
    # else:
    #     commonSourceFilesListFiltered = commonSourceFilesListAppend
    logger.debug('Exit function:: sortFiles')
    return commonSourceFilesListAppend

def populateListofDoneFiles(logger, processEachFrequency):
    print("populateListofDoneFiles")
    logger.debug('Inside function:: populateListofDoneFiles')
    if processEachFrequency.list_of_done_files is not None and not processEachFrequency.list_of_done_files:
            foundDoneButNoMatchingFile = list(set(processEachFrequency.list_of_done_files).difference(set(processEachFrequency.list_of_gz_files)))
            processEachFrequency.list_of_missing_files.append(foundDoneButNoMatchingFile)
    logger.debug('populateListofDoneFiles :processEachFrequency {0}'.format(processEachFrequency))
    logger.debug('Exit function:: populateListofDoneFiles')
    #return processEachFrequency

def populateListofMissingFiles(logger, processEachFrequency):
    print("populateListofMissingFiles")
    logger.debug('Inside function:: populateListofMissingFiles')
    if processEachFrequency.list_of_done_files is not None and not processEachFrequency.list_of_missing_files:
            foundDoneFileButMissingMainFile = list(set(processEachFrequency.list_of_missing_files).intersection(set(processEachFrequency.list_of_expected_files)))
            if foundDoneFileButMissingMainFile:
                # print ('Done present for an expected File, but expected file missing {} '.format(foundDoneFileButMissingMainFile))
                processEachFrequency.preProcessEndTime = datetime.datetime.now()
                #break
                return 
    logger.debug('populateListofMissingFiles :processEachFrequency {0}'.format(processEachFrequency))
    logger.debug('Exit function:: populateListofMissingFiles')
    #return processEachFrequency
                

def populateListofCompressedFiles(logger, processEachFrequency, extn_list):
    print("populateListofCompressedFiles")
    logger.debug('Inside function:: populateListofCompressedFiles')
    working_date_dir = working_dir + "\\" + processEachFrequency.file_date
    archive_date_dir = archive_dir + "\\" + processEachFrequency.file_date
    check_and_create(working_date_dir)
    check_and_create(archive_date_dir)
    if processEachFrequency.list_of_gz_files:
            for gzfile in processEachFrequency.list_of_gz_files:
                # print(processEachFrequency.base_dir)
                gzfileName = ''
                for extn in extn_list:
                    gzfileName = processEachFrequency.source_dir + "\\" + gzfile + '_' + processEachFrequency.source_file_date + '.txt.' + extn
                    gzArchiveFileName = archive_date_dir + "\\" + gzfile + '_' + processEachFrequency.file_date + '.txt.' + extn
                    if os.path.isfile(gzfileName):
                        break
                if gzfileName == '':
                    sys.tracebacklimit = -1
                    raise Exception ("Compressed File {0}, {1} doesn't exist in either extension".format(extn_list, gzfile))

                gzDestFileName = working_date_dir + "\\" + gzfile + '_' + processEachFrequency.file_date + '.txt'
                gzDestFileName_in_src_dir = processEachFrequency.source_dir + "\\" + gzfile + '_' + processEachFrequency.file_date + '.txt'

                # print (gzfileName)
                # check if the GZ file is found in either Expected Files or Optional File before uncompressing.
                if (gzfile.lower() in map(str.lower, processEachFrequency.list_of_expected_files)) or (gzfile.lower() in map(str.lower, processEachFrequency.list_of_optional_files)):
                    ## **Logger as null, check later
                    # file_utils.decompressToFolder(gzfileName, working_date_dir, gzDestFileName, logger)
                    if os.path.exists(gzDestFileName_in_src_dir) and os.path.getsize(gzDestFileName_in_src_dir) > 0 :
                        logger.debug('Source directory has file uncompressed already - No decompress action for file - {0}'.format(gzfileName))
                        shutil.move(gzDestFileName_in_src_dir, gzDestFileName)
                        processEachFrequency.list_of_working_files.append(gzfile)
                    else:
                        logger.debug('Uncompress only expected or optional {0}'.format(gzfile))
                        logger.debug('Started -- gzFileName {0} - Working Date {1} - Dest FileName {2}'.format(gzfile, working_date_dir, gzDestFileName))
                        returncode = file_utils.decompressToFolder(gzfileName, working_date_dir, gzDestFileName, gzArchiveFileName, logger)
                        if(returncode == 0):
                            processEachFrequency.list_of_working_files.append(gzfile)
                        logger.debug('Completed -- gzFileName {0} - Working Date {1} - Dest FileName {2}'.format(gzfile, working_date_dir, gzDestFileName))
                        logger.debug('Exit function:: populateListofCompressedFiles')
    #return processEachFrequency

def populateListofTextFiles(logger, processEachFrequency):
    print("populateListofTextFiles")
    logger.debug('Inside function:: populateListofTextFiles')
    working_date_dir = working_dir + "\\" + processEachFrequency.file_date
    check_and_create(working_date_dir)

    if processEachFrequency.list_of_text_files:
            allTxtFiles = os.listdir(processEachFrequency.source_dir)
            textFileName = ''
            for textFile in processEachFrequency.list_of_text_files:
                list_of_text_file_extn = parseYamlProperty.get_list_of_text_file_extn()
                for extn in list_of_text_file_extn:
                    textFileName = processEachFrequency.source_dir + "\\" + textFile + '_' + (processEachFrequency.requestorId + "_" if processEachFrequency.requestorId else '') + processEachFrequency.file_date + '.' + extn
                    working_filename = working_date_dir + "\\" + textFile + '_' + (processEachFrequency.requestorId + "_" if processEachFrequency.requestorId else '') + processEachFrequency.file_date + '.' + extn

                    logger.debug('TextFile ...{0}'.format(textFileName))
                    # print('Found in Expected ? {0}:'.format(textFileName.upper() in processEachFrequency.list_of_expected_files))
                    # print('Found in Optional ? {0}:'.format(textFileName.upper() in processEachFrequency.list_of_optional_files))
                    if os.path.exists(textFileName) == True :
                        if (textFile.lower() in map(str.lower, processEachFrequency.list_of_expected_files)) or (textFile.lower() in map(str.lower, processEachFrequency.list_of_optional_files)):
                            if(parseYamlProperty.get_notify_source_on_file_missing(processEachFrequency.source) == False or fido_utils.is_feed_file_non_empty(textFileName)):
                                processEachFrequency.list_of_working_files.append(textFile)
                                if(os.path.exists(os.path.join(working_date_dir, os.path.basename(textFileName))) == False):
                                    # file_utils.safeMoveFiles(working_date_dir, textFileName)
                                    # changed to copy the file to working dir than moving
                                    shutil.copy(textFileName, working_filename)
    logger.debug('populateListofTextFiles :processEachFrequency {0}'.format(processEachFrequency))
    logger.debug('Exit function:: populateListofTextFiles')
    #return processEachFrequency

def getlistOfExpectedButMissingFiles(processEachFrequency):
    s1 = (set(map(str.lower, processEachFrequency.list_of_expected_files)))
    s2 = (set(map(str.lower, processEachFrequency.list_of_working_files)))
    return list(s1.difference(s2))

def processListOfMissingFiles(logger, sourceInfo, processEachFrequency):
    print("processListOfMissingFiles")
    skipFindAllRequiredFiles = commonArgs.getSkipFindAllRequiredFlag() 
    print("skipFindAllRequiredFiles{0} ".format(skipFindAllRequiredFiles))
    logger.debug('Inside function:: processListOfMissingFiles')
    s1 = (set(map(str.lower, processEachFrequency.list_of_expected_files)))
    s2 = (set(map(str.lower, processEachFrequency.list_of_working_files)))
    s3 = (set(map(str.lower, processEachFrequency.list_of_optional_files)))
    
    ### these below files are used only once, hence removing its global scope, moving them from process() to here.
    # global list_of_pull_expected_files, list_of_push_expected_files, list_of_pull_optional_files, list_of_push_optional_files
    list_of_pull_expected_files = commonSourceInfo.getPullRequiredFeedFiles(processEachFrequency.source, processEachFrequency.frequency)
    list_of_push_expected_files = commonSourceInfo.getPushRequiredFeedFiles(processEachFrequency.source, processEachFrequency.frequency)
    list_of_pull_optional_files = commonSourceInfo.getPullOptionalFeedFiles(processEachFrequency.source, processEachFrequency.frequency)
    list_of_push_optional_files = commonSourceInfo.getPushOptionalFeedFiles(processEachFrequency.source, processEachFrequency.frequency)

    listOfExpectedButMissingFiles = getlistOfExpectedButMissingFiles(processEachFrequency)
    logger.debug(listOfExpectedButMissingFiles)
    print("listOfExpectedButMissingFiles:{0}".format(listOfExpectedButMissingFiles))
    for i, inFName in enumerate(listOfExpectedButMissingFiles):
        print(i)
        print(inFName)
        print('list_of_pull_expected_files : {0}'.format(list_of_pull_expected_files))
        print('list_of_push_expected_files : {0}'.format(list_of_push_expected_files))
        for expectedFile in list_of_pull_expected_files:
            if expectedFile.fidoname.upper() == inFName.upper():
                listOfExpectedButMissingFiles[i] = inFName + ',pull'
                break
        for expectedFile in list_of_push_expected_files:
            if expectedFile.fidoname.upper() == inFName.upper():
                listOfExpectedButMissingFiles[i] = inFName + ',push'
                break
        print('Modified {0}'.format(listOfExpectedButMissingFiles[i]))
        
    print(listOfExpectedButMissingFiles)

    if listOfExpectedButMissingFiles and skipFindAllRequiredFiles == False:
        processEachFrequency.status = False
        processEachFrequency.list_of_expected_but_missing_files = listOfExpectedButMissingFiles
    elif skipFindAllRequiredFiles:
        processEachFrequency.status = True
        
    listOfOptionalButMissingFiles = list(s3.difference(s2))

    logger.debug(listOfOptionalButMissingFiles)

    for i, inFName in enumerate(listOfOptionalButMissingFiles):
        print(i)
        print(inFName)
        for optionalFile in list_of_pull_optional_files:
            if optionalFile.fidoname.upper() == inFName.upper():
                listOfOptionalButMissingFiles[i] = inFName + ',pull'
                break
        for optionalFile in list_of_push_optional_files:
            if optionalFile.fidoname.upper() == inFName.upper():
                listOfOptionalButMissingFiles[i] = inFName + ',push'
                break
        print('Modified {0}'.format(listOfOptionalButMissingFiles[i]))

    if (listOfOptionalButMissingFiles):
        # print('OptionalFilesMissing List : {}'.format(listOfOptionalButMissingFiles))
        processEachFrequency.list_of_optional_but_missing_files = listOfOptionalButMissingFiles
        # processEachFrequency.msg += "\nOptional Files are Missing\n" + '\n'.join(map(str, listOfOptionalButMissingFiles))

    listOfExpectedAndOptionalFiles = processEachFrequency.list_of_expected_files + processEachFrequency.list_of_optional_files
    s4 = set(map(str.lower, listOfExpectedAndOptionalFiles))
    listOfExtraFiles = list(s2.difference(s4))
    processEachFrequency.list_of_extra_files = listOfExtraFiles

    logger.debug('processListOfMissingFiles :processEachFrequency {0}'.format(processEachFrequency))
    logger.debug('Exit function:: processListOfMissingFiles')
    return processEachFrequency

def waitForFile(logger, filename, sourceInfo, processEachFrequency, extn_list, end_time=0):
    logger.debug('Inside function :: waitForFile')
    wait_cycle = 30
    EmailAfterMinutes=0 
    EmailAttempt=0

    duration = int(sourceInfo.waitforminutes)
    wait_cycle = int(sourceInfo.WaitCycleSeconds) 
    EmailAfterMinutes = int(sourceInfo.EmailAfterMinutes)
    EmailAttempt = int(sourceInfo.EmailAttempt)
    
    start_time = datetime.datetime.now()
    print(start_time)
    if (end_time == 0):
        end_time = start_time + datetime.timedelta(minutes = duration)
    print(end_time)

    file_found = False
    wait_cycles_completed = 0
    counter = 0
    ct = 0
    final_time = EmailAfterMinutes*EmailAttempt
    file_to_find = ''
    while not file_found and datetime.datetime.now() < end_time:
        print('Waited for {0} seconds .. lookin for {1}'.format(wait_cycles_completed * wait_cycle, filename))
        logger.debug('Waited for {0} seconds .. lookin for {1}'.format(wait_cycles_completed * wait_cycle, filename))
        if(filename != '_getRequiredFiles'):
            #file_found, file_to_find = fido_utils.checkFiles(processEachFrequency.source_dir, filename, processEachFrequency.file_date) 
            #directory = Path(processEachFrequency.source_dir)
            directory = Path(source_dir)
            file_to_find = directory / filename
            file_found = file_to_find.exists() 
        else:
            list_of_expected_but_missing_files = getlistOfExpectedButMissingFiles(processEachFrequency)
            if list_of_expected_but_missing_files:
                file_found = False
                file_to_find = ','.join([str(elem) for elem in list_of_expected_but_missing_files])
            else:
                file_found = True

            #file_to_find = getlistOfExpectedButMissingFiles(processEachFrequency)
        timestring = fido_utils.elapsedTime(datetime.datetime.now(),start_time)
        print(timestring)
        
        pt = time.strptime(timestring,'%H:%M:%S')
        total_minutes = pt.tm_sec//60 + pt.tm_min + pt.tm_hour*60
        print (datetime.datetime.now())
        print("Elaspsed time in minutes: total_minutes {0}".format(total_minutes))
        logger.debug("Elaspsed time in minutes: total_minutes {0}".format(total_minutes))
        timeResetCounter = total_minutes - counter
        print("Time counter that restarts after every iteration of EmailAfterMinutes {0}".format(timeResetCounter))
        print("File to find are :: {0}".format(file_to_find))
        logger.debug("Time counter that restarts after every iteration of EmailAfterMinutes {0}".format(timeResetCounter))
        logger.debug("File to find are :: {0}".format(file_to_find))
        if(file_found):
            print('Found the file...')
            break
        elif (total_minutes >= final_time and EmailAfterMinutes!=0):
            print("EXIT: No files found")
            fido_utils.sendEmailNotification("Error", file_to_find.replace(',','\n'), sourceInfo)
            break
        elif (timeResetCounter >= EmailAfterMinutes and EmailAfterMinutes!=0):
            print("Send Email and check again")
            fido_utils.sendEmailNotification("Warning", file_to_find.replace(',','\n'), sourceInfo)
            timeResetCounter = 0
            ct = ct + 1
            counter = ct * EmailAfterMinutes
            #time.sleep(wait_cycle)
            #wait_cycles_completed += 1    
        
        time.sleep(wait_cycle)
        wait_cycles_completed += 1
        if(filename == '_getRequiredFiles'):
            populateInputFiles(logger, processEachFrequency, extn_list)

    if file_found == False and filename != '_getRequiredFiles':
        sys.tracebacklimit = -1
        raise ValueError('Looking for {0} -- Found - {1} -- waited for {2}'.format(file_to_find, file_found, wait_cycles_completed * wait_cycle))
    
    print('Looking for {0} -- Found - {1} -- waited for {2}'.format(file_to_find, file_found, wait_cycles_completed * wait_cycle))
    logger.debug ('Exit function: waitFor')
    return file_to_find, file_found, wait_cycles_completed * wait_cycle

def populateInputFiles(logger, processEachFrequency, extn_list):
    (dict_of_gz_files, dict_of_done_files, dict_of_txt_files, text_file_extn, requestorId) = fileListByExtension(logger, extn_list, processEachFrequency.source_dir)
    processEachFrequency.list_of_gz_files = dict_of_gz_files.get(processEachFrequency.file_date)
    processEachFrequency.list_of_text_files = dict_of_txt_files.get(processEachFrequency.file_date)
    processEachFrequency.list_of_done_files = dict_of_done_files.get(processEachFrequency.file_date)
    populateListofCompressedFiles(logger, processEachFrequency, extn_list)
    populateListofTextFiles(logger, processEachFrequency)
    return 

def preprocess_filecopy(sourceInfo):
    inbound_dir_path = commonSourceInfo.getInboundFolder(sourceInfo.source, sourceInfo.frequency)
    processing_dir_path = commonSourceInfo.getProcessingFolder(sourceInfo.source, sourceInfo.frequency)
    check_and_create(processing_dir_path)
    filesToCopy = [ele for ele in glob.glob(inbound_dir_path + '\\*') if(os.path.isfile(ele))]
    if commonArgs.getFiledate() != '':
        filesToCopy = [ele for ele in glob.glob(inbound_dir_path + '\\*' + commonArgs.getFiledate() + '*')  if(os.path.isfile(ele))]

    if(inbound_dir_path != processing_dir_path):
        files = [ f for f in filesToCopy if os.path.isfile(os.path.join(inbound_dir_path,f))]
        for f in files:
            shutil.copy(os.path.join(inbound_dir_path, os.path.basename(f)), os.path.join(processing_dir_path, os.path.basename(f)))
            print('file copied -- {0}'.format(f))
    return

def does_file_exist_in_dir(path):
    return any(isfile(join(path, i)) for i in listdir(path))

def process(sourceInfo):
    print('process')
    

    logger = getLogger()
    print('calling preprocess')
    preprocess_filecopy(sourceInfo)
    print('preprocess is completed')
    #global source_name, frequency_name, buildYearMonthFlag
    #Pass logger to all functions : check later
    processStartTime = datetime.datetime.now()
    run_date_time = datetime.datetime.now()
    filedate = commonArgs.getFiledate()
    in_filedate = ''
    in_filedate = filedate

    #g_in_filedate = in_filedate
    #g_build_month = build_month
    #buildYearMonthFlag = parseYamlProperty.get_buildByYearMonth_flag(source, frequency)
    preProcessStartTime = processStartTime
    global source_dir
    source_dir = commonSourceInfo.getProcessingFolder(sourceInfo.source, sourceInfo.frequency)

    

    #if adhocfolder != '':
    #    source_dir = source_dir + "\\" + adhocfolder

    global working_dir, archive_dir, commonSourceFilesList, list_of_working_files, list_of_expected_files, list_of_optional_files, text_file_extn   
    working_dir = source_dir + "\\working"
    archive_dir = commonSourceInfo.getArchiveFolder(sourceInfo.source, sourceInfo.frequency)
    commonSourceFilesList = [] 
    dict_of_gz__files = {}
    list_of_working_files = []
    list_of_expected_files = []
    list_of_optional_files = []
    text_file_extn = ""
    check_and_create(working_dir)
    check_and_create(archive_dir)
    
    
    #pushRequiredFiles = commonSourceInfo.getPushRequiredFiles(sourceInfo.source, sourceInfo.frequency, sourceInfo.file_date)

    #logger.debug('###Done files found : {}'.format(dict_of_done_files))


    #move files from source to destination
    ### commenting this below line as allfiles is unused in this file
    # allFiles = list_of_pull_expected_files + list_of_push_expected_files + list_of_pull_optional_files + list_of_push_optional_files

    list_of_expected_files = commonSourceInfo.getRequiredFiles(sourceInfo.source, sourceInfo.frequency)
    print ("list_of_expected_files : {0}".format(list_of_expected_files))
    list_of_optional_files = commonSourceInfo.getOptionalFiles(sourceInfo.source, sourceInfo.frequency)
    extn_list = list(set(commonSourceInfo.getFidoExtns(sourceInfo.source, sourceInfo.frequency)))
    processEachFrequency = ''
    #Wait For MBSi monthly
    if(sourceInfo.waitforfile != '' ):  
        duration = int(sourceInfo.waitforminutes)
        end_time = datetime.datetime.now() + datetime.timedelta(minutes = duration) 
        _waitforfile = sourceInfo.waitforfile    
        if sourceInfo.waitforfile == '_getRequiredFiles':   
            while(not does_file_exist_in_dir(source_dir) and datetime.datetime.now() < end_time):
                wait_cycle = int(sourceInfo.WaitCycleSeconds)
                time.sleep(wait_cycle)
                logger.debug('Folder is empty')
                print("Inside wait")
                #wait_cycles_completed += 1

            if(datetime.datetime.now() > end_time):
                fido_utils.sendEmailNotification("Error", 'No files found', sourceInfo)


        if sourceInfo.waitforfile != '_getRequiredFiles':
            _waitforfile = ''
            #(dict_of_gz_files, dict_of_done_files, dict_of_txt_files, text_file_extn, requestorId) = fileListByExtension(logger, extn_list, source_dir)
            if(filedate == ''):
                filedate = fido_utils.today
                
            pattern = re.compile('[$]today', re.IGNORECASE)
            _waitforfile = pattern.sub(filedate, sourceInfo.waitforfile)
            logger.debug('Waiting for file : {0}'.format(_waitforfile))
            waitForFile(logger, _waitforfile, sourceInfo, None, extn_list, end_time)
            #Function is called only to gather unique file dates present in inbound folder
            fileListByExtension(logger, extn_list, source_dir)
            sorted_file_dates = sorted(file_dates, key=int)
            if((not commonArgs.getSkipOldDates()) and sorted_file_dates):
                for fdate in sorted_file_dates:
                    _waitforfile = pattern.sub(fdate, sourceInfo.waitforfile)
                    logger.debug('Waiting for file : {0}'.format(_waitforfile))
                    waitForFile(logger, _waitforfile, sourceInfo, None, extn_list, end_time)

        

    commonSourceFilesList = sortFiles(logger, sourceInfo, in_filedate, extn_list)
    sortedcommonSourceFilesList = sorted(commonSourceFilesList)

    if commonArgs.getSkipOldDates() == True and len(sortedcommonSourceFilesList) > 0:
        sortedcommonSourceFilesList = [sorted(sortedcommonSourceFilesList, reverse = True)[0]]
    print('sortedcommonSourceFilesList {0}'.format(sortedcommonSourceFilesList))
    resultcommonSourceFilesList = []
    for processEachFrequency in sortedcommonSourceFilesList:
        processEachFrequency.processStartTime = processStartTime
        processEachFrequency.preProcessStartTime = preProcessStartTime
        logging_into_db.process(processEachFrequency,run_date_time)
         
        logger.debug('File Date {0}'.format(processEachFrequency.file_date))
        logger.debug('List of Done files {0}'.format(processEachFrequency.list_of_done_files))
        
        populateListofDoneFiles(logger, processEachFrequency)
        #populateListofMissingFiles(logger, processEachFrequency)
        #populateListofCompressedFiles(logger, processEachFrequency, extn_list)
        #populateListofTextFiles(logger, processEachFrequency)
        populateInputFiles(logger, processEachFrequency, extn_list)

        logger.debug(processEachFrequency)
 
        #Wait For MBSi monthly
        if(sourceInfo.waitforfile != ''):
            _waitforfile = sourceInfo.waitforfile
            
            if _waitforfile == '_getRequiredFiles':
                if(getlistOfExpectedButMissingFiles(processEachFrequency)):
                    print("THIS IS THE PLACE!!!!!!!!!")
                    #waitForFile(source_dir, listOfExpectedButMissingFiles, sourceInfo, processEachFrequency.file_date)
                    waitForFile(logger, _waitforfile, sourceInfo, processEachFrequency, extn_list, end_time)
                

        processEachFrequency = processListOfMissingFiles(logger, sourceInfo, processEachFrequency)
        populateListofMissingFiles(logger, processEachFrequency)

        if not processEachFrequency.status:
            logger.debug('Status for {0} is False'.format(processEachFrequency.file_date))
            if commonArgs.getskipPostProcess() == True:
                print("Skipping Post Processing")
            else:
                postProcess(logger, processEachFrequency, run_date_time) 
            sys.tracebacklimit = None
            processEachFrequency.preProcessEndTime = datetime.datetime.now()
        
        resultcommonSourceFilesList.append(processEachFrequency)
        logger.debug(processEachFrequency)
        if not processEachFrequency.status:
            processEachFrequency.preProcessEndTime = datetime.datetime.now()
            break

        processEachFrequency.preProcessEndTime = datetime.datetime.now()  # Normal End Point - FOR LOOP
        logging_into_db.process(processEachFrequency,run_date_time) 

    
    logger.info('resultcommonSourceFilesList {0}\n'.format(resultcommonSourceFilesList))
    if not resultcommonSourceFilesList:
        _basePS = commonSourceFiles(sourceInfo.source, sourceInfo.frequency, sourceInfo.processtype)
        _basePS.status = False
        _basePS.msg = 'No files to Process'

        if not list_of_expected_files:
            if list_of_optional_files:
                _basePS.status = True
                _basePS.file_date = in_filedate
                _basePS.msg = ''
                _basePS.postProcessFlag = False

        _basePS.list_of_expected_files = list_of_expected_files
        _basePS.list_of_optional_files = list_of_optional_files
        _basePS.list_of_expected_but_missing_files = list_of_expected_files
        # _basePS.file_date = in_filedate
        _basePS.file_date = fido_utils.getToday() if in_filedate == '' else in_filedate   
        _basePS.processStartTime = preProcessStartTime
        resultcommonSourceFilesList.append(_basePS)
        logging_into_db.process(_basePS,run_date_time)    

    return sorted(resultcommonSourceFilesList)


if __name__ == "__main__":

    logger = getLogger()
    #process(commonSourceInfo.getFeedFiles('mbs', 'prefinal'), 'mbs', 'prefinal', 'inbound')
    process(None)