import xml
import json
from ssl import SSLWantReadError
import js2py
import http.client
from datetime import timezone
from datetime import datetime
import time
import pathlib
from xml.dom import minidom

crypto = js2py.require("crypto-js")

P_APIKeyId = ""
P_APIKey = ""
P_AuthId = ""
P_VerintSessionId = ""
P_VerintTimeZone = ""
P_BaseURL = "alawptelapp205.risk.regn.net"

def empty_for_none(val):
    if val == None:
        return ""
    else:
        return val 

def get_response( APIKeyId, APIKey, AuthId, VerintSessionId, VerintTimeZone, BaseURL, API_Full_Path, 
                    APIPath_part1, APIPath_part2, APIPath_dyanmic_value, APIPath_parameter, Timed_Out_Seconds):

    if API_Full_Path == "": 
        if APIPath_parameter == "":
            if APIPath_dyanmic_value != "":
                APIPath = APIPath_part1 + "/" + APIPath_dyanmic_value + APIPath_part2 
            else:
                APIPath = APIPath_part1 + APIPath_part2 
            APIPath_Sig_Gen = APIPath
        else:
            if APIPath_dyanmic_value != "":
                APIPath = APIPath_part1 + "/" + APIPath_dyanmic_value + APIPath_part2 + APIPath_parameter
                APIPath_Sig_Gen = APIPath_part1 + "/" + APIPath_dyanmic_value + APIPath_part2
            else:
                APIPath = APIPath_part1 +  APIPath_part2 + APIPath_parameter
                APIPath_Sig_Gen = APIPath_part1 + APIPath_part2
    else:
        APIPath = API_Full_Path
        APIPath_Sig_Gen = API_Full_Path

    iso_date = datetime.now(timezone.utc).isoformat("T","seconds")[0:19]+"Z"

    random = crypto.lib.WordArray.random(16)

    base64String = crypto.enc.Base64.stringify(random)

    urlConvertBase64_js = '''function urlConvertBase64(input) {
    var output = input.replace(/=+$/, '');
    output = output.replace(/\+/g, '-');
    output = output.replace(/\//g, '_');
    return output;
    }'''

    salt = js2py.eval_js(urlConvertBase64_js)(base64String)

    canonicalizedHeader = 'verint-session-id:'+VerintSessionId+ '\n' + 'verint-time-zone:'+VerintTimeZone.lower() + '\n'

    stringToSign = salt + '\n' + 'GET' + '\n'+ APIPath_Sig_Gen + '\n' + iso_date + '\n' + canonicalizedHeader +  '\n'

    debase64url_js = '''function debase64url (str) {
    return (str + '==='.slice((str.length + 3) % 4))
    .replace(/-/g, '+')
    .replace(/_/g, '/')
    }'''

    debase64url_api_key = js2py.eval_js(debase64url_js)(APIKey)

    hash = crypto.HmacSHA256(stringToSign, crypto.enc.Base64.parse(debase64url_api_key))
    
    signature = crypto.enc.Base64.stringify(hash)

    urlConvertBase64_signature = js2py.eval_js(urlConvertBase64_js)(signature)

    auth_header = AuthId+" salt="+salt+",iat="+iso_date+",kid="+APIKeyId+",sig="+urlConvertBase64_signature

    conn = http.client.HTTPSConnection(BaseURL,timeout=int(Timed_Out_Seconds))
    payload = ''
    headers = {
    'Authorization': auth_header,
    'Verint-Session-Id': VerintSessionId,
    'Verint-Time-Zone': VerintTimeZone,
    }
    conn.request("GET", APIPath, payload, headers)
    res = conn.getresponse()
    data = res.read()
    return data

def write_response(log_File_name,Target_file, APIKeyId, APIKey, AuthId, VerintSessionId, VerintTimeZone, BaseURL, 
                    API_Full_Path="", APIPath_part1="", APIPath_part2="", APIPath_parameter="",
                    Depenedent_File="", Dependent_column="", Dependent_Parent_Tag="", Timed_Out_Seconds="15",
                    Re_Hit_Cap="1",Sleep_Seconds="3"):
    with open(log_File_name, "a+") as log_File:
        log_File.write(str(datetime.now())+' : Started ' +API_Full_Path+APIPath_part1+APIPath_part2+APIPath_parameter+'\n')
    start_time = datetime.now()                
    dependent_file_type = pathlib.Path(Depenedent_File).suffix
    target_file_type = pathlib.Path(Target_file).suffix
    if Dependent_column != "":
        Depenedent_File_open = open(Depenedent_File)
        Target_File_open = open(Target_file,"ab")

        if dependent_file_type == '.json':
            dependent_data = json.load(Depenedent_File_open) 
            dependent_data = dependent_data[Dependent_Parent_Tag]
        elif dependent_file_type == '.xml':
            xml_file = minidom.parse(Depenedent_File)
            dependent_data = xml_file.getElementsByTagName(Dependent_Parent_Tag)

        timed_out_dep_values = []
        re_hit_cap_initial = 0
        while True:
            if re_hit_cap_initial == 0:
                x = 0 
                for rec in dependent_data:
                    try:
                        if dependent_file_type == '.json':
                            dependent_value = rec[Dependent_column]
                        elif dependent_file_type == '.xml':  
                            dependent_value = rec.attributes[Dependent_column].value

                        get_data = get_response( APIKeyId, APIKey, AuthId, VerintSessionId, VerintTimeZone, 
                                                BaseURL, API_Full_Path, APIPath_part1, APIPath_part2,
                                                dependent_value,APIPath_parameter,Timed_Out_Seconds)
                        if target_file_type == '.json':
                            Target_File_open.write(get_data)    
                        elif target_file_type == '.xml':  
                            parsed_xml = xml.dom.minidom.parseString(get_data)
                            pretty_xml = parsed_xml.toprettyxml()
                            Target_File_open.write(bytes(pretty_xml, encoding='utf-8'))
                        x = x+1
                        print(str(datetime.now())+" : "+str(dependent_value) +" : "+str(x))
                        print(str(datetime.now())+" : "+str(datetime.now()-start_time))
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : '+str(dependent_value) +" : "+str(x)+'\n')
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : '+str(datetime.now()-start_time)+'\n')
                    except TimeoutError:
                        print(str(datetime.now())+" : "+'Timed out needs to be handled for : '+dependent_value)
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : Timed out needs to be handled for : '+dependent_value+'\n')
                        timed_out_dep_values.append(dependent_value)
                    except SSLWantReadError:
                        print(str(datetime.now())+" : "+'SSL Want Read Error to be handled for : '+dependent_value)
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : SSL Want Read Error to be handled for : '+dependent_value+'\n')
                        timed_out_dep_values.append(dependent_value) 
                    except ConnectionResetError:
                        print(str(datetime.now())+" : "+'ConnectionResetError to be handled for : '+dependent_value)
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : ConnectionResetError to be handled for : '+dependent_value+'\n')
                        timed_out_dep_values.append(dependent_value) 
            if timed_out_dep_values != []:
                time.sleep(int(Sleep_Seconds))
                x = 0 
                for rec in timed_out_dep_values:
                    try:
                        get_data = get_response( APIKeyId, APIKey, AuthId, VerintSessionId, VerintTimeZone, 
                                                BaseURL, API_Full_Path, APIPath_part1, APIPath_part2,
                                                str(rec),APIPath_parameter,Timed_Out_Seconds)
                        if target_file_type == '.json':
                            Target_File_open.write(get_data)    
                        elif target_file_type == '.xml':  
                            parsed_xml = xml.dom.minidom.parseString(get_data)
                            pretty_xml = parsed_xml.toprettyxml()
                            Target_File_open.write(bytes(pretty_xml,encoding='utf-8'))
                        x = x+1
                        print(str(datetime.now())+" : "+str(rec) +" : "+str(x))
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+" : "+str(rec) +" : "+str(x)+'\n')
                        timed_out_dep_values.remove(rec)
                        print(str(datetime.now())+" : "+datetime.now()-start_time)
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+" : "+datetime.now()-start_time+'\n')
                    except TimeoutError:
                        print(str(datetime.now())+" : "+'Timed out needs to be handled for timed out dep value : '+str(rec))
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : Timed out needs to be handled for timed out dep value : '+str(rec)+'\n')
                    except SSLWantReadError:
                        print(str(datetime.now())+" : "+'SSL Want Read Error to be handled for : '+str(rec))
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : SSL Want Read Error to be handled for : '+str(rec)+'\n')
                    except ConnectionResetError:
                        print(str(datetime.now())+" : "+'ConnectionResetError to be handled for : '+str(rec))
                        with open(log_File_name, "a+") as log_File:
                            log_File.write(str(datetime.now())+' : ConnectionResetError to be handled for : '+str(rec)+'\n')    
            if timed_out_dep_values == [] or re_hit_cap_initial>=int(Re_Hit_Cap) :
                break
            re_hit_cap_initial = re_hit_cap_initial + 1
            print(str(datetime.now())+" : "+"re_hit_cap_initial : " +str(re_hit_cap_initial) +" | timed_out_dep_values : "+ str(timed_out_dep_values))
            with open(log_File_name, "a+") as log_File:
                log_File.write(str(datetime.now())+" : re_hit_cap_initial : " +str(re_hit_cap_initial) +" | timed_out_dep_values : "+ str(timed_out_dep_values)+'\n')
            print(str(datetime.now())+" : "+str(datetime.now()-start_time))
            with open(log_File_name, "a+") as log_File:
                log_File.write(str(datetime.now())+" : "+ str(datetime.now()-start_time)+'\n')
        if timed_out_dep_values != []:
            print(str(datetime.now())+" : "+"Unable to fetch data for following dependent values : " + str(timed_out_dep_values) + " for " +API_Full_Path+APIPath_part1+APIPath_part2+APIPath_parameter)
            with open(log_File_name, "a+") as log_File:
                log_File.write(str(datetime.now())+" : Unable to fetch data for following dependent values : " + str(timed_out_dep_values) + " for " +API_Full_Path+APIPath_part1+APIPath_part2+APIPath_parameter+'\n')
        Target_File_open.close()
        Depenedent_File_open.close()    
    else:
        timed_out_error_flag = 0
        for re_hit_cap_initial in range(0,int(Re_Hit_Cap)):
            try:
                get_data = get_response(APIKeyId, APIKey, AuthId, VerintSessionId, VerintTimeZone, 
                                        BaseURL, API_Full_Path, APIPath_part1, APIPath_part2,
                                        "",APIPath_parameter,Timed_Out_Seconds)
                
                                        
                with open(Target_file, "wb") as outfile:
                    if target_file_type == '.json':
                        outfile.write(get_data)    
                    elif target_file_type == '.xml':  
                        parsed_xml = xml.dom.minidom.parseString(get_data)
                        pretty_xml = parsed_xml.toprettyxml()
                        outfile.write(bytes(pretty_xml, encoding='utf-8'))                    
                timed_out_error_flag = 0
            except TimeoutError:
                timed_out_error_flag = 1
            except SSLWantReadError:
                timed_out_error_flag = 1
            except ConnectionResetError:
                timed_out_error_flag = 1                  
            if timed_out_error_flag == 0:
                break
            else:
                time.sleep(int(Sleep_Seconds))
        if timed_out_error_flag == 1:
            print(str(datetime.now())+" : "+"Unable to fetch data for : " +API_Full_Path+APIPath_part1+APIPath_part2+APIPath_parameter)
            with open(log_File_name, "a+") as log_File:
                log_File.write(str(datetime.now())+" : Unable to fetch data for : " +API_Full_Path+APIPath_part1+APIPath_part2+APIPath_parameter+'\n')


Properties_File = open('D:\\Automation\\python\\verint_pull\\properties\\verint_api.json')
Properties_Data = json.load(Properties_File)

log_File_name = "D:\\red\\data\\inbound\\verint\\applogs\\daily\\log_"+datetime.strptime(str(datetime.now())[0:19], "%Y-%m-%d %H:%M:%S").strftime("%Y%m%d%H%M%S")+".txt"

for rec in Properties_Data:

    Source_Content = empty_for_none(rec.get('Source_Content'))
    P_Target_File = empty_for_none(rec.get('Target_File'))
    P_API_Full_Path = empty_for_none(rec.get('API_Full_Path'))
    P_APIPath_Part1 = empty_for_none(rec.get('APIPath_Part1'))
    P_APIPath_Part2 = empty_for_none(rec.get('APIPath_Part2'))
    P_APIPath_parameter = empty_for_none(rec.get('APIPath_Parameter'))
    P_Dependent_File = empty_for_none(rec.get('Dependent_File'))
    P_Dependent_Column = empty_for_none(rec.get('Dependent_Column'))
    P_Dependent_Parent_Tag = empty_for_none(rec.get('Dependent_Parent_Tag'))    
    P_Timed_Out_Seconds = empty_for_none(rec.get('Timed_Out_Seconds'))
    P_Re_Hit_Cap = empty_for_none(rec.get('Re_Hit_Cap'))    
    P_Sleep_Seconds = empty_for_none(rec.get('Sleep_Seconds'))    
    
    with open(log_File_name, "a+") as log_File:
        log_File.write(str(datetime.now())+' : Started : '+Source_Content+'\n')
    

    write_response(log_File_name,P_Target_File, P_APIKeyId, P_APIKey, P_AuthId, P_VerintSessionId, P_VerintTimeZone, P_BaseURL, 
                                API_Full_Path = P_API_Full_Path, APIPath_part1 = P_APIPath_Part1, APIPath_part2 = P_APIPath_Part2, 
                                APIPath_parameter = P_APIPath_parameter, Depenedent_File = P_Dependent_File, Dependent_column = P_Dependent_Column,
                                Dependent_Parent_Tag = P_Dependent_Parent_Tag, Timed_Out_Seconds = P_Timed_Out_Seconds,
                                Re_Hit_Cap = P_Re_Hit_Cap, Sleep_Seconds = P_Sleep_Seconds)

    with open(log_File_name, "a+") as log_File:
        log_File.write(str(datetime.now())+' : Finished : '+Source_Content+'\n\n\n')
    print('Finished : '+Source_Content)

Properties_File.close()  
                