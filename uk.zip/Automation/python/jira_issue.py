from jira import JIRA
import json
import csv
from collections import defaultdict
from datetime import datetime, timedelta
import parseYamlProperty
import sys 
import os
import AutomationLogging
from vault.secrets import get_api_secret

sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir() ,'jira//issue_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
def main():

	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_issue', True)
	uname, pwd = get_api_secret(logger, 'jira')
	jira = JIRA(options, basic_auth=(uname, pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		print('working')
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   updated >= -5d and updated <= 1d order by updated ' , startidx, blocksize)
		#newissues=jira.search_issues('project !=EMPTY and  created >= "2019/01/01" AND created <= "2019/03/31" ' , startidx, blocksize)
		numissues=len(newissues)
		if  numissues==0 or  blocknum==200:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0	
	issuesfile=open(os.path.join(parseYamlProperty.get_inbound_dir() ,'jira//daily//issues_'+ datetime.now().strftime('%Y%m%d') + '.csv'),"w+", encoding='utf-8',newline="")
	#issuesfile=open('D:\\red\\data\\inbound\\jira\\daily\\issues_' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	issueswriter=csv.writer(issuesfile)
		
	for resultlist in issues:	
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
			fields=dict['fields']
			del dict['fields']
			fields['issue']=issueId
			if issue is not None:
				del fields['issue']

			print(issue.key)
			
			if issuecount==0:
						issueswriter.writerow(['key','issueId'])
			issueswriter.writerow([issue.key,issueId])	
				
			issuecount=issuecount+1
				
	issuesfile.close()
	#f.close()
if __name__== "__main__" :
     main()





