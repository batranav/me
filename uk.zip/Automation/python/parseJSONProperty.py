from collections import namedtuple
import json
import re, os
import fido_utils
import commonArgs
import parseYamlProperty as parse_props
import getProperties

# if(commonArgs.getSkipenv()):
#     json_file_name = os.path.join('D:\\red\\scripts', 'properties\\red.json')
# else:
#     json_file_name = os.path.join(os.environ.get('RED_automation_scripts', 'D:\\red\\scripts\\'), 'properties\\red.json')

json_file_name = getProperties.getJsonFilename()

Source = namedtuple('Source', ['source', 'frequency', 'IngestType', 'clustername', 'attribute', 'processtype', 'adhoc_despray', 'maxCsvRowSizeMb', 'whenparam', 'waitforfile', 'waitforminutes', 'WaitCycleSeconds', 'EmailAfterMinutes', 'EmailAttempt', 'erroremailto', 'successemailto', 'preProcess', 'runCheckAndPull','importparam','wu_priority', 'filedate', 'NotifyOnFailure', 'FailureAction', 'despray_path'])

sourceInfo = ''

def getSourceInfo(fido_source, fido_frequency, filedate):
    print('GetSourceInfo {0} {1}'.format(fido_source, fido_frequency))
    
    if filedate == '':
        filedate = fido_utils.today
    jsonRef = json.load(open(json_file_name))

    source = ''
    sourceMatched = ''
    for source in jsonRef:
        if source['Source'] == fido_source and source['Frequency'] == fido_frequency:
            sourceMatched = source
            break
    if sourceMatched == '':
        raise ValueError('Fido source {0} for frequency {1} not found in property file'.format(fido_source, fido_frequency))    

    whenparam = ''
    NotifyOnFailure = ''
    FailureActionParam = ''
    WaitForFile = ''
    WaitForMinutes = ''
    errorEmailTo = ''
    successEmailTo = ''
    ingestType = ''
    preProcess = ''
    runCheckAndPull=False
    maxCsvRowSizeMb = ''
    clustername = ''
    importparam = ''
    wu_priority = ''
    WaitCycleSeconds = ''
    EmailAfterMinutes = ''
    EmailAttempt = ''
    despray_path = ''
    #print (source)
    try:
        runCheckAndPull=source['runCheckAndPull']
    except:
        pass
    try:
        preProcess = source['preProcess']
    except:
        pass
    try:
        maxCsvRowSizeMb = source['maxCsvRowSizeMb']
    except:
        pass
    try:
        ingestType = source['IngestType']
    except:
        pass
    try:
        errorEmailTo = source['ErrorEmailTo']
    except:
        pass
    try:
        clustername = source['clustername']
    except:
        pass
    try:
        successEmailTo = source['SuccessEmailTo']
    except:
        pass

    try:
        importparam = source['importparam']
    except:
        pass
    try:
        wu_priority = source['wu_priority']
    except:
        wu_priority = '\'normal\''
    try:
        whenparam = source['WhenParam']
        pattern = re.compile('[$]today', re.IGNORECASE)
        whenparam = pattern.sub(fido_utils.today, whenparam)
        if int(filedate) < int(fido_utils.today) and commonArgs.getIgnoreWhenparamHistoryDate():
            whenparam = ''
        # whenparam = pattern.sub(filedate, whenparam)
    except:
        pass
    try:
        # whenparam = source['WhenParam']
        pattern = re.compile('[$]tomorrow', re.IGNORECASE)
        whenparam = pattern.sub(fido_utils.tomorrow, whenparam)
        # whenparam = pattern.sub(filedate, whenparam)
    except:
        pass
    try:
        # whenparam = source['WhenParam']
        pattern = re.compile('[$]buildmonth', re.IGNORECASE)
        whenparam = pattern.sub(fido_utils.buildmonth, whenparam)
        # whenparam = pattern.sub(filedate, whenparam)
    except:
        pass
    try:
        NotifyOnFailure=source['NotifyOnFailure']
    except:
        pass
    try:
        FailureActionParam=source['FailureAction']
    except:
        pass
    try:
        waitfor = source['WaitFor']
        WaitForFile = waitfor['File']
        #WaitCycleSeconds = waitfor['WaitCycleSeconds']
        #EmailAfterMinutes = waitfor['EmailAfterMinutes']
        #EmailAttempt = waitfor['EmailAttempt']
        WaitForMinutes = 0
        WaitCycleSeconds = 30
        EmailAfterMinutes = 0
        EmailAttempt = 0
        if 'WaitCycleSeconds' in waitfor.keys():
            WaitCycleSeconds = waitfor['WaitCycleSeconds']
        if 'EmailAfterMinutes' in waitfor.keys():
            EmailAfterMinutes = waitfor['EmailAfterMinutes']
        if 'EmailAttempt' in waitfor.keys():
            EmailAttempt = waitfor['EmailAttempt']
        if fido_utils.dayName().lower() in map(str.lower, waitfor['WaitForMinutes'].keys()):
            WaitForMinutes = waitfor['WaitForMinutes'][fido_utils.dayName()]
            print('waifor .. {0}'.format(WaitForMinutes))
        else:
            WaitForMinutes = waitfor['WaitForMinutes']['Default']
            print('waifor .. {0}'.format(WaitForMinutes))
        
        if WaitForMinutes == 0:
            raise ValueError ('WaitForMinutes, when provided should be an Integer > 0')

        #pattern = re.compile('[$]today', re.IGNORECASE)
        #WaitForFile = pattern.sub(filedate, WaitForFile)
    except ValueError as valErr:
        print('ValueError {0} is not a valid value'.format(valErr))        
    except:
        pass

    adhoc_despray = ''
    try:
        adhoc_despray = source['adhoc_despray']
        despray_path = source['despray_path']
    except:
        pass

    

# revisit
    errorEmailTo = 'FIDOCoreTeam@lexisnexisrisk.com' if errorEmailTo == '' else errorEmailTo
    successEmailTo = 'FIDOCoreTeam@lexisnexisrisk.com' if successEmailTo == '' else successEmailTo

    if commonArgs.getDebugFlag():
        successEmailTo = parse_props.get_debug_email()
        errorEmailTo = parse_props.get_debug_email()
    return(Source(fido_source, fido_frequency, ingestType, clustername, source['AttributeToCall'], source['ProcessType'], adhoc_despray, maxCsvRowSizeMb, whenparam, WaitForFile, WaitForMinutes, WaitCycleSeconds, EmailAfterMinutes, EmailAttempt, errorEmailTo, successEmailTo, preProcess, runCheckAndPull,importparam,wu_priority, filedate,NotifyOnFailure,FailureActionParam, despray_path))
    
def process(source, frequency, filedate=''):
    
    if filedate == '':
        filedate = fido_utils.today

    global sourceInfo
    sourceInfo = getSourceInfo(source, frequency, filedate)
    
if __name__ == "__main__":
    #global sourceInfo
    try:
        # process('ins_resptime_logs', 'daily')
        sourceInfo = getSourceInfo('icisdashboard', 'daily', '20210723')
        print(sourceInfo)
    except ValueError as valErr:
        print('Am I printing here ... {0}'.format(valErr))