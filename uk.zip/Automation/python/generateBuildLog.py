import parseYamlProperty as parse_props
import generateBuildNotification

def buildHTML(inList, listTitle,Error=False):
    strTbl = ''
    if Error:
        strTbl += '<TABLE id=builderror><tr><td>' + listTitle + '</td></tr>'
    else:
        strTbl += '<TABLE id=buildsuccess><tr><th>' + listTitle + '</th></tr>'
        
    #strTbl += '<tr><td>' + '\n'.join(map(str, inList)) + '</td></tr></table>'

    for item in inList:
        strTbl += ('<tr><td>' + item + '</td></tr>')
    
    strTbl += '</table>'
    
    return strTbl

def generate(sourceFiles):
    strHtml = ''
    if sourceFiles.list_of_working_files:
        strHtml += buildHTML(sourceFiles.list_of_working_files, 'Files in Working Folder (Includes Reqd. and Optional)')
    if sourceFiles.list_of_missing_files:
        strHtml += buildHTML(sourceFiles.list_of_missing_files, 'Missing Files')
    if sourceFiles.list_of_extra_files:
        strHtml += buildHTML(sourceFiles.list_of_extra_files, 'Extra Files')

    header = '<html><head><link rel="stylesheet" type="text/css" href="' + parse_props.getCSSPath() + '"></head>'
    finalstr = header + generateBuildNotification.generateErrorInfo(sourceFiles) + generateBuildNotification.generateSourceInfo(sourceFiles)  +  strHtml +  '</html>'

    text_file = open(parse_props.get_build_logs_dir() + sourceFiles.log_filename, "w")
    text_file.write(finalstr)
    text_file.close()
