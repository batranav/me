import weekly_release_sql
import commonArgs

def process():
    args = commonArgs.parse()
    weekly_release_sql.process('view')

if __name__ == '__main__':    
    process()