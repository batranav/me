from ftplib import FTP
import datetime, os, parseYamlProperty
import AutomationLogging
from vault.secrets import get_ftp_secret

def getToday():
   today=datetime.date.today()
   return today.strftime("%Y%m%d")

def pull_files():
   server = 'transfer.seisint.com'
   logger = AutomationLogging.getLogger('pull_nps', True)
   pwd = get_ftp_secret(logger, server + '_nps', secret='pwd')
   ftp = FTP(server)
   ftp.login('nps', pwd)
   today = getToday()
   ftp.retrbinary('RETR NPS_QA.txt', open(os.path.join(parseYamlProperty.get_inbound_dir(),'nps\\daily\\NPS_QA_' + today + '.txt'), 'wb').write)
   ftp.close()
   
if __name__ == '__main__':
   pull_files()