import pyodbc
from datetime import datetime
import codecs
import parseYamlProperty
import os
from vault.secrets import get_db_secret
import AutomationLogging

def attempt_strip(x):
    try:
        #print(x)
        return x.strip()
    except AttributeError:
        return x

def checkNone(x):
    if x is None:
        #print('None condition')
        return ('')
    else:
        return(x)

def pull_files():
    logger = AutomationLogging.getLogger('preprocess_DW_sumtotal_pull')
    uname, pwd = get_db_secret(logger, 'emplauth')
    cnxn = pyodbc.connect('Trusted Connection=yes;DRIVER={ODBC Driver 17 for SQL Server};SERVER=RETDAYSQLP102.lexisnexis.com,1433;DATABASE=emplauth;UID=' + uname + ';PWD=' + pwd)
    cursor = cnxn.cursor()
    cpsql ="SELECT [Attemptfk],[ActivityName],[Code],[EmpNo],[CostCenter],[BusUnit],[MgrEmpNo],[MgrEmail],[ActivityLabel],[ActivityActive],[StartDt],[EndDt],[AttendanceStatus],[CostBase] FROM [DW_SUMTOTAL].[DW_sumtotal].[dbo].[RELX_Transcript_RBXXX_RKXXX_Users]"
   
    sqltoexecute = cpsql
    
    print (sqltoexecute)
    
    cursor.execute(sqltoexecute)
    
    f = open(os.path.join(parseYamlProperty.get_inbound_dir(), 'workday\\daily\\workday_sumtotal_' + datetime.now().strftime('%Y%m%d') + '.txt'),'w')

    while 1:
        row = cursor.fetchone()
        iterator = range(0, len(cursor.description)).__iter__()
        col = ''
        outStr = []
        result = ''
        #print(row)
        if not row:
            break
        for idx in iterator:
            col = checkNone(attempt_strip(row[idx]))
            if idx > 0:
                outStr.append('|')
                outStr.append(col)
            else:
                outStr.append(col)

        result = ' '.join([str(i) for i in outStr])
		
		
        f.write(result.encode("ascii", "ignore").decode() + '\n')
	
    #print(result)

    f.close()

if __name__ == '__main__':
   pull_files()