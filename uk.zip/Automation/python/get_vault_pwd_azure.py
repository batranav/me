import AutomationLogging
from vault.secrets import get_azure_secret

''' 
Script is built to return vault creds to terminal
Don't use outside of this case as script prints creds to console
Calling script should capture output such as >$pass = python .\get_vault_pwd_azure.py
'''
logger = AutomationLogging.getLogger('get_vault_pwd_azure', True)
pwd = get_azure_secret(logger, secret='pwd')
print(pwd)
