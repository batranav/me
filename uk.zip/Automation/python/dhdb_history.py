'''
Created on Oct 22, 2014

@author: nagararx
'''
import glob,os
import datetime, shutil

rootdir = 'D:/red/data/inbound/mvr/daily/DHDBTOBERUN2015/'
file_dir_extension = os.path.join(rootdir, '*.txt')

def check_and_create(dir_name):
    print('In Check and Create .. ' + dir_name)
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)
        print('folder created ?')
    return dir_name

def process():
    print(file_dir_extension)
    for file_name in glob.glob(file_dir_extension):
        if file_name.endswith('.txt'):
            datestr = (file_name.split("_")[2]).split("-")[0]
            print(datestr)
            date_folder_name = datetime.datetime.strptime(datestr,"%m%d%Y").strftime("%Y%m%d")
            print(date_folder_name)
            absfilename = os.path.split(file_name)[1]
            print(absfilename)
            destination_folder = check_and_create(rootdir + "/" + date_folder_name)
            print(destination_folder)
            src_file = rootdir + "/" + absfilename
            dest_file = destination_folder + "/" + absfilename 
            print(src_file)
            print(dest_file)
            if os.path.exists(dest_file):
                os.remove(dest_file)
            shutil.move(src_file,destination_folder)

if __name__ == "__main__":
    process()
    #print(getDateRange('20141117', '20150105'))