import os
import shutil
import commonArgs
import parseYamlProperty

from fido_utils import *


# Get all files from daily working folder
# app env freq
env = commonArgs.getEnv()
app = commonArgs.getApplication()
freq = commonArgs.getFrequency()

inbound_oracle_financials = parseYamlProperty.get_inbound_dir() + \
    f'oracle_financials\\{freq}\\'
inbound_oracle_financials_archive = parseYamlProperty.get_inbound_dir() + \
    f'oracle_financials\\{freq}\\archive\\'


if __name__ == "__main__":
    if os.path.isdir(inbound_oracle_financials):
        submitted_files = [f for f in os.listdir(
            inbound_oracle_financials) if os.path.isfile(inbound_oracle_financials + f)]

    grouped_files = {}

    # group files by file name
    for f in submitted_files:
        file_name = f.strip('.txt')
        file_name_split = file_name.split('_')

        key = '_'.join(file_name_split[:-2])
        request_id = file_name_split[-2]
        file_date = file_name_split[-1]
        print(f'{key} - {request_id} - {file_date}')
 
        if key not in grouped_files:
            grouped_files[key] = {
                'request_ids': [int(request_id)],
                'file_date': file_date
            }
        else:
            grouped_files[key]['request_ids'].append(int(request_id))

        grouped_files[key][request_id] = str(f)

    # sort files by request ID in descending order
    for key, value in grouped_files.items():
        request_ids = list(value['request_ids'])
        request_ids.sort(reverse=True)

        # clear all files apart from the first
        for id in request_ids[1:]:
            if os.path.exists(inbound_oracle_financials + value[str(id)]):
                if not os.path.isdir(inbound_oracle_financials_archive + value['file_date'] + '\\'):
                    os.makedirs(inbound_oracle_financials_archive +
                                value['file_date'] + '\\')

                source = inbound_oracle_financials + value[str(id)]
                destination = inbound_oracle_financials_archive + \
                    value['file_date'] + f'\\{value[str(id)]}'
                shutil.move(source, destination)
