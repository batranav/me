import requests
import json 
import pprint
from collections import OrderedDict
from requests.auth import HTTPBasicAuth
import parseYamlProperty
import time
import AutomationLogging
from vault.secrets import get_api_secret

def getDictionaryData(dictionaryList) :
    strOut = ''
    counter = 0
    for dict in dictionaryList:
        for k, v in dict.items():
            if counter > 0:
                strOut += ','
            strOut += '{0}'.format(v.strip())
            counter += 1
    return strOut

def isfloat(value):
  try:
    float(value)
    return True
  except ValueError:
    return False

def getVarianceInfo(workunit) :
    
    json_data = getWUResultsJSON(workunit)
    #print(json_data)
    json_dict = json_data['WUFullResultResponse']['Results']['Results']['VarianceDiff']['Row']
    
    #print(json_dict)
    printDict = OrderedDict()

    for entry in json_dict:
        print(isfloat(entry['value']))
        printDict[entry['frequency']] = round(float(entry['value']), 5) if isfloat(entry['value']) else entry['value']

    return printDict

def getWUResultsJSON(workunit):
    (cluster_url, cluster) = parseYamlProperty.getHPCCURLCluster()
    url =  cluster_url + '/WsWorkunits/WUFullResult.json?Wuid=' + workunit # + '&ResultName=input'
    #url =  'http://' + cluster_url + '/WsWorkunits/WUFullResult.json?Wuid=' + workunit # + '&ResultName=input'
    print(url)
    head = {'Content-type':'application/json; charset=UTF-8', 'Accept':'application/json'}
    print(url)
    logger = AutomationLogging.getLogger('parseWUFullResults', True)
    uname, pwd = get_api_secret(logger, 'hpccthor')
    # adding a sleep for 1 min interval for 10 times, re fetch the WU results in case of SOAP call failures
    # retry fetching of WU results via SOAP call in a loop, until we reach 10 times or we get statuscode 200
    counter = 10
    while counter > 0:
        counter -= 1
        ret = requests.post(url,auth=HTTPBasicAuth(uname, pwd))
        if ret.status_code == 200:
            break
        time.sleep(60)

    if ret.status_code == 200:
        json_data = json.loads(ret.text, object_pairs_hook=OrderedDict)
    else:
        return ""
    print(json_data)
    return json_data

def remove_keys_empty_from_list(input_dict):
    return_data = []
    key = 0
    for value in input_dict:
        if isinstance(value, dict):
            if 'Year' in value:
                value = "%02d-%02d-%d %02d:%02d:%02d" % (value['Day'], value['Month'], value['Year'], value['Hour24'], value['Minute'], value['Second'])
            else:
                value = remove_keys_empty_from_dict(value)
        elif isinstance(value, list):
            value = remove_keys_empty_from_list(value)
        if value not in (None, str(), list(), dict(),):
            if type(value) == str:
                uniString = value.replace("\xc2\xa0", " ")
                if uniString.strip() != '':
                    return_data[key] = uniString.strip()
            else:
                return_data[key] = value
    return return_data

def remove_keys_empty_from_dict(input_dict):
    return_data = {}
    for key, value in input_dict.items():
        if isinstance(value, dict):
            if 'Year' in value:
                value = "%02d-%02d-%d %02d:%02d:%02d" % (value['Day'], value['Month'], value['Year'], value['Hour24'], value['Minute'], value['Second'])
            else:
                value = remove_keys_empty_from_dict(value)
        elif isinstance(value, list):
            value = remove_keys_empty_from_list(value)
        if value not in (None, str(), list(), dict(),):
            if type(value) == str:
                uniString = value.replace("\xc2\xa0", " ")
                if uniString.strip() != '':
                    return_data[key] = uniString.strip()
            else:
                return_data[key] = value
    return return_data
    
def getDictValue(dict_data) :
    value = ' '
    if type(dict_data) != 'str':
        temp_value = json.dumps(dict_data)
        return temp_value.replace('"', '').replace('{', '').replace('}', '')
    else:
        return value

def getNVPairs(json_dict) :
    
    printDict = OrderedDict()

    for key in json_dict:
        key = key.strip()
        if(isinstance(json_dict[key] , dict) == True):
            value = remove_keys_empty_from_dict(json_dict[key])
        else:
            value =  str(json_dict[key]).strip()
        
        print('Key : {0}'.format(key))
        if key in ['User', 'RemoteLocations', 'ServiceLocations']:
            continue
        elif key == 'reasoncodes':
            reasoncodeDict = json_dict[key]
            for rKey in reasoncodeDict:
                rValue = str(reasoncodeDict[rKey]).strip()
                if rValue != '[]':
                    rValue = getDictionaryData(reasoncodeDict[rKey])
                    printDict[key] = rValue
        elif key == 'SearchBy':
            if value != '' and value not in (None, str(), list(), dict(),):
                if key.lower() == 'companyid':
                    if value == '0':
                        continue
                for subkey in value:
                    subkey = subkey.strip()
                    subvalue = value[subkey]
                    
                    if subkey == 'DateRange':
                        for datekey in subvalue:
                            datevalue = subvalue[datekey]
                            printDict[datekey] = getDictValue(datevalue)
                    else:
                        printDict[subkey] = getDictValue(subvalue)
        else:
            if value != '' and value not in (None, str(), list(), dict(),):
                if key.lower() == 'companyid':
                    if value == '0':
                        continue
                printDict[key] = getDictValue(value)
    return printDict

def getInput(workunit):
    
    json_data = getWUResultsJSON(workunit)
    if 'WUFullResultResponse' in json_data:
        json_dict = OrderedDict(json_data['WUFullResultResponse']['Results']['Results']['input']['Row'][0])
    else:
        json_dict = {}
    return getNVPairs(json_dict)

def getExportCount(workunit):

    json_data = getWUResultsJSON(workunit)

    printDict = OrderedDict()

    export_count = 'N/A'

    try:
        json_export_count_dict = OrderedDict(json_data['WUFullResultResponse']['Results']['Results']['export_count'])
        export_count = (getDictionaryData(json_export_count_dict['Row']))
    except KeyError:
        pass
    
    printDict['Row Count'] = export_count
    
    return printDict

def getAlertInput(workunit):

    return getInput(workunit)

def getSearchInput(workunit):

    inputDict = getInput(workunit)
    exportDict = getExportCount(workunit)
    return OrderedDict(list(inputDict.items()) + list(exportDict.items()))

def getSummaryInput(workunit):
    inputDict = getInput(workunit)
    exportDict = getExportCount(workunit)
    return OrderedDict(list(inputDict.items()) + list(exportDict.items()))

if __name__ == "__main__":
    #x = getVarianceInfo('W20181115-122114')    
    #print(getPrevRunPeriodValue(x, 'Baseline --'))

    #getInput('W20180827-163541')
    #for x in json_dict:
    #print(str(x))
    #for y in json_dict[x]:
    #print(str(y)
    print(getSummaryInput('W20190826-175750'))
    print('done')