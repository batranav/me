from send_email import send_mail
from automationFileMonitor import AutomationFileMonitor
# from ECL_Python import getWUID, checkStatus
import openpyxl
from datetime import datetime
import os
from time import sleep
import subprocess, shlex, re, time
# from config import username, password, prodServer, devServer, prodTarget, devTarget

class FileMonitorInsRevOverride(AutomationFileMonitor):

	err = []
	metricsList = ['growth_from_price_action', 'growth_from_qtp', 'growth_from_other_price', 'growth_from_registry_price', 'growth_from_mix', 'plug_base_growth', 'growth_from_prescreen_volume', 'growth_from_other_volume', 'growth_from_shc_adj', 'growth_from_incremental_recurring', 'growth_from_incremental_non_recurring', 'growth_from_incremental_cannibalization', 'growth_from_mvr_attrition', 'growth_from_non_mvr_attrition', 'growth_from_py_incremental_non_recurring', 'growth_from_non_recurring', 'growth_from_billing_credits']
	headerName = ['growth_metrics', 'sub_acct_id',	'transaction_date',	'product_name',	'search_type_id', 'delivery_method', 'state_province_cd', 'trans_nontrans_flag', 'vertical_for_reporting', 'OVERRIDE billed_unit', 'OVERRIDE USD_billed_revenue', 'Notes', 'User']

	def __init__(self, fileMonitor):
		super().__init__(fileMonitor.sendFrom, fileMonitor.sendTo, fileMonitor.sendCC, fileMonitor.landingZoneRootPath, fileMonitor.targetFolderPath, fileMonitor.fileType)
	
	def dateFormatValidation(self, inputDate):
		if len(inputDate) != 8:
			return False
		try:		
			dateTime = datetime.strptime(inputDate, '%Y%m%d')
			return True
		except:
			return False		

		
	def errMessage(self, e):
		print(e)
		self.err.append(e)	
	
	def readAndValidation(self, targetFolderPath, folderPath, fileName, todayDateTime, todayDate, fileNameBase):
		
		sleep(3)
		print("Begin to process file")
		
		errorFile = open(folderPath+ todayDate + '/' + 'Error_' + fileNameBase + todayDateTime+'.txt','w+')
		
		errorIndicator = False
		
		outputFile = open(folderPath + todayDate + '/' + fileNameBase + todayDate +'.txt','w+')
		
		book = openpyxl.load_workbook(folderPath+fileName, data_only = True)
		
		
		inputMissing = self.missingInputTabName(book.sheetnames)
		if inputMissing:
			errorFile.write(inputMissing)
			errorFile.close()
			return True		
		if 'Input' in book.sheetnames:
			wb = book['Input']
		else:
			wb = book['input']
		
		rowIndex = 0
		header = []
		
		rows = wb.rows
		
		reveneEachDate = {}
		
		for row in rows:
			tableContent = []		
			
			cellIndex = 0
			
			#read whole line to tab contect array
			for cell in row:
				if cellIndex > 12:
					print('Warning: This row contains more than 13 cols. Data after 13th column are abandoned!'+'\n')
					continue
				
				#write to output txt file
				cellValue = ' ' if cell.value == None else str(cell.value).strip()	
					
				tableContent.append(cellValue)
				outputFile.write(cellValue + "\t")
				cellIndex += 1
			
			# check if the whole row is empty
			if all(map(lambda x: x in [None, '\t', '\n', ' ', '\r'], tableContent)):
				print('This line is probably empty. Skipped!')
				rowIndex +=1
				continue
				
			if rowIndex == 0:
				outputFile.write("\n")
				rowIndex +=1
				continue #header no need QA				
			
			#loop on table contect for QA
			for i in range(len(self.headerName)):
				#growth metrics QA
				if i==0 and tableContent[i].lower() not in self.metricsList:
					self.errMessage('Line: ' + str(rowIndex) + ' ' + tableContent[i] + ' is not in growth metric list. \n')					
				
				#transaction date format yyyymmdd
				if i==2 and not self.dateFormatValidation(tableContent[i]):
					self.errMessage('Line: ' + str(rowIndex) + ' ' + tableContent[i] + ' is not in correct date format(yyyymmdd). \n')
					
				#trans_nontrans_flag should always be 0 or 1	
				if i==7 and tableContent[i] not in ['0', '1']:
					self.errMessage('Line: ' + str(rowIndex) + ' ' + tableContent[i] + ' is not 0 or 1 for trans_nontrans_flag\n')

					
			#add up revenue for each transaction date
			transDate = tableContent[2]
			revenue = tableContent[10]
			if transDate in reveneEachDate:
				reveneEachDate[transDate] = reveneEachDate[transDate] + float(revenue)
			else:
				reveneEachDate[transDate] = float(revenue)
			

			outputFile.write("\n")
			rowIndex += 1
		
		if len(self.err) > 0:
			errorIndicator = True
			for e in self.err:
				errorFile.write(e)

		for key in reveneEachDate:
			if round(reveneEachDate[key],2) != 0:
				errMessage = 'Error: Total of Transaction date ' + key + ' is not 0. \n'
				print(errMessage)
				errorFile.write(errMessage)
				errorIndicator = True
		
		errorFile.close()
		outputFile.close()
		book.close()
		
		return errorIndicator
	
	def run(self, fileName):
		# set up path, file name and folders
		# targetFolderPath = 'D:/red/data/inbound/manual_adjustment/'
		# landingZoneRootPath = 'D:/red/data/inbound/manual/adhoc/working/'
		
		fileNameBase = self.txtFileName('insurance override')
	
		targetFolderPath = self.targetFolderPath
		todayDate = datetime.now().strftime("%Y%m%d")
		todayDateTime = datetime.now().strftime("%Y%m%d%H%M%S")
		currentFolder = targetFolderPath #+ todayDate + '/'		
		landingZonePath = self.landingZoneRootPath
		archiveRootPath = targetFolderPath + 'Archive/'
		
		if not os.path.exists(currentFolder + '/' + todayDate):
			os.makedirs(currentFolder +'/' + todayDate)

		try:
			pythonError = self.readAndValidation(targetFolderPath, currentFolder, fileName, todayDateTime, todayDate, fileNameBase)
		except Exception as e:
			print("Something wrong with reading excel files")
			send_mail(self.sendFrom, self.sendTo, self.sendCC, 'Something Wrong with Reading Insurance override File', 'Please Check Terminal')
			self.copyFile(currentFolder, targetFolderPath + 'Archive/' + 'DataWithError/General/' + todayDateTime + '/', 'insurance override', 'archive')			
			return
		
		if pythonError:
			# if pre-HPCC error, copy file to error folder
			print('There is error in Python validation. File would be copied to DataWithError folder instead of landing zone!!!')
			archivePath = archiveRootPath + 'DataWithError/Python/' + todayDate + '/' + todayDateTime + '/'
			# fileName = archiveRootPath + 'DataWithError/Python/' + todayDate + '/' + todayDateTime + '/' + 'Error_' + fileNameBase + todayDateTime+'.txt'
			fileName = currentFolder + todayDate + '/' + 'Error_' + fileNameBase + todayDateTime+'.txt'
			self.sendEmail(self.sendFrom, self.sendTo, self.sendCC, subject = 'Insurance Override Process Error', err=True, fileName=fileName)
		else:
			# print('landingzone path ' + landingZonePath)
			self.copyFile(currentFolder, landingZonePath, 'insurance override', 'landing zone')
			
			# eclRunning = self.callECL(self.ECLscript, 'Insurance Override')
			eclRunning = True
			# if no ECL error, copy file to landing zone.
			if not eclRunning:
				print('There is error in ECL. File would be copied to DataWithError folder instead of landing zone!!!')
				archivePath = archiveRootPath + 'DataWithError/ECL/' + todayDate + '/' + todayDateTime + '/'			
			archivePath = archiveRootPath + 'NoError/' + todayDate + '/' + todayDateTime + '/'				


		self.copyFile(currentFolder, archivePath, 'insurance override', 'archive')
def main():
	computerName = os.environ['COMPUTERNAME']
	env = 'production' if computerName in ['ALAWPRED001', 'ALAWPFIDOLZ201'] else 'dev'	
	fileMonitor = AutomationFileMonitor('Yang.xu@lexisnexisrisk.com', ['Yang.xu@lexisnexisrisk.com,raja.sundarrajan@lexisnexis.com', 'Hua.Xia@lexisnexisrisk.com'], ['Yang.xu@lexisnexisrisk.com,raja.sundarrajan@lexisnexis.com','Hua.Xia@lexisnexisrisk.com'], 'D:/red/data/inbound/manual/adhoc/', 'D:/red/data/inbound/userfeeds/', 'override')
	fileName = fileMonitor.run()
	insOverrideJob = FileMonitorInsRevOverride(fileMonitor)
	insOverrideJob.run(fileName)
if __name__ =="__main__":
	main()


	
	
		
		
		
		
				