from collections import namedtuple
import paramiko
import os, re
from pathlib import Path
import time
import datetime
from multiprocessing.dummy import Pool as ThreadPool
import sys
import traceback
import io
import checkAndPullFiles
import commonArgs
from datetime import datetime as sub_dt
import AutomationLogging
import parseYamlProperty
global logger
logger = AutomationLogging.getLogger('coplogic_preprocess')
class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)

# revisit
def pull():
    start_time = time.time()
    my_source = commonArgs.getSource()
    my_frequency = commonArgs.getFrequency()
    logger.debug('preprocess started for the source ' + my_source)
    
    sftp_client_list = checkAndPullFiles.getSourcePullInfo(logger, my_source)
    filedate = commonArgs.getFiledate()

    if len([o for o in sftp_client_list if o.host == 'supportftp.lexisnexis.com']) == 0 :
        sys.tracebacklimit = -1
        # raise Exception('Don\'t see any definition for FTP pull, please check source {0} for date {1}'.format(my_source, filedate))
        return

    sftp = [o for o in sftp_client_list if o.host == 'supportftp.lexisnexis.com'][0]

    ssh_conn = FastTransport((sftp.host, 22))
    ssh_conn.connect(username=sftp.uname,password=sftp.pwd)
    sftp_client = paramiko.SFTPClient.from_transport(ssh_conn)
    lz_file_path = parseYamlProperty.get_inbound_dir(my_source) +  my_source + '\\' + my_frequency + '\\'
    
    # pull_files_list = ['FIDOO_']
    pull_files_list = {'FIDOO_': 'peoplesoft_extract'}
    sftp_client.chdir('/')

    no_feeds_for_today = True
    sftp_client.chdir('/outbound')
    all_file_list = sftp_client.listdir('.')
    for pull_file in pull_files_list:
        filtered_file_list = [name for name in all_file_list if name.startswith(pull_file + filedate)]
        if len(filtered_file_list) > 0 :
            no_feeds_for_today = False
    
    if no_feeds_for_today == True:
        logger.debug("There are no feeds for processing  today -- {0}".format(filedate))
        return

    sftp_client.chdir('/outbound/processed')
    all_processed_file_list = sftp_client.listdir('.')


    for pull_file in pull_files_list:
        for processed_file in all_processed_file_list:
            if processed_file.startswith(pull_file):
                sftp_client.remove(processed_file)
    
    sftp_client.chdir('/outbound')

    all_file_list = sftp_client.listdir('.')
    for pull_file in pull_files_list:
        filtered_file_list = [name for name in all_file_list if name.startswith(pull_file)]
        
        
        raw_file_path = lz_file_path  + filedate + '\\' + '\\raw_files\\'
        if not os.path.isdir(raw_file_path):
            os.makedirs(raw_file_path)
        
        for file in filtered_file_list:
            match = re.findall(r'' + pull_file + '\d{8}',file)
            if match[0] == None:
                continue
            if filedate != match[0].replace(pull_file ,''):
                continue
            out_file = lz_file_path + pull_files_list.get(pull_file) + '_' +  my_frequency + '_' + filedate +'.txt'
            fout = open(out_file, "w+")
            sftp_client.get(file, raw_file_path + '\\' + file)
            for line in open(raw_file_path + '\\' + file, "r"):
                fout.write(line)
            fout.close()
        
        for file in filtered_file_list:
            sftp_client.rename(file, '\\processed\\' + file)
    return 

if __name__ == "__main__":

    try:
        pull()

    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))    
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        print(processerrorMsg)
