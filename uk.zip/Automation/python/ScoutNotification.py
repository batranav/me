class ScoutNotification(object):
    notificationType = "" ''' Either an Alert, Search '''
    id = ""
    name = ""
    alert_run_period = ""
    alert_type_id = ""
    alert_input_field = ""
    alert_reason_codes = ""
    requestedUser = ""
    requestedUserEmail = ""
    workunit = ""
    workunitStatus = ""
    workUnitMsg = ""
    startTime = ""
    completionTime = ""
    elapsedTime = ""
    folderPath = ""
    list_of_exportedFiles = []
    searchInput = {}
    results = {}
    score_median_excluding_exceptions = 0
    score_average_excluding_exceptions = 0
    IncreaseOrDecrease = ""

    def __init__(self, _id, _name, _requestedUser, _requestedUserEmail):
        self.id = _id
        self.name = _name
        self.requestedUser = _requestedUser
        self.requestedUserEmail = _requestedUserEmail
        self.workunit = ""
        self.workunitStatus = ""
        self.workUnitMsg = ""
        self.startTime = ""
        self.completionTime = ""
        self.elapsedTime = ""
        self.folderPath = ""
        self.set_of_exportedFiles = set()
        self.notificationType = ""
        self.searchInput = {}
    
    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 

    def __lt__(self, other):
        return self.id < other.id
