import sendEmail
import parseYamlProperty as parse_props
import fido_utils
import commonArgs
import commonSourceInfo
import os, json
import getProperties
import commonSourceInfo

def xstr(s):
    return '' if s is None else str(s)

def commonArgsInfo():
    args = commonArgs.parse()
    lines = ''
    commonArgsTable = """<table id='buildsuccess'>
                        <tr>
                        <th># CommonArgs Params</th>
                        <th># Values</th>
                        </tr>"""
    lines = lines + commonArgsTable
    for item in vars(args).keys(): 
        if vars(args)[item] != '':
            print (item + ":::" + xstr(vars(args)[item]))
            lines += ('<tr><td>' + xstr(item) + '</td><td>' + xstr(vars(args)[item]) + '</td></tr>')      
    lines += '</tr></TABLE>'
    return lines


def generateSourceInfo(sourceFiles):
    sourceTable = """ <TABLE id="build"> """ 
    
    wuURL = ''
    
    if sourceFiles.workunit != '':
        HPCCURL = parse_props.getHPCCURL().split('//')
        wuURL = '<a href="http://' + HPCCURL[1] + '/?Wuid=' + sourceFiles.workunit.strip() + '&Widget=WUDetailsWidget' + '">' + sourceFiles.workunit.strip()  + '</a>'        
            
    sourceDataRow = ('' 
                     '<tr><th>Hostname</th><td>' + xstr(parse_props.getHostName()) + '</td></tr>' 
                     '<tr><th>Source</th><td>' + xstr(sourceFiles.source) + '</td></tr>' 
                     '<tr><th>LoadType</th><td>' + xstr(sourceFiles.processtype) + '</td></tr>'  
                     '<tr><th>Frequency</th><td>' + xstr(sourceFiles.frequency) + '</td></tr>' 
                     '<tr><th>File Date</th><td>' + xstr(sourceFiles.file_date) + '</td></tr>' 
                     '<tr><th>Workunit</th><td>' + xstr(wuURL) + '</td></tr>' 
                     '<tr><th>WorkUnitStatus</th><td>' + xstr(sourceFiles.workunitstatus) + '</td></tr>' 
                     '<tr><th>Archived File is located</th><td>' + xstr(sourceFiles.archivedFileName) + '</td></tr>'
                     '<tr><th>Process Elapsed Time</th><td>' + 
                      xstr(fido_utils.elapsedTime(sourceFiles.processEndTime, sourceFiles.processStartTime)) + 
                     '</td></tr>'
                     '<tr><th>Pre Process Elapsed Time</th><td>' 
                     + xstr(fido_utils.elapsedTime(sourceFiles.preProcessEndTime, sourceFiles.preProcessStartTime))  
                     + '</td></tr>' 
                     '<tr><th>HPCC Elapsed Time</th><td>'
                     + xstr(fido_utils.elapsedTime(sourceFiles.HPCCEndTime, sourceFiles.HPCCStartTime))
                     + '</td></tr></TABLE>')

    sourceListRow = ''
    lines = ''
    #if sourceFiles.status:
    sourceListRow = """<table id='buildsuccess'>
                        <tr>
                        <th># of Expected Files</th>
                        <th># of Optional Files</th>
                        <th># of Missing Files</th>
                        <th># of Missing(Expected) Files</th>
                        <th># of Missing(Optional) Files</th>
                        <th># of Extra Files</th>
                        </tr>"""
    lines += '<td>' +  xstr(len(sourceFiles.list_of_expected_files)) + '</td>'
    lines += '<td>' +  xstr(len(sourceFiles.list_of_optional_files)) + '</td>'
    lines += '<td>' +  xstr(len(sourceFiles.list_of_missing_files)) + '</td>'
    lines += '<td>' +  xstr(len(sourceFiles.list_of_expected_but_missing_files)) + '</td>'
    lines += '<td>' +  xstr(len(sourceFiles.list_of_optional_but_missing_files)) + '</td>'
    lines += '<td>' +  xstr(len(sourceFiles.list_of_extra_files)) + '</td>'
    lines += '</tr></TABLE>'
    sourceListRow += lines

    sourceListRow = sourceListRow if sourceFiles.processtype == 'inboundloads' else ''
    
    optionalMissingFileStr = ""
    
    if sourceFiles.list_of_optional_but_missing_files:
        optionalMissingFileStr = ("<table id='buildoptional'><tr><td>optional Files are Missing</td></tr>")
        for item in sourceFiles.list_of_optional_but_missing_files:
            optionalMissingFileStr += ('<tr><td>' + item + '</td></tr>')
        optionalMissingFileStr += '</table>'
        
    return (sourceTable + sourceDataRow + sourceListRow + optionalMissingFileStr)

def getSourcePullInfo(mySQLSource):
    ftp_file_name = getProperties.getFTPJsonFilename()
    print('GetSourceInfo {0}'.format(mySQLSource))
    jsonRef = json.load(open(ftp_file_name))

    MySQLSourceList = []

    for index in range(len(jsonRef)):
        print('IDX {0}'.format(index))
        for key in jsonRef[index]:
            if (key == mySQLSource):
                src = jsonRef[index][key]
                print(src)
                for index2 in range(len(src)):
                    src2 = src[index2]
                    MySQLSourceList.append(src2['host'])
    return ",".join(MySQLSourceList)

def generateNotifyMissingFiles(sourceFiles_push, sourceFiles_pull):

    cssdata = open(parse_props.getCSSPath(), "r").read()

    htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>""" + cssdata + "</style>"""

    lines = ""
    lines += """<table id="builderror">
                        <tr>
                        <th>Source Filename</th>
                        <th>Server Name(s)</th>
                        <th>Folder Name</th>
                        <th>Date</th>
                        </tr>"""
    for fileObj in sourceFiles_push:
        lines += "<tr>"
        lines += "<td>" + fileObj.fidoname + "</td>"
        lines += "<td>" + parse_props.getHostName() + "</td>"
        lines += "<td>" + os.path.join(parse_props.get_inbound_dir(fileObj.source), fileObj.source, fileObj.frequency) + "</td>"
        lines += "<td>" + fileObj.fileDate + "</td>"
        # lines += "<td>" + 'Push' + "</td>"
        lines += "</tr>"
    
    pull_server_list = getSourcePullInfo(commonArgs.getSource())

    for fileObj in sourceFiles_pull:
        lines += "<tr>"
        lines += "<td>" + fileObj.fidoname + "</td>"
        if fileObj.foundServer == '':
            lines += "<td>" + pull_server_list + "</td>"
        else:
            lines += "<td>" + fileObj.foundServer + "</td>"
        lines += "<td>" + fileObj.relativeSourceFolder + "</td>"
        lines += "<td>" + fileObj.fileDate + "</td>"
        # lines += "<td>" + 'Pull' + "</td>"
        lines += "</tr>"

    lines += "</TABLE>"

    searchTable = lines

    return (htmlHeader + searchTable)


def special_email_missing_files(MissingRequiredFiles):
    if (len(MissingRequiredFiles) == 0):
        return

    missing_pull_inputs =  [x for x in MissingRequiredFiles if x.pullOrPush == 'pull']
    missing_push_inputs =  [x for x in MissingRequiredFiles if x.pullOrPush == 'push'] 

    all_missing_feeds = missing_pull_inputs + missing_push_inputs

    unique_email_ids_temp = []
    for fileobj in all_missing_feeds:
        if fileobj.error_cc_email_on_missingfile != '':
            unique_email_ids_temp.append(fileobj.error_cc_email_on_missingfile)

    unique_email_ids=list(set(unique_email_ids_temp))

    emailFrom = 'ERROR-Fido.'+ commonArgs.getApplication() + '.automation@lexisnexisrisk.com'

    subject = 'Fido feeds are missing'

    for i in range(0, len(unique_email_ids)):
        missing_files_pull = []
        missing_files_push = []
        # missing_files_pull.extend(fileObj  for fileObj in [x for x in all_pull_inputs if unique_email_ids[i] in x.error_cc_email_on_missingfile.split(',') ])
        # missing_files_push.extend(fileObj  for fileObj in [x for x in all_push_inputs if unique_email_ids[i] in x.error_cc_email_on_missingfile.split(',') ])
        missing_files_pull.extend(fileObj  for fileObj in [x for x in missing_pull_inputs if unique_email_ids[i] == x.error_cc_email_on_missingfile ])
        missing_files_push.extend(fileObj  for fileObj in [x for x in missing_push_inputs if unique_email_ids[i] == x.error_cc_email_on_missingfile ])
        print(unique_email_ids[i])
        msg = '<p>hi Team,</BR> The below are files are empty/unavailable for FIDO, please review </BR> </p>'
        missingFileEmailContent = msg + generateNotifyMissingFiles(missing_files_push,missing_files_pull)
        sendEmail.send(emailFrom, unique_email_ids[i], 'FIDOCoreTeam@risk.lexisnexis.com', subject, missingFileEmailContent)     
    print(all_missing_feeds)

def generateErrorInfo(sourceFiles):
    
    errorTable = ""
    wuErrorTable = ""
    errorMsgListStr = ""
    expectedMissingFileStr = ""
    optionalMissingFileStr = ""
    processerrorMsg = ""
    
    if not sourceFiles.status:
        # if parse_props.get_notify_source_on_file_missing(sourceFiles.source):
        #     special_email_missing_files(sourceFiles.list_of_expected_but_missing_files)

        errorTableTemp =  """<table id='builderror'>"""
        
        if sourceFiles.list_of_expected_but_missing_files:
            expectedMissingFileStr = ('<th>Error: Expected Files are Missing</th>')
            for item in sourceFiles.list_of_expected_but_missing_files:
                expectedMissingFileStr += ('<tr><td>' + item + '</td></tr>')
        
        errorTable = errorTableTemp + expectedMissingFileStr + '</td></tr></table>' if expectedMissingFileStr != '' else ''

    if sourceFiles.workunitstatus.lower() in ['failed', 'aborted']:
        errorMsgListStr =  """<table id='builderror'>
                            <tr>
                            <th>Error: Workunit didn't finish, it is {0}</th>
                            </tr><tr><td>""".format(sourceFiles.workunitstatus.lower())
    
        errorMsgList = sourceFiles.workunitMsg.split('\n')
        for item in errorMsgList:
            errorMsgListStr += ('<tr><td>' + item + '</td></tr>')
        errorMsgListStr += '</table>'

    if sourceFiles.processerrorMsg.strip() not in ['']:
        errorMsgListStr =  """<table id='builderror'>
                            <tr>
                            <th>Error: Process errored out, it is {0}</th>
                            </tr><tr><td>""".format(sourceFiles.processerrorMsg.lower())
    
        errorMsgList = sourceFiles.processerrorMsg.split('\n')
        for item in errorMsgList:
            errorMsgListStr += ('<tr><td>' + item + '</td></tr>')
        errorMsgListStr += '</table>'
        
    ErrorTable = errorTable + errorMsgListStr
    
    return ErrorTable

def logFileLink(sourceFiles):
    
    return '<table id="buildsuccess"><tr><td><a href="file:' + parse_props.getLogFileRef() +  sourceFiles.log_filename + '">LogFile</a></td></tr></table>'


def generate(sourceFiles):

    cssdata = open(parse_props.getCSSPath(), 'r').read()

    htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>""" + cssdata + "</style>"""
    
    sourceInfo = generateSourceInfo(sourceFiles)
    errorInfo = generateErrorInfo(sourceFiles)
    commonArgsInfoRow = ''    
    commonArgsInfoRow = commonArgsInfo()                   
    return (htmlHeader + errorInfo + sourceInfo + logFileLink(sourceFiles) + commonArgsInfoRow)

def notifyEmail(ssFiles):

    sourcefeedinfo = []

    temp_pull_files = commonSourceInfo.getPullRequiredFiles(ssFiles.source, ssFiles.frequency, ssFiles.file_date) + commonSourceInfo.getPullOptionalFiles(ssFiles.source, ssFiles.frequency, ssFiles.file_date) 
    temp_push_files = commonSourceInfo.getPushFiles(ssFiles.source, ssFiles.frequency, ssFiles.file_date);
    
    sourcefeedinfo.append(commonSourceInfo.getPullRequiredFiles(ssFiles.source, ssFiles.frequency, ssFiles.file_date));
    sourcefeedinfo.append(commonSourceInfo.getPullOptionalFiles(ssFiles.source, ssFiles.frequency, ssFiles.file_date));
    sourcefeedinfo.append(commonSourceInfo.getPushFiles(ssFiles.source, ssFiles.frequency, ssFiles.file_date));
    missingFileObjects = [ x for x in temp_pull_files if x.fidoname +',pull' in ssFiles.list_of_expected_but_missing_files] +  [ x for x in temp_push_files if x.fidoname +',push' in ssFiles.list_of_expected_but_missing_files]

    if parse_props.get_notify_source_on_file_missing(commonArgs.getSource()) and ssFiles.list_of_expected_but_missing_files != None and len(ssFiles.list_of_expected_but_missing_files) > 0:
        special_email_missing_files(missingFileObjects)
    successEmailFrom = 'SUCESS-Fido.'+ commonArgs.getApplication() + '.automation@lexisnexisrisk.com'
    errorEmailFrom  = 'ERROR-Fido.'+ commonArgs.getApplication() + '.automation@lexisnexisrisk.com'
    emailFrom = successEmailFrom if ssFiles.status else errorEmailFrom
    emailTo = ssFiles.successEmailTo if ssFiles.status else ssFiles.errorEmailTo
    PlatformPrefix = parse_props.getPlatform() + ' :: '  
    subjectPrefix = 'Success :: ' if ssFiles.status else 'Error :: '
    subject = subjectPrefix + PlatformPrefix + commonArgs.getApplication() + ' Build for ' + ssFiles.source + "-" + ssFiles.frequency + "-" + ssFiles.file_date
    msg = generate(ssFiles)
    print('Printing in NotifyEmail {0}'.format(ssFiles))
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com', subject, msg)     

def notifyWarningEmail(ssFiles):
    successEmailFrom = 'SUCESS-Fido.'+ commonArgs.getApplication() + '.automation@lexisnexisrisk.com'
    errorEmailFrom  = 'Warning-Fido.'+ commonArgs.getApplication() + '.automation@lexisnexisrisk.com'
    emailFrom = successEmailFrom if ssFiles.status else errorEmailFrom
    emailTo = ssFiles.successEmailTo if ssFiles.status else ssFiles.errorEmailTo
    PlatformPrefix = parse_props.getPlatform() + ' :: '  
    subjectPrefix = 'Success :: ' if ssFiles.status else 'Warning :: '
    subject = subjectPrefix + PlatformPrefix + commonArgs.getApplication() + ' Build for ' + ssFiles.source + "-" + ssFiles.frequency + "-" + ssFiles.file_date
    msg = generate(ssFiles)
    print('Printing in NotifyEmail {0}'.format(ssFiles))
    sendEmail.send(emailFrom, emailTo, 'raju.nagarajan@lexisnexisrisk.com', subject, msg)  