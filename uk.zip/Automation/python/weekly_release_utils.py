import pandas as pd
import json
import traceback
import sys
from datetime import datetime
import commonArgs
import getProperties
import parseYamlProperty as parse_props
import os
import pyodbc
import subprocess
import re
import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
import AutomationLogging
from vault.secrets import get_db_secret, get_api_secret

base_path = "{0}weekly-code-release".format(parse_props.get_app_dir())
logger = AutomationLogging.getLogger('preprocess_weekly_release_utils')
_svc_acct, _svc_pwd = get_api_secret(logger, 'hpccthor')
constant_table_view_name = 'Table/Object/Report'
constant_change = 'Change'
constant_change_type = 'Object Type'
constant_sql_ecl_type = 'Type of change (SQL, OBIEE,ECL)'
constant_application = 'Application'
constant_dim_fact = 'dim/fact name'
constant_despray_start_month = 'despray_start_month'
constant_despray_end_month = 'despray_end_month'
constant_modify_keep = 'columns to modify and keep'
constant_jira_ticket = 'Jira Ticket'
constant_despray_by_developer = 'despray by developer'

def getDeltas(x, y):
    return (list(set(x) - set(y)))

def check_and_create(dir_name):
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)


def read_despray_excel(file_path):
    try:
        excel_opject = pd.ExcelFile(file_path)
        sheet_name_list = excel_opject.sheet_names
        df = excel_opject.parse(0, skiprows=0, na_values='', keep_default_na=False)
        df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        app_name = commonArgs.getApplication().lower()
                    
        file_columns = df.columns.values
        # required_columns = [constant_table_view_name, constant_change, constant_change_type, constant_sql_ecl_type, constant_application, constant_dim_fact, constant_despray_start_month, constant_despray_end_month, constant_modify_keep, constant_jira_ticket, constant_despray_by_developer]
        # missing_columns = getDeltas(required_columns, file_columns)

        # if missing_columns:
        #     missing_coulmn_string = ",".join(missing_columns)
        #     raise Exception("Excel file following column missing {0}".format(missing_coulmn_string))

        return df#[df['Application'].str.lower() == app_name]
        # return df
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = ''.join(line for line in lines)
        print(processerrorMsg)
        
def read_excel(file_path, sheet_name, skip_rows = 0):
    try:
        excel_opject = pd.ExcelFile(file_path)
        sheet_name_list = excel_opject.sheet_names
        if sheet_name in sheet_name_list:
            df = excel_opject.parse(sheet_name, skiprows=skip_rows, na_values='', keep_default_na=False)
            df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            app_name = commonArgs.getApplication().lower()
        else:
            raise Exception("Excel file don't have sheetname {0}".format(sheet_name))
                    
        file_columns = df.columns.values
        required_columns = [constant_table_view_name, constant_change, constant_change_type, constant_sql_ecl_type, constant_application, constant_dim_fact, constant_despray_start_month, constant_despray_end_month, constant_modify_keep, constant_jira_ticket, constant_despray_by_developer]
        missing_columns = getDeltas(required_columns, file_columns)

        if missing_columns:
            missing_coulmn_string = ",".join(missing_columns)
            raise Exception("Excel file following column missing {0}".format(missing_coulmn_string))

        return df[df['Application'].str.lower() == app_name]
        # return df
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('\n\n{0}'.format(ex.args[0]))
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg = ''.join(line for line in lines)
        print(processerrorMsg)

def read_cred_for_server(logger, server_name):
    with open(getProperties.getSQL_credJsonFilename(), 'r') as f:
      data = json.load(f)
    data_dict = {k:v for item in data for k,v in item.items()}  # flatten data for easy access
    cred = data_dict[server_name][0]
    server = cred['sql_server'] + ',' + cred['port']  # sql_server,port format
    uname, pwd = get_db_secret(logger, server_name)
    return server, uname, pwd

def get_release_date():
    if(commonArgs.getFiledate() == ''):
        release_date = datetime.today().strftime('%Y%m%d')
    else:
        release_date = commonArgs.getFiledate()
    return release_date

def get_script_path():
    release_date = get_release_date()
    app_name = commonArgs.getApplication().lower()
    scripts_path = '{0}\\{1}\\scripts\\{2}\\'.format(base_path, release_date, app_name)
    return scripts_path

def get_despray_path():
    release_date = get_release_date()
    scripts_path = '{0}data\\outbound\\sql\\dm\\weekly_release_{1}\\'.format(parse_props.get_app_dir(), release_date)
    return scripts_path

def get_sql_adhoc_path():
    scripts_path = '{0}data\\outbound\\sql\\dm\\adhoc\\'.format(parse_props.get_app_dir())
    return scripts_path

def insert_query_maker(tablename, rowdict):
    keys = tuple(rowdict)
    dictsize = len(rowdict)
    sql = ''
    for i in range(dictsize) :
        if(type(rowdict[keys[i]]).__name__ == 'str'):
            sql += '\'' + str(rowdict[keys[i]]) + '\''
        else:
            sql += str(rowdict[keys[i]])
        if(i< dictsize-1):
            sql += ', '    
    
    query = "insert into " + str(tablename) + " " + str(keys).replace("'", "") + " values (" + sql + ")"
    return(query) 
    
def check_load_tables_filegroup_record(obj_name, server, db, uid, pwd):
    conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};Server='+server+';Database='+db+';UID='+uid+';PWD='+pwd+'')
    sql_query = "select count(*) from load_tables_filegroup where table_name = '{0}'".format(obj_name)
    cursor = conn.cursor().execute(sql_query)

    count_record = 0 
    for row in cursor.fetchall():
        count_record = row[0]

    conn.close()

    return count_record

def get_insert_file_group(obj_name, server, db, uid, pwd):
    conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};Server='+server+';Database='+db+';UID='+uid+';PWD='+pwd+'')
    sql_query = "select * from load_tables_filegroup where table_name = '{0}'".format(obj_name)
    cursor = conn.cursor().execute(sql_query)
    columns = [column[0] for column in cursor.description]
    results =[]
    for row in cursor.fetchall():
        results.append(dict(zip(columns, row)))

    insert_query = ''
    if results:
        myDict = results[0]
        table = 'load_tables_filegroup'
        insert_query = insert_query_maker(table, myDict)
    conn.close()

    return insert_query


def get_base_path():    
    return base_path


def sql_metadata_exp(logger, server, db, u, p, obj_name, file_loc):
    str_nm = 'mssql-scripter -S="%s", -d="%s" -U="%s" -P="%s" --include-objects=%s -f %s --file-per-object --data-compressions' % (server, db, u, p ,obj_name, file_loc)
    logger.debug('sql_metadata_exp query string {0}'.format(str_nm))
    sub_a = subprocess.Popen(str_nm, shell= True) 
    # sub_a = subprocess.Popen(str_nm, shell= True) 
    stdout_sub_a = sub_a.communicate()[0]
    
def table_column_structure(server, db, uid, pwd, schm, tbl):
    conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};Server='+server+';Database='+db+';UID='+uid+';PWD='+pwd+'')
    
    query = '''select * from get_table_definition('schm.table_variable')'''
    first_chnge = re.sub(r'schm', schm, query)
    sql_query = pd.read_sql_query(re.sub(r'table_variable', tbl, first_chnge), conn)
    conn.close()
    return sql_query

def file_idx_usr_grp(logger, server, db, uid, pwd, tbl_name, object_type):
    partition_by_column = ''
    if object_type.lower().strip() == 'table':
        partition_by_column = check_partition_table(logger, tbl_name, db)
    if partition_by_column == '':
        conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};Server='+server+';Database='+db+';UID='+uid+';PWD='+pwd+'')
        file_grp_usr = pd.read_sql_query(
                            '''
                            select top 1 FILEGROUP_NAME from  [dbo].[get_file_group_allocation]() where SUBSTRING(FILEGROUP_NAME, 1,6) = 'FG_USR' order by freespace_percent desc
                            ''', conn)
        # file_grp_idx = pd.read_sql_query(
        #                     '''
        #                     select top 1 FILEGROUP_NAME from  [dbo].[get_file_group_allocation]() where SUBSTRING(FILEGROUP_NAME, 1,6) = 'FG_IDX' order by freespace_percent desc
        #                     ''', conn)
        file_grp_usr = list(file_grp_usr.values[0])[0]
        user_group_number = re.findall(r'\d{2,}', file_grp_usr)
        file_grp_idx = "FG_IDX{0}".format(user_group_number[-1])
        conn.close()
        return file_grp_usr, file_grp_idx
    else:
        return 'PS_FG_USR01', 'PS_FG_IDX01'

def add_record_into_load_table_filegroup_sql_file(logger, dserver_name, pserver_name, without_dbo, release_flag = False):
    insert_file_group_sql = get_script_path() +'\\Table\\insert_loads_tables_filegroup.sql'
    (pserver, puid, ppwd) = read_cred_for_server(logger, pserver_name)
    (dserver, duid, dpwd) = read_cred_for_server(logger, dserver_name)
    usr, idx = file_idx_usr_grp(logger, pserver, commonArgs.getApplication(), puid, ppwd, without_dbo, 'table')
    usr = re.sub('PS_', '', usr, flags=re.I) 
    idx = re.sub('PS_', '', idx, flags=re.I) 
    insert_file_group_query = get_insert_file_group(without_dbo, dserver, commonArgs.getApplication(), duid, dpwd )
    logger.debug('Insert sql file name  {0}'.format(insert_file_group_sql))
    if release_flag:
        re_tbl_str = "\'{0}\'".format(without_dbo)
        re_stage_str = "\'release_{0}\'".format(without_dbo)
        insert_file_group_query = re.sub(re_tbl_str, re_stage_str, insert_file_group_query, flags=re.I) 

    re_usr = "\'{0}\'".format(usr)
    re_idx = "\'{0}\'".format(idx)                
    insert_file_group_query = re.sub(r'\'\w*FG_IDX\d{2}\'', re_idx, insert_file_group_query, flags=re.I)
    insert_file_group_query = re.sub(r'\'\w*FG_USR\d{2}\'', re_usr, insert_file_group_query, flags=re.I)             
    insert_file_group_query = re.sub(r'None', "NULL", insert_file_group_query)
    insert_file_group_query = re.sub(r'True', "\'True\'", insert_file_group_query)
    insert_file_group_query = re.sub(r'False', "\'False\'", insert_file_group_query) 
                    
    if insert_file_group_query != '':
        fp = open(insert_file_group_sql, 'a')
        fp.writelines('\n') 
        string = "use {0};\n{1};\n".format(commonArgs.getApplication(), insert_file_group_query)
        fp.writelines(string)
        fp.close()

    return

def get_logical_filename_layout(logical_file, hpccurl = parse_props.getHPCCURL()):
    wdetails_soap_url = "{0}/wsdfu/dFUDefFile?Name={1}&Format=xml".format(hpccurl, logical_file)

    ecl_column_list = []
    try:
        proxies = {
            "http": None,
            "https": None,
            }        
        ret = requests.post(wdetails_soap_url, auth=HTTPBasicAuth(_svc_acct, _svc_pwd), proxies=proxies)
        xmlstr = ret.text
        root = ET.fromstring(xmlstr)        
        if len(root):
            for i in range(0, len(root)-1):
                ecl_column_list.append(root[i].attrib['label'])
        print(ecl_column_list)
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        # return(False, processerrorMsg)
    return(ecl_column_list)


def check_partition_table(logger, obj_name, db):
    (server, uid, pwd) = read_cred_for_server(logger, 'DEV_SQl_DB_CRED')
    conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};Server='+server+';Database='+db+';UID='+uid+';PWD='+pwd+'')
    sql_query = "select partition_column from load_tables_filegroup where table_name = '{0}'".format(obj_name)
    cursor = conn.cursor().execute(sql_query)

    partition_by_values = ''
    for row in cursor.fetchall():
        partition_by_values = row[0]

    if partition_by_values is None:
        partition_by_values = ''

    conn.close()

    return partition_by_values

def status_mark_as_issue_list(df, jira_task, status_dict):
    df_jira = df.loc[(df['Jira Ticket'] == jira_task)]
    insert_file_group_sql = get_script_path() +'\\Table\\insert_loads_tables_filegroup.sql'
    for index, row in df_jira.iterrows():
        obj_name = row['Table/Object/Report']
        listsstatus =[]
        listsstatus.append('False')
        listsstatus.append(jira_task.lower())
        listsstatus.append('One of the Jira object having issue')
        status_dict[obj_name] = listsstatus        
            
    return status_dict