#import datetime
from datetime import datetime
import shutil
import os
import paramiko
import sys
import traceback
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret

source_file =  parseYamlProperty.get_outbound_dir() +  "extract\\instant_id\\instant_id_batchr3_extract.tsv"
dest_file = "/incoming/iam_batchr3_extract.tsv"

class GracefullyExit(Exception):
    pass

def getToday():
   today = datetime.now()
   return today.strftime("%Y%m%d")

def printwrapper(str, errorFlag=False):
    print(str)
    if errorFlag:
       printList.reverse()
       printList.append(str)
       printList.reverse()
    else:
       printList.append(str)

def createlog(source):
    #print(len(printList))
    if len(printList) > 0:
        logger = AutomationLogging.getLogger('IID')
        # logfile = open('D:\\red\\applogs\\python\\extract\\iam_batchr3_extract\\'+source +'_' + datetime.now().strftime('%m-%d-%Y_%H_%M_%S'), 'w')
        for str in printList:
            # logfile.write('%s\n' %str)
            logger.debug('%s\n' %str)
        #logfile.close()
 
class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40) 
 
def process():
    global printList
    printList = []
    #ssh_conn = FastTransport((mySQLsource.host, 22))
    #ssh_conn.connect(username=mySQLsource.uname,password=mySQLsource.pwd)
    ssh_conn = FastTransport(("batchtransfer.seisint.com", 22))
    logger = AutomationLogging.getLogger('preprocess_instant_id_batchr3_push')
    uname, pwd = get_api_secret(logger, 'batchtransfer')
    ssh_conn.connect(username=uname, password=pwd)
    sftp_client = paramiko.SFTPClient.from_transport(ssh_conn)
    print(source_file)
    sftp_client.put(source_file, dest_file)

if __name__ == '__main__':
   try:
     process()
   except Exception as ex:
     exc_type, exc_value, exc_traceback = sys.exc_info()
     lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
     processerrorMsg =  ''.join(line for line in lines)
     #print(processerrorMsg)
     printwrapper('\n\n{0}'.format(processerrorMsg))
   finally:
     printwrapper('\n**********\nAll Done!\n**********')
     createlog('iam_batchr3_extract')