from jira import JIRA
import sys, http.client, os
import json
import csv
from collections import defaultdict
from datetime import datetime, timedelta
import parseYamlProperty
import AutomationLogging
from vault.secrets import get_api_secret

#'project != EMPTY and updatedDate > startOfDay()'  updated>= "2020-05-02" 'os.path.join(parseYamlProperty.get_inbound_dir() + jira\daily\worklog_'
sys.stdout = open(os.path.join(parseYamlProperty.get_build_logs_dir() ,'jira//worklog_'+ datetime.now().strftime('%Y%m%d') + '.txt'),'w')
#sys.stdout = open('D:\\red\\applogs\\worklog_'+ datetime.now().strftime('%Y%m%d') + '.txt','w')
def main():

	options = {'server': 'https://jira.rsi.lexisnexis.com/'}
	logger = AutomationLogging.getLogger('jira_worklog', True)
	uname, pwd = get_api_secret(logger, 'jira')
	jira = JIRA(options, basic_auth=(uname, pwd))
	blocksize=100
	blocknum=0
	issues= []
	while True:
		print('working')
		startidx=blocknum*blocksize
		newissues=jira.search_issues('project !=EMPTY and   worklogDate > -5d and worklogDate <= 1d ' , startidx, blocksize)
		# newissues=jira.search_issues('project != EMPTY and   worklogDate >= "2019/01/01" AND worklogDate <= "2019/01/31" ' , startidx, blocksize)
		#'project !=EMPTY and updatedDate >  startOfDay()'
		numissues=len(newissues)
		if  numissues==0 or  blocknum==100:
			break
		blocknum+=1
		issues.append(newissues)
	issuecount=0
	issuesfile=open(os.path.join(parseYamlProperty.get_inbound_dir() ,'jira//daily//worklog_'+ datetime.now().strftime('%Y%m%d') + '.csv'),"w+", encoding='utf-8',newline="")
	#issuesfile=open('D:\\red\\data\\inbound\\jira\daily\\ jira\\daily\\worklog_' + datetime.now().strftime('%Y%m%d') + '.csv',"w+", encoding='utf-8',newline="")
	issueswriter=csv.writer(issuesfile)
	fieldname = ['author','created','timeSpentSeconds','timeSpent','started','updateAuthor','key','updated','id','issueid']
	issueswriter.writerow(fieldname)
	for resultlist in issues:
		for issue in resultlist:
			dict=issue.raw
			issueId=dict['id']
            #fields=dict['worklog']            
			print(issueId)
			worklogs=jira.worklogs(issueId)
			for worklog in worklogs:
				issueswriter.writerow([worklog.author,worklog.created,worklog.timeSpentSeconds,worklog.timeSpent,worklog.started,worklog.updateAuthor,worklog.author.key,worklog.updated,worklog.id,issueId ])
	issuesfile.close()
	#f.close()
if __name__== "__main__" :
     main()

            
            
            
            
            
            
            
            