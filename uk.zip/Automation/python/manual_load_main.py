import os
import json
import time
import shutil
import random
import sqlalchemy
import getSQLdata
import commonArgs
import numpy as np
import pandas as pd
import urllib.parse
import datetime as dt
import runSourceBuilds
import parseYamlProperty

from fido_utils import *
from string import Template
from datetime import datetime
from vault.secrets import get_api_secret
from AutomationLogging import getLogger
from getProperties import getPropertyDir
from distutils.command.build import build
from manual_load_validation import Validation
from multiprocessing.dummy import Pool as ThreadPool
from manual_load_send_email import send_mail, send_to_teams_channel, send_mail_with_table

# Set up program - get global variables and setting i.e. todaysdate, env, host, landing zones
global engine, logger, json_file_path, process_timestamp, program_timestamp, email_timestamp, manual_adjustment, hpcc_landing_zone, hpcc_configurations, hpcc_landing_zone_archive, validations, communications, env_subj, file_count, teams_webhook_path, admin

# program_timestamp = datetime.fromisoformat('2023-07-13 18:18:48').strftime('%Y-%m-%d %H:%M:%S') # for testing purposes
program_timestamp = getCurrentTimeStamp()
email_timestamp   = formatDate(datetime.fromisoformat(program_timestamp), "%m/%d/%Y %I:%M %p")
process_timestamp = formatDate(datetime.fromisoformat(program_timestamp), "%Y%m%d%H%M%S")
working_timestamp = formatDate(datetime.fromisoformat(program_timestamp), "%Y%m%d_%H%M%S")

debug_log = pd.DataFrame()
logger = getLogger('main')
logger.debug("Running set up")

#app, env and freq
env  = commonArgs.getEnv()
app  = commonArgs.getApplication()
freq = commonArgs.getFrequency()

# vault secrets
teams_webhook_path = get_api_secret(logger, f"manual_load_{env if env == 'dev' else 'user'}_webhook_path", secret='pwd')
admin = get_api_secret(logger, 'hpccthor', secret='uname')

#json configuration file 
json_file_path = getPropertyDir() + f'\\{app}_manual_load_config.json'

with open(json_file_path, 'r') as json_file:
    data = json.load(json_file)

validations = dict(data["validations"])
communications = dict(data["communications"])
current_templates = list(data["current_templates"])
hpcc_configurations = dict(data["hpcc_configurations"])

#current envirmant path files
outbound_manual = parseYamlProperty.get_outbound_dir() + 'manual\\'
inbound_forcast = parseYamlProperty.get_inbound_dir() + 'forecast\\'
inbound_manual_adhoc = parseYamlProperty.get_inbound_dir() + 'manual\\adhoc\\'
manual_adjustment = parseYamlProperty.get_inbound_dir() + 'manual_adjustment\\'
report_template = parseYamlProperty.get_base_dir() + '\python\manual_load_template_report.html'

# Landing zones and archives
source_file_archive = manual_adjustment + 'archive\\'
hpcc_landing_zone = inbound_manual_adhoc + 'working\\'
inbound_forcast_working = inbound_forcast + 'working\\'
inbound_forcast_adhoc = inbound_forcast + 'adhoc\\working\\'
hpcc_landing_zone_archive = inbound_manual_adhoc + 'archive\\'
inbound_forcast_archive = inbound_forcast_working + 'Archive\\'
hpcc_outbound_landing_zone_archive = outbound_manual + 'archive\\'

# Subject environment
env_subj = f"{'DEV :: ' if env == 'dev' else ''}{app.upper()} :: "

# Source file folders
drop_zone_folder_paths = [manual_adjustment + v for _,v in dict(communications["drop_zone_folders"]).items()]

#database connection string
connection_string = getSQLdata.getSourcePullInfo(logger, "fido_dev" if env=='dev' else "fido_prod", "daily", "trial")
if app.upper() == "RBI":   
    modified_conn_string = str(connection_string[0]).replace("DEV_SQl_DB_CRED", "rbi").replace("PROD_SQl_DB_CRED", "rbi")
    modified_conn_string = modified_conn_string.replace("ALAWDREDSQL201", "alawdredsql201.risk.regn.net,50255")
    modified_conn_string = modified_conn_string.replace("ALAWPREDSQLCL1\SQLPRD01", "ALAWPREDSQLCL1\\SQLPRD01,50750")
    connection_uri = f"mssql+pyodbc://?odbc_connect={urllib.parse.quote_plus(''.join(modified_conn_string))}"
else:
    connection_string = getSQLdata.getSourcePullInfo(logger, "fido_dev" if env=='dev' else "fido_prod", "daily", "trial")
    connection_uri = f"mssql+pyodbc://?odbc_connect={urllib.parse.quote_plus(''.join(connection_string))}" 
engine = sqlalchemy.create_engine(connection_uri, fast_executemany=True)

file_count = 0

def pre_setup_check():
    '''
    Ensure that these folder are available in the current environement
    '''
    if not os.path.isdir(hpcc_landing_zone):
        os.makedirs(hpcc_landing_zone)
    if not os.path.isdir(source_file_archive):
        os.makedirs(source_file_archive)
    if not os.path.isdir(hpcc_landing_zone_archive):
        os.makedirs(hpcc_landing_zone_archive)
    if not os.path.isdir(hpcc_outbound_landing_zone_archive):
        os.makedirs(hpcc_outbound_landing_zone_archive)

    try:
        if os.path.isdir(hpcc_landing_zone + today + '\\'):
            t_files = os.listdir(hpcc_landing_zone + today + '\\')
            if len(t_files) >= 1:
                for t_file in t_files:
                    t = t_file.rstrip(f'{today}.txt').rstrip("_")
                    if t in hpcc_configurations:
                        if os.path.exists(hpcc_landing_zone + today + '\\' + t_file):
                            os.remove(hpcc_landing_zone + today + '\\' + t_file)

        if os.path.isdir(inbound_forcast_adhoc + today + '\\'):
            t_files = os.listdir(inbound_forcast_adhoc + today + '\\')
            if len(t_files) >= 1:
                for t_file in t_files:
                    t = t_file.rstrip(f'.txt').rstrip("_")
                    if t in hpcc_configurations:
                        if os.path.exists(inbound_forcast_adhoc + today + '\\' + t_file):
                            os.remove(inbound_forcast_adhoc + today + '\\' + t_file)

        if os.path.isdir(manual_adjustment + str(today) + '\\'):
            t_files = os.listdir(manual_adjustment + str(today) + '\\')
            if len(t_files) >= 1:
                for t_file in t_files:
                    if os.path.exists(manual_adjustment + str(today) + '\\' + t_file):
                        os.remove(manual_adjustment + str(today) + '\\' + t_file)

    except Exception as err:
        teams_alert(err, 'Pre setup. Removing previous files!')

    
def initial_transfer():
    '''
    Function that checks the designated bussines unit folders for any excell files. If any are found 
    transfer is initiated. If in dev the files are copied and overwritten int he destination folder
    and moved when in production. An alert is sent via teams and email to alert concerned parties
    '''
    global file_count
    write_to_log("Checking and transfering source files")
    destination = manual_adjustment + str(today) + '\\'
    if not os.path.exists(destination):
        os.makedirs(destination)

    source_files = []
    source_folders = []
    notify_email = {}

    for folder_path in drop_zone_folder_paths:
        if os.path.isdir(folder_path):
            allfiles = os.listdir(folder_path)
            folder_name = str(os.path.basename(folder_path))
            input_data_files = [folder_path + '\\' + f for f in allfiles if f.lower().endswith("xlsx") or f.lower().endswith("txt") or f.lower().endswith("csv")]
            source_files.extend([f for f in allfiles if f.lower().endswith("xlsx") or f.lower().endswith("txt") or f.lower().endswith("csv")])
            file_count += len(input_data_files)

            if len(input_data_files) >= 1:
                write_to_log(f"File(s) found in {folder_name} folder")
                notify_email[folder_name] = {
                    "count" : len(input_data_files),
                    "email" : communications["distribution_list"][folder_name],
                    "files" : []
                }
                
                source_folders.append(folder_name)
                count = 0
                for i, source in enumerate(input_data_files):
                    try:
                        basename = str(os.path.basename(source))

                        #### https://jira.rsi.lexisnexis.com/browse/FMR-8560
                        basename = basename.replace(folder_name + "_", '') # remove folder name from resubmited files
                        notify_email[folder_name]["files"].append(basename)
                        basename = "_".join(basename.split(" ")) # add hypens to filename to distinguish username
                        #### 

                        newfilename = folder_name + '_' + basename.replace("'", "") 
                        shutil.move(source, os.path.join(destination, newfilename))
                        count += 1
                    except Exception as err:
                        teams_alert(err, 'Manual Load File Transfer')
                        continue

    forecast_source = inbound_forcast_working + str(today) + '\\'
    if os.path.isdir(forecast_source):
        allfiles = os.listdir(forecast_source)
        folder_name = "Forecast"
        input_data_files = [forecast_source + f for f in allfiles if f.lower().endswith("txt")]
        source_files.extend([f for f in allfiles if f.lower().endswith("txt")])
        file_count += len(input_data_files)

        if len(input_data_files) >= 1:
            write_to_log(f"File(s) found in {folder_name} folder")
            notify_email[folder_name] = {
                "count" : len(input_data_files),
                "email" : communications["distribution_list"][folder_name],
                "files" : []
            }
            source_folders.append(folder_name)
            for i, source in enumerate(input_data_files):
                try:
                    basename = str(os.path.basename(source))

                    ## https://jira.rsi.lexisnexis.com/browse/FMR-8560 
                    ## remove folder name from resubmited files
                    basename = basename.replace(folder_name + "_", '') 

                    ## https://jira.rsi.lexisnexis.com/browse/FMR-9795 
                    ## remove username from resubmited files
                    basename = basename.replace(f"_{admin}_{i+1:02d}", '').replace("'", "")

                    notify_email[folder_name]["files"].append(basename)
                    newfilename = folder_name + '_' + basename.replace(".txt", f"_{admin}_{i+1:02d}.txt")
                    shutil.move(source, os.path.join(destination, newfilename))
                except Exception as err:
                    teams_alert(err, 'Forecast File Transfer')
                    continue


    write_to_log(f"File(s) collected - {len(source_files)}")
    if len(source_files) >= 1:

        for i, folder in enumerate(notify_email):
            files = f'\n\t\t* '.join(list(notify_email[folder]["files"]))
            send_mail(
                send_from=communications["send_from"],
                send_to=communications['team_list'] if env=='dev' else notify_email[folder]["email"],
                send_cc=[] if env=='dev' else communications["CC"],
                subject=env_subj + communications['report']['alert'] + f'{folder} file(s) found.',
                text=f"""
                Automation system has began {email_timestamp}. Processing {notify_email[folder]['count']} file(s) from {folder} folder.
                Files collected:
                \t* {files}
                """
            )
            
        send_to_teams_channel(
            webhook=communications["teams_webhook_url"].format(teams_webhook_path),
            title=env_subj + communications['report']['alert'] + f'File(s) found.',
            message=f"Automation system has began. Processing {len(source_files)} file(s)."
        )


def pre_process_validation():
    """
    This function gets all files from the source file landing zone and filters the list based 
    by excell files. Pre-validation is then excecuted in a multithread process if the files in
    the correct format are found.
    """

    allFiles = os.listdir(manual_adjustment + str(today) + '\\')
    source_files = [manual_adjustment + str(today) + '\\' + f for f in allFiles if f.lower().endswith("xlsx") or f.lower().endswith("txt") or f.lower().endswith("csv")]
    allFiles = [os.path.basename(source) for source in source_files]

    if len(source_files) >= 1:
        start_time = time.time()

        write_to_log("Running multithread preprocess validation")

        with ThreadPool(len(source_files)) as pool:
            pool.starmap(run_pre_process_validation, zip(source_files))

        end_time = time.time() - start_time
        write_to_log(f'Pre-processing {len(source_files)} input files took {str(dt.timedelta(seconds=end_time))} time using multiprocessing')
    else:
        write_to_log("No files in the correct format were found")


def run_pre_process_validation(file_path):
    """
    run_pre_process_validation:
        This functions calls the validation class with all initialization 
        and executes the main validation process
    """
    try:
        validate = Validation(
            engine=engine,
            teams_webhook_path=teams_webhook_path,
            file_path=file_path,
            source_path=manual_adjustment,
            json_file_path=json_file_path,
            hpcc_landing_zone=hpcc_landing_zone,
            program_timestamp=program_timestamp,
            working_timestamp=working_timestamp,
            source_file_archive=source_file_archive,
            inbound_forcast_adhoc=inbound_forcast_adhoc,
            inbound_forcast_working=inbound_forcast_working,
            inbound_forcast_archive=inbound_forcast_archive
        )
        validate.run()
    except Exception as err:
        teams_alert(f"{os.path.basename(file_path)}\t{err}", 'Prevalidation Error')


def ecl_validation():
    """
    This functions gets the template names from the data files that were created 
    by the pre-validation process. If template files are founds then a mutlithread 
    process is excuted running validation on hpcc.
    """
    hpcc_files = []
    # check for files in the manual inbound landing zone folder
    if os.path.isdir(hpcc_landing_zone + str(today) + '\\'):
        data_folders = os.listdir(hpcc_landing_zone + str(today) + '\\')
        files = ['_'.join(file.rstrip('.txt').split('_')[:-1]) for file in data_folders]
        manual_files = [f for f in files if f in hpcc_configurations and hpcc_configurations[f]["validation"]]
        if len(manual_files) >= 1:
            hpcc_files.extend(manual_files)
        else:
            write_to_log("No manual inbound file(s) available for validation.", warning=True)
    else:
        write_to_log("No manual inbound file(s) available for validation.", warning=True)

    # check for files in the forecast inbound landing zone folder
    if os.path.isdir(inbound_forcast_adhoc + str(today) + '\\'):
        data_folders = os.listdir(inbound_forcast_adhoc + str(today) + '\\')
        files = [file.rstrip('.txt') for file in data_folders]
        forecast_files = [f for f in files if f in hpcc_configurations and hpcc_configurations[f]["validation"]]
        if len(forecast_files) >= 1:
            hpcc_files.extend(forecast_files)
        else:
            write_to_log("No forecast inbound file(s) available for validation.", warning=True)
    else:
        write_to_log("No forecast inbound file(s) available for validation.", warning=True)

    # run ECL validations 
    if len(hpcc_files) >= 1:
        write_to_log("Running multithread forecast ecl hthor validation")
        start_time = time.time()

        with ThreadPool(len(hpcc_files)) as pool:
            pool.starmap(hpcc_hthor_validation, zip(hpcc_files))

        end_time = time.time() - start_time
        write_to_log(f'ECL validations {len(hpcc_files)} input files took {str(dt.timedelta(seconds=end_time))} time using multiprocessing')
    

def hpcc_hthor_validation(hpcc_file: str, attempts=5):
    """
    hpcc_hthor_validation: 
        using the configuration file and data, this function determine whether a template requires 
        validation in HPCC. if it doesnt the file is skipped. If the validation is 
        not completed then we archive the file as data with errors
    """
    try:
        validation = dict(hpcc_configurations[hpcc_file]["validation"])
        template = hpcc_configurations[hpcc_file]['template']
        time.sleep(int(validation["sleep_time"]))
        write_to_log(f"Starting validation for hpcc_file {hpcc_file}")

        #get the worksheet/tab/layout that contained the dat to be validated
        for sheet, config in dict(validations[template]).items():
            if config["data_file"] == hpcc_file:
                current_sheet = sheet.split('_')[0] if template == "fact_forecast_details" else sheet
                break

        workunit = wuMsg = status = ""

        try:
            time.sleep(int(validation["sleep_time"]))
            sourceRun = runSourceBuilds.commonSourceFiles(validation["build"], freq, 'fromHPCC')
            sourceRun.file_date = today
            time.sleep(int(validation["sleep_time"]))
            (workunit, status, wuMsg) = runSourceBuilds.eclCall(sourceRun)
        except Exception as err:
            teams_alert(err, f"{validation['build']} source run")
            if attempts >= 1:
                time.sleep(1)
                write_to_log(f"Re-attempting source run function execution. {attempts-1} more attempts left.")
                hpcc_hthor_validation(hpcc_file, attempts-1)
            else:
                teams_alert("hpcc_hthor_validation function attempts failed")
        else:
            write_to_log(f"Validation build for {hpcc_file} status: {status}!", error=(status != "completed"))

            if wuMsg is not None and len(wuMsg) > 0:
                wuMsg = wuMsg.replace('\n', '').replace('\r','')
                write_to_log(wuMsg, error=(status != "completed"))

            # Archive the file if the validation status is not complete
            # for forecast data there are a group of files involved so all file will need to be archived as well 
            if status != "completed":
                update_report(wuid=workunit, template=template, sheet=current_sheet, ecl_validation=0, validation_wumsg=wuMsg)
                if template == "fact_forecast_details":
                    group = hpcc_configurations[hpcc_file]['group']
                    data_folders = os.listdir(inbound_forcast_adhoc + str(today) + '\\')
                    files = [file.rstrip('.txt') for file in data_folders]
                    lz_files = [f for f in files if f in hpcc_configurations and hpcc_configurations[f]["group"] == group]
                    for lz_file in lz_files:
                        archive_file(target='DataWithErrors',source_file=lz_file + '.txt', t_source='forecast')
                else:
                    archive_file(target='DataWithErrors',source_file=hpcc_file + f'_{today}.txt')
            else:   
                # Forecast validation involves more than one related submited file 
                # so we update all records involved 
                if template == "fact_forecast_details":
                    update_report(wuid=workunit, template=template, sheet=current_sheet, ecl_validation=1, validation_wumsg=wuMsg)
                else:
                    try:
                        # HPCC validation desprays a summary file in the outbound folder 
                        # summary file contains report level details attained from the vlaidation process
                        # we update these details in the manualloadreport table 

                        despray_summary_file = outbound_manual + today + "\\" + hpcc_file + "_summary.tsv"
                        assert os.path.exists(despray_summary_file), f"Summary data for {hpcc_file} was not desprayed"
                        df_from_hpcc = pd.read_csv(despray_summary_file, delimiter='\t')
                        df_from_hpcc["eclvalidation"] = df_from_hpcc["eclvalidation"].map(dict(passed=1, failed=0))
                        
                        write_to_log(f"Updating ManualLoadReport table with {len(df_from_hpcc)} row(s)")
                        for f, w, v, t in zip(list(df_from_hpcc["input_filename"]), list(df_from_hpcc["worksheet"]), list(df_from_hpcc["eclvalidation"]), list(df_from_hpcc["template"])):
                            update_report(wuid=workunit,template=t, sheet=w,ecl_validation=v,validation_wumsg=wuMsg,input_filename=f)
                        if (df_from_hpcc["eclvalidation"] == 0).all():
                            archive_file(target='DataWithErrors',source_file=hpcc_file + f'_{today}.txt')
                        archive_file('', hpcc_file + "_summary.tsv", lz='outbound')
                    except Exception as err:
                        teams_alert(err, "Updating ManualLoadReport")

                    try:
                        # HPCC validation desprays a error log file in the outbound folder 
                        # this file contains any possible error logs from the ecl validation
                        # we update these details in the ManualLoadLog table

                        despray_log_file = outbound_manual + today + "\\" + hpcc_file + "_error_logs.tsv"
                        assert os.path.exists(despray_log_file), f"Log data for {hpcc_file} was not desprayed"
                        hpcc_errors_ds = pd.read_csv(despray_log_file, delimiter='\t')
                        hpcc_errors_ds['start_datetime'] = [program_timestamp for _ in range(len(hpcc_errors_ds))]
                        hpcc_errors_ds['working_timestamp'] = [working_timestamp for _ in range(len(hpcc_errors_ds))]
                        write_to_log(f"Updating ManualLoadLogs table with {len(hpcc_errors_ds)} row(s)")
                        rows_affected = hpcc_errors_ds.to_sql('ManualLoadLogs', con=engine, if_exists="append", index=False, method='multi')
                        write_to_log(f"{rows_affected} row(s) added to ManualLoadLogs table.")
                        archive_file('', hpcc_file + "_error_logs.tsv", lz='outbound')
                    except Exception as err:
                        teams_alert(err, "Updating ManualLoadLogs")
    except Exception as err:
        teams_alert(err, "running hpcc_hthor_validation")


def ecl_stage_facts():
    """
    This functions gets the template names from the data files that were created 
    by the pre-validation process and passed the ecl validation. If template files 
    are founds then a mutlithread process is excuted to run stage and facts buil on HPCC.
    """
    start_time = time.time()
    forecast_list = []
    input_files = []

    manual_load_lz = hpcc_landing_zone + str(today) + '\\'
    forecast_lz = inbound_forcast_adhoc + str(today) + '\\'
    count = 0
    manual_load_lz_data_files = os.listdir(manual_load_lz) if os.path.isdir(manual_load_lz) else []
    if len(manual_load_lz_data_files) >= 1:
        manual_load_lz_templates = ['_'.join(file.rstrip('.txt').split('_')[:-1]) for file in manual_load_lz_data_files]
        manual_load_files = [ t for t in manual_load_lz_templates if t in hpcc_configurations ]
        if len(manual_load_files) >= 1:
            count += len(manual_load_files)
            main_run_stage_fact(False, manual_load_files)
            # forecast_list.append(False)
            # input_files.append(manual_load_files)

    forecast_lz_data_files = os.listdir(forecast_lz) if os.path.isdir(forecast_lz) else []
    if len(forecast_lz_data_files) >= 1:
        forecast_lz_templates = ['_'.join(file.rstrip('.txt').split('_')) for file in forecast_lz_data_files]
        fact_forecast_files = [ t for t in forecast_lz_templates if t in hpcc_configurations ]
        if len(fact_forecast_files) >= 1:
            count += len(fact_forecast_files)
            main_run_stage_fact(True, fact_forecast_files)
            # forecast_list.append(True)
            # input_files.append(fact_forecast_files)

    # if len(input_files) >= 1:
    #     with ThreadPool(2) as pool:
    #         pool.starmap(main_run_stage_fact, zip(forecast_list, input_files))
        
        end_time = time.time() - start_time
        write_to_log('Building {0} data file(s) took {1}.'.format(count, str(dt.timedelta(seconds=end_time))))
    else:
        write_to_log("No build file(s) available.", warning=True)


def main_run_stage_fact(forecast=False, t_files=[]):
    """
    main_run_stage_fact: 
        Run stage and fact for manual load and forecast files. 
        Builds are executed sequentially for run that should neither 
        be on the same WUID nor executed at the same time 
    """
    time.sleep(random.randint(0, 3))
    
    source_template_map = {}

    for t_file in t_files:
        if t_file in hpcc_configurations and hpcc_configurations[t_file]["build"]:
            source = hpcc_configurations[t_file]["build"]
            if source in source_template_map:
                source_template_map[source].append(hpcc_configurations[t_file]["template"])
            else:
                source_template_map[source] = [hpcc_configurations[t_file]["template"]]

    source_files = list(source_template_map.keys()) ## remove duplicate sourcefile names
    source_files.sort()
    write_to_log(f"Running the following sources {', '.join(source_files)}")
    
    for source in source_files:
        # Run ECL build and get WUID status and possible message from WU
        workunit = wuMsg = status = ""
        templates = ','.join(set(source_template_map[source]))

        try:
            sourceRun = runSourceBuilds.commonSourceFiles(source, freq, 'fromHPCC')
            sourceRun.file_date = today
            (workunit, status, wuMsg) = runSourceBuilds.eclCall(sourceRun)
        except Exception as err:
            teams_alert(err, "main_run_stage_fact")
        
        if wuMsg is not None and len(wuMsg) > 0:
            wuMsg = wuMsg.replace('\n', '').replace('\r', '')
            write_to_log(wuMsg, error=(status != "completed"))

        write_to_log(f"Stage and fact build status {status}!", error=(status != "completed"))

        # Update the report table with the build results
        update_report(
            validation=False, 
            wuid=workunit, 
            template=templates, 
            sheet="bsv_" if 'forecast_bsv' in source else "ins_" if 'forecast_insurance' in source else "hc_" if 'forecast_healthcare' in source else None,
            ecl_stage_fact= 0 if status != "completed" else 1,
            stage_fact_wumsg=wuMsg
        )

        for t in t_files:
            if hpcc_configurations[t]["build"] == source:
                f = f"{t}.txt" if forecast else f"{t}_{today}.txt"
                error_archive_target = 'DataWithError\\ECL' if forecast else 'DataWithError'
                archive_file(
                    target= error_archive_target if status != "completed" else 'NoError',
                    source_file=f,
                    t_source = "forecast" if forecast else "manual_load"
                )


def update_report(wuid=None, validation=True, template=None, sheet=None, ecl_validation=0, validation_wumsg=None, ecl_stage_fact=0, stage_fact_wumsg=None, input_filename=None, attempts=10):
    '''
    Function that updates the ManualLoadReport table in the database with either validation 
    data or stage and facts data from HPCC builds
    '''
    try:
        if validation and wuid:
            update = f"""
            EXEC UpdateManualLoadReport 
            @working_timestamp='{working_timestamp}', 
            @validation_wuid='{wuid}', 
            @ecl_validation={ecl_validation}, 
            @template='{template}', 
            @validation_wumsg={'NULL' if validation_wumsg=='' or not validation_wumsg else "'"+validation_wumsg+"'" }, 
            @worksheet={'NULL' if sheet=='' or not sheet else "'"+sheet+"'" }, 
            @input_filename={'NULL' if input_filename=='' or not input_filename else "'"+input_filename+"'" }
            """
        elif not validation and wuid:
            update = f"""
            EXEC UpdateManualLoadReport 
            @working_timestamp='{working_timestamp}', 
            @stage_fact_wuid='{wuid}', 
            @ecl_stage_fact={ecl_stage_fact}, 
            @template='{template}', 
            @stage_fact_wumsg={'NULL' if stage_fact_wumsg=='' or not stage_fact_wumsg else "'"+stage_fact_wumsg+"'" },
            @worksheet={'NULL' if sheet=='' or not sheet else "'"+sheet+"'" };"""
        else:
            update = f"""
            EXEC UpdateManualLoadReport 
            @working_timestamp='{working_timestamp}', 
            @end_datetime='{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}';"""

        with engine.begin() as conn:
            write_to_log(f"Running sql script: {update}")
            conn.execute(update)

    except Exception as err:
        teams_alert(err, "update_report")
        if attempts >= 1:
            time.sleep(60)
            write_to_log(f"Re-attempting sql function execution. {attempts-1} more attempts left.")
            update_report(wuid, validation, template, sheet, ecl_validation, validation_wumsg, ecl_stage_fact, stage_fact_wumsg, input_filename, attempts-1)
        else:
            teams_alert("SQL UpdateManualLoadReport function attempts failed")


def get_reports_from_db(attempts=5):
    '''
    Function creates a report from two tables by loading data into a report and log data frame. Report are
    to be sent to different distribution lists based on the the source folder. The folder name is in each record in
    the "Filename" column of both dataframes therefore we filter out the dataframe for each folder distrubition and 
    further filter the dataframes based on the template name.
    '''
    try:
        write_to_log("Getting reports and logs from Database")

        try:
            # Execute store procedures that will return a process report and error logs 
            get_reports = f"EXEC GetManualLoadReport @program_timestamp='{working_timestamp}'"
            get_logs = f"EXEC GetManualLoadErrorLogs @program_timestamp='{working_timestamp}'"

            db_report_df = pd.read_sql_query(get_reports, con=engine)
            db_report_df = db_report_df.replace(np.NAN, "N/A")
            db_report_df = db_report_df.replace('$nan', "N/A")
            db_report_df["Total Billed Revenue"] = db_report_df["Total Billed Revenue"].replace("N/A", "Not Calculated")
            
            db_errors_df = pd.read_sql_query(get_logs, con=engine)
            db_errors_df = db_errors_df.replace(np.NAN, "N/A")
            db_errors_df["Line Number"] = db_errors_df["Line Number"].replace(0, 'N/A')

        except Exception as err:
            teams_alert(err, "get_reports_from_db red_sql_query")
            if attempts >= 1:
                time.sleep(30)
                write_to_log(f"Re-attempting sql function execution. {attempts-1} more attempts left.")
                get_reports_from_db(attempts-1)
            else:
                teams_alert("SQL read_report_sql query function attempts failed")
        else:
            # Create a report for all templates submitted in each folder
            for _, current_folder in dict(communications["drop_zone_folders"]).items():
                distribution_list = communications['distribution_list'][current_folder]

                folder_report = db_report_df[db_report_df['Filename'].str.startswith(current_folder)]
                folder_errors = db_errors_df[db_errors_df['Filename'].str.startswith(current_folder)]

                if folder_report.empty:
                    write_to_log(f"No reporting for {current_folder} folder.")
                else:
                    # Loop through all implemented templates
                    # Determine if the template was submitted for that folder and create report
                    for current_template in current_templates:
                        template_report = folder_report[folder_report['Template'] == current_template]
                        template_errors = folder_errors[folder_errors['Template'] == current_template]

                        if not template_report.empty:
                            write_to_log(f"Creating {current_template} report for {current_folder}")
                            send_template_report(
                                report_df=template_report, 
                                errors_df=template_errors,
                                email=distribution_list,
                                folder=current_folder, 
                                template=current_template
                            )
    except Exception as err:
        teams_alert(err, "get_reports_from_db")


def send_template_report(report_df: pd.DataFrame, errors_df: pd.DataFrame, email: list, folder: str, template: str):
    '''
    Function for creating and sending report for all implemented templates. 
    Set to reduce the LOE of adding another template to the automation
    '''
    try:
        if template != 'unknown':
            validation_config   = dict(validations[template])
            template_sheets     = list(validation_config.keys())
            hpcc_worksheets     = [sh for sh in template_sheets if validation_config[sh]['hpcc_validation'] == True]
            non_hpcc_worksheets = [sh for sh in template_sheets if validation_config[sh]['hpcc_validation'] == False]
        else:
            hpcc_worksheets     = []
            non_hpcc_worksheets = [template]

        report_config = communications['report']["general" if len(hpcc_worksheets) == 0 else template]
        report_layout = 'Layout' if template == "fact_forecast_details" else 'Worksheet'

        if template == "fact_forecast_details":
            report_df = report_df.rename(mapper={"Worksheet":"Layout"}, axis='columns')
            errors_df = errors_df.rename(mapper={"Worksheet":"Layout"}, axis='columns')

        passed_files = report_df[
            (report_df["Pre-HPCC Validation"] == "PASSED") &
            (((report_df[report_layout].str.lower().isin(hpcc_worksheets)) & (report_df["HPCC Validation"] == "PASSED")) | 
             (report_df[report_layout].str.lower().isin(non_hpcc_worksheets))
            ) & (report_df["HPCC Stage_Fact"] == "PASSED")
        ]

        failed_files = report_df[
            (report_df["Pre-HPCC Validation"] != "PASSED") |
            ((report_df[report_layout].str.lower().isin(hpcc_worksheets)) & (report_df["HPCC Validation"] != "PASSED")) | 
            (report_df["HPCC Stage_Fact"] != "PASSED")
        ]

        report_summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template"          : [' '.join([str(w).capitalize() for w in template.split('_')])],
            "Folder"            : [folder],
            "Files Collected"   : [len(report_df)],
            "Files Rejected"    : [len(failed_files)],
            "Files Loaded"      : [len(passed_files)],
            "Stage/Fact WUID"   : ['N/A' if len(report_df[report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else report_df[report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        failed_stage_fact = report_df[(~report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (report_df["Stage_Fact WuMSG"] != 'N/A')]
        failed_validation = report_df[(~report_df["HPCC Validation"].str.contains("PASSED")) & (report_df["Validation WuMSG"] != 'N/A')]  

        if len(hpcc_worksheets) >= 1:
            Validation_WUID = 'N/A' if len(report_df[report_df["Validation WUID"] != "N/A"]["Validation WUID"]) <= 0 else report_df[report_df["Validation WUID"] != "N/A"]["Validation WUID"].iloc[0]
            report_summary_df.insert(loc=6, column='Validation WUID', value=Validation_WUID)

        passed_files = passed_files[report_config['columns']]
        failed_files = failed_files[report_config['columns']]

        # Add any message received and recorded from HPCC validation and Stage fact process to the logs 
        def hpcc_error_log(hpcc_df: pd.DataFrame, wuid_step ) -> pd.DataFrame :
            if not hpcc_df.empty:
                add_error_log = pd.DataFrame({
                    'Source'        : ['HPCC' for _ in range(len(hpcc_df))],
                    'Template'      : hpcc_df['Template'],
                    'User'          : hpcc_df['User'],
                    'Filename'      : hpcc_df['Filename'],
                    report_layout   : hpcc_df[report_layout],
                    'Message'       : hpcc_df[f'{wuid_step} WuMSG'],
                    'Line Number'   : ['N/A' for _ in range(len(hpcc_df))],
                    'WUID'          : hpcc_df[f'{wuid_step} WUID']}
                )
                # check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else  msg
                # add_error_log['Message'] = check_sys_message(add_error_log['Message'])
                return add_error_log
            else:
                return pd.DataFrame()

        errors_df = pd.concat([errors_df, hpcc_error_log(failed_validation, "Validation")], ignore_index=True) 
        errors_df = pd.concat([errors_df, hpcc_error_log(failed_stage_fact, "Stage_Fact")], ignore_index=True) 

        # Set the data values for the report 
        data = {
            'timestamp'         : email_timestamp,
            'summary_table'     : report_summary_df.to_html(index=False, table_id="aop"),
            'passed_desc'       : '' if len(passed_files) <= 0 else 'Below are file(s) that completed processing',
            'passed_files'      : '' if len(passed_files) <= 0 else passed_files[report_config['data']].to_html(index=False, table_id="aop"),
            'failed_desc'       : '' if len(failed_files) <= 0 else 'Below are file(s) that were rejected.',
            'failed_files'      : '' if len(failed_files) <= 0 else failed_files[report_config['data']].to_html(index=False, table_id="aoperror"),
            'error_log_desc'    : '' if len(errors_df) <= 0 else 'Below are error logs from processing the submitted files.',
            'error_log_table'   : '' if len(errors_df) <= 0 else errors_df.to_html(index=False, table_id="aoperror")
        }

        # Open the html template and instert the above data values
        with open(report_template, 'r') as T:
            email_template = Template(T.read())
            email_report = email_template.substitute(data)
            subject = env_subj + communications['report']['error' if len(failed_files) >= 1 else 'success']
            subject += ' '.join([str(w).capitalize() for w in template.split('_')]) + f' :: {folder}'

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=subject,
                dataframe=email_report.replace("\n", "")
            )
    except Exception as err:
        teams_alert(err, f"Creating {template}_report")


def write_to_log(message, error=False, warning=False, validation_type="", t_function='Automation'):
    global debug_log

    timestamp = getCurrentTimeStamp()
    log_style = " ERROR " if error or validation_type == "Error" else "WARNING" if warning or validation_type == "Warning" else " DEBUG "
    log = f"[{timestamp}]:[{log_style}]: {message}"
    print(log)

    try:
        if error or validation_type == "Error":
            logger.error(f"{message}")

            send_to_teams_channel(
                webhook=communications["teams_webhook_url"].format(teams_webhook_path),
                title=env_subj + communications['report']['errors'] + t_function,
                message=f"{message}"
            )
        else:
            logger.debug(f"{message}")
    except Exception as err:
        teams_alert(err, "File Logger")

    try:
        df_to_add = pd.DataFrame({
            'input_filename':   ["manual_load_main"],
            'username':         [admin],
            'worksheet':        ["None"],
            'template':         ["None"],
            'record_number':    [""],
            'log_type':         [log_style.strip()],
            'log_message':      [f"{message}"],
            'source':           ["Automation"],
            'log_datetime':     [timestamp],
            'start_datetime':   [program_timestamp],
            'working_timestamp':[working_timestamp],
            'log_timestamp':    [datetime.fromisoformat(timestamp).strftime("%Y%m%d_%H%M%S")]
        })

        if debug_log.empty:
            debug_log = df_to_add
        else:
            debug_log = pd.concat([debug_log, df_to_add], ignore_index=True)
    except Exception as err:
        teams_alert(err, "Logger DB")


def return_exc(msg):
    exc_type, _, exc_tb = sys.exc_info()
    line_no = exc_tb.tb_lineno
    return f"{exc_type} line:{line_no}  {msg}"


def teams_alert(msg, function=''):
    _, _, exc_tb = sys.exc_info()
    line_no = exc_tb.tb_lineno
    message = f"Line:{line_no}\t{msg}"
    write_to_log(message, error=True, t_function=function)
    

def archive_file(target: str, source_file: str, lz='inbound', t_source="manual_load"):
    '''
    Archive function that moves file to archive folders of which depends on whether
    an error occurred with the related files or if the file is for the outbound or 
    inbound folder
    '''
    write_to_log(f"Archiving {source_file} to {t_source} {lz} archive")
    if lz == 'inbound':
        archive = hpcc_landing_zone_archive if t_source=="manual_load" else inbound_forcast_archive
        archive_folder = archive + target + '\\' + today + '\\' + process_timestamp + '\\'
        source_path = hpcc_landing_zone if t_source=="manual_load" else inbound_forcast_adhoc 
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)
        shutil.move(source_path + today + '\\' + source_file, archive_folder)
    else:
        archive_folder = hpcc_outbound_landing_zone_archive + today + '\\' + process_timestamp + '\\'
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)
        shutil.move(outbound_manual + today + '\\' + source_file, archive_folder)


def end_processing():
    """
    Email the debug and error logs for the process and delete the log files
    """
    global debug_log, file_count

    try:
        debug_log = debug_log.replace("", sqlalchemy.sql.null())
        print(len(debug_log))
        rows_affected = debug_log.to_sql('ManualLoadLogs', con=engine, if_exists="append", index=False, method='multi')
        print(f"Log rows affected: {rows_affected}")
    except Exception as err:
        teams_alert(err, 'Automation DB log error')

    try:
        debug_log = debug_log[["working_timestamp","log_datetime", "log_type", "log_message"]]
        error_log = debug_log[debug_log["log_type"] == "ERROR"]

        data = {
            'timestamp': email_timestamp,
            'summary_table': '',
            'passed_desc': '' if len(debug_log) <= 0 else 'Below are the logs for the manual load automation program.',
            'passed_files': '' if len(debug_log) <= 0 else debug_log.to_html(index=False, table_id="aop"),
            'failed_desc': '',
            'failed_files': '',
            'error_log_desc': '' if len(error_log) <= 0 else 'Below are error logs for the manual load automation program.',
            'error_log_table': '' if len(error_log) <= 0 else error_log.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else communications['CC'],
                subject=env_subj + communications['report']['logs' if len(error_log) <= 0 else 'errors'] + f'{working_timestamp}{" :: No Files Found" if file_count <= 0 else ""}',
                dataframe=email_report.replace("\n", "")
            )
    except Exception as err:
        teams_alert(err, 'Automation log error')


if __name__ == "__main__":
    start_time = time.time()
    write_to_log("Starting main program")
    try:
        pre_setup_check()
        initial_transfer()
        pre_process_validation()
        ecl_validation()
        ecl_stage_facts()
        update_report() # Update report table with endtime 
        get_reports_from_db()
    except Exception as err:
        teams_alert(err, 'Automation')
    finally:
        end_time = time.time() - start_time
        msg = f"Manual load automation took {str(dt.timedelta(seconds=end_time))}"
        send_to_teams_channel(
            webhook=communications["teams_webhook_url"].format(teams_webhook_path),
            title=env_subj + communications['report']['alert'] + f'Automation completed.',
            message=msg
        )
        write_to_log(msg)
        write_to_log("End of automation program")
        end_processing()