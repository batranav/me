import requests
import json 
import smtplib
import subprocess
import email
import sys
from email import encoders
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from requests.auth import HTTPBasicAuth
from collections import OrderedDict
from datetime import date,datetime,timedelta
from ecl_call_wrapper import getWUIDbyJob
import AutomationLogging
import parseYamlProperty
from vault.secrets import get_api_secret

def getLogger():
    return AutomationLogging.getLogger('mbs_usage_monitoring_email_python')

today     = datetime.now().strftime("%Y%m%d")

global logger

logger = getLogger()

def getDictionaryData(dictionaryList) :
    strOut = ''
    counter = 0
    for dict in dictionaryList:
        for k, v in dict.items():
            if counter > 0:
                strOut += ','
            strOut += '{0}'.format(str(v).strip())
            counter += 1
    return strOut

def getWorkunitJSON():  
    #workunit = "W20220322-095823"
    workunit = getWUIDbyJob('mbs_usage_monitoring_email,' +  today).upper()
    print(workunit)
    logger.debug(workunit)
    
    if workunit != '':
        url = 'https://fido-prod.hpcc.risk.regn.net:18010/WsWorkunits/WUFullResult.json?Wuid=' + workunit # + '&ResultName=input'
        head = {'Content-type':'application/json; charset=UTF-8', 'Accept':'application/json'}
        print(url)
        proxies = {
            "http": None,
            "https": None,
            }   
        uname, pwd = get_api_secret(logger, 'hpccthor')    
        ret = requests.post(url,auth=HTTPBasicAuth(uname, pwd),proxies=proxies)
        print(ret.text)
        json1_data = json.loads(ret.text, object_pairs_hook=OrderedDict)
    else:
        print('****Valid WUID not found****')
        sys.exit()
    return json1_data

def getMissingFileFlag():
    
    json_data = getWorkunitJSON()
    logger.debug("getMissingFileFlag -- the Json data read is {0}".format(json_data))

    for i in json_data['WUFullResultResponse']['Results']['Results']['missing_file_flag']['Row']:  
        for x, y in i.items():
            missing_file_flag = y    
    return missing_file_flag

def getMissingFileList():
    
    json_data = getWorkunitJSON()
    final_missing_file_list = ""
    logger.debug("getMissingFileList --- the Json data read is {0}".format(json_data))    
    output = ''
    for i in json_data['WUFullResultResponse']['Results']['Results']['missing_file_table']['Row']:  
        counter = 0
        for x, y in i.items():
            if counter > 0:
                output += ','
            output += (('"' + '{0}'.format(str(y).strip()) + '"') if str(y).find(',') != -1 else str(y).strip())
            counter += 1
        output += '<br>'
    final_missing_file_list += output       
    return final_missing_file_list   

def getSprayAlertFlag():
    
    json_data = getWorkunitJSON()
    logger.debug("getSprayAlertFlag -- the Json data read is {0}".format(json_data))    

    for i in json_data['WUFullResultResponse']['Results']['Results']['spray_alert_flag']['Row']:  
        for x, y in i.items():
            spray_alert_flag = y    
    return spray_alert_flag       

def getSprayAlertList():
    
    json_data = getWorkunitJSON()
    logger.debug("getSprayAlertList -- the Json data read is {0}".format(json_data)) 
    spray_alert_list = ""
    for i in json_data['WUFullResultResponse']['Results']['Results']['spray_alert_file_table']['Row']:  
        for x, y in i.items():
            spray_alert_list = y    
    return spray_alert_list

def getUsageTrendAlertFlag():
    
    json_data = getWorkunitJSON()

    for i in json_data['WUFullResultResponse']['Results']['Results']['usage_trend_alert_flag']['Row']:  
        for x, y in i.items():
            usage_trend_alert_flag = y    
    return usage_trend_alert_flag 

def getUsageSummary():
    
    json_data = getWorkunitJSON()
    logger.debug("getUsageSummary -- the Json data read is {0}".format(json_data)) 
    output = ''
    with open(parseYamlProperty.get_generated_ecl_dir() + 'usage_trend_summary.csv', 'w') as f:
        headers = "alert_flag," +  "alert_frequency," + "alert_type," + "alert_key," + "week_day," + "date_std," + "run_date_sk," + "yesterday_std," + "total," + "mean," + "standard_deviation," + "num_std_from_mean," + "wuid\n"
        f.write(headers)       
        for i in json_data['WUFullResultResponse']['Results']['Results']['usage_trend_summary_file']['Row']:
            counter = 0
            for x, y in i.items():
                if counter > 0:
                    output += ','
                output += (('"' + '{0}'.format(str(y).strip()) + '"') if str(y).find(',') != -1 else str(y).strip())
                counter += 1
            output += '\n'
        f.write(output)
        f.close()    

def getUsageTopTen():
    
    json_data = getWorkunitJSON()
    output = ''
    with open(parseYamlProperty.get_generated_ecl_dir() + 'top_ten_details.csv', 'w') as f: 
        header = "rank," +  "data_source_id," + "hist_subaccount_id," + "subaccount_name," + "date_sk," + "week_day," + "searches," + "avg_searches," + "diff," + "pct_diff\n"
        f.write(header) 
        for i in json_data['WUFullResultResponse']['Results']['Results']['usage_trend_top10']['Row']:
            counter = 0
            for x, y in i.items():
                if counter > 0:
                    output += ','
                output += (('"' + '{0}'.format(str(y).strip()) + '"') if str(y).find(',') != -1 else str(y).strip())
                counter += 1
            output += '\n'
        f.write(output)
        f.close()              


def GenerateEmailBody():

    missing_file_flag = getMissingFileFlag()
    missing_file_list = getMissingFileList()
    spray_alert_flag = getSprayAlertFlag()
    spray_alert_list = getSprayAlertList()
    usage_trend_alert_flag = getUsageTrendAlertFlag()
    getUsageSummary()
    getUsageTopTen()


    html_header = """<html>
                     <head>
                     <meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
                     <style>
                     #filecheck {
                     font-family: Verdana, sans-serif;
                     border-collapse: collapse;
                     }

                     #filecheck td,
                     #filecheck th {
                     border: 1px solid #000000;
                     padding: 8px;
                     }

                     #filecheck th {
                     padding-top: 10px;
                     padding-bottom: 10px;
                     text-align: left;
                     background-color: #C0C0C0;
                     color: black;
                     }

                     </style>
                     </head>"""

    key_dates_table = """<TABLE style = "font-family: Verdana, sans-serif;"><tr><td style="border: 1px solid #000000; padding: 8px;border-collapse: collapse;background-color: #4C6791;color: white;">
                        File Load Date</td><td   style="border: 1px solid #000000;padding: 5px;border-collapse: collapse;">
                        """ + datetime.strftime(datetime.now(), '%m-%d-%Y')  + """</td></tr><tr>

                        <td style = "border: 1px solid #000000; padding: 8px;border-collapse: collapse;background-color: #4C6791;color: white;">
                        Transaction Date</td>
                        
                        <td style="border: 1px solid #000000;padding: 5px;border-collapse: collapse;">
                        """ + datetime.strftime(datetime.now() - timedelta(days=1), '%m-%d-%Y') + """</td></tr></TABLE><br>""" 

    green_check_img = """<td style = "width: 75px; text-align:center; background-color: #52BE80;"><strong>Green</strong></td>"""
    red_x_img = """<td style = "width: 75px; text-align:center; background-color: #C0392B;"><strong>Red</strong></td>""" 
    yellow_caution_img = """<td style = "width: 75px; text-align:center; background-color: #F1C40F;"><strong>Yellow</strong></td>""" 
    

    file_check_image = green_check_img if missing_file_flag == "0" else red_x_img
    file_check_details = "All required files received." if missing_file_flag == "0" else "<strong>The following required file(s) are missing:</strong><br><br>" + str(missing_file_list)

    file_complete_image = red_x_img if spray_alert_flag == "1" or missing_file_flag == "1" else green_check_img

    if spray_alert_flag == "1":
        file_complete_details = "<strong>The following file(s) contained missing/incomplete data:</strong><br><br>" + str(spray_alert_list)
    elif missing_file_flag == "1":
        file_complete_details = "MBS daily build failed due to missing files."
    else:
        file_complete_details = "No missing data identified."  

    file_check_table = """<TABLE id="filecheck">
                            <tr> 
                            <th style = "background-color: #4C6791; color:white;">Validation </th>
                            <th style = "background-color: #4C6791; color:white;">Status</th>
                            <th style = "background-color: #4C6791; color:white;">Details</th>
                            </tr>
                            <tr>
                               <td style="background-color: #B6B6B4; width: 175px;">
                                 <strong>Files Received</strong></td>""" + file_check_image + """
                               <td NOWRAP>
                               """ + file_check_details + """</td>
                            </tr>
                            <tr>
                                <td style="background-color: #B6B6B4; width: 175px;"> 
                                <strong>Files Complete</strong></td>""" + file_complete_image + """
                               <td NOWRAP>
                               """ + file_complete_details + """</td>
                            </tr>"""

    if missing_file_flag == "1":
        data_check_image = red_x_img
    elif usage_trend_alert_flag == "1":
        data_check_image = yellow_caution_img
    else:
        data_check_image = green_check_img

    if missing_file_flag == "1":
        data_check_details = "MBS daily build failed due to missing files."
    elif usage_trend_alert_flag == "1":
        data_check_details = "<strong>Potential data issues flagged. Please review attached files for details.</strong>"
    else:
        data_check_details = "No data alerts identified."  

    data_check_table = """<tr>
                               <td style="background-color: #B6B6B4; width: 175px;">
                                 <strong>Data Alerts</strong></td>""" +  data_check_image + """
                               <td NOWRAP>""" +  data_check_details + """</td>
                            </tr>
                            <tr>
                            
                          </TABLE>
                          <br>
                          Please contact <strong>FIDOCoreTeam@risk.lexisnexis.com</strong> with any questions related to this email."""

    return html_header + key_dates_table + file_check_table + data_check_table                     


def send_mail_file():

    missing_file_flag = getMissingFileFlag()
    spray_alert_flag = getSprayAlertFlag()
    usage_trend_alert_flag = getUsageTrendAlertFlag()

    logger.debug("send_mail_file started")
  
    sender_email = "FIDO@risk.lexisnexis.com"

    if missing_file_flag == "0" and spray_alert_flag == "0" and usage_trend_alert_flag == "0":
        receiver_email = ['fido.MbsUsageAlert@lexisnexisrisk.com']
    else:
        receiver_email = ['FIDOCoreTeam@risk.lexisnexis.com'] 

    #receiver_email = "stephen.rosser@lexisnexisrisk.com"

    msg = MIMEMultipart("alternative")
    msg["Subject"] = "Daily Bus Svc Usage - Fido Load Status - as of " + datetime.strftime(datetime.now(), '%m-%d-%Y')
    msg["From"] = sender_email
    msg["To"] = ", ".join(receiver_email)

    filename1 = parseYamlProperty.get_generated_ecl_dir() + 'usage_trend_summary.csv'
    filename2 = parseYamlProperty.get_generated_ecl_dir() + 'top_ten_details.csv'

    html_body = GenerateEmailBody()

    logger.debug(html_body)

    part = MIMEText(html_body, "html")

    msg.attach(part)

    if usage_trend_alert_flag == "1":

        with open(filename1, "rb") as attachment1:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment1.read())

        encoders.encode_base64(part)

        part.add_header(
            "Content-Disposition",
            "attachment", filename = "Usage_Trend_summary.csv")

        msg.attach(part)

        with open(filename2, "rb") as attachment2:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment2.read())

        encoders.encode_base64(part)

        part.add_header(
            "Content-Disposition",
            "attachment", filename = "Usage_top_ten.csv")
        
        msg.attach(part)

    s = smtplib.SMTP('appmail.risk.regn.net')
    s.sendmail(sender_email, receiver_email, msg.as_string())
    print(html_body)

    logger.debug("send_mail_file Finished {0}".format(html_body))
if __name__ == "__main__":
    try:
        send_mail_file()
    except Exception as ex:
        logger.debug("There is a problem {0}".format(ex))
    #workunit = getWUIDbyJob('mbs_usage_monitoring_email,20220321')
    #print(workunit)
               