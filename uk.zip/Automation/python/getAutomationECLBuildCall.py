import fido_utils
import socket
from tempfile import mkstemp
from shutil import move
from collections import namedtuple
import os
import json
import parseJSONProperty, parseYamlProperty
import commonArgs
import weekly_release_adhoc_despray
from datetime import datetime

Source = namedtuple('Source', ['source', 'frequency', 'attribute'])

sourceBaseFolder = ''
templateBaseFolder = parseYamlProperty.get_ecl_script_dir()

def getSourceDetails(fido_source, fido_frequency, filedate):
    return parseJSONProperty.getSourceInfo(fido_source, fido_frequency, filedate)

# def getSourceInfo(fido_source, fido_frequency):
#     print('GetSourceInfo {0} {1}'.format(fido_source, fido_frequency))
#     file_name = parseYamlProperty.get_base_script_dir() + '\\properties\\red.json'   
#     jsonRef = json.load(open(file_name))

#     for source in jsonRef:
#         if source['Source'] == fido_source and source['Frequency'] == fido_frequency:
#             return(Source(fido_source, fido_frequency, source['AttributeToCall']))

#     raise IOError('Could not find source "{0}" and frequency "{1}" in spreadsheet "{2}"'.format(fido_source, fido_frequency, file_name))

def createECL(logger, source, frequency, filedate=fido_utils.getToday(), env='prod'):
    # sourceparam
    # filedateparam
    # envparam
    # importparam
    # buildparam
    # frequencyparam
    
    logger.debug('createECL {0}, {1}, {2}'.format(source, frequency, filedate))

    sourceInfo = getSourceDetails(source, frequency, filedate)
    if(parseYamlProperty.get_processing_dir(source) != None and parseYamlProperty.get_processing_dir(source) != ''):
        inbound_drive = parseYamlProperty.get_processing_dir(source).strip()[0]
    
    if(sourceInfo.importparam == ''):
        if commonArgs.getApplication() != '':
            importprm = commonArgs.getApplication()
        else:
            importprm = 'red'
    else:
        importprm = sourceInfo.importparam
    despray_path_paramvalue=''
    if(sourceInfo.source == 'weekly_release_adhoc_despray'):
        if(commonArgs.getFiledate() != ''):
            adhoc_despray_paramvalue = 'weekly_release_' + commonArgs.getFiledate()
        else:
            adhoc_despray_paramvalue = 'weekly_release_' + datetime.today().strftime('%Y%m%d')
        attributeToCall = weekly_release_adhoc_despray.get_adhoc_despray_script()
    elif(sourceInfo.source == 'weekly_release_adhoc_despray_headers_only'):
        if(commonArgs.getFiledate() != ''):
            adhoc_despray_paramvalue = 'weekly_release_' + commonArgs.getFiledate()
        else:
            adhoc_despray_paramvalue = 'weekly_release_' + datetime.today().strftime('%Y%m%d')
        attributeToCall = weekly_release_adhoc_despray.get_adhoc_despray_script_headers_only()
    elif(sourceInfo.source == 'despray_auto_generate'):
        attributeToCall = weekly_release_adhoc_despray.get_adhoc_despray_script_auto_generate()
        adhoc_despray_paramvalue = sourceInfo.adhoc_despray             
    else:
        adhoc_despray_paramvalue = sourceInfo.adhoc_despray
        despray_path_paramvalue = sourceInfo.despray_path
        attributeToCall = sourceInfo.attribute

    if(commonArgs.get_despray_hostname() != ''):
        despray_hostname  = commonArgs.get_despray_hostname()
    else:
        despray_hostname = socket.gethostname()
    paramdict = {
        'sourceparam': sourceInfo.source,
        'filedateparam': filedate,
        'envparam': env,
        'hostnameparam' : socket.gethostname(),
        'despray_host_nameparam' : despray_hostname,
        'despray_path_param' : despray_path_paramvalue,
        'importparam': importprm,
        'buildparam': attributeToCall,
        #'buildmonthparam': build_month,
        'buildmonthparam': fido_utils.getBuildMonth(),
        'frequencyparam': frequency,
        'adhocdesprayparam' : adhoc_despray_paramvalue,
        'maxCsvRowSizeMbparam' : sourceInfo.maxCsvRowSizeMb,
        'wu_priority' : sourceInfo.wu_priority,
        'whenparam' : sourceInfo.whenparam,
        'NotifyOnFailure' : sourceInfo.NotifyOnFailure,
        'FailureActionParam' : sourceInfo.FailureAction,
        'inbound_drive_param' : inbound_drive}

    if frequency.lower() == 'daily':
        if sourceInfo.whenparam.strip() != '' and sourceInfo.NotifyOnFailure.strip().lower() == 'true' :
            templateFile = os.path.join( templateBaseFolder,'_build_source_daily_when_check_with_failure.txt')
        elif sourceInfo.whenparam.strip() != '' and commonArgs.getSkipWhen() is not True:
            templateFile = os.path.join( templateBaseFolder,'_build_source_daily_when_check.txt')
        elif sourceInfo.NotifyOnFailure.strip().lower() == 'true' :
            templateFile = os.path.join( templateBaseFolder,'_build_source_daily_with_failure.txt')
        elif sourceInfo.NotifyOnFailure.strip().lower() == 'failureaction' :
            templateFile = os.path.join( templateBaseFolder,'_build_source_daily_with_failure_action.txt')
        else:
            templateFile = os.path.join( templateBaseFolder,'_build_source_daily.txt')
    if frequency.lower() == 'weekly':
        if sourceInfo.whenparam.strip() != '' and commonArgs.getSkipWhen() is not True:
            templateFile = os.path.join( templateBaseFolder,'_build_source_weekly_when_check.txt')
        else:
            templateFile = os.path.join( templateBaseFolder,'_build_source_weekly.txt')
    elif frequency.lower() in ['monthly']:
        if sourceInfo.whenparam.strip() != '' and commonArgs.getSkipWhen() is not True:
            templateFile = os.path.join( templateBaseFolder,'_build_source_monthly_when_check.txt')
        else: 
            templateFile = os.path.join( templateBaseFolder,'_build_source_monthly.txt')
    elif frequency.lower() in ['adhoc']:
        if sourceInfo.whenparam.strip() != '' and commonArgs.getSkipWhen() is not True:
            templateFile = os.path.join( templateBaseFolder,'_build_source_adhoc_when_check.txt')
        else: 
            templateFile = os.path.join( templateBaseFolder,'_build_source_adhoc.txt')
    elif frequency.lower() in ['prefinal']:
        if sourceInfo.whenparam.strip() != '' and commonArgs.getSkipWhen() is not True:
            templateFile = os.path.join( templateBaseFolder,'_build_source_prefinal_when_check.txt')
        else: 
            templateFile = os.path.join( templateBaseFolder,'_build_source_prefinal.txt')

    logger.debug('createECL -- templateFile {0}'.format(templateFile))

    eclFileName = source + '_' + frequency + '_' + filedate + '.ecl'

    fileToExecute = os.path.join(parseYamlProperty.get_generated_ecl_dir(), eclFileName)

    logger.debug('createECL -- fileToExecute {0}'.format(fileToExecute))
    
    fh, abs_path = mkstemp()
    print (fh, abs_path)
    new_file = open(abs_path, 'w')
    old_file = open(templateFile)
    
    for line in old_file:
        writeFlag = True
        for key, val in paramdict.items():
            print(key)
            print(val)
            if key in line: 
                if key == 'whenparam' and sourceInfo.whenparam.strip() == '':
                    writeFlag = False
                if key == 'despray_path_param' and sourceInfo.despray_path.strip() == '':
                    writeFlag = False
                if key == 'adhocdesprayparam' and sourceInfo.adhoc_despray.strip() == '':
                    writeFlag = False
                if key == 'maxCsvRowSizeMbparam' and sourceInfo.maxCsvRowSizeMb.strip() == '':
                    writeFlag = False
                if key == 'wu_priority' and sourceInfo.wu_priority.strip() == '\'high\'':
                    # line += '#workunit(\'priority\',\'10\');' + '\n'           
                    line = '#workunit(\'priority\',\'10\');' + '\n' + line     
                line = line.replace(key, val)
            # print(line)
        if writeFlag:
            new_file.write(line)

    # close temp file
    new_file.close()
    os.close(fh)
    old_file.close()
    # Move new file
    print('AbsPath {0}'.format(abs_path))
    print('Output {0}'.format(fileToExecute))
    move(abs_path, fileToExecute)

    logger.debug('AbsPath {0}, output {1}'.format(abs_path, fileToExecute))
    
    return fileToExecute

if __name__ == "__main__":
    #createECL('mbs', 'daily')
    print('all good')
    import AutomationLogging
    logger = AutomationLogging.getLogger('eclbuild')
    createECL(logger, 'accuityiban' , 'daily', '20210723')
    print(commonArgs.get_despray_hostname())