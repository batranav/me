import os
import json
import time
import getSQLdata
import commonArgs
import sqlalchemy
import fido_utils
import numpy as np
import urllib.parse
import pandas as pd


from string import Template
from datetime import datetime
from AutomationLogging import getLogger
from manual_load_send_email import send_mail, send_to_teams_channel, send_mail_with_table


computerName = os.environ['COMPUTERNAME']

if computerName not in ('ALAWDRED201', 'ALAWPFIDOLZ301', 'BCTWPFIDOLZ201'):
    hostname = 'alawdred201'
else:
    hostname = computerName

json_file_path = "C:\\DEVELOPMENTRoot\\FIDO\\automation\\scripts\\red\properties\\red_manual_load_config.json"
report_template = "C:\\DEVELOPMENTRoot\\FIDO\\automation\\scripts\\python\\manual_load_template_report.html"


with open(json_file_path, 'r') as json_file:
    data = json.load(json_file)
    hpcc_configurations = data["hpcc_configurations"]
    communications = data["communications"]
    validations = data["validations"]

## Change env depenfin on where the you want the data to be sent
# env = 'prod' 
env = commonArgs.getEnv()
env_subj = "DEV :: " if env == "dev" else ''

## Change todays date of needed
# todayDate = datetime.now().strftime("%Y%m%d") 
todayDate = fido_utils.getYesterday()

## Changed timestamp to match stamp in question 
process_timestamp = todayDate + datetime.now().strftime("%H%M%S")
# program_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
program_timestamp = datetime.fromisoformat('2022-10-06 18:30:04').strftime('%Y-%m-%d %H:%M:%S') # for testing purposes
email_time = datetime.fromisoformat(program_timestamp).strftime("%m/%d/%Y %I:%M %p")
working_timestamp = datetime.fromisoformat(program_timestamp).strftime("%Y%m%d_%H%M%S")

logger = getLogger('email report')
connection_string = getSQLdata.getSourcePullInfo(logger, "fido_dev" if env=='dev' else "fido_prod", "daily", "trial")
# connection_string = getSQLdata.getSourcePullInfo(logger, "fido_prod", "daily", "trial")
connection_uri = f"mssql+pyodbc://?odbc_connect={urllib.parse.quote_plus(''.join(connection_string))}"
engine = sqlalchemy.create_engine(connection_uri, fast_executemany=True)


def revenue_adjustment_report(db_report_df: pd.DataFrame, db_logs_df: pd.DataFrame, report: dict, email: list, folder):
    '''
    Function for creating a revenue adjustment reports. The first report goes to the dev team containing more 
    details including ECL report. The second report goes to the end users with less details 
    '''
    if not db_report_df.empty:
        print(f"Creating revenue adjustment report for {folder}")

        db_report_df = db_report_df[report['columns']]
        passed_files = db_report_df[
            (db_report_df["Pre-HPCC Validation"] == "PASSED") & 
            (db_report_df["HPCC Validation"] == "PASSED") & 
            (db_report_df["HPCC Stage_Fact"] == "PASSED")
        ]
        failed_files = db_report_df[
            ((db_report_df["Pre-HPCC Validation"] == "PASSED") | (db_report_df["Pre-HPCC Validation"] == "FAILED")) & 
            (db_report_df["HPCC Validation"] != "PASSED") | (db_report_df["HPCC Stage_Fact"] != "PASSED")
        ]

        failed_validation = db_report_df[(~db_report_df["HPCC Validation"].str.contains("PASSED")) & (db_report_df["Validation WuMSG"] != 'N/A')]
        if not failed_validation.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_validation))],
                'Template': failed_validation['Template'],
                'User': failed_validation['User'],
                'Filename': failed_validation['Filename'],
                'Worksheet': failed_validation['Worksheet'],
                'Message': failed_validation['Validation WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_validation))],
                'WUID': failed_validation['Validation WUID']}
            )
            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else  msg
            check_int_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "internal error:" in str(msg).lower() else  msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            add_error_log['Message'] = check_int_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)

        failed_stage = db_report_df[(~db_report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (db_report_df["Stage_Fact WuMSG"] != 'N/A')]
        if not failed_stage.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_stage))],
                'Template': failed_stage['Template'],
                'User': failed_stage['User'],
                'Filename': failed_stage['Filename'],
                'Worksheet': failed_stage['Worksheet'],
                'Message': failed_stage['Stage_Fact WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_stage))],
                'WUID': failed_stage['Stage_Fact WUID']}
            )
            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)
        
        summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template": ["Revenue Adjustment"],
            "Folder": [folder],
            "Files Collected": [len(db_report_df)],
            "Files Rejected": [len(failed_files)],
            "Files Loaded": [len(passed_files)],
            "Validation WUID": ['N/A' if len(db_report_df[db_report_df["Validation WUID"] != "N/A"]["Validation WUID"]) <= 0 else db_report_df[db_report_df["Validation WUID"] != "N/A"]["Validation WUID"].iloc[0]],
            "Stage/Fact WUID": ['N/A' if len(db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        data = {
            'timestamp': email_time,
            'summary_table': summary_df.to_html(index=False, table_id="aop"),
            'passed_desc': '' if len(passed_files) <= 0 else 'Below are file(s) that passed Pre-HPCC and HPCC validation in order of template and username',
            'passed_files': '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aop"),
            'failed_desc': '' if len(failed_files) <= 0 else 'Below are file(s) that failed both Pre-HPCC and HPCC validation or just HPCC validation in order of template and username.',
            'failed_files': '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc': '' if len(db_logs_df) <= 0 else 'Below are error logs from Pre HPCC and HPCC validation. Ordered by source, username and filename.',
            'error_log_table': '' if len(db_logs_df) <= 0 else db_logs_df.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            data.update({
                'passed_files': '' if len(passed_files) <= 0 else passed_files.iloc[:, :8].to_html(index=False, table_id="aop"),
                'failed_files': '' if len(failed_files) <= 0 else failed_files.iloc[:, :8].to_html(index=False, table_id="aoperror"),
            })

            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=env_subj + report['error' if len(failed_files) >= 1 else 'success'] + folder,
                dataframe=email_report.replace("\n", "")
        )
    

def customer_attributes_report(db_report_df: pd.DataFrame, db_logs_df: pd.DataFrame, report: dict, email: list, folder):
    '''
    Function for creating a Customer attributes reports. The first report goes to the dev team containing more 
    details including ECL report. The second report goes to the end users with less details. Only the CY_Vertical 
    worksheet from the source folder required HPCC validation so the record from this tab would pass if it passed 
    both Pre-ECL and ECL validation
    '''
    if not db_report_df.empty:
        print(f"Creating customer attributes report for {folder}")

        db_report_df = db_report_df[report['columns']]
        passed_files = db_report_df[
            ((db_report_df["Worksheet"] == "CY_Vertical") & (db_report_df["Pre-HPCC Validation"] == "PASSED") & (db_report_df["HPCC Validation"] == "PASSED")) |
            ((db_report_df["Worksheet"] != "CY_Vertical") & (db_report_df["Pre-HPCC Validation"] == "PASSED")) & 
            (db_report_df["HPCC Stage_Fact"] == "PASSED")
        ]

        failed_files = db_report_df[
            ((db_report_df["Worksheet"] == "CY_Vertical") & ((db_report_df["Pre-HPCC Validation"] == "FAILED") | (db_report_df["HPCC Validation"] != "PASSED"))) |
            ((db_report_df["Worksheet"] != "CY_Vertical") & (db_report_df["Pre-HPCC Validation"] == "FAILED")) | 
            (db_report_df["HPCC Stage_Fact"] != "PASSED")
        ]

        failed_validation = db_report_df[(db_report_df["Worksheet"] == "CY_Vertical") & (~db_report_df["HPCC Validation"].str.contains("PASSED")) & (db_report_df["Validation WuMSG"] != 'N/A')]
        if not failed_validation.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_validation))],
                'Template': failed_validation['Template'],
                'User': failed_validation['User'],
                'Filename': failed_validation['Filename'],
                'Worksheet': failed_validation['Worksheet'],
                'Message': failed_validation['Validation WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_validation))],
                'WUID': failed_validation['Validation WUID']}
            )

            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else  msg
            check_int_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "internal error:" in str(msg).lower() else  msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            add_error_log['Message'] = check_int_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)

        failed_stage = db_report_df[(~db_report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (db_report_df["HPCC Stage_Fact"] != 'N/A')]
        if not failed_stage.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_stage))],
                'Template': failed_stage['Template'],
                'User': failed_stage['User'],
                'Filename': failed_stage['Filename'],
                'Worksheet': failed_stage['Worksheet'],
                'Message': failed_stage['Stage_Fact WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_stage))],
                'WUID': failed_stage['Stage_Fact WUID']}
            )
            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)

        summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template": ["Customer Attributes"],
            "Folder": [folder],
            "Files Collected": [len(db_report_df["Filename"].unique())],
            "Files Rejected": [len(failed_files["Filename"].unique())],
            "Files Loaded": [len(passed_files["Filename"].unique())],
            "Validation WUID": ['N/A' if len(db_report_df[db_report_df["Validation WUID"] != "N/A"]["Validation WUID"]) <= 0 else db_report_df[db_report_df["Validation WUID"] != "N/A"]["Validation WUID"].iloc[0]],
            "Stage/Fact WUID": ['N/A' if len(db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        data = {
            'timestamp': email_time,
            'summary_table': summary_df.to_html(index=False, table_id="aop"),
            'passed_desc': '' if len(passed_files) <= 0 else 'Below are file(s) that passed Pre-HPCC and HPCC validation in order of template and username',
            'passed_files': '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aop"),
            'failed_desc': '' if len(failed_files) <= 0 else 'Below are file(s) that failed both Pre-HPCC and HPCC validation or just HPCC validation in order of template and username',
            'failed_files': '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc': '' if len(db_logs_df) <= 0 else 'Below are error logs from Pre HPCC and HPCC validation. Ordered by source, username and filename.',
            'error_log_table': '' if len(db_logs_df) <= 0 else db_logs_df.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            data.update({
                'passed_files': '' if len(passed_files) <= 0 else passed_files.iloc[:, :6].to_html(index=False, table_id="aop"),
                'failed_files': '' if len(failed_files) <= 0 else failed_files.iloc[:, :6].to_html(index=False, table_id="aoperror"),
            })

            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=env_subj + report['error' if len(failed_files) >= 1 else 'success'] + folder,
                dataframe=email_report.replace("\n", "")
            )


def override_report(db_report_df: pd.DataFrame, db_logs_df: pd.DataFrame, report: dict, email: list, folder):
    '''
    Function for creating a override template reports. The first report goes to the dev team containing more 
    details including ECL report. The second report goes to the end users with less details 
    '''
    if not db_report_df.empty:
        print(f"Creating Override report for {folder}")

        db_report_df = db_report_df[report['columns']]
        passed_files = db_report_df[
            (db_report_df["Pre-HPCC Validation"] == "PASSED") & 
            (db_report_df["HPCC Validation"] == "PASSED")  & 
            (db_report_df["HPCC Stage_Fact"] == "PASSED")
        ]
        failed_files = db_report_df[
            ((db_report_df["Pre-HPCC Validation"] == "PASSED") | (db_report_df["Pre-HPCC Validation"] == "FAILED")) & 
            (db_report_df["HPCC Validation"] != "PASSED")  | (db_report_df["HPCC Stage_Fact"] != "PASSED")
        ]

        failed_validation = db_report_df[(~db_report_df["HPCC Validation"].str.contains("PASSED")) & (db_report_df["Validation WuMSG"] != 'N/A')]
        if not failed_validation.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_validation))],
                'Template': failed_validation['Template'],
                'User': failed_validation['User'],
                'Filename': failed_validation['Filename'],
                'Worksheet': failed_validation['Worksheet'],
                'Message': failed_validation['Validation WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_validation))],
                'WUID': failed_validation['Validation WUID']}
            )
            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else  msg
            check_int_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "internal error:" in str(msg).lower() else  msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            add_error_log['Message'] = check_int_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)
          
        failed_stage = db_report_df[(~db_report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (db_report_df["HPCC Stage_Fact"] != 'N/A')]
        if not failed_stage.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_stage))],
                'Template': failed_stage['Template'],
                'User': failed_stage['User'],
                'Filename': failed_stage['Filename'],
                'Worksheet': failed_stage['Worksheet'],
                'Message': failed_stage['Stage_Fact WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_stage))],
                'WUID': failed_stage['Stage_Fact WUID']}
            )
            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)

        summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template": ["Override"],
            "Folder": [folder],
            "Files Collected": [len(db_report_df)],
            "Files Rejected": [len(failed_files)],
            "Files Loaded": [len(passed_files)],
            "Validation WUID": ['N/A' if len(db_report_df[db_report_df["Validation WUID"] != "N/A"]["Validation WUID"]) <= 0 else db_report_df[db_report_df["Validation WUID"] != "N/A"]["Validation WUID"].iloc[0]],
            "Stage/Fact WUID": ['N/A' if len(db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        data = {
            'timestamp': email_time,
            'summary_table': summary_df.to_html(index=False, table_id="aop"),
            'passed_desc': '' if len(passed_files) <= 0 else 'Below are file(s) that passed Pre-HPCC and HPCC validation in order of template and username',
            'passed_files': '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aop"),
            'failed_desc': '' if len(failed_files) <= 0 else 'Below are file(s) that failed both Pre-HPCC and HPCC validation or just HPCC validation in order of template and username.',
            'failed_files': '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc': '' if len(db_logs_df) <= 0 else 'Below are error logs from Pre HPCC and HPCC validation. Ordered by source, username and filename.',
            'error_log_table': '' if len(db_logs_df) <= 0 else db_logs_df.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            data.update({
                'passed_files': '' if len(passed_files) <= 0 else passed_files.iloc[:, :7].to_html(index=False, table_id="aop"),
                'failed_files': '' if len(failed_files) <= 0 else failed_files.iloc[:, :7].to_html(index=False, table_id="aoperror"),
            })

            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=env_subj + report['error' if len(failed_files) >= 1 else 'success'] + folder,
                dataframe=email_report.replace("\n", "")
            )


def vertical_allocation_report(db_report_df: pd.DataFrame, db_logs_df: pd.DataFrame, report: dict, email: list, folder):
    '''
    Function for creating a override template reports. The first report goes to the dev team containing more 
    details including ECL report. The second report goes to the end users with less details 
    '''
    if not db_report_df.empty:
        print(f"Creating Vertical Allocation report for {folder}")

        db_report_df = db_report_df[report['columns']]
        passed_files = db_report_df[(db_report_df["Pre-HPCC Validation"] == "PASSED") & (db_report_df["HPCC Stage_Fact"] == "PASSED")]
        failed_files = db_report_df[(db_report_df["Pre-HPCC Validation"] == "FAILED") | (db_report_df["HPCC Stage_Fact"] != "PASSED")]

        failed_stage = db_report_df[(~db_report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (db_report_df["HPCC Stage_Fact"] != 'N/A')]
        if not failed_stage.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_stage))],
                'Template': failed_stage['Template'],
                'User': failed_stage['User'],
                'Filename': failed_stage['Filename'],
                'Worksheet': failed_stage['Worksheet'],
                'Message': failed_stage['Stage_Fact WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_stage))],
                'WUID': failed_stage['Stage_Fact WUID']}
            )
            check_sys_message = lambda msg : "An unexpected system error has occured. Please try resubmitting the file for the next session"  if "system error:" in str(msg).lower() else msg
            add_error_log['Message'] = check_sys_message(add_error_log['Message'])
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)

        summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template": ["Vertical Allocation"],
            "Folder": [folder],
            "Files Collected": [len(db_report_df)],
            "Files Rejected": [len(failed_files)],
            "Files Loaded": [len(passed_files)],
            "Stage/Fact WUID": ['N/A' if len(db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        data = {
            'timestamp': email_time,
            'summary_table': summary_df.to_html(index=False, table_id="aop"),
            'passed_desc': '' if len(passed_files) <= 0 else 'Below are file(s) that passed Pre-HPCC and HPCC validation in order of template and username',
            'passed_files': '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aop"),
            'failed_desc': '' if len(failed_files) <= 0 else 'Below are file(s) that failed both Pre-HPCC and HPCC validation or just HPCC validation in order of template and username.',
            'failed_files': '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc': '' if len(db_logs_df) <= 0 else 'Below are error logs from Pre HPCC and HPCC validation. Ordered by source, username and filename.',
            'error_log_table': '' if len(db_logs_df) <= 0 else db_logs_df.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            data.update({
                'passed_files': '' if len(passed_files) <= 0 else passed_files.iloc[:, :6].to_html(index=False, table_id="aop"),
                'failed_files': '' if len(failed_files) <= 0 else failed_files.iloc[:, :6].to_html(index=False, table_id="aoperror"),
            })

            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=env_subj + report['error' if len(failed_files) >= 1 else 'success'] + folder,
                dataframe=email_report.replace("\n", "")
            )


def fact_forecast_details_report(db_report_df: pd.DataFrame, db_logs_df: pd.DataFrame, report: dict, email: list, folder):
    '''
    Function for creating a override template reports. The first report goes to the dev team containing more 
    details including ECL report. The second report goes to the end users with less details 
    '''
    if not db_report_df.empty:
        print(f"Creating fact forecast details report for {folder}")

        db_report_df = db_report_df[report['columns']]
        db_report_df.rename(columns={"Worksheet":"Layout"})
        passed_files = db_report_df[(db_report_df["Pre-HPCC Validation"] == "PASSED") & (db_report_df["HPCC Stage_Fact"] == "PASSED")]
        failed_files = db_report_df[(db_report_df["Pre-HPCC Validation"] == "FAILED") | (db_report_df["HPCC Stage_Fact"] != "PASSED")]

        failed_stage = db_report_df[(~db_report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (db_report_df["HPCC Stage_Fact"] != 'N/A')]
        if not failed_stage.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_stage))],
                'Template': failed_stage['Template'],
                'User': failed_stage['User'],
                'Filename': failed_stage['Filename'],
                'Worksheet': failed_stage['Worksheet'],
                'Message': failed_stage['Stage_Fact WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_stage))],
                'WUID': failed_stage['Stage_Fact WUID']}
            )
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)
        db_logs_df.rename(columns={"Worksheet":"Layout"})

        summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template": ["Fact Forecast Details"],
            "Folder": [folder],
            "Files Collected": [len(db_report_df)],
            "Files Rejected": [len(failed_files)],
            "Files Loaded": [len(passed_files)],
            "Stage/Fact WUID": ['N/A' if len(db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        data = {
            'timestamp': email_time,
            'summary_table': summary_df.to_html(index=False, table_id="aop"),
            'passed_desc': '' if len(passed_files) <= 0 else 'Below are file(s) that passed Pre-HPCC and HPCC validation in order of template and username',
            'passed_files': '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aop"),
            'failed_desc': '' if len(failed_files) <= 0 else 'Below are file(s) that failed both Pre-HPCC and HPCC validation or just HPCC validation in order of template and username.',
            'failed_files': '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc': '' if len(db_logs_df) <= 0 else 'Below are error logs from Pre HPCC and HPCC validation. Ordered by source, username and filename.',
            'error_log_table': '' if len(db_logs_df) <= 0 else db_logs_df.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            data.update({
                'passed_files': '' if len(passed_files) <= 0 else passed_files.iloc[:, :6].to_html(index=False, table_id="aop"),
                'failed_files': '' if len(failed_files) <= 0 else failed_files.iloc[:, :6].to_html(index=False, table_id="aoperror"),
            })

            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=env_subj + report['error' if len(failed_files) >= 1 else 'success'] + folder,
                dataframe=email_report.replace("\n", "")
            )


def vc_report(db_report_df: pd.DataFrame, db_logs_df: pd.DataFrame, report: dict, email: list, folder):
    '''
    Function for creating a override template reports. The first report goes to the dev team containing more 
    details including ECL report. The second report goes to the end users with less details 
    '''
    if not db_report_df.empty:
        print(f"Creating VC report from {folder} folder")

        db_report_df = db_report_df[report['columns']]
        db_report_df.rename(columns={"Worksheet":"Layout"})
        passed_files = db_report_df[(db_report_df["Pre-HPCC Validation"] == "PASSED") & (db_report_df["HPCC Stage_Fact"] == "PASSED")]
        failed_files = db_report_df[(db_report_df["Pre-HPCC Validation"] == "FAILED") | (db_report_df["HPCC Stage_Fact"] != "PASSED")]

        failed_stage = db_report_df[(~db_report_df["HPCC Stage_Fact"].str.contains("PASSED")) & (db_report_df["HPCC Stage_Fact"] != 'N/A')]
        if not failed_stage.empty:
            add_error_log = pd.DataFrame({
                'Source': ['HPCC' for _ in range(len(failed_stage))],
                'Template': failed_stage['Template'],
                'User': failed_stage['User'],
                'Filename': failed_stage['Filename'],
                'Worksheet': failed_stage['Worksheet'],
                'Message': failed_stage['Stage_Fact WuMSG'],
                'Line Number': ['N/A' for _ in range(len(failed_stage))],
                'WUID': failed_stage['Stage_Fact WUID']}
            )
            db_logs_df = pd.concat([db_logs_df, add_error_log], ignore_index=True)
        db_logs_df.rename(columns={"Worksheet":"Layout"})

        summary_df = pd.DataFrame({
            "Working Start Time": [working_timestamp],
            "Template": ["VC"],
            "Folder": [folder],
            "Files Collected": [len(db_report_df)],
            "Files Rejected": [len(failed_files)],
            "Files Loaded": [len(passed_files)],
            "Stage/Fact WUID": ['N/A' if len(db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"]) <= 0 else db_report_df[db_report_df["Stage_Fact WUID"] != "N/A"]["Stage_Fact WUID"].iloc[0]]
        })

        data = {
            'timestamp': email_time,
            'summary_table': summary_df.to_html(index=False, table_id="aop"),
            'passed_desc': '' if len(passed_files) <= 0 else 'Below are file(s) that passed Pre-HPCC and HPCC validation in order of template and username',
            'passed_files': '' if len(passed_files) <= 0 else passed_files.to_html(index=False, table_id="aop"),
            'failed_desc': '' if len(failed_files) <= 0 else 'Below are file(s) that failed both Pre-HPCC and HPCC validation or just HPCC validation in order of template and username.',
            'failed_files': '' if len(failed_files) <= 0 else failed_files.to_html(index=False, table_id="aoperror"),
            'error_log_desc': '' if len(db_logs_df) <= 0 else 'Below are error logs from Pre HPCC and HPCC validation. Ordered by source, username and filename.',
            'error_log_table': '' if len(db_logs_df) <= 0 else db_logs_df.to_html(index=False, table_id="aoperror")
        }

        with open(report_template, 'r') as T:
            data.update({
                'passed_files': '' if len(passed_files) <= 0 else passed_files.iloc[:, :6].to_html(index=False, table_id="aop"),
                'failed_files': '' if len(failed_files) <= 0 else failed_files.iloc[:, :6].to_html(index=False, table_id="aoperror"),
            })

            template = Template(T.read())
            email_report = template.substitute(data)

            send_mail_with_table(
                send_from=communications['send_from'],
                send_to=communications['team_list'] if env=='dev' else email,
                send_cc=[] if env=='dev' else communications['CC'],
                subject=env_subj + report['error' if len(failed_files) >= 1 else 'success'] + folder,
                dataframe=email_report.replace("\n", "")
            )


def get_reports_from_db(attempts=10):
    '''
    Function creates a report from two tables by loading data into a report and log data frame. Report are
    to be sent to different distribution lists based on the the source folder. The folder name is in each record in
    the "Filename" column of both dataframes therefore we filter out the dataframe for each folder distrubition and 
    further filter the dataframes based on the template name.
    '''
    try:
        get_reports = f"EXEC GetManualLoadReport @program_timestamp='{working_timestamp}'"
        get_logs = f"EXEC GetManualLoadErrorLogs @program_timestamp='{working_timestamp}'"

        print("Getting logs from Database")

        try:
            db_logs_df = pd.read_sql_query(get_logs, con=engine)
            db_report_df = pd.read_sql_query(get_reports, con=engine)
        except Exception as err:
            print(err, "get_reports_from_db red_sql_query")
            if attempts >= 1:
                time.sleep(30)
                print(f"Re-attempting sql function execution. {attempts-1} more attempts left.")
                get_reports_from_db(attempts-1)
            else:
                print("SQL read_report_sql query function attempts failed")

        db_logs_df = db_logs_df.replace(np.NAN, "N/A")
        db_logs_df["Line Number"] = db_logs_df["Line Number"].replace(0, 'N/A')

        db_report_df = db_report_df.replace(np.NAN, "N/A")
        db_report_df = db_report_df.replace('$nan', "N/A")
        db_report_df["Total Billed Revenue"] = db_report_df["Total Billed Revenue"].replace("N/A", "Not Calculated")

        print("Creating report for different distribution list")
        for _, folder in dict(communications["drop_zone_folders"]).items():
            # distribution_list = communications['distribution_list'][folder]
            distribution_list = communications['team_list']

            report_df = db_report_df[db_report_df['Filename'].str.startswith(folder)]
            debug_log = db_logs_df[db_logs_df['Filename'].str.startswith(folder)]
            if report_df.empty:
                print(f"No reporting for {folder} folder.")
            else:
                try:
                    revenue_adjustment_report(
                        db_report_df=report_df[report_df['Template'] == 'revenue_adjustment'],
                        db_logs_df=debug_log[debug_log['Template']== 'revenue_adjustment'],
                        report=communications['report']['revenue_adjustment'],
                        email=distribution_list,
                        folder=folder
                    )
                except Exception as err:
                    print(err, "Creating revenue_adjustment_report")

                try:
                    customer_attributes_report(
                        db_report_df=report_df[report_df['Template'] == 'customer_attributes'],
                        db_logs_df=debug_log[debug_log['Template'] == 'customer_attributes'],
                        report=communications['report']['customer_attributes'],
                        email=distribution_list,
                        folder=folder
                    )
                except Exception as err:
                    print(err, "Creating customer_attributes_report")

                try:
                    override_report(
                        db_report_df=report_df[report_df['Template'] == 'override'],
                        db_logs_df=debug_log[debug_log['Template']== 'override'],
                        report=communications['report']['override'],
                        email=distribution_list,
                        folder=folder
                    )
                except Exception as err:
                    print(err, "Creating override_report")

                try:
                    vertical_allocation_report(
                        db_report_df=report_df[report_df['Template'] == 'vertical_allocation'],
                        db_logs_df=debug_log[debug_log['Template']== 'vertical_allocation'],
                        report=communications['report']['vertical_allocation'],
                        email=distribution_list,
                        folder=folder
                    )
                except Exception as err:
                    print(err, "Creating vertical_allocation_report")

                try:
                    fact_forecast_details_report(
                        db_report_df=report_df[report_df['Template'] == 'fact_forecast_details'],
                        db_logs_df=debug_log[debug_log['Template']== 'fact_forecast_details'],
                        report=communications['report']['fact_forecast_details'],
                        email=distribution_list,
                        folder=folder
                    )
                except Exception as err:
                    print(err, "Creating fact_forecast_details_report")

                try:
                    vc_report(
                        db_report_df=report_df[report_df['Template'] == 'vc'],
                        db_logs_df=debug_log[debug_log['Template']== 'vc'],
                        report=communications['report']['vc'],
                        email=distribution_list,
                        folder=folder
                    )
                except Exception as err:
                    print(err, "Creating VC")

    except Exception as err:
        print(err, "get_reports_from_db")


if __name__ == '__main__':
    get_reports_from_db()
