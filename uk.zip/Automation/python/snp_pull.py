import file_utils
import commonSourceInfo
import commonArgs
import file_utils
def snp_pull(source):
    args = commonArgs.parse()
    source = 'snp' #args.source
    frequency = 'monthly'# args.frequen
    file_utils.zipuncompressparts(commonSourceInfo.getPushOptionalFeedFiles(source, frequency), source, frequency)
if __name__ == '__main__':
   snp_pull('snp')
