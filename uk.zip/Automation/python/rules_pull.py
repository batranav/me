#!/usr/bin/env python

import datetime, pyodbc, re, zlib
from sendEmail import *
import parseYamlProperty
import getSQLdata
import os
import commonArgs
import AutomationLogging
from vault.secrets import get_db_secret

# Timestamps.

filedate = commonArgs.getFiledate()
filedate = filedate if filedate else datetime.datetime.today().strftime('%Y%m%d')
today     = datetime.datetime.strptime(filedate, '%Y%m%d')
yesterday = datetime.datetime.strptime(filedate, '%Y%m%d') - datetime.timedelta(days=1)
conn = None
#yesterday = datetime.datetime.now() - datetime.timedelta(hours=10)

today_timestamp     = today.strftime("%Y-%m-%d") + ' 00:00:00'
yesterday_timestamp = yesterday.strftime("%Y-%m-%d") + ' 00:00:00'

## All of our SQL.
sql_client_order = '''
select distinct *
from framework.client_order
where  ((received_dt  >= '{0}' and received_dt  < '{1}')
or  (completed_dt >= '{0}' and completed_dt < '{1}')) 
'''.format(yesterday_timestamp, today_timestamp)

sql_product_order = '''\
select PO.*
from framework.product_order PO
force index (PROD_ORDER_DATE_IDX) 
where po.order_dt >= '{0}'
and po.order_dt <  '{1}'
'''.format(yesterday_timestamp, today_timestamp)

sql_product_result = '''\
select *
from framework.product_result 
FORCE INDEX (PROD_RESULT_DATE_IDX)
where  result_dt >= '{0}'
and   result_dt <  '{1}'
'''.format(yesterday_timestamp, today_timestamp)

sql_client_result = '''\
select CR.*
from framework.client_result CR 
where  add_dt >= '{0}'
and   add_dt <  '{1}'
'''.format(yesterday_timestamp, today_timestamp)

sql_rule_plan = '''\
select * from framework.rule_plan
'''


sql_order_variable = '''\
select t1.* 
 from framework.order_variable t1 join 
      framework.client_order t2
      on t1.order_id = t2.order_id
where  ((t2.received_dt  >= '{0}' and t2.received_dt  < '{1}')
or  (t2.completed_dt >= '{0}' and t2.completed_dt < '{1}')) 
'''.format(yesterday_timestamp, today_timestamp)

sql_account = '''\
select acct_number, update_dt, update_id, description, acct_grp_seq, inactive_flg
from framework.account
'''

sql_acct_grp_option = '''\
select acct_grp_seq, option_name, option_value, option_type, update_id, update_dt
from framework.acct_grp_option
'''

sql_acct_option = '''\
select acct_number, option_name, option_value, option_type, update_id, update_dt
from framework.acct_option
'''

sql_rule_plan_acct_option_config = '''\
select * from framework.rule_plan_acct_option_config
'''

sql_account_grp_definition = '''\
select * from framework.account_grp_definition
'''

sql_acct_option_reference = '''\
select * from framework.acct_option_reference
'''

sql_acct_history_changes = '''\
select * from framework.acct_history_changes
'''

sql_to_execute = [
    sql_client_order,
    sql_product_order,
    sql_product_result,
    sql_client_result,
    sql_rule_plan,
    sql_order_variable,
    sql_account,
    sql_acct_grp_option,
    sql_acct_option,
    sql_rule_plan_acct_option_config,
    sql_account_grp_definition,
    sql_acct_option_reference,
    sql_acct_history_changes
    ]

logger = AutomationLogging.getLogger('preprocess_rules_pull')

## Connection strings, table names, and columns.
server = 'alalpdba054.risk.regn.net'
uname, pwd = get_db_secret(logger, server)
conn_string = (
        'DRIVER=MySQL ODBC 8.0 ANSI Driver;' +
        f'SERVER={server};' +
        'PORT=3306;' +
        'DATABASE=framework;' +
        f'UID={uname};' +
        f'PASSWORD={pwd};' +
        'AllowBatch=False;' +
        'NO_CACHE=1;' +
        'FORWARD_CURSOR=1;' +
        'UseCompression=True;')

table_list = [
    'client_order',
    'product_order',
    'product_result',
    'client_result',
    'rule_plan',
    'order_variable',
    'account',
    'acct_grp_option',
    'acct_option',
    'rule_plan_acct_option_config',
    'account_grp_definition',
    'acct_option_reference',
    'acct_history_changes'
    ]

blob_column_names = [
    'order_records',
    'result_records',
    'result']


def clean_field_names(field_names):
    replacements = [('[',  ''),
                    (',',  '|#?'),
                    (']',  ''),
                    ('\'', ''),
                    (' ',  '')]
    result = field_names
    for (before, after) in replacements:
        result = result.replace(before, after)
    return result


def get_compressed_data(blobdata):
    buf = blobdata
    if str.replace(str(buf), '\n', '') == "bytearray(b\'\')":
        return ''
    else:
        result = str(zlib.decompress(buf, 16 + zlib.MAX_WBITS))
        result = result.replace('\n', '')
        result = result.replace('|#?','')
    return result


def get_normal_data(data):
    try:
        data = data.strip()
    except AttributeError:
        data = str(data)
    if data == 'None':
        data = ''
    return data


printList = []
def printwrapper(str):
    print(str)
    printList.append(str)

def get_database_connection():
    global conn
    if conn == None:
        (connstr,scriptname) = getSQLdata.getSourcePullInfo(logger, 'rules','daily','')
        conn = pyodbc.connect(connstr)
    return conn

def pull_all_files():
    success_flag = True
    thrownthing = None
    try:
        printwrapper('Calling RULES DB extract process')
        start_time = datetime.datetime.now()
        printwrapper('Connection to RULES DB extablished')
        conn   = get_database_connection()
        for index, sql in enumerate(sql_to_execute):
            table_name = table_list[index]
            pull_one_file(table_name, sql, conn)
        endtime = datetime.datetime.now()
        tdelta = endtime - start_time
        tdelta_min = tdelta.total_seconds() / 60
        printwrapper('*************************************************************')
        printwrapper('Total Duration in minutes: {0}'.format(tdelta_min))
        printwrapper('RULES Data extract completed...')
        success_flag = True
        thrownthing = None
    except Exception as ex:
        printwrapper('Exception raised : {0}'.format(ex))
        success_flag = False
        thrownthing = ex
    finally:
        printwrapper('**********')
        printwrapper('All Done!')
        printwrapper('**********')
        email_subject = 'data pull from RULES DB for ' + today.strftime('%Y%m%d')
        email_from    =  'arjun.mudunuru@lexisnexis.com'
        email_to      = 'arjun.mudunuru@lexisnexis.com' 
        if success_flag:
            subject = 'Success: ' + email_subject
        else:
            subject = 'ERROR / WARNING: ' + email_subject
        #send_mail(email_from, email_to, '', subject, '' + '\n'.join(printList))
        send(email_from, email_to, '', subject, '' + '\n'.join(printList))
        if thrownthing:
            raise thrownthing


def pull_one_file(table_name, sqlquery, conn):
    printwrapper('\n****************************{0}*********************************'.format(table_name))
    printwrapper('\nTable being extracted : {0}'.format(table_name))
    file_name   = os.path.join(parseYamlProperty.get_inbound_dir(), 'rules\\daily\\' + table_name + '_' + today.strftime('%Y%m%d') + '.txt')
    # conn   = get_database_connection()
    cursor = conn.cursor()
    #cursor.execute("SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")
    cursor.execute(sqlquery)
    #print (cursor.description)
    columns     = [t[0] for t in cursor.description]
    field_names = str([i[0] for i in cursor.description])
    header      = clean_field_names(field_names)
    with open(file_name, 'w') as f:
        printwrapper('\nFile location : {0}'.format(file_name))
        f.write(header + '\n')
        printwrapper('\nFetching records from table : {0}'.format(table_name))
        row_count = 0
        while True:
            row = cursor.fetchone()
            if not row:
                break
            row_count += 1
            out_str = []
            for idx in range(len(cursor.description)):
                if columns[idx] in blob_column_names:
                    uz_clean = get_compressed_data(row[idx])
                    #out_str.append(uz_clean)
                    out_str.append(str(uz_clean)[2:len(str(uz_clean))-1])                   
                else:
                    field = get_normal_data(row[idx])
                    out_str.append(field)
            result = '|#?'.join(out_str)
            f.write(result + '\n')
        printwrapper('\nFile count of file {0} : {1} '.format(file_name, row_count))
        printwrapper('\nData extract completed for table : {0}'.format(table_name))


if __name__ == '__main__':
    pull_all_files()