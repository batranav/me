from .client import Client
from commonArgs import getApplication, getSource

def get_payload(logger, app, secret_type, source, secret):
    '''wraps vault.Client to instantiate hvac.client object, get secrets from vault, and logout client, plus it writes logs
       must specify secret keyword arg if you only want either uname or pwd, else returns tuple: (uname, pwd)'''
    start_msg = 'Initiating Vault Read: vault.secrets.get_{0}_secret(app={1}, source={2})'.format(secret_type, app, source)
    logger.debug(start_msg)
    print(start_msg)
    c = Client()
    payload = c.get_secret(app, secret_type, source, secret)
    c.logout()
    if (secret == 'both' and payload[0] and payload[1]) or payload:
        finish_msg = 'Finished Vault Read: vault.secrets.get_{0}_secret(app={1}, source={2})'.format(secret_type, app, source)
        logger.debug(finish_msg)
        print(finish_msg)
    else:
        fail_msg = 'Failed Vault Read: vault.secrets.get_{0}_secret(app={1}, source={2})'.format(secret_type, app, source)
        logger.debug(fail_msg)
        print(fail_msg)
    return payload

def get_ftp_secret(logger, source, app=getApplication(), secret='both'):
    '''get ftp secret(s) read, send args to get_payload'''
    payload = get_payload(logger, app, 'ftp', source, secret)
    return payload

def get_db_secret(logger, source, app=getApplication(), secret='both'):
    '''specify db secret read, send args to get_payload'''
    payload = get_payload(logger, app, 'db', source, secret)
    return payload

def get_api_secret(logger, source, app=getApplication(), secret='both'):
    '''specify api secret read, send args to get_payload'''
    payload = get_payload(logger, app, 'api', source, secret)
    return payload

def get_azure_secret(logger, source=getSource(), app='azure', secret='both'):
    '''specify azure secret read, send args to get_payload'''
    payload = get_payload(logger, app, 'service_principal', source, secret)
    return payload
