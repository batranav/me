import sys
import hvac
import traceback
from .creds import vault_url, vault_namespace, role_id, secret_id
from getProperties import getVaultFilename
from cryptography.fernet import Fernet
import requests.exceptions

class Client():

    def __init__(self):
        # instantiate hvac.Client object pointing to vault
        self.client = hvac.Client(url=vault_url, namespace=vault_namespace)
        self.login()

    def login(self):
        '''decrypt creds with key and login client'''
        # instantiate Fernet object to decrypt approle creds
        vault_decrypt_key = getVaultFilename()
        with open(vault_decrypt_key, 'r') as infile:
            f = Fernet(infile.read().encode())
        # login with decrypted creds
        try:
            self.client.auth.approle.login(
                role_id = f.decrypt(role_id).decode(),
                secret_id = f.decrypt(secret_id).decode()
            )
        except requests.exceptions.MissingSchema:
            traceback.print_exc()
            print('*** Invalid Vault URL')
            print('*** Vault is down or your URL is invalid')
            print('*** Check that vault.creds.vault_url = https://vault.cluster.us-vault-prod.azure.lnrsg.io/')
            sys.exit(1)
        except hvac.exceptions.InvalidRequest:
            traceback.print_exc()
            print('*** Invalid Request')
            print('*** Check that login creds & Fernet decrypt key are valid')
            sys.exit(1)

    def get_secret(self, app, file_type, source, secret):
        '''return secret(s) at source, pass either secret="uname" or secret="pwd" if you only need one'''
        path = f'{app}/{file_type}/{source}'
        try:
            if secret == 'both':
                uname = self.client.secrets.kv.v2.read_secret(
                    mount_point='uname',
                    path=path
                )['data']['data']['uname']
                pwd = self.client.secrets.kv.v2.read_secret(
                    mount_point='pwd',
                    path=path
                )['data']['data']['pwd']
                return uname, pwd
            else:
                return self.client.secrets.kv.v2.read_secret(
                    mount_point=secret,
                    path=path
                )['data']['data'][secret]
        except hvac.exceptions.InvalidPath:
            traceback.print_exc()
            print('*** Invalid Vault Path')
            print(f'*** No secrets exist at <{path}>')
            print('*** Please use a valid path')
            sys.exit(1)

    def list_secrets(self, mount, path):
        '''returns list of secrets at mount/path'''
        try:
            secrets = self.client.secrets.kv.v2.list_secrets(
                mount_point=mount,
                path=path
            )['data']['keys']
        except hvac.exceptions.InvalidPath:
            secrets = []
        return secrets

    def print_secrets(self, mount, path='', root=True):
        '''print out tree of secrets at path'''
        path_list = [item for item in path.split('/') if item]
        level = len(path_list)
        if root:
            print(f'/{mount}')
            for i, dir in enumerate(path_list):
                print('|   ' * i + '|---' + dir)
        if not path.endswith('/'):
            path += '/'
        secrets = self.list_secrets(mount, path)
        if secrets:
            for item in secrets:
                print('|   ' * level + '|---' + item.strip('/'))
                self.print_secrets(mount, path + item, False)

    def logout(self):
        '''logout client'''
        self.client.logout()

if __name__ == "__main__":
    client = Client()
    client.print_secrets('uname', '/')
    client.logout()
