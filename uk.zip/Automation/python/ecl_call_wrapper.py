from tempfile import mkstemp
from shutil import move
import os.path, re, glob, shutil, os, subprocess
from subprocess import Popen, PIPE
import parseYamlProperty as parse_props
from fileinput import close
import time
import datetime
from datetime import date
from xml.dom import minidom
from contextlib import closing
from xml.etree import ElementTree
import re
import sys
import getAutomationECLBuildCall
import parseJSONProperty
from pathlib import Path
import commonArgs
import AutomationLogging
import generateBuildNotification
import traceback
from collections import OrderedDict
import requests
from requests.auth import HTTPBasicAuth
import json
from commonSourceFiles import commonSourceFiles
import generateBuildLog
from vault.secrets import get_api_secret

ecl_script_dir = parse_props.get_ecl_script_dir()
base_script_dir = parse_props.get_base_script_dir()
# revisit - overall
_eclFileName = ""
_workunit = ""
_timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y%m%d_%H%M%S')
currentmonth = datetime.datetime.now().strftime('%Y%m')
(_thor_ip_port_temp, _thor_cluster) = parse_props.getHPCCURLCluster()
_thor_ip_port = _thor_ip_port_temp.replace('https://','').replace('http://','')

# to get values for _ssl_option and _ssl_option_args where the execution 
# comes other invoke_ecl, like invoke_by_filename and direct call to getWUError/getWUState
_ssl_option = parse_props.getSSLFlagForClusterURL()
if(_ssl_option == True):
    _ssl_option_args = '--ssl=true'
else:
    _ssl_option_args = '--ssl=false'

# _thor_ip_port = '10.194.169.2:8010'
# _thor_cluster = 'thor'
logger = AutomationLogging.getLogger('ecl_call_wrapper_invoke_ecl_by_filename', True)
_svc_acct, _svc_pwd = get_api_secret(logger, 'hpccthor')
_ecl_run_command = 'ecl'
_ecl_wait_args = '--wait=0'

_ecl_verbose = '-v'
_source = ''
_src_location = parse_props.get_src_dir(_source)
_script_to_run_base = parse_props.get_generated_ecl_dir()

def logMessage(logger, str):
    if logger is not None:
        logger.debug(str)

def getWUError(workunit):
    _ecl_to_call = [_ecl_run_command,
                'results',
                workunit, 
                _ssl_option_args,
    		'-s',
    		_thor_ip_port,
    		'-u',
    		_svc_acct,
		'-pw',
		_svc_pwd]

    print('What is the eclcall WUError {0}'.format(_ecl_to_call))
    
    p = subprocess.Popen(_ecl_to_call, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    stdoutlines = p.communicate()[0].decode('utf-8')
    stderrlines = p.communicate()[1].decode('utf-8')

    print('StdOut in WUError {0}'.format(stdoutlines))
    print('StdErr in WUError {0}'.format(stderrlines))

    if stderrlines != '':
        return stderrlines
    
    tree = ElementTree.fromstring(stdoutlines)
    # print('What is the tree {0}'.format(tree))
    errorMsgsSet = set()
    
    for node in tree.findall('./Exception/Message'):
        print(node.text)
        errorMsgsSet.add(node.text)
    
    return('\n'.join(errorMsgsSet))
    
def getWUResults(workunit):
    _ecl_to_call = [_ecl_run_command,
                'results',
                workunit,
                _ssl_option_args,
    		'-s',
    		_thor_ip_port,
    		'-u',
    		_svc_acct,
		'-pw',
		_svc_pwd]

    # print('What is the eclcall {0}'.format(_ecl_to_call))
    
    p = subprocess.Popen(_ecl_to_call, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    stdoutlines = p.communicate()[0].decode('utf-8')
    stderrlines = p.communicate()[1].decode('utf-8')

    # print(stdoutlines)

    tree = ElementTree.fromstring(stdoutlines)
    
    absoultePathSet = set()
    absoulteFileNameSet = set()

    for node in tree.findall('.//exportfilenameabsolutepath'):
        # print(node.text)
        absoulteFileNameSet.add(node.text)
        absoultePathSet.add(os.path.dirname(node.text))
    
    return(''.join(absoultePathSet), absoulteFileNameSet)

def call_ecl_compile(logger, input_ecl_script = None):
    logger.debug('going to compile_ecl now Input ecl script name - {0}'.format(input_ecl_script))
    if input_ecl_script is None:
        input_ecl_script = _script_to_run
    _src_location = parse_props.get_src_dir()
    _eclxmlsrc_location = os.path.join(parse_props.get_generated_ecl_xml_dir(), Path(input_ecl_script).stem + '.eclxml')

    logger.debug(_src_location)
    logger.debug(_eclxmlsrc_location)
    logfilename = os.path.join(parse_props.get_ecl_build_logs_dir(),  Path(input_ecl_script).stem + '.log')
    # _src_location = parse_props.get_src_dir(_source)

    _eclxml_to_call = [ os.path.join(parse_props.get_env_path_ecl_compiler(_source), 'eclcc.exe'),
                        input_ecl_script,
                        '-I',
                        _src_location,
                        '-E',
                        '-o', 
                        _eclxmlsrc_location,
                        '--logfile',
                        logfilename,
                        '--nostdinc'
                        ]
    
    p = subprocess.Popen(_eclxml_to_call, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    logger.debug('What is the eclcccall {0}'.format(_eclxml_to_call))

    eclxmlout = b''
    eclxmlerr = b''
   
    (eclxmlout, eclxmlerr) = p.communicate()

    stdeclxmllogs = eclxmlout.decode('utf-8').split("\r\n")
    stdeclxmlerrs = eclxmlerr.decode('utf-8').split("\r\n")

    logger.debug('compile_ecl completed now \n eclxmlsrc - {0} \n Subprocess returncode {1}\n eclcc out logs {2} \n eclcc err logs {3}'.format(_eclxmlsrc_location, p.returncode, stdeclxmllogs, stdeclxmlerrs))


    otherErrorList = []

    return (_eclxmlsrc_location, p.returncode, eclxmlout, eclxmlerr)

def call_ecl_async(logger, input_ecl_script = None):
    global _src_location, _ecl_run_command, _script_to_run
    
    if input_ecl_script is not None:
        _script_to_run = input_ecl_script
    # _eclxmlsrc_location = os.path.join(parse_props.get_generated_ecl_xml_dir(),  Path(_script_to_run).stem + '.eclxml')
    _eclcompiler_path = parse_props.get_env_path_ecl_compiler(_source)
    
    logfilename = os.path.join(parse_props.get_ecl_build_logs_dir(),  Path(_script_to_run).stem + '.log')

    # if os.path.exists(_eclxmlsrc_location) != True:
    (_eclxmlsrc_location, returncode, eclxmlout, eclxmlerr) = call_ecl_compile(logger)
    
    logger.debug('going to call_ecl now - input script name {0} and \n generated eclxml filename {1}'.format(_src_location, _eclxmlsrc_location))
        
    eclout = b''
    eclerr = b''
    if returncode == 0:
        _ecl_to_call = [ os.path.join(parse_props.get_env_path_ecl_compiler(_source), 'ecl.exe'),
                        'run',
                        _thor_cluster,
                        _eclxmlsrc_location,
                        _ecl_wait_args,
                        _ecl_verbose,
                        '--ecl-only',
                    '-s',
                    _thor_ip_port,
                    '-u',
                    _svc_acct,
                '-pw',
                _svc_pwd,
                _ssl_option_args,
                '-legacy',
                '-I',
                _src_location]

        logger.debug('What is the eclcall {0}'.format(_ecl_to_call))
        
        p = subprocess.Popen(_ecl_to_call, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        (eclout, eclerr) = p.communicate()

    stdoutlines = eclout.decode('utf-8').split("\r\n") + eclxmlout.decode('utf-8').split("\r\n")
    stderrlines = eclerr.decode('utf-8').split("\r\n") + eclxmlerr.decode('utf-8').split("\r\n")

    logger.debug('The ecl workunit logs are follows \n')
    otherErrorList = []
    wu = ''
    for line in stdoutlines + stderrlines:
        line = line.lower().strip()
        logger.debug(line + '\n')
        errorList = re.findall(r'\d+\ error', line, re.MULTILINE)
        if line.startswith('wuid'):
            wu = line.replace('wuid:', '').strip().upper()
            logger.debug('In Std Out WU {0}'.format(wu))
        
        if ": error c" in line:
            otherErrorList.append(line)
            logger.debug(line)
    logger.debug('The ecl workunit logs are completed \n')

    if len(errorList) != 0:
        return ('', '\n'.join(stderrlines))
    if len(otherErrorList) != 0:
        return ('', '\n'.join(otherErrorList))
    return (wu, '')



def invoke_ecl_and_wait_for_completion(logger, sourceRun):
    source = sourceRun.source
    frequency = sourceRun.frequency
    filedate = sourceRun.file_date
    logger.debug('In invoke_ecl_and_wait_for_completion {0}, {1}, {2}'.format(source, frequency, filedate))
    env = commonArgs.getEnv()

    (workunit, wuInvokeErrMsg) = invoke_ecl(logger, sourceRun)
    logger.debug('Workunit submitted - {0}, wu invoke error msgs {1}'.format(workunit, wuInvokeErrMsg))
    if wuInvokeErrMsg != '' or workunit == '':
        return ('No Workunit', 'failed' , wuInvokeErrMsg)
    (workunit, wuState, wuMsg) = check_for_completion(logger, workunit)
    return (workunit, wuState, wuMsg)

def invoke_ecl(logger, sourceRun):

    global _script_to_run, _thor_cluster, _thor_ip_port, _source, _ssl_option, _ssl_option_args
    source = sourceRun.source
    frequency = sourceRun.frequency
    filedate = sourceRun.file_date
    env = commonArgs.getEnv()   
    _source = source

    logger.debug('invoke_ecl -- {0}, {1}, {2}'.format(source, frequency, filedate))
    sourceInfo = parseJSONProperty.getSourceInfo(source, frequency, filedate)
    (_thor_ip_port, _thor_cluster) = parse_props.getHPCCURLCluster(source, sourceInfo.clustername)
    _thor_ip_port = _thor_ip_port.lower().replace('http://', '').replace('https://', '')
    _ssl_option = parse_props.getSSLFlagForClusterURL(source, sourceInfo.clustername)
    if(_ssl_option == True):
        _ssl_option_args = '--ssl=true'
    else:
        _ssl_option_args = '--ssl=false'
    logger.debug('invoke_ecl -- Thor IP {0}, thor cluster {1}'.format(_thor_ip_port,_thor_cluster))
    _script_to_run = getAutomationECLBuildCall.createECL(logger, source, frequency, filedate, env)
    logger.debug('invoke_ecl -- scriptToRun {0}'.format(_script_to_run))

    (workunit, errorMsgs) = call_ecl_async(logger)

    logger.debug('invoke_ecl -- errorMsgs {0}'.format(errorMsgs))

    print(errorMsgs)
    if errorMsgs:
        print('Processinng ERROR MSG \n\n\n')
        sys.tracebacklimit = None
        sys.stderr.write(errorMsgs + '\n')
        return (workunit, errorMsgs)
        # raise RuntimeError('Error creatinng WU')
    
    return (workunit, '')

def check_for_completion(logger, workunit):
    #### my wu start time - 730
    #### wu_threashold parseYamlProperty.getLockCheckWaitTime(commonArgs.getSource())  - 30
    workunit_start_time = datetime.datetime.now()
    threshold_time = parse_props.get_lock_check_wait_time(commonArgs.getSource())
    logger.debug('Thershold time {0}'.format(threshold_time))
    
    now_plus_threshold_time = workunit_start_time + datetime.timedelta(minutes = threshold_time)
    while True:
        logger.debug('check_for_completion for WU {0}'.format(workunit))
        print('going in iteration {0}'.format(workunit))
        time.sleep(60)
        (wuState, wuflag) = getWUState(workunit)
 
        logger.debug('check_for_completion GetWUState {0}, wuFlag {1}'.format(wuState, wuflag))
     
        if wuflag == True:
            break
        else:
            False
            if now_plus_threshold_time  < datetime.datetime.now():
                now_plus_threshold_time = now_plus_threshold_time + datetime.timedelta(minutes = 5) 
                (wuLockState, wuLockMessage) = isWUlocked(logger, workunit)
                if wuLockState == True:
                    # return (workunit, False, wuLockMessage)
                    Lockerror(workunit, False, wuLockMessage, workunit_start_time)
                    # Send Warning email about WU is locked with messages 
    if wuflag:
        if wuState == 'completed':
            return (workunit, wuState, '')
        else:
            wuMsg = getWUError(workunit)
            return (workunit, wuState, wuMsg)
    else:
        wuMsg = getWUError(workunit)
        return (workunit, wuState, wuMsg)

def Lockerror(workunit, runstatus, errormessage, hpccstarttime):
    run_date_time = datetime.datetime.now()
    source = commonArgs.getSource()
    frequency = commonArgs.getFrequency()
    processtype = 'FromHpcc'
    WarningRun = commonSourceFiles(source, frequency, processtype)
    WarningRun.source = source
    WarningRun.successEmailTo = ",".join(parse_props.get_success_email(source)) 
    WarningRun.errorEmailTo = ",".join(parse_props.get_error_cc_email(source))
    WarningRun.processtype = processtype
    WarningRun.workunit = workunit
    WarningRun.file_date = commonArgs.getFiledate()
    WarningRun.frequency = frequency
    WarningRun.processStartTime = hpccstarttime
    WarningRun.processEndTime = run_date_time
    WarningRun.processerrorMsg = errormessage
    WarningRun.status = runstatus    
    log_filename = WarningRun.source + '_' + WarningRun.frequency + '_' + WarningRun.file_date + '_build.html'
    WarningRun.log_filename = log_filename
    generateBuildLog.generate(WarningRun)    
    generateBuildNotification.notifyWarningEmail(WarningRun)
 
def isWUlocked(logger, workunit):
    base_soap_url = "{0}/WsWorkunits".format(parse_props.getHPCCURL())
    re_cdf_lock = "CDFAction\s+lock\s+timed\s+out\s+on[^<]+?\""
    wdetails_soap_url = "{0}/WUInfoDetails.json?Wuid={1}".format(base_soap_url, workunit)
    logger.debug("Make soap call to {0} to get process id ".format(wdetails_soap_url))
    head = {'Content-type':'application/json; charset=UTF-8', 'Accept':'application/json'}
    try:

        ret = requests.post(wdetails_soap_url,auth=HTTPBasicAuth(_svc_acct, _svc_pwd))
        json1_data = json.loads(ret.text, object_pairs_hook=OrderedDict)
        json_dict = OrderedDict(json1_data['WUInfoResponse']['Workunit']['Helpers'])
        res = json_dict['ECLHelpFile']
        log_url = ''
        for list_value in res:
            dict_value = dict(list_value)
            if dict_value['Type'] == 'EclAgentLog':
                eclagentlog_url = "{0}/WUFile/EclAgentLog?Wuid={1}&Name={2}&Process={3}&Type=EclAgentLog".format(base_soap_url, workunit, dict_value['Name'], str(dict_value['PID']))
                logger.debug("Make soap call to {0} to get soap lock out message".format(eclagentlog_url))
                ret = requests.post(eclagentlog_url, auth=HTTPBasicAuth(_svc_acct, _svc_pwd))
                find_index = re.findall(re_cdf_lock, ret.text)
                Locked_flag = False
                locked_file_name = ""
                if find_index:
                    Locked_flag = True
                    locked_file_name = find_index[0]
                return(Locked_flag, locked_file_name)
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        processerrorMsg =  ''.join(line for line in lines)
        return(False, processerrorMsg)

def invoke_ecl_by_filename(eclfilename):
    
    global _script_to_run
    
    print('EclFileName to Call {0}'.format(eclfilename))
    
    _script_to_run = eclfilename 

    (workunit, errorMsgs) = call_ecl_async(logger)

    print(errorMsgs)
    if errorMsgs:
        print('Processinng ERROR MSG \n\n\n')
        sys.tracebacklimit = None
        sys.stderr.write(errorMsgs + '\n')
        return (workunit, errorMsgs)
        # raise RuntimeError('Error creatinng WU')
    
    if errorMsgs != '':
        return ('No Workunit', 'failed' , errorMsgs)
    (workunit, wuState, wuMsg) = check_for_completion(logger, workunit)
    return (workunit, wuState, wuMsg)
    
def getWUState(workunit):

    result = subprocess.run([_ecl_run_command, 'status', '-wu',  workunit, _ssl_option_args, '-s', _thor_ip_port, '-u', _svc_acct, '-pw', _svc_pwd], stdout=subprocess.PIPE)
    wuState = result.stdout.lower().strip().decode('ascii') 
    print (wuState)
    if wuState.lower() in ['completed', 'compiled', 'aborted', 'failed']:
        # print('True')
        return (wuState, True)
    else:
        # print('False')
        return (wuState, False)

def getWUIDbyJob(jobName):

    result = subprocess.run([_ecl_run_command, 'getWuid', '-n',  jobName, _ssl_option_args, '-s', _thor_ip_port, '-u', _svc_acct, '-pw', _svc_pwd], stdout=subprocess.PIPE)

    wuid = result.stdout.lower().strip().decode('ascii')

    #print (wuid)

    return wuid        


if __name__ == "__main__":
    # createECL('mbs', 'daily', '20170606', 'build_mbs', ['red', 'source', 'billing', 'mbs'])
    # createECL('DNC_ELOQUA_EXTRACT', 'daily', '20170405', 'dnc_eloqua_extract', ['red', 'extract', 'marketing'])
    # invoke_ecl('LEXISNEXIS_PERSONAL_REPORTS', 'monthly', '20170502', 'build_LEXISNEXIS_PERSONAL_REPORTS' , ['red', 'source', 'billing', 'lexisnexis_personal_reports'])
    # invoke_ecl('LEXISNEXIS_PERSONAL_REPORTS', 'daily', '20170502', ['red', 'source', 'billing', 'lexisnexis_personal_reports', 'build_LEXISNEXIS_PERSONAL_REPORTS'])
    # invoke_ecl('mbs', 'daily', '20170606', ['red', 'source', 'billing', 'mbs', 'build_mbs']);
    #print(getWUStatusTest('W20171012-215240'))
    print(getWUError('W20180423-221416'))
