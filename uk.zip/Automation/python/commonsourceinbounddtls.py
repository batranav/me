class commonsourceinbounddtls(object):
    sourcefolder = ""  
    retentiondays = ""

    def __init__(self, _sourcefolder, _retentiondays):
        self.sourcefolder = _sourcefolder
        self.retentiondays = _retentiondays

    def __str__(self):
        sb = []
        for key in self.__dict__:
            sb.append("{key}='{value}'".format(key=key, value=self.__dict__[key]))
        return ',\n '.join(sb)
    
    def __repr__(self):
        return self.__str__() 
