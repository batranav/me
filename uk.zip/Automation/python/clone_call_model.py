import os
import sys
import paramiko
import parseYamlProperty
import AutomationLogging
from commonArgs import getSource
import get_vault_ssh
from vault.secrets import get_api_secret

def get_ssh_client(pemkey_filepath, user, host):
    k = paramiko.RSAKey.from_private_key_file(pemkey_filepath)
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect( hostname=host, username=user, pkey=k)
    return c

def remove_pemkey(pemkey_filepath):
    pemkey_filepath_win = pemkey_filepath.replace('/C/', 'C:/')  # reformat to Windows friendly path
    if os.path.exists(pemkey_filepath_win):
        os.chmod(pemkey_filepath_win, 0o700)
        os.remove(pemkey_filepath_win)

# get source and create custom logger
source = getSource()
logger = AutomationLogging.getLogger(source)

logger.info('Retreiving openstack pem key from vault...')
# get filepath for pem key we use to authenticate sftp connection
openstack_pemkey_filepath = parseYamlProperty.get_openstack_rsa_key_path()
# pull down the openstack pem key from the vault
get_vault_ssh.get_ssh_key(vault_source='openstack_prvkey', logger=logger)

logger.info('Retreiving github pem key from vault...')
# get filepath for github pem key we will be moving
github_pemkey_filepath = parseYamlProperty.get_github_rsa_key_path()
# pull down the github pem key from the vault
get_vault_ssh.get_ssh_key(vault_source='github_prvkey', logger=logger)

# user and host of machine we want ssh connection
logger.info('Creating paramiko ssh client...')
user = get_api_secret(logger, 'openstack', secret='uname')
host = 'fido-prod.jupyter_spark.noam.lnrm.net'
# get ssh client for sftp copy and remote calls
try:
    ssh_client = get_ssh_client(openstack_pemkey_filepath, user, host)
except Exception as err:
    logger.info('Error creating ssh client: check error log and debug ssh connection')
    logger.error(f'Error creating ssh client: Ensure User ({user}) & pem key (openstack_prvkey) are valid and host ({host}) is running')
    logger.error(err)
    raise err

logger.info('Creating paramiko sftp client...')
# create sftp client for moving files
sftp_client = ssh_client.open_sftp()
# list of tuples: source, destination of files being moved over sftp
github_pemkey_dest = f'/home/{user}/fido/github_prvkey.pem'
clone_model_src = 'C:\\automation\\scripts\\python\\cloneModel.py'
clone_model_dest = f'/home/{user}/fido/cloneModel.py'
src_dest_pairs = [
    (github_pemkey_filepath, github_pemkey_dest),
    (clone_model_src, clone_model_dest)      
]
logger.info('SFTP Copying github pem key and clone model script...')
# iterate through list and move files with sftp client
for src, destination in src_dest_pairs:
    try:
        sftp_client.put(src, destination)
    except Exception as err:
        logger.info(f'Error copying {src} to {destination}; Check error log and debug')
        logger.error(f'Error copying {src} to {destination}')
        logger.error(err)
        raise err
sftp_client.close()

logger.info('Remotely calling cloneModel.py using ssh client...')
# now remotely call clone script
try:
    stdin, stdout, stderr = ssh_client.exec_command(f'python {clone_model_dest}')
    print(stdout.read().decode(), end='')
    sys.stderr.write(stderr.read().decode())
except Exception as err:
    logger.info(f'Error calling {clone_model_dest}; Check error log and debug')
    logger.error(f'Error calling {clone_model_dest}')
    logger.error(err)
    raise err

# now remotely call clone script
source_script_map = {'clone_call_imi': 'IMI_Contributory_insuranceBenchmark_script.sh', 'clone_call_mvr': 'MVR_missingBatch_script.sh'}
logger.info(f'Remotely calling {source_script_map[source]} using ssh client...')
try:
    stdin, stdout, stderr = ssh_client.exec_command(f"bash /home/{user}/fido-models/scripts/{source_script_map[source]}")
    print(stdout.read().decode(), end='')
    sys.stderr.write(stderr.read().decode())
except Exception as err:
    logger.info(f'Error calling {source_script_map[source]}; Check error log and debug')
    logger.error(f'Error calling {source_script_map[source]}')
    logger.error(err)
    raise err

# close client
ssh_client.close()

logger.info(f'Removing temp ssh pem keys from this machine...')
# delete the pem keys from this machine
for pemkey_filepath in (openstack_pemkey_filepath, github_pemkey_filepath):
    try:
        remove_pemkey(pemkey_filepath)
    except Exception as err:
        logger.info(f'Error removing {pemkey_filepath}; Check error log and debug')
        logger.error(f'Error calling {pemkey_filepath}')
        logger.error(err)
        raise err
logger.info('...process finished without error')