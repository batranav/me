import sys, http.client, os, os.path
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from send_email import *
import parseYamlProperty

error_email_list = ['stephen.rosser@lexisnexis.com','Vijay.Maddipatla@lexisnexisrisk.com']

project_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_projectlog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
workgroup_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_workgrouplog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
resource_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_resourcelog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
contour_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_contourlog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
allocation_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_allocationlog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
change_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_changeloglog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
objects_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_objectslog_'+ datetime.now().strftime('%Y%m%d') + '.txt')
bus_case_log_path = os.path.join(parseYamlProperty.get_build_logs_dir(),'innotas_buscase_namelog_'+ datetime.now().strftime('%Y%m%d') + '.txt')


def validate_innotas_soap(filename):
	if os.path.isfile(filename):
		log_file = open(filename, 'r')
		log_contents = log_file.read()
		if 'status_code: 504' in log_contents:
			send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','Innotas SOAP Issue -- Gateway Timeout -- ' + filename,log_contents)
			print(log_contents)
		elif 'reply: \'\'' in log_contents:
			send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','Innotas SOAP Issue -- Gateway Timeout -- ' + filename,log_contents)
			print(log_contents)
		elif 'status_code: 500' in log_contents:
			send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','Innotas SOAP Issue -- Internal Server Error -- ' + filename,log_contents)
			print(log_contents)
	else:
		send_mail('stephen.rosser@lexisnexis.com',error_email_list,'','Innotas SOAP Issue -- Log File Not Found -- ' + filename,'')

validate_innotas_soap(project_log_path)
validate_innotas_soap(workgroup_log_path)
validate_innotas_soap(resource_log_path)
validate_innotas_soap(contour_log_path)
validate_innotas_soap(allocation_log_path)
validate_innotas_soap(change_log_path)
validate_innotas_soap(objects_log_path)
validate_innotas_soap(bus_case_log_path)