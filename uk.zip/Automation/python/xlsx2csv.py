import xlrd
import csv
import os.path
import parseYamlProperty
def csv_from_excel(inputfile, outputfile):
    
    if os.path.isfile(inputfile): 
        wb = xlrd.open_workbook(os.path.join(parseYamlProperty.get_inbound_dir(),'ins_performance_hub\\' + inputfile))
        sh = wb.sheet_by_name('Table')
        your_csv_file = open(os.path.join(parseYamlProperty.get_inbound_dir(),'ins_performance_hub\\' + outputfile), 'w', encoding='utf-8', newline='')
        wr = csv.writer(your_csv_file, quoting=csv.QUOTE_ALL)
        for rownum in range(sh.nrows):
           wr.writerow(sh.row_values(rownum))
        your_csv_file.close()

    else:
        print('input file not found' + inputfile)

    
csv_from_excel('HPCC CC monthly SLA.xlsx',          'HPCC_CC_monthly_SLA_20160218.csv')
csv_from_excel('HPCC cc mtd report.xlsx',	     'HPCC_cc_mtd_report_20160218.csv')
csv_from_excel('HPCC CC weekly.xlsx',		     'HPCC_CC_weekly_20160218.csv')
csv_from_excel('HPCC CCFC SLA monthly.xlsx',	     'HPCC_CCFC_SLA_monthly_201601.csv')
csv_from_excel('HPCC CCFC SLA Weekly.xlsx',	     'HPCC_CCFC_SLA_Weekly_20160218.csv')
csv_from_excel('HPCC cdsc report.xlsx',	             'HPCC_cdsc_report_20160218.csv')
csv_from_excel('HPCC clua cc report.xlsx',	     'HPCC_clua_cc_report_20160218.csv')
csv_from_excel('HPCC CLUA weekly.xlsx',	             'HPCC_CLUA_weekly_20160218.csv')
csv_from_excel('HPCC CLUEA monthly SLA.xlsx',	     'HPCC_CLUEA_monthly_SLA_20160218.csv')
csv_from_excel('HPCC cluea report.xlsx',	     'HPCC_cluea_report_20160218.csv')
csv_from_excel('HPCC cluea_cc monthly SLA.xlsx',    'HPCC_cluea_cc_monthly_SLA_20160218.csv')
csv_from_excel('HPCC cluea_cc weekly.xlsx',	     'HPCC_cluea_cc_weekly_20160218.csv')
csv_from_excel('HPCC CLUEP monthly SLA.xlsx',	     'HPCC_CLUEP_monthly_SLA_20160218.csv')
csv_from_excel('HPCC cluep report.xlsx',	     'HPCC_cluep_report_20160218.csv')
csv_from_excel('HPCC CLUEP weekly SLA.xlsx',	     'HPCC_CLUEP_weekly_SLA_20160218.csv')
csv_from_excel('HPCC dd rollup.xlsx',		     'HPCC_dd_rollup_20160218.csv')
csv_from_excel('HPCC de rollup.xlsx',		     'HPCC_de_rollup_20160218.csv')
csv_from_excel('HPCC hsi_detail rollup.xlsx',	     'HPCC_hsi_detail_rollup_20160218.csv')
csv_from_excel('HPCC iid rollup.xlsx',		     'HPCC_iid_rollup_20160218.csv')
csv_from_excel('HPCC life_eirl rollup.xlsx',	     'HPCC_life_eirl_rollup_20160218.csv')
csv_from_excel('HPCC NCF CC Monthly SLA.xlsx',	     'HPCC_NCF_CC_Monthly_SLA_20160218.csv')
csv_from_excel('HPCC ncf cc mpo rollup.xlsx',	     'HPCC_ncf_cc_mpo_rollup_20160218.csv')
csv_from_excel('HPCC NCF CC Weekly.xlsx',	     'HPCC_NCF_CC_Weekly_20160218.csv')
csv_from_excel('HPCC ncf detail rollup.xlsx',	     'HPCC_ncf_detail_rollup_20160218.csv')
csv_from_excel('HPCC NCF monthly SLA.xlsx',	     'HPCC_NCF_monthly_SLA_20160218.csv')
csv_from_excel('HPCC pd rollup.xlsx',		     'HPCC_pd_rollup_20160218.csv')
csv_from_excel('HPCC vin res times rollup.xlsx',     'HPCC_vin_res_times_rollup_20160218.csv')
csv_from_excel('HPCC VIN SLA monthly.xlsx',	     'HPCC_VIN_SLA_monthly_201601.csv')
csv_from_excel('HPCC VIN SLA weekly.xlsx',	     'HPCC_VIN_SLA_weekly_20160218.csv')
csv_from_excel('HPCC_cc DAILY SLA.xlsx',	     'HPCC_cc_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_ccfc DAILY SLA.xlsx',	     'HPCC_ccfc_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_ccfc mtd report.xlsx',	     'HPCC_ccfc_mtd_report_20160218.csv')
csv_from_excel('HPCC_clua DAILY SLA.xlsx',	     'HPCC_clua_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_clua _cc DAILY SLA.xlsx',	     'HPCC_clua__cc_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_clup DAILY SLA.xlsx',	     'HPCC_clup_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_ncf DAILY SLA.xlsx',	     'HPCC_ncf_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_ncf_cc_mpo DAILY SLA.xlsx',     'HPCC_ncf_cc_mpo_DAILY_SLA_20160218.csv')
csv_from_excel('HPCC_vin DAILY SLA.xlsx',	     'HPCC_vin_DAILY_SLA_20160218.csv')
