import shutil
import os
import sys
from pathlib import Path
path = str(Path(Path(__file__).parent.absolute()).parent.absolute())
sys.path.insert(0, path)
import commonArgs
import parseYamlProperty
def copyFilesToVMdirectory(src, frequency):
    src_dir = os.path.join(parseYamlProperty.get_inbound_dir(), src, frequency)
    dst_dir = os.path.join(parseYamlProperty.get_inbound_dir(), 'vm_' + src, frequency)
    print(dst_dir)
    print(src_dir)
    for item in os.listdir(src_dir):
        s = os.path.join(src_dir, item)
        d = os.path.join(dst_dir, item)
        if os.path.isdir(s):
            continue
        else:
            shutil.copy2(s, d)




if __name__ == "__main__":
    copyFilesToVMdirectory(commonArgs.getSource(),commonArgs.getFrequency())