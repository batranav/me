#filters output
from send_email import *
import datetime
import io
import logging
import optparse
import os
import platform
import subprocess
import sys
from git import Repo
from git import Git    
from git import RemoteProgress
import parseYamlProperty
import commonArgs
from pathlib import Path
import get_vault_ssh
import time

dt = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')  # datetime now (all in UTC)
dtstr = datetime.datetime.strptime(dt, '%Y%m%d%H%M%S%f').strftime('%m-%d-%Y_%H%M%S')

print(dtstr)

_processInfo = []

class CloneProgress(RemoteProgress):
    def update(self, op_code, cur_count, max_count=None, message=''):
        global _processInfo
        _processInfo.append(self._cur_line)
        #print(self._cur_line)

def cloneProject():

    print(dt)
    rsaKeyFilepath = parseYamlProperty.get_git_rsa_key_path()
    # create temporary rsa key file at rsaKeyFilepath
    get_vault_ssh.get_ssh_key('gitlab_id_rsa')
    appFolder = parseYamlProperty.get_base_src_dir()
    tsFolder = os.path.join(appFolder , dt, myApplication)
    tsFolder = str(Path(tsFolder).resolve())
    
    if not os.path.exists(tsFolder):
        os.makedirs(tsFolder)
        try:
            rsaKeyFilepath_unix = '/' + str(Path(rsaKeyFilepath.replace(':',''))).replace('\\','/')
            Repo.clone_from('git@gitlab.ins.risk.regn.net:fido/' + myApplication + '.git', tsFolder, progress=CloneProgress(), env=dict(GIT_SSH_COMMAND="ssh -i " + rsaKeyFilepath_unix))
            # remove temporary rsa key file at rsaKeyFilepath
            if os.path.exists(rsaKeyFilepath):
                os.chmod(rsaKeyFilepath, 0o700)
                os.remove(rsaKeyFilepath)
            return True
        except:
            raise Exception('Error during git Clone {0}'.format(str(tsFolder)))
    
    return False

def killprocess(pidList):
    for pid in pidList:
        killproc = subprocess.Popen(['Taskkill','/PID', pid, '/F'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        for killline in io.TextIOWrapper(killproc.stdout, encoding="UTF-8"):
            print(killline.rstrip())
            logging.info(killline.rstrip())
      
def ensure_dir(directory):
    print('Ensure Dir {0}'.format(directory))
    if not os.path.exists(directory):
        os.makedirs(directory)
              
def process():

    global dt,myApplication
    print(dt)
    myApplication = commonArgs.getApplication()
    
    gitlabfolderBase = parseYamlProperty.get_code_dir()
    fidofolder  = gitlabfolderBase + '\\fido'
    backupfolder = gitlabfolderBase + '\\fido' + dt
    timestampfolder = gitlabfolderBase + '\\' + dt
     
    ensure_dir(fidofolder) 

    _errLogfile = os.path.join(parseYamlProperty.get_git_logs_dir(), myApplication + '_gitclone_' + dt + '.err')

    returncode = cloneProject()
    
    strReturnCode = str(returncode)
    time.sleep(60)

    print(_processInfo)
    print('Whats my return code -- {0}'.format(strReturnCode))

    #print(gitErr, gitOut, returncode)
    processInfo = []
	
    errFlag = False
   
    if not returncode:
        processInfo.append(strReturnCode)
        sendMail(processInfo)
        exit(1)
   
    try:
        os.rename(fidofolder, backupfolder)
    except OSError as ioex:
        print('OS Error is #1 .. {0}'.format(os.strerror(ioex.errno)))
        errFlag = True              
    #os.rename(dt, fidofolder)

    if errFlag:
        appLog = os.path.join(parseYamlProperty.get_git_logs_dir(), '\\gitlablock_' + str(dt) + '.log')
        logging.basicConfig(filename=appLog, level=logging.INFO)
        
        proc = subprocess.Popen(['handle64', '/accepteula', '-u', str(Path(parseYamlProperty.get_base_src_dir()).resolve())],stdout=subprocess.PIPE, shell=True)
                        
        killPIDList = []
        prevPID = 0

        for line in io.TextIOWrapper(proc.stdout, encoding="utf-8"):
            if "pid" in line:
                pid_line = line.rstrip()
                print('Pid Line {0}'.format(pid_line))
                logging.info(pid_line)
                words = pid_line.split()
                print('Words {0}'.format(words))
                prevword = ''
                for word in words:
                    if prevword == 'pid:':
                        pidvalue = word
                        print(pidvalue)
                        killPIDList.append(pidvalue)
                        if prevPID != pidvalue:
                            processInfo.append(line)
                        prevPID = pidvalue
                    prevword = word
        print('Process Info {0}'.format(processInfo))
        sendMail(processInfo)
    else:
        print('Inside Else {0}'.format(errFlag))
        if not errFlag:
            try:
                print('Going to rename {0} to {1}'.format(timestampfolder, fidofolder))
                os.rename(timestampfolder, fidofolder)
                # sendSuccessEmail(processInfo)
            except OSError as ioex:
                print('OS Error is #2.. {0}'.format(os.strerror(ioex.errno)))

def sendMail(processInfo) :
        servername = platform.node()
        
        EmailSubject = servername + '-- ' + myApplication +' GitLabPull - ' + dtstr 

        ErrorEmailSubject = 'ERROR / WARNING : ' + EmailSubject
        
        emailFrom = 'fido-' + myApplication + '-gitpull.automation@lexisnexisrisk.com'
        emailTo = ['raja.sundarrajan@lexisnexisrisk.com','Aishwarya.Srivastava@lexisnexisrisk.com','Nyruthya.Sanandan@lexisnexisrisk.com']
        print('EmailTo -- {0}'.format(emailTo))
        send_mail(emailFrom,emailTo,['raju.nagarajan@lexisnexisrisk.com'],ErrorEmailSubject,'' + '\n'.join(processInfo))

def sendSuccessEmail(processInfo) :
        servername = platform.node()
        
        EmailSubject = servername + '-- ' + myApplication +' GitLabPull - ' + dtstr 

        ErrorEmailSubject = 'SUCCESS : ' + EmailSubject
        
        emailFrom = 'fido-' + myApplication + '-gitpull.automation@lexisnexisrisk.com'
        emailTo = ['raja.sundarrajan@lexisnexisrisk.com','Aishwarya.Srivastava@lexisnexisrisk.com','Nyruthya.Sanandan@lexisnexisrisk.com']
        print('EmailTo -- {0}'.format(emailTo))
        send_mail(emailFrom,emailTo,['raju.nagarajan@lexisnexisrisk.com'],ErrorEmailSubject,'' + '\n'.join(processInfo))
		
if __name__ == "__main__":
    process()
    print('All Done!')