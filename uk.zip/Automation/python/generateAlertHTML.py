import ScoutNotification
import scoutUtils
import os
from collections import namedtuple

def xstr(s):
    return '' if s is None else str(s)

htmlHeader = """<html>
                <head> 
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii"> 
                </head>
                <style>#alert {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }
                #alert td, 
                #alert 
                th {   border: 1px solid #ddd;   padding: 8px;}
                #alert 
                th {    padding-top: 10px;   padding-bottom: 10px;   text-align: left;   background-color: #357040;   color: white;}  
                #alertsuccess {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }  
                #alertsuccess td, #alert th { border: 1px solid #ddd;   padding: 8px;} 
                #alertsuccess th { padding-top: 10px;   padding-bottom: 10px; 
                text-align: left;   background-color: #354c70;   color: white;} 
                #alerterror {font-family: \'Trebuchet MS\', Arial, Helvetica, sans-serif;border-collapse: collapse;width: 100%; }
                #alerterror td, #alert th {   border: 1px solid #ddd;   padding: 8px;}
                #alerterror th {    padding-top: 10px;   padding-bottom: 10px;   text-align: left;   background-color: #f25d5d;   color: white;}  
                </style>"""

def generateAudit(alertRunList):
    
    searchDataRow = ""

    searchTable = """ <TABLE id="alert"> 
                            <TR> 
                            <th>Alert Id</th> 
                            <th>Alert Name</th>
                            <th>Requested By</th>
                            <th>Workunit</th>
                            <th>Status</th>
                            <th>Number of files</th>
                            <th>Start Time</th> 
                            <th>End Time</th> 
                            <th>Elapsed Time</th> 
                            </tr> """
    
    for alertRun in alertRunList:
        searchDataRow += (' <tr> ' 
                        '<td>' + xstr(alertRun.id) + '</td>' 
                        '<td>' + xstr(alertRun.name) + '</td>'
                        '<td>' + xstr(alertRun.requestedUser) + '</td>'                        
                        '<td>' + xstr(alertRun.workunit) + '</td>' 
                        '<td>' + xstr(alertRun.workunitStatus) + '</td>' 
                        '<td>' + xstr(len(alertRun.set_of_exportedFiles)) + '</td>' 
                        '<td>' + xstr(alertRun.startTime) + '</td>' 
                        '<td>' + xstr(alertRun.completionTime) + '</td>' 
                        '<td>' + xstr(alertRun.elapsedTime) + '</td>' 
                        '</tr>')

    if alertRunList:
        searchDataRow += '</TABLE>'
        return (htmlHeader + searchTable + searchDataRow)
    else: 
        return htmlHeader + '<table><tr><td>No Data exported</td></tr></table>'

def getInfo(inputfield):

    InputFieldTranslation = namedtuple('InputFieldTranslation', 'input_field literal required')

    inputFieldList = []

    inputFieldList.append(InputFieldTranslation('alert_id', 'Alert Id', True))
    inputFieldList.append(InputFieldTranslation('type_description','Alert Description', True))
    inputFieldList.append(InputFieldTranslation('alert_name','Alert Name', True))
    inputFieldList.append(InputFieldTranslation('esp_method_name','ESP Method Name', True))
    inputFieldList.append(InputFieldTranslation('alert_baseline_timeframe_type_description','Baseline Type', True))
    inputFieldList.append(InputFieldTranslation('date_range_type_description','Baseline Date Description', True))
    inputFieldList.append(InputFieldTranslation('threshold_increases_by_percent','Increase by %', False))
    inputFieldList.append(InputFieldTranslation('threshold_decreases_by_percent','Decrease by %', False))
    inputFieldList.append(InputFieldTranslation('company_id','Company Id', False))
    inputFieldList.append(InputFieldTranslation('mbs_product_id','Product Id', False))
    inputFieldList.append(InputFieldTranslation('score_low','Score Low', False))
    inputFieldList.append(InputFieldTranslation('score_high','Score High', False))
    inputFieldList.append(InputFieldTranslation('score_average_excluding_exceptions',' Score Average Flag', False))
    inputFieldList.append(InputFieldTranslation('score_median_excluding_exceptions','Score Median Flag', False))
    inputFieldList.append(InputFieldTranslation('inputfield_id', 'Variance By (Inputfield)', False))
    inputFieldList.append(InputFieldTranslation('date_added', 'Date Added', True))
    inputFieldList.append(InputFieldTranslation('user_added', 'User Added', True))
    inputFieldList.append(InputFieldTranslation('date_changed', 'Date Changed', True)) 
    inputFieldList.append(InputFieldTranslation('user_changed', 'User Changed', True))
    
    for field in inputFieldList:
        if field.input_field == inputfield:
            return (field.literal, field.required)

    return ('', False)

def generate(alertRun):
    searchTable = """ <TABLE id="alert"> 
                    <TR> 
                    <th>Alert Id</th> 
                    <th>Alert Name</th> 
                    <th>Workunit</th> 
                    <th>Start Time</th> 
                    <th>End Time</th> 
                    <th>Elapsed Time</th> 
                    </tr> """

    print('alertRun {0}'.format(alertRun))

    print(alertRun.id)
    print(alertRun.name)
    print(alertRun.startTime)
    print(alertRun.completionTime)
    print(alertRun.elapsedTime)

    searchDataRow = (' <tr> ' 
                     '<td>' + xstr(alertRun.id) + '</td>' 
                     '<td>' + xstr(alertRun.name) + '</td>' 
                     '<td>' + xstr(alertRun.workunit) + '</td>' 
                     '<td>' + xstr(alertRun.startTime) + '</td>' 
                     '<td>' + xstr(alertRun.completionTime) + '</td>' 
                     '<td>' + xstr(alertRun.elapsedTime) + '</td>' 
                     '</tr> </TABLE>')

    searchListRow = ''
    lines = ''

    if alertRun.results:
        searchListRow = """<table id='alertsuccess'>
                          <tr>
                          <th>Name</th>
                          <th>Value</th>
                          </tr>"""

    #for k, v in alertRun.results.items():
    
    res = alertRun.results

    for k in sorted(res):
        if k != 'AvgPrevFrequenciesVariance':
            lines += '<tr><td>' + k + '</td><td>' + str(res[k]) + '</td></tr>'
    
    lines += '</TABLE>'

    
    searchListRow += lines

    if searchListRow == '':
        searchListRow = """<table id='alertsuccess'>
                          <tr>
                          <th>No alerts found</th>
                          </tr></table>"""

    errorTable = ""
    
    if alertRun.workunitStatus in ['failed', 'aborted']:
        errorTableTemp =  """<table id='alerterror'>
                            <tr>
                            <th>Error:</th>
                            </tr><tr><td>""" 
        errorTable = errorTableTemp + alertRun.workUnitMsg + '</td></tr></table>' 

    searchInputTable = """<table id='alertsuccess'>
                          <th colspan='2'>Search Parameters</th>"""
                          
    for k, v in alertRun.searchInput.items():
        (inputFieldLiteral, required) = getInfo(k)
        print(inputFieldLiteral, required, k)
        if inputFieldLiteral != '':
            if required:
                searchInputTable += '<tr><td>{0}</td><td>{1}</td></tr>'.format(inputFieldLiteral, v)
            elif not required:
                if v not in ['0' or '']:
                    searchInputTable += '<tr><td>{0}</td><td>{1}</td></tr>'.format(inputFieldLiteral, v)

    #for k, v in alertRun.searchInput.items():
        #searchInputTable += '<tr><td>{0}</td><td>{1}</td></tr>'.format(k, v)
    
    searchInputTable += '</table>'
    

    return (htmlHeader + searchTable + searchDataRow + searchInputTable + searchListRow + errorTable)