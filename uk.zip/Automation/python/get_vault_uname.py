import AutomationLogging
from commonArgs import getSource
from vault.secrets import get_api_secret

''' 
Script is built to return vault creds to terminal
Don't use outside of this case as script prints creds to console
Calling script should capture output such as >$uname = python .\get_vault_uname.py
'''
logger = AutomationLogging.getLogger('get_vault_uname', True)
source = getSource()
uname = get_api_secret(logger, source, secret='uname')
print(uname)
