if python ./python/yamljsonValidator.py -a red -s sample -f daily -e prod -path ./
then
    echo "success $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
else
    echo "fail $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
    exit 1
fi

if python ./python/yamljsonValidator.py -a rbi -s sample -f daily -e prod -path ./
then
    echo "success $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
else
    echo "fail $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
    exit 1
fi

if python ./python/yamljsonValidator.py -a scout -s sample -f daily -e prod -path ./
then
    echo "success $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
else
    echo "fail $CI_COMMIT_TITLE submitted by $GITLAB_USER_NAME"
    exit 1
fi

