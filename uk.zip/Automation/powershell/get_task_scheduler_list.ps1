$date = get-date
$DateStr = $Date.ToString("yyyyMMdd")

function getTasks($path) {
    $out = @()

    # Get root tasks
    $schedule.GetFolder($path).GetTasks(0) | % {
        $xml = [xml]$_.xml
        $out += New-Object psobject -Property @{
            "run_date" = $DateStr
            "job_name" = $_.Name
            "Path" = $_.Path
            "Status" = switch($_.State) {0 {"Unknown"} 1 {"Disabled"} 2 {"Queued"} 3 {"Ready"} 4 {"Running"}}
            "NextRunDateTime" = $_.NextRunTime
            "LastRunDateTime" = $_.LastRunTime
            "LastRunResult" = $_.LastTaskResult
            "Author" = $xml.Task.Principals.Principal.UserId
            "Created" = $xml.Task.RegistrationInfo.Date
        }
    }

    # Get tasks from subfolders
    $schedule.GetFolder($path).GetFolders(0) | % {
        $out += getTasks($_.Path)
    }

    #Output
    $out
}

$tasks = @()

$schedule = New-Object -ComObject "Schedule.Service"
$schedule.Connect() 

# Start inventory
$tasks += getTasks("\FidoAutomation\red")

# Close com
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($schedule) | Out-Null
Remove-Variable schedule


if (!$Env:red_automation_applogs){
    $red_path = "D:\\red"
}
else{
    $red_path = $Env:red_automation_applogs
}

$tasks | Select-Object run_date,job_name,Path,Status,NextRunDateTime,LastRunDateTime,LastRunResult,Author,Created | export-csv -NoTypeInformation -Path $red_path\data\inbound\task_scheduler\$DateStr'_'task_list.csv