$application = "rbi"
$source = "hyperion"
$frequency = "daily"
$environment = "prod"
$essbasehostname = "alawpfido102"
$essbaseserver = $essbasehostname + ".risk.regn.net"
$get_uname_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_uname.py"
$get_pwd_filepath = $Env:FIDO_automation_scripts + "\python\get_vault_pwd.py"
$uname = python $get_uname_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
$uname_full = $essbasehostname + '\' + $uname
$pass = python $get_pwd_filepath -a $application -s $source -f $frequency -e $environment | Select -Last 1
#PSExec.exe /accepteula -s $essbasehostnamepath -u $uname_full -p $pass F:\scripts\RSG_BSV\RSG_BSV_Month_End_LOAD.bat
schtasks /run /tn "fido\RSG_BSV_MONTH_END_COPY" /s $essbaseserver /u $uname_full /p $pass